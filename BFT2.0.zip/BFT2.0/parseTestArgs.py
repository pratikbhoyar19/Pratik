###################
def parsepara(line):
    ''' Input: <class>:<test name>,para1=val1,para2=val2,...
        Create/Append global variable <class>_list with the parameters
        return: <class>
    '''
    testpara = line.split(',')

    # @ Create valid testparameter for appending
    if len(testpara) == 1:
        test = testpara[0]
        parameters = []
    else:
        test = testpara[0]
        parameters = testpara[1:]

    # @ Create and append to global list
    testclassid = test.split(':')
    if len(testclassid) == 1:
        testclass = testclassid[0]
        testid = 'Default'
    elif len(testclassid) == 2:
        testclass = testclassid[0]
        testid = testclassid[1]
    else:
        pass

    #Insert the testcase Id at the start
    parameters.insert(0, testid)

    testargslist = testclass + '_list'
    if testargslist in globals():
        eval(testargslist + '.append(' + str(parameters) + ')')
    else:
         exec('globals()[\'' + testargslist + '\'] = []')
         eval(testargslist + '.append(' + str(parameters) + ')')

    return testclass

