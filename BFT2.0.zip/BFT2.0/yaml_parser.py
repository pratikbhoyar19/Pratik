#!/usr/bin/env python

"""
Libary file having defination for parsing input yaml files.
"""
__author__ = "Manikandan"
__copyright__ = "Copyright 2019, Intel Corporation"
__version__ = "0.0.1"
__maintainer__ = "Mirafra"
__email__ = "framework@mirafra.com"
__status__ = "Development"
###########################################################
import yaml
import re
import config
import json
from collections import OrderedDict
from library import print_bold

dict_var = {}


def parse_yaml_to_json(input_yaml):

    """
    Method Name       :  parse_yaml_to_json
    Description       : Convert YAML files into JSON
    Input parameters  : YAML file
    Output            : JSON file
    """

    file_extent = input_yaml.split(".")[1]
    if file_extent != "yaml":
        print('Accept only input yaml file')
        return False

    output_file = input_yaml.split(".")[0]
    out_file = output_file + ".json"
    with open(input_yaml, 'r') as stream:
        try:
            data_map = yaml.safe_load(stream)
            with open(out_file, 'w') as output:
                json.dump(data_map, output)
        except yaml.YAMLError as exc:
            return exc

    return out_file


def ordered_load(stream, Loader=yaml.Loader, object_pairs_hook=OrderedDict):
    class OrderedLoader(Loader):
        pass

    def construct_mapping(loader, node):
        loader.flatten_mapping(node)
        return object_pairs_hook(loader.construct_pairs(node))
    OrderedLoader.add_constructor(
        yaml.resolver.BaseResolver.DEFAULT_MAPPING_TAG,
        construct_mapping)
    return yaml.load(stream, OrderedLoader)


def parse_json_to_dict(input_json):

    """
    Method Name       : parse_json_to_dict
    Description       : Convert JSON into dictionary
    Input parameters  : JSON file
    Output            : dictionary
    """

    with open(input_json) as fd:
        data = fd.read()
        dict_var = eval(json.loads(json.dumps(data, sort_keys=True)))

    return dict_var


def parse_yaml_to_dict(input_yaml):

    """
    Method Name      : parse_yaml_to_dict
    Description      : Convert YAML file into dictionary
    Input parameters : YAML file
    Output           : dictionary
    """

    with open(input_yaml) as fd:
        data = fd.read()
        dict_var = ordered_load(data, yaml.SafeLoader)

    return dict_var


def generate_board_config(test_bed, run_test):

    """
    Method Name      : generate_board_config
    Description      : Generate testbed.json file based on the YAML (testbed,run_test) files
    Input Parameters : test_bed - test_bed.yaml, run_test - run_test.yaml
    Output           : board.json
    """

    test_bed_dict = parse_yaml_to_dict(test_bed)
    run_dict = parse_yaml_to_dict(run_test)
    device_name = None
    for device, val in test_bed_dict['devices'].iteritems():
        for device_attr, val1 in test_bed_dict['devices'][device].iteritems():
            if device_attr == 'type' and val1 == 'dut':
                device_name = device
                break
        if device_name is not None:
            break
    config_name = "intel_"+''.join(run_dict['Run_time_parameters']['devices'][device]['model'])
    config.model = run_dict['Run_time_parameters']['devices'][device]['model']
    config.testbed_config_name = config_name
    device_list1 = test_bed_dict['devices']
    device_list2 = run_dict['Run_time_parameters']['devices']
    device_list3 = run_dict['Run_time_parameters']
    # print(device_list3)
    result = {}

    for key in (device_list1.viewkeys() | device_list2.keys()):
        if key in device_list1:
            result.setdefault(key, []).append(device_list1[key])
        if key in device_list2:
            result.setdefault(key, []).append(device_list2[key])
    dict_list = []
    for key, value in result.iteritems():
        result1 = {}
        for val in value:
            result1.update(val)
        temp = result1
        dict_list.append(temp)
        # print(dict_list)

    a = {}
    board_values = {}
    for key1, value1 in device_list3.iteritems():
        if isinstance(value1, dict) is False:
            board_values[key1] = value1
    board_values['devices'] = dict_list
    a[config_name] = board_values
    with open("board.json", "w+") as fd:
        # data = json.dumps(dict_list, sort_keys=True, indent=4, separators=(',', ': '))
        data = json.dumps(a, sort_keys=True, indent=4, separators=(',', ': '))
        print >> fd, data
    return True


def generate_test_var_with_kpi(test_var_json, kpi_yaml):

    """
    Method Name      : generate_test_var_with_kpi
    Description      : Generate testvar.json file based on the existing json (testvariable) file and kpi yaml file
    Input Parameters : test_var_json - test_variables.json, kpi_yaml - platform_kpi.yaml
    Output           : test_variables.json
    """

    kpi_dict = parse_yaml_to_dict(kpi_yaml)
    with open(test_var_json) as fd:
        data = fd.read()
        json_dict = eval(json.loads(json.dumps(data, sort_keys=True)))
        result = {}
        for key in (json_dict.viewkeys() | kpi_dict.keys()):
            if key in json_dict:
                result.setdefault(key, []).append(json_dict[key])
            if key in kpi_dict:
                result.setdefault(key, []).append(kpi_dict[key])

    with open("testvar.json", "w+") as fd:
        data = json.dumps(result, sort_keys=True, indent=4, separators=(',', ': '))
        print >> fd, data
    return True


def generate_test_var(test_var_json, run_test):

    """
    Method Name      : generate_test_var
    Description      : Generate testvar.json file based on the existing json (testvariable) file and kpi yaml file
    Input Parameters : test_var_json - test_variables.json, kpi_yaml - platform_kpi.yaml
    Output           : test_variables.json
    """

    run_dict = parse_yaml_to_dict(run_test)
    run_time_dict = run_dict['Run_time_parameters']['Tests_run_time_parameters']
    with open(test_var_json) as fd:
        data = fd.read()
        json_dict = eval(json.loads(json.dumps(data, sort_keys=True)))
        result = {}

        for key in (json_dict.viewkeys() | run_time_dict.keys()):
            if key in json_dict:
                result.setdefault(key, []).append(json_dict[key])
            if key in run_time_dict:
                result.setdefault(key, []).append(run_time_dict[key])

    with open("testvar.json", "w+") as fd:
        data = json.dumps(result, sort_keys=True, indent=4, separators=(',', ': '))
        print >> fd, data
    return True


def recursive_func(input_dict, match_key):
    for key, value in input_dict.iteritems():
        if match_key == key:
            dict_var[key] = value
            break
        else:
            dict_var.clear()
            if hasattr(value, 'iteritems'):
                recursive_func(value, match_key)
    return dict_var


def generate_test_suite_config(test_suite, run_test):

    """
    Generate testsuite.cfg based on the YAML (test_suite, run_test) files.

    Method Name      : generate_test_suite_config
    Description      : Generate testsuite.cfg based on the YAML (test_suite, run_test) files.
    Input Parameters : test_suite - test_suite.yaml, run_test - run_test.yaml
    Output           : testsuite.cfg, runtime_para(dictionary)
    """

    test_suite_dict = parse_yaml_to_dict(test_suite)
    run_dict = parse_yaml_to_dict(run_test)
    test_run_list = run_dict['Run_time_parameters']['Tests_to_run']
    run_time_para = run_dict['Run_time_parameters']['Tests_run_time_parameters']
    config.prepost_suite = test_suite_dict['PREPOST_SUITE']
    suite_dir = ".".join(config.prepost_suite.split(".")[0:-1])
    if suite_dir == "":
        suite_dir = config.prepost_suite
    config.prepost_suite_dir = suite_dir
    config.prepost_suite_cls = config.prepost_suite.split(".")[-1]

    '''Variables initialization'''
    t_run_list = []
    t_suites = []
    t_classes = []

    for t_suite_key, t_suite_value in test_run_list.iteritems():
        exec("cond1_dict_%s = OrderedDict()" % t_suite_key)
        exec("cond2_dict_%s = OrderedDict()" % t_suite_key)
        exec("class_id_dict_%s = OrderedDict()" % t_suite_key)

    ''' Parsing the run_test.yaml file and create the dictionary based on the test_suites '''
    para_key_lst = []
    for t_suite_key, t_suite_value in test_run_list.iteritems():
        t_run_list.append(t_suite_key)
        if hasattr(t_suite_value, 'iteritems'):
            for t_class_key, t_class_value in t_suite_value.iteritems():
                if len(t_class_value) == 0:
                    t_class_value = {'0':None}
                if hasattr(t_class_value, 'iteritems'):
                    for t_para_key, t_para_value in t_class_value.iteritems():
                        para_key_lst.append(t_para_key)
                    para_key_lst1 = ",".join([str(i) for i in para_key_lst])
                    eval("cond1_dict_%s.update({'%s':'%s'})" % (t_suite_key, t_class_key, str(para_key_lst1)))
                    para_key_lst = []
                    para_key_lst1 = ""

    ''' Parsing testsuites.yaml file and create the dictionaries based on the test ID
       & parameters for the test '''

    '''Create dynamic list for suites,modules and classes present in test_suite.yaml'''
    for suite_name in t_run_list:
        tgt_suite_dict = recursive_func(test_suite_dict, suite_name)
        for t_suite_key, t_suite_value_lst in tgt_suite_dict.iteritems():
            t_suites.append(t_suite_key)
            for t_suite_value in t_suite_value_lst:
                if hasattr(t_suite_value, 'iteritems'):
                    for t_suite_elem_key, t_suite_elem_value in t_suite_value.iteritems():
                        if t_suite_elem_key == "TEST_CLASS":
                            t_class = t_suite_elem_value.split('.')[-1]
                            t_classes.append(t_class)
                            case_dict_name = str(t_suite_key) + "_" + str(t_class)
                            exec("num_cases_dict_%s = OrderedDict()" % case_dict_name)

    for t_suite_key, t_suite_value_lst in test_suite_dict.iteritems():
        if t_suite_key in t_suites:
            for t_suite_value in t_suite_value_lst:
                if hasattr(t_suite_value, 'iteritems'):
                    for t_suite_elem_key, t_suite_elem_value in t_suite_value.iteritems():
                        # loads the test directory mentioned in the testsuite.yaml
                        # Uses in bft for dynamic folder loading
                        k = 0
                        if t_suite_elem_key == "TEST_CLASS":
                            if k == 0:  # to loop it for once
                                # config.prepost_file = config.prepost_file + t_class_value['PREPOST']
                                t_class_key = t_suite_elem_value.split(".")[-1]
                                test_dir_cls = ".".join(t_suite_elem_value.split(".")[0:-1])
                                if test_dir_cls == "":
                                    test_dir_cls = t_suite_elem_value
                        if t_suite_elem_key == "PREPOST_CLASS":
                            class_pre_post_file = t_suite_elem_value
                            config.prepost_file[t_class_key] = class_pre_post_file
                            config.test_cls_dir_map[t_class_key] = test_dir_cls
                            k = k + 1
                            t_obj_list = []
                        if hasattr(t_suite_elem_value, 'iteritems'):
                            for t_obj_key, t_obj_value in t_suite_elem_value.iteritems():
                                if t_suite_elem_key == "TEST_LIST":
                                    # Creating Dict based on test Id as key and test parameters as value
                                    if t_obj_value is None:
                                        print('Please pass the Parameters')
                                    else:
                                        dup = t_obj_value.split(",")
                                        for i, ele in enumerate(dup):
                                            if "caselist" not in ele:
                                                ele = "sc_" + ele
                                                dup[i] = ele
                                        tidval = str(','.join(dup))
                                        t_obj_value1 = tidval.replace("=", "='").replace(',', "',")
                                        t_obj_value2 = re.sub("$", "'", t_obj_value1)
                                        eval('cond2_dict_%s.update({"%s":"%s"})' % (t_suite_key, t_obj_key,
                                                                                    str(t_obj_value2)))
                                        t_obj_list.append(t_obj_key)

                                t_suite_elem_key_cond = ''.join([i for i in t_suite_elem_key if not i.isdigit()])
                                if t_suite_elem_key_cond == "caselist":
                                    cond3_dict = OrderedDict()
                                    cond3_dict.update({t_suite_elem_key: t_obj_value})
                                    cond3_dict_values = cond3_dict.values()
                                    for i in cond3_dict_values:
                                        if i is None:
                                            print('Please pass the parameters')
                                        else:
                                            cond3_dict_values1 = i.replace("=", "='").replace(',', "',")
                                            cond3_dict_values2 = re.sub("$", "'", cond3_dict_values1)
                                    t_para_list = t_obj_key+","+cond3_dict_values2
                                    case_dict_name = str(t_suite_key)+ "_" + str(t_class_key)
                                    eval('num_cases_dict_%s.setdefault("%s",[]).append("%s")' % (case_dict_name,
                                                                                                 t_suite_elem_key,
                                                                                                 t_para_list))
                                eval('class_id_dict_%s.update({"%s":"%s"})' % (t_suite_key, t_class_key, t_obj_list))

    for t_suite in t_suites:
        exec("common_keys_%s = []" % t_suite)
        dict1 = eval("cond1_dict_%s" % t_suite)
        dict2 = eval("cond2_dict_%s" % t_suite)
        for d1_key, d1_value in dict1.iteritems():
            for d2_key, d2_value in dict2.iteritems():
                if d2_key == d1_key:
                    exec("common_keys_%s.append('%s')" % (t_suite, d2_key))

        common_keys = eval("common_keys_"+t_suite)
        for d1_key, d1_value in dict1.iteritems():
            if d1_key not in common_keys:
                print_bold("INPUT ERROR: Invalid test object '%s' has configured for testsuite '%s' in '%s'" \
                       % (d1_key, t_suite, run_test))
                return False

    with open("testsuites.cfg", "w+") as sf:
        for t_suite in t_suites:
            sf.writelines("["+t_suite+"]\n")
            common_keys = eval("common_keys_"+t_suite)
            class_id_dict_info = eval("class_id_dict_"+t_suite)
            # print(common_keys)
            for key in common_keys:
                t_obj = key   # ax_mode_2.4G
                for d_key, d_value in class_id_dict_info.iteritems():
                    if key in d_value:
                        t_class = d_key
                        break
                num_cases = eval("cond1_dict_"+t_suite+"['"+key+"']")
                t_obj_para = eval("cond2_dict_"+t_suite+"['"+key+"']")
                # print(t_obj_para)
                t_obj_case = key  # ax_mode_2.4G
                t_obj_list = re.search(r'(.)*caselist=(.*)(.)*',t_obj_para)
                t_obj_list_name = (t_obj_list.group(0)).split(",")[0]
                t_obj_name = t_obj_list_name.split("=")[1]
                t_obj_list_values = eval('num_cases_dict_'+t_suite+"_"+t_class+'['+t_obj_name+']') # Parameter list
                # print("key, value ------> %s, %s" % (t_obj_name, t_obj_list_values))
                if t_obj == t_obj_case:
                    # Complete caselist execution
                    if num_cases == "FULL":
                        for value in t_obj_list_values:
                            pattern = '.*?caselist='+t_obj_name+'.*?'
                            pattern_obj = re.compile(pattern, re.MULTILINE)
                            result = pattern_obj.sub(value, t_obj_para)
                            t_cls_obj_name = t_class
                            sf.writelines(t_cls_obj_name+":"+t_obj+"_"+result+"\n")
                    else:
                        pattern = '.*?caselist='+t_obj_name+'.*?'
                        pattern_obj = re.compile(pattern, re.MULTILINE)
                        t_cls_obj_name = t_class
                        case_lst = str(num_cases).split(",")
                        # Only particular case along with step from the given caselist
                        if len(case_lst) == 1:
                            case_lst = "".join([i for i in case_lst])
                            if "." in case_lst:
                                case_id = str(case_lst).split(".")[0]
                                step_id = str(case_lst).split(".")[1]
                            else:
                                case_id = case_lst
                                step_id = ""
                            try:
                                value = t_obj_list_values[int(case_id) - 1]
                            except Exception:
                                print_bold("INPUT ERROR: Invalid case No.%s has configured for test object '%s' of the"
                                           " testsuite '%s' in '%s'" % (case_id, t_obj_case, t_suite, run_test))
                                return False

                            result = pattern_obj.sub(value, t_obj_para)
                            lst = result.split(",")
                            try:
                                if step_id:
                                    lst[0] = lst[0]+"_step("+step_id+")"
                            except Exception:
                                pass
                            result = ','.join(lst)
                            sf.writelines(t_cls_obj_name + ":" + t_obj + "_" + result + "\n")
                        # Multiple cases with steps from the given caselist
                        elif len(case_lst) > 1:
                            step_lst = []
                            next_iteration = True
                            step_iteration = True
                            count = 0
                            for i in range(0, len(case_lst)):
                                # Skip case execution when case id as same but step id are different in case sequence
                                if next_iteration:
                                    if "." in str(case_lst[i]):
                                        case_id = case_lst[i].split(".")[0]
                                        step_id = case_lst[i].split(".")[1]
                                    else:
                                        case_id = case_lst[i]
                                        step_id = None
                                    try:
                                        value = t_obj_list_values[int(case_id) - 1]
                                    except Exception:
                                        print_bold("INPUT ERROR: Invalid case No.%s has configured for test object '%s'"
                                                   " of the testsuite '%s' in '%s'" % (case_id, t_obj_case,
                                                                                       t_suite, run_test))
                                        return False
                                    result = pattern_obj.sub(value, t_obj_para)
                                    lst = result.split(",")
                                    # Add step id to case when step is configured
                                    if step_id is not None:
                                        step_lst.append(step_id)
                                    '''
                                    Check the next element for case id is same and step ids are different in the given
                                    sequence. if yes then append step ids to the particular case and skip duplicate case
                                    execution with those steps.
                                    '''
                                    if i != len(case_lst)-1:
                                        for j in range(i+1, len(case_lst)):
                                            if step_iteration:
                                                if "." in str(case_lst[j]):
                                                    next_case_id = case_lst[j].split(".")[0]
                                                    next_step_id = case_lst[j].split(".")[1]
                                                else:
                                                    next_case_id = case_lst[j]
                                                    next_step_id = None
                                                if case_id == next_case_id:
                                                    if next_step_id is not None and step_id is not None:
                                                        step_lst.append(next_step_id)
                                                        count = count + 1
                                                    else:
                                                        break
                                                else:
                                                    break
                                    '''
                                        Check if any steps are present then write file along with the steps otherwise
                                        only cases.
                                    '''
                                    if len(step_lst) >= 1:
                                        step_lst = ";".join([str(i) for i in step_lst])

                                        '''
                                        When case is associated with single steps execution then add steps the like
                                        step(1)
                                        When case is associated with multiple steps execution then add steps like
                                        step(1;2;5;6;7)
                                        '''
                                        if len(step_lst) == 1:
                                            if step_id is not None:
                                                lst[0] = lst[0] + "_step(" + step_lst + ")"
                                                result = ','.join(lst)
                                                sf.writelines(t_cls_obj_name + ":" + t_obj + "_" + result + "\n")
                                        else:
                                            if step_id is not None or next_step_id is not None:
                                                lst[0] = lst[0] + "_step("+step_lst+")"
                                                result = ','.join(lst)
                                                sf.writelines(t_cls_obj_name + ":" + t_obj + "_" + result + "\n")
                                                next_iteration = False
                                                step_iteration = False
                                            else:
                                                result = ','.join(lst)
                                                sf.writelines(t_cls_obj_name + ":" + t_obj + "_" + result + "\n")
                                        step_lst = []
                                    else:
                                        result = ','.join(lst)
                                        sf.writelines(t_cls_obj_name + ":" + t_obj + "_" + result + "\n")

                                else:
                                    count = count - 1
                                    if count == 0:
                                        next_iteration = True
                                        step_iteration = True

                sf.writelines("endofgroup\n")
    return run_time_para


def kpi_yaml_to_dict(platform_kpi):

    """
    Covert KPI YAML file into dictionary.
    Method Name      :  kpi_yaml_to_dict
    Description      :  Convert KPI YAML file into dictionary
    Input Parameters :  KPI YAML - platform_kpi.yaml
    Output           :  kpi_para
    """

    kpi_para = parse_yaml_to_dict(platform_kpi)

    return kpi_para


if __name__ == '__main__':
    # Function Execution Example:

    generate_board_config("test_config/wlan/testbed.yaml", "test_config/wlan/run_test.yaml")

    generate_test_var_with_kpi("testvariables.json", "test_config/wlan/platform_kpi.yaml")

    run_time_dict = generate_test_suite_config("test_config/wlan/testsuite.yaml", "test_config/wlan/run_test.yaml")
    print(run_time_dict)
    print("Prepost config suite dir: %s" % config.prepost_suite_dir)
    print("Prepost config suite class: %s" % config.prepost_suite_cls)
    print("Prepost config class dir : %s" % config.prepost_file)
    print("Test class dir map : %s" % config.test_cls_dir_map)

    generate_test_var("testvariables.json", "test_config/wlan/run_test.yaml")

    kpi_dict = kpi_yaml_to_dict("test_config/wlan/platform_kpi.yaml")
    print(kpi_dict)
