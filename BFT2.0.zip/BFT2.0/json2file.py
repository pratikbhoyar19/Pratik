#!/usr/bin/env python

# Copyright (c) 2015
#
# All rights reserved.
#
# This file is distributed under the Clear BSD license.
# The full text can be found in LICENSE in the root directory.

import json


class TestCaseConfig:
    
    testcase_config_location = "testvariables.json"
    board_feature = []

    def __init__(self):
        'Function Inititalize TestCaseConfig class read jason file'
        with open(self.testcase_config_location) as f:
            data = f.read()
            self.bf = eval(json.loads(json.dumps(data,sort_keys=True)))
            print(type(self.bf))

    def GetParams( self, test_grp , config_param ):
        'it will config test case as per requirement'
        return self.bf[test_grp].get(config_param, '')

    def get_model_specification(self, board_type, model_name):
        'it will return specification of model'
        self.board_feature = self.bf["Board"][board_type].get(model_name, [])
        return self.board_feature

    def testcase_skip_or_run(self,testcase_name):
        'It will check whether module is supported by board or not and return modules'
        modules = self.bf['Modules']
        test_case_module = filter(lambda key: testcase_name in modules[key], modules.keys())
        return filter(lambda x: x in self.board_feature, test_case_module)
     


    


