from datetime import datetime
from log_creator import loggerObject as logger

json_class_obj = None
gvariable_example = None

ping_ip=[]
dev_ip_obj=[]

def get_lan_host_data(lan):
    global lan_host_eth_ip
    lan_host_eth_ip = lan.os.get_interface_ipaddr(tsv_lan_host_eth_interface)


def get_lan1_host_data(lan1):
    global lan1_host_eth_ip
    lan1_host_eth_ip = lan1.os.get_interface_ipaddr(tsv_lan1_host_eth_interface)


def get_lan2_host_data(lan2):
    global lan2_host_eth_ip
    lan2_host_eth_ip = lan2.os.get_interface_ipaddr(tsv_lan2_host_eth_interface)


def get_lan2gH1_host_data(lan2gH1):
    global lan2gH1_host_eth_ip
    lan2gH1_host_eth_ip = lan2gH1.os.get_interface_ipaddr(tsv_lan2gH1_host_eth_interface)


def get_lan5gH1_host_data(lan5gH1):
    global lan5gH1_host_eth_ip
    lan5gH1_host_eth_ip = lan5gH1.os.get_interface_ipaddr(tsv_lan5gH1_host_eth_interface)


def get_lan5gH2_host_data(lan5gH2):
    global lan5gH2_host_eth_ip
    lan5gH2_host_eth_ip = lan5gH2.os.get_interface_ipaddr(tsv_lan5gH2_host_eth_interface)


def get_wan_host_data(wan):
    global wan_host_eth_ip,wan_host_eth_ipv6
    wan_host_eth_ip = wan.os.get_interface_ipaddr(tsv_wan_host_eth_interface)
    wan_host_eth_ipv6 = wan.os.get_interface_ipaddr(tsv_wan_host_eth_interface, ipv6_enable=True,netmask=tsv_ipv6_route_netmask)

def get_dut_data(console):
    global dut_lan_ip,dut_wan_ip
    dut_lan_ip = console.os.get_interface_ipaddr(dut_lan_eth_interface)
    dut_wan_ip = console.os.get_interface_ipaddr(dut_wan_interface)

def recurse_through_dict(bf_dict):
    for key,value in bf_dict.iteritems():
        if hasattr(value,'iteritems'):
            recurse_through_dict(value)
        else:
            #key = str(key)
            exec ('global ' + str(key) +';' +key + '=value')
            #print key + "--------------->" + str(eval(key))
            #print type(key)
            #print type(value)


def initialize_device_json_obj(json_obj):
    global json_class_obj
    json_class_obj = json_obj
    recurse_through_dict(json_class_obj.bf)


def getBoardUsernamePassword(board_type, console):
    if board_type == "GRX550":
        console.board_username = 'admin'
        console.board_password = 'admin'
    elif board_type == "GRX350":
        console.board_username = 'admin'
        console.board_password = 'admin'
    elif board_type == "XRX500":
        console.board_username = 'admin'
        console.board_password = 'admin'
    elif board_type == "VRX288":
        console.board_username = vrx288_username
        console.board_password = vrx288_password


def checkTestBenchSetup():
    global setup_testbench
    if setup_testbench == "preconfigured":
        pass
    elif setup_testbench == "userdefined":
        pass
    else:
        setup_testbench = "preconfigured"


def measure_exe_time(my_fun):
    def fun_dect(*argv):
        start_time = datetime.now()
        value = my_fun(*argv)
        end_time = datetime.now()
        diff_time = end_time - start_time
        logger.dump_execution_time ('#============================================================#')
        logger.dump_execution_time ('Time taken for [%s] is  %s' %( my_fun.__name__, diff_time))
        logger.dump_execution_time ('#============================================================#')
        logger.dumpLog("%s" %(my_fun.__name__))
        return value
    return fun_dect
