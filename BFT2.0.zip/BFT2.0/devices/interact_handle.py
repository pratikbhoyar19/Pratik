''' Class for create the traffic object'''
__author__ = 'Intel Corporation'
__copyright__ = 'Copyright 2019, Intel Corporation'
__version__ = '0.0.1'
__maintainer__ = 'Mirafra'
__email__ = 'framework@mirafra.com'
__status__ = 'Development'

from devices.interact_tools.interact_paramiko import *
from devices.interact_tools.interact_pexpect import *
from devices.interact_tools.interact_pyserial import *


class InteractLayer:
    '''
    A class used to create the traffic object

    ...

    Attributes
    ----------
    version : Interact tool version

    Methods
    -------
    '''

    def __init__(self,
                 platform_type=None,
                 color=None,
                 name=None,
                 interact_tool="pexpect"):

        self.platform_type = platform_type
        self.color = color
        self.name = name
        self.interact_tool = interact_tool

        # Define the classes

        '''Define interact class name based on interact_tool'''
        self.interact_class = "Interact"+self.interact_tool.capitalize()

    def handle_creation(self):
        ''' Interact specific class objects '''
        if self.color is None:
            return eval("%s(platform_type='%s', color=None, name='%s')" % (self.interact_class, self.platform_type, self.name))
        else:
            return eval("%s(platform_type='%s', color='%s', name='%s')" % (self.interact_class, self.platform_type, self.color, self.name))
