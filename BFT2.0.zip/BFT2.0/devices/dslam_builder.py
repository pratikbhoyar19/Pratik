''' Class defination for device builder'''
__author__ = 'IntelCorporation'
__copyright__ = 'Copyright 2019, Intel Corporation'
__version__ = '0.0.1'
__maintainer__ = 'Mirafra'
__email__ = 'framework@mirafra.com'
__status__ = 'Development'

from devices.transport_types import *
from lib.common.traffic_tools import *
from devices.platform_types import *
from log_creator import loggerObject as logger

class DslamBuilder:

    def __init__(self, platform_handle, transport_handle, session_handle, tools_handle,
                 device_dict=None, dname=None, logger=logger):
        '''Initialize the handles'''
        self.os = platform_handle
        self.transport = transport_handle
        self.session = session_handle
        self.tools = tools_handle
        self.device_dict = device_dict
        self.dname = dname
        self.logger = logger
        self.prompt = ['root\\@.*:.*#', '/ # ', ".*:~ #",'.*:~ >', '.*\\@.*:.*>', '.*:~ >', '.*:~.*\\$', '.*\\@.*:.*\\$']

    def create(self):
        self.session.config_update(os_handle=self.os, device_dict=self.device_dict)
        self.transport.config_update(self.session, self.prompt, device_dict=self.device_dict)
        self.os.config_update(transport=self.transport, session=self.session, tools=self.tools,
                              device_dict=self.device_dict, dname=self.dname)
        self.tools.config_update(self.os, self.session, self.prompt, device_dict=self.device_dict,
                                 dname=self.dname, logger=self.logger)
        self.session.set_prompt(prompt=self.prompt)

        #Set the logger to different handle
        self.transport.logger = self.logger
        self.os.logger  = self.logger
        self.session.logger = self.logger

        return True


