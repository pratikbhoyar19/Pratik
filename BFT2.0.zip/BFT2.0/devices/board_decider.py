# Copyright (c) 2015
#
# All rights reserved.
#
# This file is distributed under the Clear BSD license.
# The full text can be found in LICENSE in the root directory.

import openwrt_router
import qcom_akronite_nand
import qcom_akronite_nor
import qcom_dakota_nor
import qcom_dakota_nand
import qcom_mips
import marvell
import rpi
import intel_nand


def board(model, **kwargs):
    '''
    Depending on the given model, return an object of the appropriate class type.

    Different boards are flashed with different commands, have
    different memory addresses, and must be handled differently.
    '''
    global dut_handle

    if model in ("db120", "ap135", "ap143", "ap147", "ap152", "ap151",
                 "ap151-16M", "ap143", "ap152-8M", "tew-823dru"):
        dut_handle = qcom_mips.QcomMipsRouter(model, **kwargs)
        return dut_handle

    if model in ("ipq8066", "db149", "ap145", "ap148", "ap148-osprey",
                 "ap148-beeliner", "ap160-1", "ap160-2", "ap161"):
        dut_handle = qcom_akronite_nand.QcomAkroniteRouterNAND(model, **kwargs)
        return dut_handle

    if model in ("ap148-nor"):
        dut_handle = qcom_akronite_nor.QcomAkroniteRouterNOR(model, **kwargs)
        return dut_handle

    if model in ("dk01-nor", "dk04-nor"):
        dut_handle =  qcom_dakota_nor.QcomDakotaRouterNOR(model, **kwargs)
        return dut_handle

    if model in ("dk07-nand", "dk04-nand", "ea8300"):
        dut_handle = qcom_dakota_nand.QcomDakotaRouterNAND(model, **kwargs)
        return dut_handle

    if model in ("wrt3200acm"):
        dut_handle = marvell.WRT3200ACM(model, **kwargs)
        return dut_handle

    if model in ("rpi3"):
        dut_handle =  rpi.RPI(model, **kwargs)
        return dut_handle

    if model in ("VRX288", "XRX500"):
        dut_handle = intel_nand.IntelLtqRouterNAND(model, **kwargs)
        return dut_handle

    # Default for all other models
    print("\nWARNING: Unknown board model '%s'." % model)
    print("Please check spelling, or write an appropriate class "
          "to handle that kind of board.")
    dut_handle = openwrt_router.OpenWrtRouter(model, **kwargs)
    return dut_handle
