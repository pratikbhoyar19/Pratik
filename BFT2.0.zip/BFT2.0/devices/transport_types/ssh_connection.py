''' Class defination for Ssh connection.'''
__author__ = "Intel Corporation"
__copyright__ = "Copyright 2019, Intel Corporation"
__version__ = "0.0.1"
__maintainer__ = "Mirafra"
__email__ = "framework@mirafra.com"
__status__ = "Development"
###########################################################
import sys

from devices.transport_types.transport import *

class TransportSsh(TransportTool):
    '''
    A class used to represent a Telnet transport.

    ...

    Attributes
    ----------
    intract_tool(obj): Interaction object for communicating to device

    Methods
    -------

    '''

    def __init__(self,
                 username,
                 password,
                 ipaddr,
                 port=22,
                 conn_cmd=None,
                 platform_type=None):

        '''Initialize the Ssh class'''

        self.username = username
        self.password = password
        self.ipaddr = ipaddr
        self.port = port
        self.conn_cmd = conn_cmd
        self.platform_type = platform_type

    def config_update(self, interact_handle, prompt, device_dict=None):
        '''Get the interact tool handle'''
        self.session = interact_handle
        self.prompt = prompt
        self.dict = device_dict

    def connect(self, timeout=5):
        '''Create the ssh session'''
        try:
            self.session.create_session(transport="ssh", username=self.username,
                                        password=self.password,
                                        ipaddr=self.ipaddr,
                                        port=self.port,
                                        timeout=timeout,
                                        conn_cmd=self.conn_cmd)
	except Exception as e:
            print e
            sys.exit(1)

    def close(self):
        '''Close the ssh session'''
        self.session.send_line('exit')
        self.session.close_session()

    def test_func(self):
        print("method inside in this class %s" % self.__class__.__name__)


if __name__ == "__main__":
    obj = TransportSsh('intel', 'intel@123', '127.0.0.1')
    obj.test_func()

