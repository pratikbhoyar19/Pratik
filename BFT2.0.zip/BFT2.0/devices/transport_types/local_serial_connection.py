''' Class defination for local serial.'''
__author__ = "Intel Corporation"
__copyright__ = "Copyright 2019, Intel Corporation"
__version__ = "0.0.1"
__maintainer__ = "Mirafra"
__email__ = "framework@mirafra.com"
__status__ = "Development"
###########################################################
import sys

from devices.transport_types.transport import *


class TransportLocalserial(TransportTool):

    '''
    To use, set conn_cmd in your json to "cu -s <port_speed> -l <path_to_serialport>"
    and set connection_type to "local_serial"

    ...

    Attributes
    ----------
    intract_tool(obj): Interaction object for communicating to port

    Methods
    -------

    '''

    def __init__(self,
		conn_cmd = None,
		port = None,
		username = None,
		password = None,
		platform_type = None):

        '''Initialize the Serial class'''
        self.conn_cmd = conn_cmd
        self.port = port
        self.username = username
        self.password = password
        self.platform_type = platform_type

    def config_update(self, interact_handle, prompt, device_dict=None):
        '''Get the interact tool handle'''
        self.session = interact_handle
        self.prompt = prompt
        self.dict = device_dict

    def connect(self):
        try:
            self.session.create_session(transport="serial",
                                        conn_cmd=self.conn_cmd,
                                        port=self.port,
                                        username=self.username,
                                        password=self.password)
            ## Below is used by pexpect
            #self.session.create_session(transport="serial", conn_cmd=self.conn_cmd)
        except Exception as e:
            print e
            sys.exit(1)


    def close(self):
        if 'screen' in self.conn_cmd:
            self.session.send_line("\x01")
            self.session.send_line("K")
            self.session.recv_line(".*y/n.*")
            self.session.send_line('y')
        elif 'cu' in self.conn_cmd:
            self.session.send_line("~.")
        else:
            pass

        self.session.close_session()

    def test_func(self):
        print("method inside in this class %s" % self.__class__.__name__)


if __name__ == "__main__":
    obj = TransportLocalserial()
    obj.test_func()
