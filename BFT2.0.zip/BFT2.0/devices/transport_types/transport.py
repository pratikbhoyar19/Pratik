''' Class defination for transport tool.'''
__author__ = "Intel Corporation"
__copyright__ = "Copyright 2019, Intel Corporation"
__version__ = "0.0.1"
__maintainer__ = "Mirafra"
__email__ = "framework@mirafra.com"
__status__ = "Development"
###########################################################
from  devices.interact_tools.interact import *


class TransportTool():
    '''
    A class used to represent Transport mechanism.

    ...

    Attributes
    ----------


    Methods
    -------
    '''

    def connect(self):
        '''Create the session based on the transport type (eg, ssh, telnet ..etc)'''
        pass

    def close(self):
        '''Close the session'''
        pass

    def test_func(self):
        print("method inside in this class %s" % self.__class__.__name__)


if __name__ == "__main__":
    obj = TransportTool()
    obj.test_func()

