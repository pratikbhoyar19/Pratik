''' Class for create the OS object'''
__author__ = 'Intel Corporation'
__copyright__ = 'Copyright 2019, Intel Corporation'
__version__ = '0.0.1'
__maintainer__ = 'Mirafra'
__email__ = 'framework@mirafra.com'
__status__ = 'Development'

from lib.common.sw_dist_builder import swdist_cmd


class SwDistLayer:
    '''
    A class used to create the OS object

    ...

    Attributes
    ----------
    version : OS version

    Methods
    -------
    '''

    def __init__(self,
                 sw_dist=None,
                 model=None):

        self.sw_dist = sw_dist
        self.model = model

    def handle_creation(self):
        # Initialize the object based on the defined classes
        self.swdist_handle = swdist_cmd(sw_dist_name=self.sw_dist, model_specific_name=self.model)
        return self.swdist_handle

if __name__ == "__main__":
    obj = SwDistLayer(sw_dist="ugw", model="GRX550")
    obj.handle_creation()
