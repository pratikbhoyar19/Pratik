''' Class for create the wlan tools object'''
__author__ = 'Intel Corporation'
__copyright__ = 'Copyright 2019, Intel Corporation'
__version__ = '0.0.1'
__maintainer__ = 'Mirafra'
__email__ = 'framework@mirafra.com'
__status__ = 'Development'

from lib.common.tool_handler import ToolSelect
from lib.common.config_tool.model_specific_builder import model_cmd
from lib.common.config_tool.clish_cmd_builder import clish_cmd
from lib.common.config_tool.fapi_cmd_builder import fapi_cmd
from lib.common.config_tool.uci_cmd_builder import uci_cmd
from log_creator import loggerObject as logger


class ConfigToolLayer:

    def __init__(self,
                 primary_tool=None,
                 secondary_tool=None,
                 model=None,
                 dname=None):

        self.primary_tool = str(primary_tool).capitalize()
        self.secondary_tool = str(secondary_tool).capitalize()
        self.model = str(model).capitalize()
        self.dname = dname

    def handle_creation(self, os_handle, session_handle, prompt, device_dict=None, logger=logger):

        # Initialize the object based on the defined classes

        self.m_prim_handle = model_cmd(tool_name=self.primary_tool, model_name=self.model, os_handle=os_handle,
                                       session_handle=session_handle, prompt=prompt, device_dict=device_dict,
                                       dname=self.dname, logger=logger)
        self.m_sec_handle = model_cmd(tool_name=self.secondary_tool, model_name=self.model, os_handle=os_handle,
                                      session_handle=session_handle, prompt=prompt, device_dict=device_dict,
                                      dname=self.dname, logger=logger)

        if self.primary_tool == "Uci":
            self.prim_handle = uci_cmd(os_handle=os_handle, session_handle=session_handle, prompt=prompt,
                                       device_dict=device_dict, dname=self.dname, logger=logger)
        elif self.primary_tool == "Clish":
            self.prim_handle = clish_cmd(os_handle=os_handle, session_handle=session_handle, prompt=prompt,
                                         device_dict=device_dict, dname=self.dname, logger=logger)
        elif self.primary_tool == "Fapi":
            self.prim_handle = fapi_cmd(os_handle=os_handle, session_handle=session_handle, prompt=prompt,
                                        device_dict=device_dict, dname=self.dname, logger=logger)

        if self.secondary_tool == "Uci":
            self.sec_handle = uci_cmd(os_handle=os_handle, session_handle=session_handle, prompt=prompt,
                                      device_dict=device_dict, dname=self.dname, logger=logger)
        elif self.secondary_tool == "Clish":
            self.sec_handle = clish_cmd(os_handle=os_handle, session_handle=session_handle, prompt=prompt,
                                        device_dict=device_dict, dname=self.dname, logger=logger)
        elif self.secondary_tool == "Fapi":
            self.sec_handle = fapi_cmd(os_handle=os_handle, session_handle=session_handle, prompt=prompt,
                                       device_dict=device_dict, dname=self.dname, logger=logger)

        return ToolSelect(self.m_prim_handle, self.m_sec_handle, self.prim_handle, self.sec_handle)


#Test Code
if __name__ == '__main__':
    obj = ConfigToolLayer(primary_tool="uci", secondary_tool="clish", model="GRX350")
    tool_obj = obj.handle_creation()
    tool_obj.test_grx350_uci()
    obj = ConfigToolLayer(primary_tool="uci", secondary_tool="clish", model="GRX550")
    tool_obj = obj.handle_creation()
    tool_obj.test_grx550_uci()
    obj = ConfigToolLayer(primary_tool="uci", secondary_tool="clish", model="VRX288")
    tool_obj = obj.handle_creation()
    tool_obj.test_vrx288_uci()
    obj = ConfigToolLayer(primary_tool="uci", secondary_tool="clish", model="GRX350")
    tool_obj = obj.handle_creation()
    tool_obj.test_grx350_clish()
    obj = ConfigToolLayer(primary_tool="uci", secondary_tool="clish", model="GRX550")
    tool_obj = obj.handle_creation()
    tool_obj.test_grx550_clish()
    obj = ConfigToolLayer(primary_tool="uci", secondary_tool="clish", model="VRX288")
    tool_obj = obj.handle_creation()
    tool_obj.test_vrx288_clish()
    obj = ConfigToolLayer(primary_tool="uci", secondary_tool="fapi", model="GRX350")
    tool_obj = obj.handle_creation()
    tool_obj.test_grx350_fapi()
    obj = ConfigToolLayer(primary_tool="uci", secondary_tool="fapi", model="GRX550")
    tool_obj = obj.handle_creation()
    tool_obj.test_grx550_fapi()
    obj = ConfigToolLayer(primary_tool="uci", secondary_tool="fapi", model="VRX288")
    tool_obj = obj.handle_creation()
    tool_obj.test_vrx288_fapi()
