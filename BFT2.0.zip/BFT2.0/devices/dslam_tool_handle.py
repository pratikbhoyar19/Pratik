''' Class for create the wlan tools object'''
__author__ = 'Intel Corporation'
__copyright__ = 'Copyright 2019, Intel Corporation'
__version__ = '0.0.1'
__maintainer__ = 'Mirafra'
__email__ = 'framework@mirafra.com'
__status__ = 'Development'


from lib.common.dslam_tool_builder import dslam_cmd


class DslamToolLayer:

    def __init__(self,
                 tool_name=None,
                 model_name=None):
        self.tool_name = str(tool_name).capitalize()

    def handle_creation(self):

        # Initialize the object based on the defined classes
        self.dslam_handle = dslam_cmd(tool_name=self.tool_name)
        return self.dslam_handle

#Test Code
if __name__ == '__main__':
    obj = DslamToolLayer(tool_name="nokia")
    handle = obj.handle_creation()
    handle.test_nokia()
    obj = DslamToolLayer(tool_name="rev3")
    handle = obj.handle_creation()
    handle.test_rev3()
