''' Class for create the OS object'''
__author__ = 'Sunil'
__copyright__ = 'Copyright 2019, Intel Corporation'
__version__ = '0.0.1'
__maintainer__ = 'Mirafra'
__email__ = 'framework@mirafra.com'
__status__ = 'Development'

from devices.platform_types.andriod import *
from devices.platform_types.windows import *
from devices.platform_types.linux import *


class OsLayer:
    '''
    A class used to create the OS object

    ...

    Attributes
    ----------
    version : OS version

    Methods
    -------
    '''

    def __init__(self,
                 name,
                 color,
                 output=sys.stdout,
                 reboot=False,
                 location=None,
                 pre_cmd_host=None,
                 cmd=None,
                 post_cmd_host=None,
                 post_cmd=None,
                 cleanup_cmd=None,
                 platform_type=None):

        self.name  = name
        self.color = color
        self.output = output
        self.reboot = reboot
        self.location = location
        self.pre_cmd_host= pre_cmd_host
        self.cmd = cmd
        self.post_cmd_host = post_cmd_host
        self.post_cmd = post_cmd
        self.cleanup_cmd = cleanup_cmd
        self.platform_type = platform_type

        # Define the classes

        '''Define platform class name based on platform type'''
        self.platform_class = "Platform"+self.platform_type.capitalize()

        ''' Platform(OS) specific class objects '''

    def handle_creation(self):

        if self.color is None:
            return eval("%s('%s', None, reboot='%s', location='%s', pre_cmd_host='%s', cmd='%s', post_cmd_host='%s', "
                        "post_cmd='%s', cleanup_cmd='%s')" % (self.platform_class, self.name,
                                                          self.reboot, self.location, str(self.pre_cmd_host),
                                                          str(self.cmd), str(self.post_cmd_host),
                                                          str(self.post_cmd), str(self.cleanup_cmd)))
        else:
            return eval("%s('%s', '%s', reboot='%s', location='%s', pre_cmd_host='%s', cmd='%s', post_cmd_host='%s', "
                        "post_cmd='%s', cleanup_cmd='%s')" % (self.platform_class, self.name, self.color,
                                                          self.reboot, self.location, str(self.pre_cmd_host),
                                                          str(self.cmd), str(self.post_cmd_host),
                                                          str(self.post_cmd), str(self.cleanup_cmd)))
