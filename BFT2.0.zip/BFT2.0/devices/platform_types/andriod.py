''' Class defination for android OS'''
__author__ = 'Intel Corporation'
__copyright__ = 'Copyright 2019, Intel Corporation'
__version__ = '0.0.1'
__maintainer__ = 'Mirafra'
__email__ = 'framework@mirafra.com'
__status__ = 'Development'

import sys
import time
import atexit
from termcolor import colored, cprint
from datetime import datetime
import re
from globalVariables import *
from lib.common import *
from devices.platform_types.netdevices import *


class PlatformAndriod(PlatformTool):
    '''
    A class used to represent a Windows device

    ...

    Attributes
    ----------
    version : OS version

    Methods
    -------
    get_ip_addr()
        Get the ip address of the device.
    start_ping(ip_addr)
        Ping to the specified ip_addr and checks it's success.
    '''

    prompt = []

    def __init__(self,
                 name,
                 color,
                 output=sys.stdout,
                 reboot=False,
                 location=None,
                 pre_cmd_host=None,
                 cmd=None,
                 post_cmd_host=None,
                 post_cmd=None,
                 cleanup_cmd=None):

        '''Device initialization'''

        self.name = name
        self.color = color
        self.output = output
        self.reboot = reboot
        self.location = location
        self.pre_cmd_host= pre_cmd_host
        self.cmd = cmd
        self.post_cmd_host = post_cmd_host
        self.post_cmd = post_cmd
        self.cleanup_cmd = cleanup_cmd


    def config_update(self, traffic=None, transport=None, session=None, tools=None,
                      device_dict=None, dname=None):
        '''Get the traffic tool and interact tool handle'''
        if self.name is not None:
            self.traffic = traffic
            self.transport = transport
            self.session = session
            self.tools = tools
            self.dict = device_dict
            self.dname = dname

        if self.name is not  None:
            self.transport.connect()
        else:
            if self.pre_cmd_host != 'None':
                sys.stdout.write("\tRunning pre_host_cmd.... ")
                sys.stdout.flush()
                self.session.exec_cmd_host('bash', self.pre_cmd_host)
                phc = self.session.recv_line(self.prompt, eof=True, timeout=120)
                print("\tpre_host_cmd done")

            if self.cleanup_cmd != 'None':
                atexit.register(self.run_cleanup_cmd)

            command = eval("'-c', %s" % (self.cmd))
            self.session.exec_cmd_host('bash', command)

        cprint("(%s - %s) device console = %s" % (self.dname, self.name, colored(str(self.color), self.color)), None, attrs=['bold'])
        ping_ip.append(self.name)

        if self.post_cmd_host != 'None':
            sys.stdout.write("Running post_cmd_host.... ")
            sys.stdout.flush()
            self.session.exec_cmd_host('bash', self.post_cmd_host)
            i = self.session.recv_line('password', eof=True, timeout_err=True)
            if i > 0:
                print("\tpost_cmd_host did not complete, it likely failed\n")
            else:
                print("\tpost_cmd_host done")

        if self.post_cmd != 'None':
            self.session.send_line(self.post_cmd)
            self.session.recv_line(self.prompt)

        if self.reboot:
            #self.reset()
            pass

        self.logfile_read = self.output

    def run_cleanup_cmd(self):
        sys.stdout.write("Running cleanup_cmd on %s..." % self.name)
        sys.stdout.flush()
        self.session.exec_cmd_host('bash', self.cleanup_cmd)
        cc = self.session.recv_line(eof=True, timeout=120)
        print("cleanup_cmd done.")

    def reset(self):
        self.session.send_line('reboot')
        self.session.recv_line("'going down','disconnected'")
        try:
            self.session.recv_line(self.prompt, timeout=10)
        except:
            pass
        time.sleep(15)  # Wait for the network to go down.
        for i in range(0, 20):
            try:
                self.session.exec_cmd_host('bash', 'ping -w 1 -c 1 ' + self.name).session.recv_line('64 bytes', timeout=1)
            except:
                print(self.name + " not up yet, after %s seconds." % (i + 15))
            else:
                print("%s is back after %s seconds, waiting for network daemons to spawn." % (self.name, i + 14))
                time.sleep(15)
                break
        self.__init__(self.name, self.color,
                      self.output, self.dname,
                      reboot=False)
    def get_ip_addr(self, interface):
        '''Get the ip address of the device'''
        pass

    def start_ping(self, ip_addr):
        '''Ping to the specified ip_addr and checks it's success.

        Parameters
        ----------
        ip_addr(str): IP address to send ping (default 127.0.0.1)

        Returns
        -------
        True: ping is success
        False: ping is failure
        '''
        pass

    def test_func(self):
        print("method inside in this class %s" % self.__class__.__name__)


if __name__ == "__main__":
    obj = PlatformAndriod('127.0.0.1', 'cyan', 'lan')
    obj.test_func()
