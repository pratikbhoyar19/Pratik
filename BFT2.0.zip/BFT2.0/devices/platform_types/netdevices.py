''' Class defination for OS'''

__author__ = 'Intel Corporation'
__copyright__ = 'Copyright 2019, Intel Corporation'
__version__ = '0.0.1'
__maintainer__ = 'Mirafra'
__email__ = 'framework@mirafra.com'
__status__ = 'Development'

import sys
import time
import atexit
from termcolor import colored, cprint
from datetime import datetime
import re
from globalVariables import *
from lib.common import *


class PlatformTool:
    '''
    A class used to represent an OS.
    This shall be the parent of all opersating system class

    ...

    Attributes
    ----------
    version : OS version

    Methods
    -------
    get_ip_addr()
        Get the ip address of  the device
    start_ping(ip_addr)
        Ping to the specified ip_addr and checks it's success.
    '''
    def run_cleanup_cmd(self):
        pass

    def reset(self):
        ''' Rebooting the device'''
        pass

    def get_ip_addr(self, interface):
        '''Get the ip address of  the device'''
        pass

    def ip_neigh_flush(self):
        pass

    def turn_on_pppoe(self):
        pass

    def turn_off_pppoe(self):
        pass

    def start_tftp_server(self):
        pass

    def restart_tftp_server(self):
        pass

    def start_ping(self, ip_addr):
        '''Ping to the specified ip_addr and checks it's success.'''
        pass

    def get_logfile_read(self):
        if hasattr(self, "_logfile_read"):
            return self._logfile_read
        else:
            return None

    def write(self, string):
        self._logfile_read.write(string)
        self.log += string

    def set_logfile_read(self, value):
        class o_helper():

            def __init__(self, out, color):
                self.color = color
                self.out = out
                self.log = ""
                self.start = datetime.now()

            def write(self, string):
                if self.color is not None:
                    self.out.write(colored(string, self.color))
                else:
                    self.out.write(string)
                td = datetime.now()-self.start
                ts = (td.microseconds + (td.seconds + td.days * 24 * 3600) * 10**6) / 10**6
                # check for the split case
                if len(self.log) > 1 and self.log[-1] == '\r' and string[0] == '\n':
                    tmp = '\n [%s]' % ts
                    tmp += string[1:]
                    string = tmp
                self.log += re.sub('\r\n', '\r\n[%s] ' % ts, string)

            def flush(self):
                self.out.flush()

        if value is not None:
            self._logfile_read = o_helper(value, getattr(self, "color", None))

    def get_log(self):
        return self._logfile_read.log

    logfile_read = property(get_logfile_read, set_logfile_read)
    log = property(get_log)

    def test_func(self):
        print("method inside in this class %s" % self.__class__.__name__)


if __name__ == "__main__":
    obj = PlatformTool()
    obj.test_func()





