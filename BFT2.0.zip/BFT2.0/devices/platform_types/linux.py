''' Class defination for Linux OS'''
__author__ = 'Intel Corporation'
__copyright__ = 'Copyright 2019, Intel Corporation'
__version__ = '0.0.1'
__maintainer__ = 'Mirafra'
__email__ = 'framework@mirafra.com'
__status__ = 'Development'

import atexit
import re
import sys
import time
from datetime import datetime
from termcolor import colored, cprint

from devices.platform_types.netdevices import *
from globalVariables import *
from lib.common import *


class PlatformLinux(PlatformTool):
    '''
    A class used to represent a Windows device

    ...

    Attributes
    ----------
    version : OS version

    Methods
    -------
    get_ip_addr()
        Get the ip address of the device.
    start_ping(ip_addr)
        Ping to the specified ip_addr and checks it's success.
    '''
    prompt = ['root\\@.*:.*#', '/ # ', ".*:~ #",'.*:~ >', '.*\\@.*:.*>', '.*:~ >', '.*:~.*\\$', '.*\\@.*:.*\\$']
    def __init__(self,
                 name,
                 color,
                 output=sys.stdout,
                 reboot=False,
                 location=None,
                 pre_cmd_host=None,
                 cmd=None,
                 post_cmd_host=None,
                 post_cmd=None,
                 cleanup_cmd=None):

        '''Device initialization'''

        self.name = name
        self.color = color
        self.output = output
        self.reboot = reboot
        self.location = location
        self.pre_cmd_host= pre_cmd_host
        self.cmd = cmd
        self.post_cmd_host = post_cmd_host
        self.post_cmd = post_cmd
        self.cleanup_cmd = cleanup_cmd
        self.__process_dict = {}
        self.__process_dict[self.name] = {}

    def config_update(self, traffic=None, transport=None, session=None, tools=None,
                      device_dict=None, dname=None):
        '''Get the traffic tool and interact tool handle'''
        if self.name is not None:
            self.traffic = traffic
            self.transport = transport
            self.session = session
            self.tools = tools
            self.dict = device_dict
            self.dname = dname

        if self.name is not  None:
            import datetime
            #print(datetime.datetime.now())
            self.transport.connect()
            #print(datetime.datetime.now())
        else:
            if self.pre_cmd_host != 'None':
                sys.stdout.write("\tRunning pre_host_cmd.... ")
                sys.stdout.flush()
                self.session.exec_cmd_host('bash', self.pre_cmd_host)
                phc = self.session.recv_line(self.prompt, eof=True, timeout=120)
                print("\tpre_host_cmd done")

            if self.cleanup_cmd != 'None':
                atexit.register(self.run_cleanup_cmd)

            command = eval("'-c', %s" % (self.cmd))
            self.session.exec_cmd_host('bash', command)
        cprint("(%s - %s) device console = %s" % (self.dname, self.name, colored(str(self.color), self.color)), None, attrs=['bold'])
        if self.dname == "lan":
            ping_ip.append(self.name)
        dev_ip_obj.append(self.dname)

        if self.post_cmd_host != 'None':
            sys.stdout.write("Running post_cmd_host.... ")
            sys.stdout.flush()
            self.session.exec_cmd_host('bash', self.post_cmd_host)
            i = self.session.recv_line('password', eof=True, timeout_err=True)
            if i > 0:
                print("\tpost_cmd_host did not complete, it likely failed\n")
            else:
                print("\tpost_cmd_host done")

        if self.post_cmd != 'None':
            self.session.send_line(self.post_cmd)
            self.session.recv_line(self.prompt)

        if self.reboot:
            #self.reset()
            pass

        self.logfile_read = self.output

    def run_cleanup_cmd(self):
        sys.stdout.write("Running cleanup_cmd on %s..." % self.name)
        sys.stdout.flush()
        self.session.exec_cmd_host('bash', self.cleanup_cmd)
        cc = self.session.recv_line(eof=True, timeout=120)
        print("cleanup_cmd done.")

    def add_gw_route(self,gw):
        self.session.send_line('route add default gw %s' % gw)
        return True

    def del_gw_route(self,gw):
        self.session.send_line('route del default gw %s' % gw)
        return True

    def reset(self):
        self.session.send_line('reboot')
        self.session.recv_line("'going down','disconnected'")
        try:
            self.session.recv_line(self.prompt, timeout=10)
        except:
            pass
        time.sleep(15)  # Wait for the network to go down.
        for i in range(0, 20):
            try:
                self.session.exec_cmd_host('bash', 'ping -w 1 -c 1 ' + self.name).session.recv_line('64 bytes', timeout=1)
            except:
                print(self.name + " not up yet, after %s seconds." % (i + 15))
            else:
                print("%s is back after %s seconds, waiting for network daemons to spawn." % (self.name, i + 14))
                time.sleep(15)
                break
        self.__init__(self.name, self.color,
                      self.output, self.dname,
                      reboot=False)

    def get_hostname(self):
        hostname = self.session.send_line("hostname", send_block = True)
        return hostname

    def get_interface_ipaddr(self, interface, ipv6_enable=False, netmask=""):
        """
        Return IP Address for given interface
        Args:
            interface (str): interface whose ip address is to be fetched
        Returns:
            ip_addr (str): IP address of the interface on success else "0"
        Raises:
            None
        """
        ip_addr = None
        if ipv6_enable:
            regex_ip_addr, index = re.compile(r'.*inet6.*addr: (.*)/%s\s+Scope:Global'), 1
        else:
            regex_ip_addr, index = re.compile(r'inet\s(addr:)?(\d+\.\d+\.\d+\.\d+)\s+'), 2
        try:
            for retry in range(3):
                #for i in range(2):
                    #self.session.send_line("\n")
                output = str(self.session.send_recv("\nifconfig {}".format(interface)))
                re_obj = regex_ip_addr.search(output)
                try:
                    ip_addr = re_obj.group(index)
                except AttributeError:
                    continue
                if ip_addr is not None:
                    break
            return ip_addr
        except:
            return '0'

    def get_interface_status(self, iface):
        return True

    def get_os_info(self):
        self.session.send_line("uname")
        self.session.recv_line("(?i)(linux)")
        os_info=self.session.match(1)
        return os_info

    def start_ping(self, ping_count=tsv_ping_count,
                   ip=tsv_bridge_untagged_static_ip):
        '''To start ping traffic from node
           Arguments: percent    - This argument is the packet loss percentage
                      ping_count - This argument is the ping count value, default value is tsv_ping_count
                      ip         - This argument is the IP address to which has to ping, default IP is tsv_bridge_untagged_static_ip'''
        self.session.send_line('\nping -c%s %s' % (ping_count, ip))
        try:
            self.session.recv_line('(\d+)% loss', timeout=10)
            # percent[0] = int(self.session.match(1))
            return True
        except BaseException:
            return False

    def iface_reset(self, iface=tsv_lan_host_eth_interface):
        self.session.send_line("\nifconfig %s down" %iface)
        self.session.send_line("\nifconfig %s up" %iface)
        self.session.send_line("\nifconfig %s 0.0.0.0 up" %iface)
        self.session.send_line("\nifconfig %s" %iface)
        self.session.send_line("\nroute -n")
        self.session.recv_line(self.prompt)

    def ip_neigh_flush(self):
        self.session.send_line('\nip -s neigh flush all')
        self.session.recv_line('flush all')
        self.session.recv_line(self.prompt)

    def turn_on_pppoe(self):
        self.session.send_line('apt-get -o Dpkg::Options::="--force-confnew" -y install pppoe')
        self.session.recv_line(self.prompt)
        self.session.send_line('cat > /etc/ppp/pppoe-server-options << EOF')
        self.session.send_line('noauth')
        self.session.send_line('ms-dns 8.8.8.8')
        self.session.send_line('ms-dns 8.8.4.4')
        self.session.send_line('EOF')
        self.session.recv_line(self.prompt)
        self.session.send_line('pppoe-server -k -I eth1 -L 192.168.2.1 -R 192.168.2.10 -N 4')
        self.session.recv_line(self.prompt)

    def turn_off_pppoe(self):
        self.session.send_line("\nkillall pppoe-server pppoe pppd")
        self.session.recv_line("pppd")
        self.session.recv_line(self.prompt)

    def start_tftp_server(self):
        # set WAN ip address, for now this will always be this address for the device side
        self.session.send_line('ifconfig eth1 down')
        self.session.recv_line(self.prompt)

        # install packages required
        self.session.send_line('apt-get -o DPkg::Options::="--force-confnew" -qy install tftpd-hpa')

        # set WAN ip address, for now this will always be this address for the device side
        self.session.send_line('ifconfig eth1 192.168.0.1')
        self.session.recv_line(self.prompt)

        #configure tftp server
        self.session.send_line('/etc/init.d/tftpd-hpa stop')
        self.session.recv_line('Stopping')
        self.session.recv_line(self.prompt)
        self.session.send_line('rm -rf /tftpboot')
        self.session.recv_line(self.prompt)
        self.session.send_line('rm -rf /srv/tftp')
        self.session.recv_line(self.prompt)
        self.session.send_line('mkdir -p /srv/tftp')
        self.session.recv_line(self.prompt)
        self.session.send_line('ln -sf /srv/tftp/ /tftpboot')
        self.session.recv_line(self.prompt)
        self.session.send_line('mkdir -p /tftpboot/tmp')
        self.session.recv_line(self.prompt)
        self.session.send_line('chmod a+w /tftpboot/tmp')
        self.session.recv_line(self.prompt)
        self.session.send_line('mkdir -p /tftpboot/crashdump')
        self.session.recv_line(self.prompt)
        self.session.send_line('chmod a+w /tftpboot/crashdump')
        self.session.recv_line(self.prompt)
        self.session.send_line('sed /TFTP_OPTIONS/d -i /etc/default/tftpd-hpa')
        self.session.recv_line(self.prompt)
        self.session.send_line('echo TFTP_OPTIONS=\\"-4 --secure --create\\" >> /etc/default/tftpd-hpa')
        self.session.recv_line(self.prompt)
        self.session.send_line('sed /TFTP_DIRECTORY/d -i /etc/default/tftpd-hpa')
        self.session.recv_line(self.prompt)
        self.session.send_line('echo TFTP_DIRECTORY=\\"/srv/tftp\\" >> /etc/default/tftpd-hpa')
        self.session.recv_line(self.prompt)
        self.session.send_line('/etc/init.d/tftpd-hpa restart')
        self.session.recv_line(self.prompt)


    def restart_tftp_server(self):
        self.session.send_line('\n/etc/init.d/tftpd-hpa restart')
        self.session.recv_line('Restarting')
        self.session.recv_line(self.prompt)

    def configure(self, kind):
        if kind == "wan_device":
            self.setup_as_wan_gateway()
        elif kind == "lan_device":
            self.setup_as_lan_device()

    def setup_as_wan_gateway(self):
        self.session.send_line('killall iperf ab hping3')
        self.session.recv_line(self.prompt)
        self.session.send_line('\nsysctl net.ipv6.conf.all.disable_ipv6=0')
        self.session.recv_line('sysctl ')
        self.session.recv_line(self.prompt)

        # potential cleanup so this wan device works
        self.session.send_line('iptables -t nat -X')
        self.session.recv_line(self.prompt)
        self.session.send_line('iptables -t nat -F')
        self.session.recv_line(self.prompt)

        # install packages required
        self.session.send_line('apt-get -o DPkg::Options::="--force-confnew" -qy install isc-dhcp-server procps iptables lighttpd')
        self.session.recv_line(self.prompt)

        # set WAN ip address
        self.session.send_line('ifconfig eth1 192.168.0.1')
        self.session.recv_line(self.prompt)
        self.session.send_line('ifconfig eth1 up')
        self.session.recv_line(self.prompt)

        # start openssh server if not running:
        self.session.send_line('/etc/init.d/ssh start')
        self.session.recv_line(self.prompt)
        self.session.send_line('sed "s/PermitRootLogin.*/PermitRootLogin yes/g" -i /etc/ssh/sshd_config')
        self.session.recv_line(self.prompt)
        self.session.send_line('/etc/init.d/ssh reload')
        self.session.recv_line(self.prompt)

        # configure DHCP server
        self.session.send_line('/etc/init.d/isc-dhcp-server stop')
        self.session.recv_line(self.prompt)
        self.session.send_line('sed s/INTERFACES=.*/INTERFACES=\\"eth1\\"/g -i /etc/default/isc-dhcp-server')
        self.session.recv_line(self.prompt)
        self.session.send_line('cat > /etc/dhcp/dhcpd.conf << EOF')
        self.session.send_line('ddns-update-style none;')
        self.session.send_line('option domain-name "bigfoot-test";')
        self.session.send_line('option domain-name-servers 8.8.8.8, 8.8.4.4;')
        self.session.send_line('default-lease-time 600;')
        self.session.send_line('max-lease-time 7200;')
        self.session.send_line('subnet 192.168.0.0 netmask 255.255.255.0 {')
        self.session.send_line('          range 192.168.0.10 192.168.0.100;')
        self.session.send_line('          option routers 192.168.0.1;')
        self.session.send_line('}')
        self.session.send_line('EOF')
        self.session.recv_line(self.prompt)
        self.session.send_line('/etc/init.d/isc-dhcp-server start')
        self.session.recv_line(['Starting ISC DHCP server.*dhcpd.', 'Starting isc-dhcp-server.*'])
        self.session.recv_line(self.prompt)

        # configure routing
        self.session.send_line('sysctl net.ipv4.ip_forward=1')
        self.session.recv_line(self.prompt)
        wan_ip_uplink = self.get_ip_addr("eth0")
        self.session.send_line('iptables -t nat -A POSTROUTING -o eth0 -j SNAT --to-source %s' % wan_ip_uplink)
        self.session.recv_line(self.prompt)

        self.session.send_line('echo 0 > /proc/sys/net/ipv4/tcp_timestamps')
        self.session.recv_line(self.prompt)
        self.session.send_line('echo 0 > /proc/sys/net/ipv4/tcp_sack')
        self.session.recv_line(self.prompt)

        self.session.send_line('ifconfig eth1')
        self.session.recv_line(self.prompt)

        self.turn_off_pppoe()

    def setup_as_lan_device(self, gw="192.168.1.1"):
        # potential cleanup so this wan device works
        self.session.send_line('killall iperf ab hping3')
        self.session.recv_line(self.prompt)
        self.session.send_line('\niptables -t nat -X')
        self.session.recv_line('iptables -t')
        self.session.recv_line(self.prompt)
        self.session.send_line('sysctl net.ipv6.conf.all.disable_ipv6=0')
        self.session.recv_line(self.prompt)
        self.session.send_line('sysctl net.ipv4.ip_forward=1')
        self.session.recv_line(self.prompt)
        self.session.send_line('iptables -t nat -F; iptables -t nat -X')
        self.session.recv_line(self.prompt)
        self.session.send_line('iptables -F; iptables -X')
        self.session.recv_line(self.prompt)
        self.session.send_line('iptables -t nat -A PREROUTING -p tcp --dport 222 -j DNAT --to-destination %s:22' % gw)
        self.session.recv_line(self.prompt)
        self.session.send_line('iptables -t nat -A POSTROUTING -o eth1 -p tcp --dport 22 -j MASQUERADE')
        self.session.recv_line(self.prompt)
        self.session.send_line('echo 0 > /proc/sys/net/ipv4/tcp_timestamps')
        self.session.recv_line(self.prompt)
        self.session.send_line('echo 0 > /proc/sys/net/ipv4/tcp_sack')
        self.session.recv_line(self.prompt)
        self.session.send_line('pkill --signal 9 -f dhclient.*eth1')
        self.session.recv_line(self.prompt)

    def start_lan_client(self, gw="192.168.1.1"):
        self.session.send_line('\nifconfig eth1 up')
        self.session.recv_line('ifconfig eth1 up')
        self.session.recv_line(self.prompt)
        self.session.send_line("dhclient -r eth1")
        self.session.recv_line(self.prompt)
        self.session.send_line('\nifconfig eth1 0.0.0.0')
        self.session.recv_line(self.prompt)
        self.session.send_line('rm /var/lib/dhcp/dhclient.leases')
        self.session.recv_line(self.prompt)
        for attempt in range(3):
            try:
                self.session.send_line('dhclient -v eth1')
                self.session.recv_line('DHCPOFFER', timeout=30)
                self.session.recv_line(self.prompt)
                break
            except:
                self.session.send_control('c')
        else:
            raise Exception("Error: Device on LAN couldn't obtain address via DHCP.")
        self.session.send_line('ifconfig eth1')
        self.session.recv_line(self.prompt)
        self.session.send_line('route del default')
        self.session.recv_line(self.prompt)
        self.session.send_line('route del default')
        self.session.recv_line(self.prompt)
        self.session.send_line('route del default')
        self.session.recv_line(self.prompt)
        self.session.send_line('route add default gw %s' % gw)
        self.session.recv_line(self.prompt)
        # Setup HTTP proxy, so board webserver is accessible via this device
        self.session.send_line('apt-get -qy install tinyproxy curl apache2-utils nmap')
        self.session.recv_line('Reading package')
        self.session.recv_line(self.prompt, timeout=150)
        self.session.send_line('curl --version')
        self.session.recv_line(self.prompt)
        self.session.send_line('ab -V')
        self.session.recv_line(self.prompt)
        self.session.send_line('nmap --version')
        self.session.recv_line(self.prompt)
        self.session.send_line("sed -i 's/^Port 8888/Port 8080/' /etc/tinyproxy.conf")
        self.session.recv_line(self.prompt)
        self.session.send_line("sed -i 's/^#Allow 10.0.0.0/Allow 10.0.0.0/' /etc/tinyproxy.conf")
        self.session.recv_line(self.prompt)
        self.session.send_line('/etc/init.d/tinyproxy restart')
        self.session.recv_line('Restarting')
        self.session.recv_line(self.prompt)
        # Write a useful ssh config for routers
        self.session.send_line('mkdir -p ~/.ssh')
        self.session.send_line('cat > ~/.ssh/config << EOF')
        self.session.send_line('Host %s' % gw)
        self.session.send_line('StrictHostKeyChecking no')
        self.session.send_line('UserKnownHostsFile=/dev/null')
        self.session.send_line('')
        self.session.send_line('Host krouter')
        self.session.send_line('Hostname %s' % gw)
        self.session.send_line('StrictHostKeyChecking no')
        self.session.send_line('UserKnownHostsFile=/dev/null')
        self.session.send_line('EOF')
        self.session.recv_line(self.prompt)
        # Copy an id to the router so people don't have to type a password to ssh or scp
        self.session.send_line('nc %s 22 -w 1' % gw)
        self.session.recv_line_exact('nc %s 22 -w 1' % gw)
        if 0 == self.session.recv_line(['SSH'] + self.prompt, timeout=5):
            self.session.send_line('[ -e /root/.ssh/id_rsa ] || ssh-keygen -N "" -f /root/.ssh/id_rsa')
            self.session.recv_line(self.prompt)
            self.session.send_line('scp ~/.ssh/id_rsa.pub %s:/etc/dropbear/authorized_keys' % gw)
            self.session.recv_line_exact('scp ~/.ssh/id_rsa.pub %s:/etc/dropbear/authorized_keys' % gw)
            try:
                # When resetting, no need for password
                self.session.recv_line("root@%s's password:" % gw, timeout=5)
                self.session.send_line('password')
            except:
                pass
            self.session.recv_line(self.prompt)

    def start_ping_p(self, ping_count=tsv_ping_count, ip=tsv_bridge_untagged_static_ip):
        '''To start ping traffic from node
           Arguments: node       - This argument is the object where ping traffic has to start, default object is lan
                      ip         - This argument is the IP address to which has to ping, default IP is tsv_bridge_untagged_static_ip
                      ping_count - This argument is the ping count value, default value is tsv_ping_count'''
        fail_count=0
        for i in range(0,3):
            self.session.send_line('\nping -c%s %s' % (ping_count, ip))
            try:
                self.session.recv_line('(\d+)% packet loss', timeout=10)
                percent = int(self.session.match(1))
                if percent == 100:
                    fail_count = fail_count + 1
                    continue
                else:
                    break
            except BaseException:
                fail_count = fail_count + 1
                continue
        if fail_count >=3:
            return False
        else:
            return True

    def remove_server_report(self):
        self.session.send_line("rm /tmp/%s" %tsv_server_report_name)
        self.session.recv_line(self.prompt, timeout=30)
        return True

    def remove_client_report(self):
        self.session.send_line("rm /tmp/client_report.txt")
        self.session.recv_line(self.prompt, timeout=30)
        return True

    def stop_iperf_mpstat(self):
        '''To stop Iperf and mpstat in the system
           Arguments: system  - This argument is the object where the Iperf and mpstat has to stop'''
        self.session.send_control('c')
        self.session.send_control('c')
        self.session.send_line("killall mpstat")
        self.session.send_line("killall iperf")
        return True

    def parse_iperf_server_report(self, proto=tsv_proto_tcp, report_name=tsv_server_report_name):
        '''To parse Iperf server reports
           Arguments: system        - This argument is the object where Iperf server reports has to record, default object is lan
                      report_name   - This argument is the server report name'''
        self.logger.dumpLog("parsing REG EXPRESSION in iperf traffic generator report")
        try:
            self.session.send_control('c')
            for i in range(0,5):
                self.session.send_line("cat /tmp/%s" % report_name)
                try:
                    self.session.recv_line("(\d+(.\d+)?)\s+(\S)bits/sec",timeout=10)
                    rate=float(self.session.match(1))
                    th = self.session.match(3)
                    if rate:
                        break
                except:
                    self.logger.dumpLog("Waiting for a Report")
                    time.sleep(5)

            if th == 'K':
                rate = rate / 1000;
            elif th == 'G':
                rate = rate * 1000;
        except:
            self.logger.dumpLog("parsing REG EXPRESSION in iperf traffic genertor failed")
            return False

        self.logger.dumpLog("parsing REG EXPRESSION in iperf traffic genertor and op is %s" %rate)
        return rate


        self.logger.dumpLog(
            "parsing REG EXPRESSION in iperf traffic genertor and op is %s" %rate)
        return rate

    def stop_trafficgen_mpstat(self):
        '''To stop the mpstat in system
           Arguments: system      - This argument is the object where the mpstat has to stop, default object is wan'''
        self.stop_iperf_mpstat()
        return True


    def get_host_mac_addr(self, wlan_iface=tsv_wlan_iface):
        '''To get the host MAC addr
           Arguments: system     - This argument is the object where to get MAC addr, default object is wlan
                      wlan_iface - This argument is the iface name, default name is tsv_wlan_host_iface'''
        self.session.send_line("ifconfig %s" % wlan_iface)
        try:
            self.session.recv_line(
                "HWaddr (([0-9A-Fa-f]{2}[:-]){5}([0-9A-Fa-f]{2}))",
                timeout=int(tsv_timeout_5))
            mac_addr = self.session.match(1)
            self.logger.dumpLog("MACAddress is %s" % mac_addr)
            return mac_addr
        except BaseException:
            self.logger.dumpLog("not able to obtained mac addr")
            return False


    def assign_dhcp_ip(self, wlan_iface=tsv_wlan_host_iface):
        try:
            shell_id = self.session.send_line("dhclient %s" % (wlan_iface), send_block=True)
            self.session.send_control('c')
            for i in range(0, 15):
                time.sleep(int(tsv_timeout_5))
                self.session.send_line("ifconfig %s" % wlan_iface)
                try:
                    self.session.recv_line(
                        "inet (addr:)?(\d+\.\d+\.\d+\.\d+)",
                        timeout=int(tsv_timeout_5))
                    ip_addr = self.session.match(2)
                    self.logger.dumpLog("Host obtained IP Addr::%s" % ip_addr)
                    self.session.send_line("kill -9 %s" %shell_id, send_block=True)
                    return True
                except BaseException:
                    self.logger.dumpLog("not able to obtained IP addr, retrying")
                    time.sleep(int(tsv_timeout_5))
                    continue

            self.session.send_line("kill -9 %s" %shell_id, send_block=True)
            return False
        except BaseException:
            return False


    def check_iface_status(self,iface=""):
        '''To check iface update in system
           Arguments: iface    - iface on which status needs to be checked'''
        self.session.send_line("cat /sys/class/net/%s/operstate" % iface)
        m = self.session.recv_line(["up", "down"], timeout=int(tsv_timeout_5))
        if m == 1:
            self.logger.dumpLog("%s interface is down" % iface)
            for retry in range(0, 3):
                self.session.send_line("ifconfig %s up" % iface)
                self.session.send_line("cat /sys/class/net/%s/operstate" % iface)
                try:
                    self.session.recv_line("up")
                    break
                except BaseException:
                    self.logger.dumpLog("%d retry failed" % retry)
                    continue
            if retry >= 3:
                return False
        return True

    def get_mac_addr(self, interface):
        """
        Return MAC Address for given interface
        Args:
            interface (str): interface whose MAC Address is to be fetched
        Returns:
            mac_addr (str): MAC address of the interface on successful fetch else None
        Raises:
            None
        """
        try:
            mac_addr = None
            for retry in range(3):
                for i in range(2):
                    self.session.send_line("\n")
                self.session.recv_line(self.prompt, timeout=15)
                output = str(self.session.send_recv("ifconfig %s" % interface))

                mac_re_obj = re.search(r"HWaddr (([0-9A-Fa-f]{2}[:-]){5}([0-9A-Fa-f]{2}))", output)
                try:
                    mac_addr = mac_re_obj.group(1)
                except AttributeError:
                    continue
                if mac_addr is not None:
                    break
        except BaseException:
            self.logger.dumpLog("not able to obtained mac addr")
        return mac_addr

    def config_static_ip(self, iface=None, static_ip=None, netmask=None, vlan_id=None, gw=None):
        """
        The function to configure static ip on interface
        Args:
             iface(str): interface on which ip needed
             ipaddr(str): static ip
             netmask(str): netmask
        Returns:
             result_dict["result"]: pass/fail
        """
        result_dict = {}
        result_dict["result"] = "pass"
        try:
            if vlan_id != None:
                ip_d = self.create_tag_ipaddr(ip=static_ip, vlan_id=vlan_id)
                if ip_d['result'] == 'fail':
                     result_dict["result"] = "fail"
                     return result_dict
                static_ip = ip_d['ip']
            self.session.send_recv('ifconfig {} {} netmask {}'.format(iface, static_ip, netmask))
            if gw != None:
                if vlan_id != None:
                    gw_d = self.create_tag_ipaddr(ip=gw, vlan_id=vlan_id)
                    if gw_d['result'] == 'fail':
                        result_dict["result"] = "fail"
                        return result_dict
                    gw = gw_d['ip']
                self.session.send_recv('route add default gw {}'.format(gw))
        except Exception as err:
            result_dict["result"] = "fail"
            self.logger.dumpLog("{}".format(err))
        return result_dict

    def remove_static_ip(self, iface=None):
        """
        The function to remove static configurations from interface
        Args:
             iface(str): interface on which ip to be removed
        Returns:
             result_dict["result"]: pass/fail
        """
        result_dict = {}
        result_dict["result"] = "pass"
        ipaddr = "0.0.0.0"
        try:
            self.session.send_recv('ifconfig {} {}'.format(iface, ipaddr))
        except Exception as err:
            result_dict["result"] = "fail"
            self.logger.dumpLog("{}".format(err))
        return result_dict

    def restart_services(self):
        """
        The function to restart services at wan side
        Args:
            None
        Returns:
            result_dict["result"]: pass/fail
        """

        result_dict = {}
        result_dict["result"] = "pass"
        try:
            self.session.send_recv("service isc-dhcp-server restart")
            self.session.send_recv("sh /etc/VLANscript.sh")
        except Exception as err:
            result_dict["result"] = "fail"
            self.logger.dumpLog("{}".format(err))
        return result_dict

    def create_tag_ipaddr(self, ip=None, vlan_id=None):
        """
        The function to create tag ipaddr
        Args:
            ip(str): ip addr to modify
            vlan_id(str): vlan id to be used for modification
        Returns:
            result_dict["result"]: pass/fail
        """
        result_dict = {}
        result_dict["result"] = "pass"
        try:
            tmp = ip.split('.')
            tmp[2] = str(vlan_id)
            result_dict['ip'] = '.'.join(tmp)
        except Exception as err:
            result_dict["result"] = "fail"
            self.logger.dumpLog("{}".format(err))
        return result_dict

    def copy_from(self, local_path="", remote_path=""):
        if not self.session.copy_frm_cmd(local_path=local_path, remote_path=remote_path):
            return False
        return True


    def release_dhcp_ip(self, iface=None):
        """
        The function to release dhcp ip
        Args:
            iface(str): iface which needs dhcp ip to be released
        Returns:
            result_dict["result"]: pass/fail
        """
        result_dict = {}
        result_dict["result"] = "pass"
        try:
            self.session.send_recv("dhclient -r {}".format(iface), timeout=60)
        except Exception as err:
            result_dict["result"] = "fail"
            self.logger.dumpLog("{}".format(err))
        return result_dict

    def config_dhcp_ip(self, iface=None):
        """
        The function to get dhcp ip
        Args:
            iface(str): iface which needed dhcp ip
        Returns:
            result_dict["result"]: pass/fail
            result_dict["ip"]: ip obtained by dhcp server
        """
        result_dict = {}
        result_dict["result"] = "pass"
        try:
            self.session.send_line("ifconfig {} 0.0.0.0 down".format(iface))
            self.session.recv_line(self.prompt, timeout=20)
            self.session.send_line("dhclient -r {}".format(iface))
            self.session.recv_line(self.prompt, timeout=20)
            self.session.send_line("dhclient {}".format(iface))
            self.session.recv_line(self.prompt, timeout=20)
            #time.sleep(2)
            for i in range(0,2):
                ip = self.get_interface_ipaddr(iface)
                if ip:
                    result_dict['ip'] = ip
                    break
                time.sleep(5)
        except Exception as err:
            result_dict["result"] = "fail"
            self.logger.dumpLog("{}".format(err))
        if not ip:
            result_dict["result"] = "fail"
        self.session.send_recv("killall dhclient")
        return result_dict

    def get_file_content(self, file_path):
        """
        This method gets the file content of file in file_path

        Args:
            file_path (str): complete file path

        Returns: (str)
            file_content (str): complete file content of file in file_path

        Raises:
            None
        """
        cmd = "cat {}".format(file_path)

        file_content = self.session.send_recv(cmd)
        return file_content

    def process_id_exist(self, process_id, process_name):
        """
        This method gets the file content of file in file_path

        Args:
            process_id (str): pid of the process_name
            process_name (str): process name

        Returns: (boolean)
            True : if process_id is already in process
            False : if process_id is not in process

        Raises:
            None
        """
        self.__update_process_id(process_name)
        return process_id in self.__process_dict[self.name][process_name]

    def __update_process_id(self, process_name):
        """
        This method updates the master process_dict for process

        Args:
            process_name (str): process name

        Returns:
            None

        Raises:
            None
        """
        if process_name not in self.__process_dict[self.name]:
            self.__process_dict[self.name][process_name] = []
        cmd = 'pidof ' + str(process_name)
        out_string = self.session.send_recv(cmd)
        if out_string:
            process_id_list = out_string.split()
            self.__process_dict[self.name][process_name] = process_id_list

    def kill_process(self, process_name):
        """
        This method kills the process

        Args:
            process_id (str): process_id to be killed.

        Returns: (boolean)
            True : if process kill is successful
            False : if no process is running or process kill is unsuccessful

        Raises:
            None
        """
        cmd = 'killall {}'.format(process_name)
        out_string = self.session.send_recv(cmd)
        if '{}: no process found'.format(process_name) in out_string:
            return False
        self.__process_dict[self.name][process_name] = []
        return True

    def kill_process_id(self, process_id):
        """
        This method kills the process_id

        Args:
            process_id (str): process_id to be killed.

        Returns: (boolean)
            True : if pid kill is successful
            False : if pid is not running or pid kill is unsuccessful

        Raises:
            None
        """
        if process_id in self.__process_dict[self.name]:
            cmd = "kill {}".format(process_id)
            out_string = self.session.send_recv(cmd)
            if "No such process" in out_string:
                self.__process_dict[self.name].remove(process_id)
                return False
        return True

    def log_path(self):
        """
        It would return the default log path to store the logs locally
        Args:
            None
        Returns:
            log_path (str): the default log path
        Raises:
            None
        """
        log_path = "/tmp/"
        return log_path

    def send_ping(self, destination_ip, config_dict=None, threshold_percentage=None):
        """
        Method to send ping to destination

        Args:
            destination_ip (str): destination device IP Address
            config_dict (dict): dictionary with ping param configuration values
                config_dict: {
                                'count': '5',
                                'interval': '1' to '255',
                                'buffer_size': '0' to '65500',
                                'ipv6': 'true'|'false',
                            }
        Returns:
            True: on ping success
            False: on ping failure
        Raises:
            None
        """
        if threshold_percentage is None:
            threshold_percentage = 20
        ping_command = "ping "
        ping_command += " -c {} ".format(config_dict.get('count', 5))
        ping_command += " {} ".format(destination_ip)
        if config_dict is None:
            if "buffer_size" in config_dict:
                ping_command += " -s {} ".format(config_dict.get('buffer_size', 65500))
            if "interval" in config_dict:
                ping_command += " -i {} ".format(config_dict.get('interval', 1))
            if "ipv6" in config_dict and str(config_dict['ipv6']).lower() == 'true':
                ping_command += " -6 "
        output = self.session.send_recv(ping_command)

        re_ping_obj = re.search(r'.*([\d]+) packets transmitted, ([\d]+) packets received, ([\d]+)% packet loss.*',
                                str(output))
        if re_ping_obj is not None:
            sent, rec, lost_per = re_ping_obj.groups()
            if int(lost_per) < int(threshold_percentage) and int(sent) > 0:
                return True
        else:
            return False
        return False

    def get_process_id(self, process_name):
        """
        This method returns pid of started process

        Args:
            process_name (str): name of the process

        Returns: (str)
            'process_id' : pid of the process_name
            False : if no process is running with process_name

        Raises:
            None
        """
        if process_name not in self.__process_dict[self.name]:
            self.__process_dict[self.name][process_name] = []
        else:
            print("self.__process_dict[{}][{}] = {}".format(self.name, process_name,
                                                            self.__process_dict[self.name][process_name]))
        cmd = 'pidof {}'.format(process_name)
        result = self.session.send_recv(cmd)
        if result == '':
            return False
        else:
            process_id_list = re.findall(r'(\d+)', result)
            if self.__process_dict[self.name][process_name] and len(process_id_list) != 1:
                result_list = [process_id for process_id in process_id_list if
                               process_id not in self.__process_dict[self.name][process_name]]
            else:
                result_list = process_id_list
            self.__process_dict[self.name][process_name] = list(
                set(self.__process_dict[self.name][process_name] + process_id_list))
            return result_list[0]

    def config_pppoe_ip(self, iface=None, user=None, password=None):
        """
        This method configure pppoe interface on system

        Args:
            iface (str): iface which needed pppoe ip
            user (str): username for pppoe server authentication
            password (str): password for ppppoe server authentication

        Returns:
            result_dict["result"]: pass/fail
        """
        result_dict={}
        result_dict["result"] = "pass"
        try:
            f_buf = self.session.send_recv("cat /etc/ppp/options")
            f_ob = re.search('No such file or directory', f_buf)
            if f_ob == None:#file already present
                self.session.send_recv("rm -rf /etc/ppp/options", timeout=10)

            #this logic will be common for both cases, i.e, options present or not present
            self.session.send_recv("touch /etc/ppp/options",timeout=10)

            self.__create_pppoe_options_config()

            d_buf = self.session.send_recv("cat /etc/ppp/peers")
            d_ob = re.search('No such file or directory', d_buf)
            if f_ob == None:#directory already present
                f_buf = self.session.send_recv("cat /etc/ppp/peers/pppoe0")
                f_ob = re.search('No such file or directory', f_buf)
                if f_ob == None:#file already present
                    self.session.send_recv("rm -rf /etc/ppp/peers/pppoe0", timeout=10)

            #this logic will be common for both cases, i.e, peers present or not present
            self.session.send_recv("mkdir -p /etc/ppp/peers", timeout=10)
            self.session.send_recv("touch /etc/ppp/peers/pppoe0", timeout=10)

            self.__create_pppoe_peers_config(iface=iface, user=user, password=password)

            #Executing pppoe command
            self.session.send_recv("/usr/sbin/pppd file /etc/ppp/options call pppoe0", timeout=20)
        except Exception as err:
            result_dict["result"] = "fail"
            self.logger.dumpLog("{}".format(err))
        return result_dict

    def __create_pppoe_options_config(self):
        """
        This method configure pppoe options configuration on system

        Args:
            None
        Returns:
            result_dict["result"]: pass/fail
        """
        result_dict={}
        result_dict["result"] = "pass"
        try:
            #start echo, to write new file with options
            self.session.send_recv("echo \"maxfail 0\" > /etc/ppp/options",timeout=10)
            self.session.send_recv("echo \"persist\" >> /etc/ppp/options",timeout=10)
        except Exception as err:
            result_dict["result"] = "fail"
            self.logger.dumpLog("{}".format(err))
        return result_dict

    def __create_pppoe_peers_config(self, iface=None, user=None, password=None):
        """
        This method configure pppoe peers configuration on system

        Args:
            iface (str): iface which needed pppoe ip
            user (str): username for pppoe server authentication
            password (str): password for ppppoe server authentication
        Returns:
            result_dict["result"]: pass/fail
        """
        result_dict={}
        result_dict["result"] = "pass"
        try:
            #start echo, to write new file with options
            self.session.send_recv("echo \"linkname pppoe-0\" > /etc/ppp/peers/pppoe0", timeout=10)
            self.session.send_recv("echo \"lcp-echo-interval 30\" >> /etc/ppp/peers/pppoe0", timeout=10)
            self.session.send_recv("echo \"lcp-echo-failure 4\" >> /etc/ppp/peers/pppoe0", timeout=10)
            self.session.send_recv("echo \"unit 3\" >> /etc/ppp/peers/pppoe0", timeout=10)
            self.session.send_recv("echo \"maxfail 0\" >> /etc/ppp/peers/pppoe0", timeout=10)
            self.session.send_recv("echo \"usepeerdns\" >> /etc/ppp/peers/pppoe0", timeout=10)
            self.session.send_recv("echo \"noipdefault\" >> /etc/ppp/peers/pppoe0", timeout=10)
            self.session.send_recv("echo \"user {}\" >> /etc/ppp/peers/pppoe0".format(user), timeout=10)
            self.session.send_recv("echo \"password {}\" >> /etc/ppp/peers/pppoe0".format(password), timeout=10)
            self.session.send_recv("echo \"mtu 1492\" >> /etc/ppp/peers/pppoe0", timeout=10)
            self.session.send_recv("echo \"mru 1492\" >> /etc/ppp/peers/pppoe0", timeout=10)
            self.session.send_recv("echo \"holdoff 4\" >> /etc/ppp/peers/pppoe0", timeout=10)
            self.session.send_recv("echo \"persist\" >> /etc/ppp/peers/pppoe0", timeout=10)
            self.session.send_line("echo \"plugin\" /usr/lib/pppd/2.4.7/rp-pppoe.so >> /etc/ppp/peers/pppoe0")
            self.session.recv_line(self.prompt, timeout=10)
            self.session.send_recv("echo \"{}\" >> /etc/ppp/peers/pppoe0".format(iface), timeout=10)
        except Exception as err:
            result_dict["result"] = "fail"
            self.logger.dumpLog("{}".format(err))
        return result_dict

    def create_ipogre(self,
                      local_ip=None,
                      remote_ip=None,
                      tun_nw=None,
                      tun_ip=None,
                      mtu=None):
        """
        This function is used to create ipogre tunnel
        Args:
            local_ip(str): local ip
            remote_ip(str): remote ip
            tun_nw(str): tunnel network address
            tun_ip(str): tunnel Ip address
            mtu(str): mtu size
        Returns:
            result_dict["result"]: pass/fail
        """
        result_dict = {}
        result_dict["result"] = "pass"

        try:
	    self.session.send_line("ip tunnel add tunIPoGre mode gre remote {} local {} ttl 255".format(remote_ip,local_ip))
            self.session.recv_line(self.prompt, timeout=20)
	    self.session.send_line("ip link set tunIPoGre up")
            self.session.recv_line(self.prompt, timeout=20)
	    self.session.send_line("ip addr add {} dev tunIPoGre".format(tun_ip))
            self.session.recv_line(self.prompt, timeout=20)
	    self.session.send_line("ip route add {}/24 dev tunIPoGre".format(tun_nw))
            self.session.recv_line(self.prompt, timeout=20)
	    self.session.send_line("ip link set dev tunIPoGre mtu {}".format(mtu))
            self.session.recv_line(self.prompt, timeout=20)
        except Exception as err:
            result_dict["result"] = "fail"
            logger.dumpLog("{}".format(err))
        return result_dict

    def delete_ipogre(self, tun_nw=None):
        """
        This function is used to create ipogre tunnel
        Args:
            tun_nw(str): Tunnel network address

        Returns:
            result_dict["result"]: pass/fail
        """
        result_dict = {}
        result_dict["result"] = "pass"

        try:
 	    self.session.send_line("ip route del {}/24 dev tunIPoGre".format(tun_nw))
            self.session.recv_line(self.prompt, timeout=20)
	    self.session.send_line("ip link set tunIPoGre down")
            self.session.recv_line(self.prompt, timeout=20)
	    self.session.send_line("ip tunnel del tunIPoGre")
            self.session.recv_line(self.prompt, timeout=20)
        except Exception as err:
	    result_dict["result"] = "fail"
	    logger.dumpLog("{}".format(err))
        return result_dict

    def create_eogre_bras(self,
                          wan_host_ip=None,
                          ip_addr=None,
                          br_ip=None,
                          tun_bras_ip=None,
                          netmask=None):
        """
        This function is used to create eogre tunnel
        Args:
            wan_host_ip(str): wan host ip address
            ip_addr(str): local ip address
            br_ip(str):bras bridge ip address
            tun_bras_ip(str): tunnel bras ip address
            netmask(str): netmask address
        Returns:
            result_dict["result"]: pass/fail
        """
        result_dict = {}
        result_dict["result"] = "pass"

        try:
            self.session.send_line('brctl addbr br0')
            self.session.recv_line(self.prompt, timeout=20)
            self.session.send_line('ifconfig br0 {}/24 up'.format(br_ip))
            self.session.recv_line(self.prompt, timeout=20)
            self.session.send_line('ip link add tunEoGre type gretap remote {} local {} ttl 255'.format(ip_addr,wan_host_ip))
            self.session.recv_line(self.prompt, timeout=20)
            self.session.send_line('ip link set tunEoGre up')
            self.session.recv_line(self.prompt, timeout=20)
            self.session.send_line('brctl addif br0 tunEoGre')
            self.session.recv_line(self.prompt, timeout=20)
        except Exception as err:
            result_dict["result"] = "fail"
            logger.dumpLog("{}".format(err))
        return result_dict

    def delete_eogre_bras(self, br_ip=None):
        """
        This function is used to delete eogre tunnel
        Args:
            br_ip(str): bridge ip address
        Returns:
            result_dict["result"]: pass/fail
        """
        result_dict = {}
        result_dict["result"] = "pass"

        try:
            self.session.send_line('brctl delif br0 tunEoGre')
            self.session.recv_line(self.prompt, timeout=20)
            self.session.send_line('ip link set tunEoGre down')
            self.session.recv_line(self.prompt, timeout=20)
            self.session.send_line('ip link del tunEoGre')
            self.session.recv_line(self.prompt, timeout=20)
            self.session.send_line('ifconfig br0 {}/24 down'.format(br_ip))
            self.session.recv_line(self.prompt, timeout=20)
            self.session.send_line('brctl delbr br0')
            self.session.recv_line(self.prompt, timeout=20)
            self.session.send_line('brctl show')
            self.session.recv_line(self.prompt, timeout=20)
        except Exception as err:
            result_dict["result"] = "fail"
            logger.dumpLog("{}".format(err))
        return result_dict

    def kill_proc(self, cmd):
        '''
        Kill the command running in the device.

        Args:
            cmd - cmd to be killed

        Returns:
            True/False
        Raises:
            None
        '''
        ## Remove additional spaces, required for linux
        cmd = re.sub('\s+',' ', cmd)
        cmd = re.sub('\s+>.*','',cmd)
        time.sleep(2)
        cmd_output = self.session.send_recv("ps -eo pid,command | grep \"{}\" | grep -v grep".format(cmd))
        if cmd_output != '':
            op_lst = re.findall("(\d+)",cmd_output)
            logger.dumpLog("kill -9 {}".format(op_lst[0]))
            self.session.send_recv("kill -9 {}".format(op_lst[0]))
        else:
            logger.warning('Process is already closed')
            return False
        return True

    def l2tp_rm_files_client(self):
        """
        To remove exiting xl2tpd.conf, options.xl2tpd and options file from wan machine
        Args:
            None
        Returns:
            result_dict["result"]:pass/fail
        """
        result_dict = {}
        result_dict["result"] = "pass"
        logger.dumpLog("removing exiting configured files from WAN side")
        try:
            self.session.send_line("rm -rf /etc/xl2tpd/xl2tpd.conf")
            self.session.recv_line(self.prompt,timeout=20)
            self.session.send_line("rm -rf /etc/ppp/options.xl2tpd")
            self.session.recv_line(self.prompt,timeout=20)
            self.session.send_line("rm -rf /etc/ppp/options")
            self.session.recv_line(self.prompt,timeout=20)
            logger.dumpLog("File deleted successfully")
        except Exception as err:
            logger.dumpLog("{}".format(err))
            result_dict["result"] = "fail"
        return result_dict

    def create_xl2tpd_conf_client(self, lns_addr=None, local_ip=None, ip_start=None, ip_end=None):
        """
           To create xl2tpd.conf file at wan side
           Args:
               lns_addr(str): specifies the wan host ip address
               local_ip(str): local ip address
           Returns:
               result_dict['result']:pass/fail
        """
        result_dict = {}
        result_dict["result"] = "pass"
        logger.dumpLog("creating the xl2tpd.conf file at WAN side")
        try:
            self.session.send_line("echo '' > /etc/xl2tpd/xl2tpd.conf")
            self.session.recv_line(self.prompt,timeout=20)
            self.session.send_line("echo '[global]' >> /etc/xl2tpd/xl2tpd.conf")
            self.session.recv_line(self.prompt,timeout=20)
            self.session.send_line("echo 'listen-addr = {}' >> /etc/xl2tpd/xl2tpd.conf".format(lns_addr))
            self.session.recv_line(self.prompt,timeout=20)
            self.session.send_line("echo '[lns default]' >> /etc/xl2tpd/xl2tpd.conf")
            self.session.recv_line(self.prompt, timeout=20)
            self.session.send_line("echo 'exclusive = no' >> /etc/xl2tpd/xl2tpd.conf")
            self.session.recv_line(self.prompt,timeout=20)
            self.session.send_line("echo 'ip range = {}-{}' >> /etc/xl2tpd/xl2tpd.conf".format(ip_start,ip_end))
            self.session.recv_line(self.prompt,timeout=20)
            self.session.send_line("echo 'local ip = {}' >> /etc/xl2tpd/xl2tpd.conf".format(local_ip))
            self.session.recv_line(self.prompt,timeout=20)
            self.session.send_line("echo 'length bit = yes' >> /etc/xl2tpd/xl2tpd.conf")
            self.session.recv_line(self.prompt,timeout=20)
            self.session.send_line("echo 'refuse authentication = yes' >> /etc/xl2tpd/xl2tpd.conf")
            self.session.recv_line(self.prompt,timeout=20)
            self.session.send_line("echo 'ppp debug = yes' >> /etc/xl2tpd/xl2tpd.conf")
            self.session.recv_line(self.prompt,timeout=20)
            self.session.send_line("echo 'pppoptfile = /etc/ppp/options.xl2tpd' >> /etc/xl2tpd/xl2tpd.conf")
            self.session.recv_line(self.prompt,timeout=20)
            self.session.send_line("echo 'name = l2tp_pppd' >> /etc/xl2tpd/xl2tpd.conf")
            self.session.recv_line(self.prompt,timeout=20)
        except Exception as err:
             logger.dumpLog("{}".format(err))
             result_dict["result"] = "fail"
        return result_dict

    def create_xl2tpd_options_client(self):
        """
           To create option.xl2tpd file at wan side
           Args:
               None
           Returns:
               result_dict['result']:pass/fail
        """
        result_dict = {}
        result_dict["result"] = "pass"
        logger.dumpLog("creating the options.xl2tpd file at WAN side")
        try:
            self.session.send_line("echo '' > /etc/ppp/options.xl2tpd")
            self.session.recv_line(self.prompt,timeout=20)
            self.session.send_line("echo 'noccp' >> /etc/ppp/options.xl2tpd")
            self.session.recv_line(self.prompt,timeout=20)
            self.session.send_line("echo 'noauth' >> /etc/ppp/options.xl2tpd")
            self.session.recv_line(self.prompt,timeout=20)
            self.session.send_line("echo 'crtscts' >> /etc/ppp/options.xl2tpd")
            self.session.recv_line(self.prompt,timeout=20)
            self.session.send_line("echo 'lock' >> /etc/ppp/options.xl2tpd")
            self.session.recv_line(self.prompt,timeout=20)
            self.session.send_line("echo 'mru 1410' >> /etc/ppp/options.xl2tpd")
            self.session.recv_line(self.prompt,timeout=20)
            self.session.send_line("echo 'debug' >> /etc/ppp/options.xl2tpd")
            self.session.recv_line(self.prompt,timeout=20)
            self.session.send_line("echo 'mtu 1410' >> /etc/ppp/options.xl2tpd")
            self.session.recv_line(self.prompt,timeout=20)
            self.session.send_line("echo 'name' >> /etc/ppp/options.xl2tpd")
            self.session.recv_line(self.prompt,timeout=20)
            self.session.send_line("echo 'proxyarp' >> /etc/ppp/options.xl2tpd")
            self.session.recv_line(self.prompt,timeout=20)
            self.session.send_line("echo 'lcp-echo-interval 120' >> /etc/ppp/options.xl2tpd")
            self.session.recv_line(self.prompt,timeout=20)
            self.session.send_line("echo 'lcp-echo-failure 10' >> /etc/ppp/options.xl2tpd")
            self.session.recv_line(self.prompt,timeout=20)
            self.session.send_line("echo 'noipx' >> /etc/ppp/options.xl2tpd")
            self.session.recv_line(self.prompt,timeout=20)
            self.session.send_line("echo 'idle 1800' >> /etc/ppp/options.xl2tpd")
            self.session.recv_line(self.prompt,timeout=20)
            self.session.send_line("echo 'connect-delay 5000' >> /etc/ppp/options.xl2tpd")
            self.session.recv_line(self.prompt,timeout=20)
            self.session.send_line("echo 'logfile /tmp/xl2tpd-pppd.log' >> /etc/ppp/options.xl2tpd")
            self.session.recv_line(self.prompt,timeout=20)
        except Exception as err:
             logger.dumpLog("{}".format(err))
             result_dict["result"] = "fail"
        return result_dict

    def create_xl2tpd_ppp_options_client(self):
        """
           To create option file at wan side
           Args:
               None
           Returns:
               return_dict['result']:pass/fail
        """
        result_dict = {}
        result_dict["result"] = "pass"
        logger.dumpLog("creating the options file at WAN side")
        try:
            self.session.send_line("echo 'lock' >> /etc/ppp/options")
            self.session.recv_line(self.prompt,timeout=20)
            self.session.send_line("echo 'crtscts' >> /etc/ppp/options")
            self.session.recv_line(self.prompt,timeout=20)
            self.session.send_line("echo 'nobsdcomp' >> /etc/ppp/options")
            self.session.recv_line(self.prompt,timeout=20)
            self.session.send_line("echo 'nodeflate' >> /etc/ppp/options")
            self.session.recv_line(self.prompt,timeout=20)
            self.session.send_line("echo 'nopcomp' >> /etc/ppp/options")
            self.session.recv_line(self.prompt,timeout=20)
        except Exception as err:
            logger.dumpLog("{}".format(err))
            result_dict["result"] = "fail"
        return result_dict

    def add_route_client(self, nw_addr=None, iface=None):
        """
           To add route at wan side
           Args:
               nw_addr(str): tunnel network ip address
               iface(str): tunnel interface
           Returns:
               return_dict['result']:pass/fail
        """
        result_dict = {}
        result_dict["result"] = "pass"
        try:
            self.session.send_line("route add -net {}/24 dev {}".format(nw_addr, iface))
            self.session.recv_line(self.prompt,timeout=20)
        except Exception as err:
            logger.dumpLog("{}".format(err))
            result_dict["result"] = "fail"
        return result_dict

    def start_l2tp_client(self):
        """
           To start l2tp client at wan side
           Args:
               None
           Returns:
               result_dict['result']:pass/fail
        """
        result_dict = {}
        result_dict["result"] = "pass"
        try:
            self.session.send_line("/etc/init.d/xl2tpd stop")
            self.session.recv_line(self.prompt,timeout=20)
            self.session.send_line("/etc/init.d/xl2tpd start")
            self.session.recv_line(self.prompt,timeout=20)
            logger.dumpLog("starting l2tp client at WAN side")
            self.session.send_line("xl2tpd -D &")
            self.session.recv_line(self.prompt,timeout=20)
            self.session.send_line("")
            self.session.recv_line(self.prompt, timeout=20)
        except Exception as err:
            logger.dumpLog("{}".format(err))
            result_dict["result"] = "fail"
        return result_dict

    def del_route_client(self,nw_addr=None, iface=None):
        """
           To del route at wan side
           Args:
               nw_addr(str):tunnel network ip address
               iface(str):tunnel interface
           Returns:
               return_dict['result']:pass/fail
        """
        result_dict = {}
        result_dict["result"] = "pass"
        try:
            self.session.send_line("route del -net {}/24 dev {}".format(nw_addr, iface))
            self.session.recv_line(self.prompt,timeout=20)
        except Exception as err:
            logger.dumpLog("{}".format(err))
            result_dict["result"] = "fail"
        return result_dict

    def get_ppp_iface(self):
        """
        Function to get the ppp interface
        Args:
            None
        Returns:
            result_dict["result"]: pass/fail
        """
        result_dict = {}
        result_dict['result'] = "pass"
        ppp_iface = None
        try:
            for i in range(0,5):
                output = self.session.send_recv("ifconfig", timeout=20)
                if output != None:
                    s_obj = re.search(r'(ppp\d+)\s+Link',output)
                    if s_obj != None:
                        ppp_iface = s_obj.group(1)
                        result_dict['ppp_iface'] = ppp_iface
                        logger.dumpLog("ppp iface obtained is {}".format(result_dict['ppp_iface']))
                        break
                    else:
                        time.sleep(2)
                        continue
            if ppp_iface == None:
                result_dict['result'] = "fail"
        except Exception as err:
            result_dict["result"] = "fail"
            logger.dumpLog("{}".format(err))
        return result_dict

    def ipsec_rm_config(self):
        """
        To remove exiting ipsec file from system
        Args:
            None
        Returns:
            result_dict["result"]:pass/fail
        """
        result_dict = {}
        result_dict["result"] = "pass"
        try:
            self.session.send_line("rm -rf /etc/ipsec.conf /etc/ipsec.secrets")
            self.session.recv_line(self.prompt,timeout=20)
            #output = self.session.send_recv("ls /etc")
            #ipsec_s = re.search(r".*(ipsec).*(ipsec.[a-z]+)", output)
            #print(ipsec_s.group())
            #print(ipsec_s)
            #if ipsec_s == None:
            #    logger.dumpLog("File deleted successfully")
            #else:
            #    logger.dumpLog("File not deleted successfully")
            #    result_dict["result"] = "fail"
        except Exception as err:
            logger.dumpLog("{}".format(err))
            result_dict["result"] = "fail"
        return result_dict

    def restart_ipsec(self):
        """
        To start the Ipsec
        Args:
            None
        Returns:
            result_dict["result"]:pass/fail
        """
        result_dict = {}
        result_dict["result"] = "pass"
        try:
            opt = self.session.send_line("ipsec stop")
            self.session.recv_line(self.prompt,timeout=20)
            op = self.session.send_recv("ipsec restart")
            status = re.search(r'.*(Starting strongSwan [\d+.]+ IPsec \[starter\]).*', op)
            if status != None:
                logger.dumpLog("IPsec restarted successfully on client")
            else:
                logger.dumpLog("Faild to restarted ipsec on client")
                result_dict["result"] = "fail"
        except Exception as err:
            logger.dumpLog("{}".format(err))
            result_dict["result"] = "fail"
        return result_dict

    def ipsec_config(self,
                     left_ip=None,
                     right_ip=None,
                     left_subnet=None,
                     left_id=None,
                     right_subnet=None,
                     right_id=None,
                     local_ip=None,
                     remote_ip=None,
                     mode=None,
                     pwd=None):
        """
        To configure ipsec files(ipsec.conf,ipsec.secrets)
        Args:
            left_ip(str):wan ip address
            right_ip(str):dut ip adddress
            left_subnet(str):wan side subnet
            left_id(str):wan ip address
            right_subnet():dut side subnet
            right_id(str):dut wan ip address
            local_ip(str):wan ip address
            remote_ip(str):dut IP address
            mode(str):tunnel/transport
            pwd(str):password

        Returns:
            result_dict["result"]:pass/fail
        """
        result_dict = {}
        result_dict["result"] = "pass"
        try:
            self.session.send_line('\n')
            self.session.recv_line(self.prompt,timeout=20)
            self.session.send_line("echo '' > /etc/ipsec.conf")
            self.session.recv_line(self.prompt,timeout=20)
            self.session.send_line("echo 'version 2.0' >> /etc/ipsec.conf")
            self.session.recv_line(self.prompt,timeout=20)
            self.session.send_line("echo 'config setup' >> /etc/ipsec.conf")
            self.session.recv_line(self.prompt,timeout=20)
            self.session.send_line("echo 'conn %default' >> /etc/ipsec.conf")
            self.session.recv_line(self.prompt,timeout=20)
            self.session.send_line("echo '        keylife=20m' >> /etc/ipsec.conf")
            self.session.recv_line(self.prompt,timeout=20)
            self.session.send_line("echo '        rekeymargin=3m' >> /etc/ipsec.conf")
            self.session.recv_line(self.prompt,timeout=20)
            self.session.send_line("echo '        keyingtries=1' >> /etc/ipsec.conf")
            self.session.recv_line(self.prompt,timeout=20)
            self.session.send_line("echo '        authby=secret' >> /etc/ipsec.conf")
            self.session.recv_line(self.prompt,timeout=20)
            #self.session.send_line("echo '        replay_window=1024' >> /etc/ipsec.conf")
            #self.session.recv_line(self.prompt,timeout=20)
            self.session.send_line("echo '        mobike=no' >> /etc/ipsec.conf")
            self.session.recv_line(self.prompt,timeout=20)
            self.session.send_line("echo '        auto=start' >> /etc/ipsec.conf")
            self.session.recv_line(self.prompt,timeout=20)
            self.session.send_line("echo '' >> /etc/ipsec.conf")
            self.session.recv_line(self.prompt,timeout=20)
            self.session.send_line("echo 'conn tunnel1' >> /etc/ipsec.conf")
            self.session.recv_line(self.prompt,timeout=20)
            self.session.send_line("echo '        ikelifetime=60m' >> /etc/ipsec.conf")
            self.session.recv_line(self.prompt,timeout=20)
            self.session.send_line("echo '        ike=aes192-sha1-prfsha1-modp1536!' >> /etc/ipsec.conf")
            self.session.recv_line(self.prompt,timeout=20)
            self.session.send_line("echo '        esp=aes128-sha1-modp1536!' >> /etc/ipsec.conf")
            self.session.recv_line(self.prompt,timeout=20)
            self.session.send_line("echo '        keyexchange=ikev2' >> /etc/ipsec.conf")
            self.session.recv_line(self.prompt,timeout=20)
            self.session.send_line("echo '        left= {}' >> /etc/ipsec.conf".format(left_ip))
            self.session.recv_line(self.prompt,timeout=20)
            if mode == "tunnel":
                self.session.send_line("echo '        leftsubnet= {}/24' >> /etc/ipsec.conf".format(left_subnet))
                self.session.recv_line(self.prompt,timeout=20)
            if mode == "tunnel":
                self.session.send_line("echo '        leftid= {}' >> /etc/ipsec.conf".format(left_id))
                self.session.recv_line(self.prompt,timeout=20)
            self.session.send_line("echo '        leftfirewall=yes' >> /etc/ipsec.conf")
            self.session.recv_line(self.prompt,timeout=20)
            self.session.send_line("echo '        right= {}' >> /etc/ipsec.conf".format(right_ip))
            self.session.recv_line(self.prompt,timeout=20)
            if mode == "tunnel":
                self.session.send_line("echo '        rightsubnet= {}/24' >> /etc/ipsec.conf".format(right_subnet))
                self.session.recv_line(self.prompt,timeout=20)
            if mode == "tunnel":
                self.session.send_line("echo '        rightid= {}' >> /etc/ipsec.conf".format(right_id))
                self.session.recv_line(self.prompt,timeout=20)
            self.session.send_line("echo '        type= {}' >> /etc/ipsec.conf".format(mode))
            self.session.recv_line(self.prompt,timeout=20)

            logger.dumpLog("Creating the IPsec secrets file")
            self.session.send_line("echo '' > /etc/ipsec.secrets")
            self.session.recv_line(self.prompt,timeout=20)
            self.session.send_line("echo '{} {} : PSK {}' >> /etc/ipsec.secrets".format(local_ip, remote_ip, pwd))
            self.session.recv_line(self.prompt,timeout=20)
        except Exception as err:
            logger.dumpLog("{}".format(err))
            result_dict["result"] = "fail"
        return result_dict

    def stop_ipsec(self):
        """
        To stop the Ipsec tunnel
        Args:
            None
        Returns:
            result_dict["result"]:pass/fail
        """
        result_dict = {}
        result_dict["result"] = "pass"
        try:
            op = self.session.send_recv("ipsec stop",timeout=5)
            status = re.search(r'Stopping strongSwan IPsec', op)
            if status != None:
                logger.dumpLog("Ipsec stopped successfully")
            else:
                logger.dumpLog("Faild to stopped ipsec")
                result_dict["result"] = "fail"
           #op1 = self.session.send_recv("ipsec status")
           #status1= re.search(r'', op1)
           #if status1!= None:
           #    logger.dumpLog("Ipsec stopped")
           #else:
           #    logger.dumpLog("Faild to stop")
           #    result_dict["result"] = "fail"
        except Exception as err:
            logger.dumpLog("{}".format(err))
            logger.dumpLog("Failed to stop ipsec")
            result_dict["result"] = "fail"
        return result_dict

    def check_ipsec_status(self):
        """
        TO check the status of Ipsec
        Args:
            None
        Returns:
            result_dict["result"]=pass/fail
        """
        result_dict = {}
        result_dict["result"] = "pass"
        try:
            for i in range(0,2):
                opt = self.session.send_recv("ipsec status", timeout=5)
                continue
                status1 = re.search(r'.*(ESTABLISHED).* && .*(INSTALLED, TUNNEL, reqid 1, ESP SPIs).* | .*[\d+.\d+.\d+.\d+].* === [\d+.\d+.\d+.\d+].*', opt)
                if status1 != None:
                    logger.dumpLog("IPsec tunnel connecting successfully")
                    time.sleep(2)
                else:
                    logger.dumpLog("Failed to connect Ipsec tunnel")
                    result_dict["result"] = "fail"
        except Exception as err:
            logger.dumpLog("{}".format(err))
            logger.dumpLog("Failed to connect Ipsec tunnel")
            result_dict["result"] = "fail"
        return result_dict

    def static_ipv6(self,iface=None,ip_addr=None,prefix_lengh=None):
        """
        To start static ipv6 at wan
        Args:
            iface(str):wan interface
            ip_addr(str):wan ipv6 addr
            prefix_lengh(str):wan ipv6 prefixlengh
            
        return:
            result["result"]:pass/fail
        """
        result_dict = {}
        result_dict["result"] = "pass"
        try:
            self.session.send_line("echo 'auto {}' > /etc/network/interfaces".format(iface))
            self.session.recv_line(self.prompt,timeout=20)
            self.session.send_line("echo 'ifconfig {} inet6' > /etc/network/interfaces".format(iface))
            self.session.recv_line(self.prompt,timeout=20)
            self.session.send_line("echo '           address {}' > /etc/network/interfaces".format(ip_addr))
            self.session.recv_line(self.prompt,timeout=20)
            self.session.send_line("echo '           prefix_lengh {}' > /etc/network/interfaces".format(prefix_lengh))
            self.session.recv_line(self.prompt,timeout=20)
            self.session.send_line("echo '           pre-up modprobe ipv6' > /etc/network/interfaces")
            self.session.recv_line(self.prompt,timeout=20)
            self.session.send_line("echo '           up echo 1> /proc/sys/net/ipv6/conf/all/forwarding' > /etc/network/interfaces")
            self.session.recv_line(self.prompt,timeout=20)
            self.session.send_line("echo '           up echo 0> /proc/sys/net/ipv6/conf/all/autoconf' > /etc/network/interfaces")
            self.session.recv_line(self.prompt,timeout=20)
        except Exception as err:
            logger.dumpLog("{}".format(err))
            result_dict["result"] = "fail"
        return result_dict

    def start_static_ipv6(self, iface=None, ip_addr=None, prefix_lengh=None):
        """
        To start static ipv6 at dut
        Args:
            iface(str):dut interface
            ip_addr(str):dut ipv6 addr
            prefix_lengh(str):dut ipv6 prefixlengh
        return:
            result["result"]:pass/fail
        """
        result_dict = {}
        result_dict["result"] = "pass"
        try:
            self.session.send_line("ip addr add {}/{} dev {}".format(ip_addr,prefix_lengh,iface))
            self.session.recv_line(self.prompt,timeout=20)
        except Exception as err:
            logger.dumpLog("{}".format(err))
            result_dict["result"] = "fail"
        return result_dict

    def static_route6_add(self, iface=None, ip_addr=None, prefix_lengh=None, gw_addr=None)
        """
        To add IPv6 static route at dut
        Args:
            iface(str):dut interfcae
            ip_addr(str):dut ipv6 addr
            prefix_lengh:dut ipv6 prefixlengh
        """
        result_dict = {}
        result_dict["result"] = "pass"
        try:
           self.session.send_line("/sbin/route -A inet6 add {}/{} gw {} dev {}".format(ip_addr,prefix_lengh,gw_addr,iface))
           self.session.recv_line(self.prompt,timeout=20)
        except Exception as err:
           logger.dumpLog("{}".format(err))
           result_dict["result"] = "fail"
        return result_dict

    def static_route6_del(self, iface=None, ip_addr=None, prefix_lengh=None, gw_addr=None)
        """
        To del IPv6 static route at dut
        Args:
            iface(str):dut interfcae
            ip_addr(str):dut ipv6 addr
            prefix_lengh:dut ipv6 prefixlengh
        """
        result_dict = {}
        result_dict["result"] = "pass"
        try:
           self.session.send_line("/sbin/route -A inet6 del {}/{} gw {} dev {}".format(ip_addr,prefix_lengh,gw_addr,iface))
           self.session.recv_line(self.prompt,timeout=20)
        except Exception as err:
           logger.dumpLog("{}".format(err))
           result_dict["result"] = "fail"
        return result_dict

    def stop_static_ipv6(self, iface=None, prefix_lengh=None, ip_addr=None):
        """
        To stop static ipv6 at dut
        Args:
            iface(str):dut interface
            prefix_lengh:dut ipv6 prefixlengh
            ip_addr(str):dut ipv6 addr
        return:
            result["result"]:pass/fail
        """
        result_dict = {}
        result_dict["result"] = "pass"
        try:
            self.session.send_line("ip addr del {}/{} dev {}".format(ip_addr,prefix_lengh,iface))
            self.session.recv_line(self.prompt,timeout=20)
        except Exception as err:
            logger.dumpLog("{}".format(err))
            result_dict["result"] = "fail"
        return result_dict

    def check_ipv6(self, iface=None):
        """
        To check ipv6
        Args:
            iface(str):wan interface
            ip_addr(str):wan ipv6 addr
        return:
            result["result"]:pass/fail
        """
        result_dict = {}
        result_dict["result"] = "pass"
        try:
            self.session.send_line("ifconfig {} down".format(iface))
            self.session.recv_line(self.prompt,timeout=20)
            self.session.send_line("ifconfig {} up".format(iface))
            self.session.recv_line(self.prompt,timeout=20)
        except Exception as err:
            logger.dumpLog("{}".format(err))
            result_dict["result"] = "fail"
        return result_dict

    def add_v6_brlan(self, ip_addr=None, br_name=None):
        """
        To add the ipv6 address to br-lan interface at dut 
        Args:
            ip_addr(str):ipv6 ip address                 
            br_name(str):br-lan interface                  
        Returns:
            return_dict['result']:pass/fail
        """
        result_dict = {}
        result_dict["result"] = "pass"
        try:
            op = self.session.send_recv("ifconfig br-lan",timeout=20)
            status = re.search(r'Scope:Global',op)
            if status != None:
                logger.dumpLog("The ipv6 address is already present")
            elif status == None:
                logger.dumpLog("adding ipv6 address")
                self.session.send_line("ip addr add {} dev {}".format(ip_addr,br_name))
                self.session.recv_line(self.prompt,timeout=20)
        except Exception as err:
            logger.dumpLog("{}".format(err))
            result_dict["result"] = "fail"
        return result_dict

    def del_v6_brlan(self, ip_addr=None, br_name=None):
        """
        To del the ipv6 address to br-lan interface at dut 
        Args:
            ip_addr(str):ipv6 ip address
            br_name(str):br-lan interface                  
        Returns:
            return_dict['result']:pass/fail
        """
        result_dict = {}
        result_dict["result"] = "pass"
        try:
            self.session.send_line("ip addr del {} dev {}".format(ip_addr,br_name))
            self.session.recv_line(self.prompt,timeout=20)
            op = self.session.send_recv("ifconfig br-lan",timeout=20)
            status = re.search(r'Scope:Global',op)
            if status == None:
                logger.dumpLog("The ipv6 address is removed successfully")
            else:
                logger.dumpLog("ipv6 address is not removed")
                result_dict["result"] = "fail"
        except Exception as err:
            logger.dumpLog("{}".format(err))
            result_dict["result"] = "fail"
        return result_dict

    def enable_v6(self):
        """
        To enable the ipv6 address of br-lan interface at dut 
        Args:
            None               
        Returns:
            return_dict['result']:pass/fail
        """
        result_dict = {}
        result_dict["result"] = "pass"
        try:
            op = self.session.send_recv("sysctl -w net.ipv6.conf.all.disable_ipv6=0")
            status = re.search(r'disable_ipv6 = 0',op)
            if status != None:
                logger.dumpLog("enabled ipv6 {}".format(status.group()))
            else:
                logger.dumpLog("failed to enable the ipv6")
        except Exception as err:
            logger.dumpLog("{}".format(err))
            result_dict["result"] = "fail"
        return result_dict
        
    def disable_v6(self):
        """
        To disable the ipv6 address of br-lan interface at dut
        Args:
            None               
        Returns:
            return_dict['result']:pass/fail
        """
        result_dict = {}
        result_dict["result"] = "pass"
        try:
            op = self.session.send_recv("sysctl -w net.ipv6.conf.all.disable_ipv6=1")
            status = re.search(r'disable_ipv6 = 1',op)
            if status != None:
                logger.dumpLog("disabled ipv6 {}".format(status.group()))
            else:
                logger.dumpLog("failed to disable the ipv6")
        except Exception as err:
            logger.dumpLog("{}".format(err))
            result_dict["result"] = "fail"
        return result_dict

    def test_func(self):
        self.logger.dumpLog("Inside class %s" % self.__class__.__name__)
        self.logger.warning("Inside class %s" % self.__class__.__name__)
        self.test_func2()
        return True

    def test_func2(self):
        self.logger.error("Inside class %s" % self.__class__.__name__)
        print ("test_func2(): Inside class %s" % self.__class__.__name__)
        return True

if __name__ == "__main__":
    obj = PlatformLinux('127.0.0.1', 'cyan', 'lan')
    obj.test_func()
