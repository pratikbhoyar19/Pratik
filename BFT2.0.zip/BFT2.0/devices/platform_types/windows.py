''' Class defination for windows OS'''
__author__ = 'Intel Corporation'
__copyright__ = 'Copyright 2019, Intel Corporation'
__version__ = '0.0.1'
__maintainer__ = 'Mirafra'
__email__ = 'framework@mirafra.com'
__status__ = 'Development'

import sys
import os
import time
import atexit
from termcolor import colored, cprint
from datetime import datetime
import re
from globalVariables import *
from lib.common import *
from devices.platform_types.netdevices import *
import xml.etree.cElementTree as ET

class PlatformWindows(PlatformTool):
    '''
    A class used to represent a Windows device

    ...

    Attributes
    ----------
    version : OS version

    -------
    get_ip_addr()
        Get the ip address of the device.
    Methods
    start_ping(ip_addr)
        Ping to the specified ip_addr and checks it's success.
    '''
    prompt = ['root\\@.*:.*#', '/ # ', ".*:~ #",'.*:~ >', '.*\\@.*:.*>', '.*:~ >', '.*:~.*\\$', '.*\\@.*:.*\\$']
    def __init__(self,
                 name,
                 color,
                 output=sys.stdout,
                 reboot=False,
                 location=None,
                 pre_cmd_host=None,
                 cmd=None,
                 post_cmd_host=None,
                 post_cmd=None,
                 cleanup_cmd=None):

        '''Device initialization'''

        self.name = name
        self.color = color
        self.output = output
        self.reboot = reboot
        self.location = location
        self.pre_cmd_host= pre_cmd_host
        self.cmd = cmd
        self.post_cmd_host = post_cmd_host
        self.post_cmd = post_cmd
        self.cleanup_cmd = cleanup_cmd

    def config_update(self, traffic=None, transport=None, session=None, tools=None,
                      device_dict=None, dname=None):
        '''Get the traffic tool and interact tool handle'''
        if self.name is not None:
            self.traffic = traffic
            self.transport = transport
            self.session = session
            self.tools = tools
            self.dict = device_dict
            self.dname = dname

        if self.name is not  None:
            self.transport.connect()
        else:
            if self.pre_cmd_host != 'None':
                sys.stdout.write("\tRunning pre_host_cmd.... ")
                sys.stdout.flush()
                self.session.exec_cmd_host('bash', self.pre_cmd_host)
                phc = self.session.recv_line(self.prompt, eof=True, timeout=120)
                print("\tpre_host_cmd done")

            if self.cleanup_cmd != 'None':
                atexit.register(self.run_cleanup_cmd)

            command = eval("'-c', %s" % (self.cmd))
            self.session.exec_cmd_host('bash', command)

        cprint("(%s - %s) device console = %s" % (self.dname, self.name, colored(str(self.color), self.color)), None, attrs=['bold'])
        ping_ip.append(self.name)
        dev_ip_obj.append(self.dname)

        if self.post_cmd_host != 'None':
            sys.stdout.write("Running post_cmd_host.... ")
            sys.stdout.flush()
            self.session.exec_cmd_host('bash', self.post_cmd_host)
            i = self.session.recv_line('password', eof=True, timeout_err=True)
            if i > 0:
                print("\tpost_cmd_host did not complete, it likely failed\n")
            else:
                print("\tpost_cmd_host done")

        if self.post_cmd != 'None':
            self.session.send_line(self.post_cmd)
            self.session.recv_line(self.prompt)

        if self.reboot:
            #self.reset()
            pass

        self.logfile_read = self.output

    def run_cleanup_cmd(self):
        sys.stdout.write("Running cleanup_cmd on %s..." % self.name)
        sys.stdout.flush()
        self.session.exec_cmd_host('bash', self.cleanup_cmd)
        cc = self.session.recv_line(eof=True, timeout=120)
        print("cleanup_cmd done.")

    def xml_creator(self,profile_name='WLANProfile',ssid_name="intel",ens_cap="none"):
        '''Creates the xml profile for the ssid_name given and stores into the local copy
    	profile_name = Profile of the wlan usually WLANProfile
    	ssid_name = name of the Wlan ap to be connected
    	ens_cap = ennacpsulation type used for the connection'''

        root = ET.Element(profile_name,xmlns="http://www.microsoft.com/networking/WLAN/profile/v1")
        ET.SubElement(root, "name").text = ssid_name
        step1=ET.SubElement(root, "SSIDConfig")
        doc=ET.SubElement(step1, "SSID")
        a=ssid_name.encode('utf -8')
        ET.SubElement(doc, "hex").text = a.encode("hex").upper()
        #ET.SubElement(doc, "hex").text = ssid_hex.upper()
        ET.SubElement(doc, "name").text = ssid_name
        ET.SubElement(step1, "nonBroadcast").text = "false"
        ET.SubElement(root, "connectionType").text = "ESS"
        ET.SubElement(root, "connectionMode").text = "auto"
        step2=ET.SubElement(root, "MSM")
        doc1=ET.SubElement(step2, "security")
        doc2=ET.SubElement(doc1, "authEncryption")
        if ens_cap == "none":
            ET.SubElement(doc2, "authentication").text = "open"
        elif ens_cap == "psk2+aes":
            ET.SubElement(doc2, "authentication").text = "WPA2PSK"
        if ens_cap == "none":
            ET.SubElement(doc2, "encryption").text = "none"
        elif ens_cap == "psk2+aes":
            ET.SubElement(doc2, "encryption").text = "AES"
        ET.SubElement(doc2, "useOneX").text = "false"
        if ens_cap is not "none":
            doc3 = ET.SubElement(doc1, "sharedKey")
            ET.SubElement(doc3, "keyType").text = "passPhrase"
            ET.SubElement(doc3, "protected").text = "false"
            ET.SubElement(doc3, "keyMaterial").text = tsv_wlan_key
        tree = ET.ElementTree(root)
        filename=ssid_name + ".xml"
        #print(filename)
        try:
            tree.write(filename)
        except Exception as e:
            print (e)
            return False
        return True



    def reset(self):
        self.session.send_line('reboot')
        self.session.recv_line("'going down','disconnected'")
        try:
            self.session.recv_line(self.prompt, timeout=10)
        except:
            pass
        time.sleep(15)  # Wait for the network to go down.
        for i in range(0, 20):
            try:
                self.session.exec_cmd_host('bash', 'ping -w 1 -c 1 ' + self.name).session.recv_line('64 bytes', timeout=1)
            except:
                print(self.name + " not up yet, after %s seconds." % (i + 15))
            else:
                print("%s is back after %s seconds, waiting for network daemons to spawn." % (self.name, i + 14))
                time.sleep(15)
                break
        self.__init__(self.name, self.color,
                      self.output, self.dname,
                      reboot=False)

    def get_hostname(self):
        hostname = self.session.send_line("hostname", send_block = True)
        return hostname

    def get_os_info(self):
        self.session.send_line("ver")
        self.session.recv_line("(?i)(windows)")
        os_info=self.session.match(1)
        return os_info

    def get_interface_ipaddr(self, interface, ipv6_enable=False, netmask=""):
        try:
            if ipv6_enable:
                '''To get the interface IP/IPv6 IP address in device
                    Arguments: interface - This argument is the interface name
                '''
                for i in range(0, 3):
                    try:
                        self.session.send_line("netsh interface ipv6 show address \"%s\"" % interface)
                        self.session.recv_line('%s.*?(.*)\%%s' %(interface, netmask), timeout=30)
                        ipaddr = self.session.match(1)
                        self.session.recv_line(self.prompt, timeout=30)
                        return ipaddr
                    except Exception as e:
                        self.logger.dumpLog("Interface does not exist [%s]" % str(e))
                        time.sleep(tsv_timeout)
                        return False
            else:
                try:
                    self.session.send_line("netsh interface ipv4 show address \"%s\"" % interface)
                    self.session.recv_line(
                        '%s.*?IP Address:\s+(\d{1,3}.\d{1,3}.\d{1,3}.\d{1,3}).*ubnet' % interface,
                        timeout=30)
                    ipaddr = self.session.match(1)
                    self.session.recv_line(self.prompt, timeout=30)
                    return ipaddr
                except BaseException:
                    self.logger.dumpLog("Interface does not exist")
                    return False
        except:
            return '0'


    def interface_up_down(self, interface=tsv_lan_host_eth_interface):
        '''To LAN interface UP and Down
           Argument: system    - This argument is the object where DSlite tunnel interface has to be removed, default object is lan
                     int_name  - This argument is the tunnel interface name, default name is tsv_lan_host_eth_interface'''

        self.session.send_line('netsh interface set interface name="%s" admin=DISABLED' % interface)
        self.session.send_line('netsh interface set interface name="%s" admin=ENABLED' % interface)
        return True


    def start_ping(self, ping_count=tsv_ping_count,
                   ip=tsv_bridge_untagged_static_ip):
        '''To start ping traffic from node
           Arguments: percent    - This argument is the packet loss percentage
                      node       - This argument is the object where ping traffic has to start, default object is lan
                      ping_count - This argument is the ping count value, default value is tsv_ping_count
                      ip         - This argument is the IP address to which has to ping, default IP is tsv_bridge_untagged_static_ip'''
        self.session.send_line('ping -n %s %s' % (ping_count, ip))
        try:
            self.session.recv_line('(\d+)% loss', timeout=30)
            # percent[0] = int(self.session.match(1))
            return True
        except BaseException:
            return False


    def start_ping_p(self, ping_count=tsv_ping_count, ip=tsv_bridge_untagged_static_ip):
        '''To start ping traffic from node
           Arguments: node       - This argument is the object where ping traffic has to start, default object is lan
                      ip         - This argument is the IP address to which has to ping, default IP is tsv_bridge_untagged_static_ip
                      ping_count - This argument is the ping count value, default value is tsv_ping_count'''
        fail_count=0
        for i in range(0,5):
            self.session.send_line('ping -n %s %s' % (ping_count, ip))
            try:
                self.session.recv_line('((\d+)% loss)', timeout=30)
                percent = int(self.session.match(2))
                if percent == 100:
                    fail_count = fail_count + 1
                    continue
                else:
                    break
            except BaseException:
                fail_count = fail_count + 1
                continue
        if fail_count >=5:
            return False
        else:
            return True

    def remove_server_report(self):#"tsv_win_rpt_path":"C:\\Users\\mirafra",
        self.session.send_line("del %s\\%s" %(tsv_win_rpt_path,tsv_server_report_name))
        self.session.recv_line(self.prompt, timeout=30)
        return True

    def remove_client_report(self):#"tsv_win_rpt_path":"C:\\Users\\mirafra",
        self.session.send_line("del %s\\%s" %(tsv_win_rpt_path,tsv_server_report_name))
        self.session.recv_line(self.prompt, timeout=30)
        return True

    def stop_trafficgen_mpstat(self):
        '''To stop the mpstat in system
           Arguments: system      - This argument is the object where the mpstat has to stop, default object is wan'''
        self.session.send_line('taskkill /F /IM iperf.exe')
        self.session.recv_line(self.prompt, timeout=30)
        return True


    def parse_iperf_server_report(self, proto=tsv_proto_tcp, report_name=tsv_server_report_name):
        '''To parse Iperf server reports
           Arguments: system        - This argument is the object where Iperf server reports has to record, default object is lan
                      report_name   - This argument is the server report name'''
        self.logger.dumpLog("parsing REG EXPRESSION in iperf traffic generator report")
        try:
            self.session.send_control('c')
            for i in range(0,5):
                self.session.send_line("type %s\\%s" %(tsv_win_rpt_path,report_name))
                try:
                    self.session.recv_line("(\d+(.\d+)?)\s+(\S)bits/sec",timeout=30)
                    break
                except:
                    sleep(10)

            rate=float(self.session.match(1))
            th = self.session.match(3)
            if th == 'K':
                rate = rate / 1000;
            elif th == 'G':
                rate = rate * 1000;
        except:
            self.logger.dumpLog("parsing REG EXPRESSION in iperf traffic genertor failed")
            return False

        self.logger.dumpLog("parsing REG EXPRESSION in iperf traffic genertor and op is %s" %rate)
        return rate


    def assign_dhcp_ip(self, wlan_iface=tsv_wlan_host_iface):
        return True

    def copy_from(self, local_path="", remote_path=""):
        if not self.session.copy_frm_cmd(local_path=local_path, remote_path=remote_path):
            return False
        return True


    def kill_proc(self, cmd):
        '''
        Kill the command running in the device.

        Args:
            cmd - cmd to be killed

        Returns:
            True/False
        Raises:
            None
        '''

        ## For Windows 10 Pro: Add additional space at start and striping the redirect operation
        cmd = re.sub(' ','  ', cmd, count=1)
        cmd = re.sub('>.*','',cmd)

        ##@ For Windows 10 Enterprise: Substitute '\' with '\\' required
        #cmd = re.sub(r'\\', r'\\\\', cmd, flags=re.M)
        #self.session.send_recv ('wmic process where (CommandLine ="C:\WINDOWS\system32\cmd.exe /c iperf -s  -f m  -i 1  -w 64K -p10001  > C:\\\\Users\\\\blrcom\\\\iperflogs_pair1_from_lan_to_sta1_step1_server.txt") get processId')

        ## Get the process id for the command executed
        match_pat = '(\d+)'
        cmd_output = self.session.send_recv('c:/windows/system32/wbem/wmic process where (CommandLine ="' + cmd + '") get processId')
        proc_id_list = re.findall(match_pat, cmd_output, re.DOTALL)
        if len(proc_id_list) == 0:
            logger.warning('Regexp match failed.\n Pattern: {0}\n Output: {1}'.format(match_pat, cmd_output))
            return False
        else:
            for proc_id in proc_id_list:
                cmd_output = self.session.send_recv('taskkill /t /f /pid {0}'.format(proc_id))

        return True


    def test_func(self):
        print("method inside in this class %s" % self.__class__.__name__)


if __name__ == "__main__":
    obj = PlatformWindows('127.0.0.1', 'cyan', 'lan')
    obj.test_func()
