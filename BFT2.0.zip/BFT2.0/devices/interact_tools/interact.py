''' Class defination for interaction tool.'''
__author__ = "Intel Corporation"
__copyright__ = "Copyright 2019, Intel Corporation"
__version__ = "0.0.1"
__maintainer__ = "Mirafra"
__email__ = "framework@mirafra.com"
__status__ = "Development"
###########################################################


class InteractTool:
    '''
    A class used to represent interaction tool

    ...

    Attributes
    ----------


    Methods
    -------
    '''

    def exec_cmd_host(self, transport, cmd):
        '''Execute the command in the bash mode'''
        pass

    def send_control(self, cmd):
        '''send control command to the session'''
        pass

    def send_line(self, line, send_block=False):
        '''send command line to the session '''
        pass

    def recv_line(self, prompt, timeout=None, eof=False, timeout_err=False, exact=False):
        '''receive the expected prompt from the session'''
        pass

    def match(self, groupid):
        pass

    def test_func(self):
        print("method inside in this class %s" % self.__class__.__name__)


if __name__ == "__main__":
    obj = InteractTool()
    obj.test_func()
