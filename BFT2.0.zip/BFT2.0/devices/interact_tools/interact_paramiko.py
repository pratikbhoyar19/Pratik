''' Class defination for paramiko tool.'''
__author__ = "Intel Corporation"
__copyright__ = "Copyright 2019, Intel Corporation"
__version__ = "0.0.1"
__maintainer__ = "Mirafra"
__email__ = "framework@mirafra.com"
__status__ = "Development"
###########################################################
import paramiko
import re
import os
import time
import socket
import sys

from log_creator import loggerObject as logger
from devices.interact_tools.interact import *
from datetime import datetime
from config import output_dir
from termcolor import cprint


class InteractParamiko(InteractTool):
    '''
    A class used to represent interaction tool for Paramiko

    ...

    Attributes
    ----------


    Methods
    -------
    '''

    def __init__(self, platform_type=None, color=None, name=None):
        """
        The constructor for Paramiko interactive class
        Args:
           platform_type: Specify the platform of the device(Linux/Windows)
           name: Specify the name of the device(lan/wlan/wan)
        Returns:
           None
        """

        self.platform_type = platform_type
        self.color = color
        self.name = name
        self.line_seperator = '\r\n'
        self.CR = '\r'
        #self.line_seperator = os.linesep
        self.prompt = None
        self.shell_dict = {}
        self.shell_id = 9875
        self.output_dir = output_dir

    def config_update(self, os_handle=None, device_dict=None):
        self.os = os_handle
        self.dict = device_dict

    def flush_buffer(self):
        """
        The function to flush the buffer contents of previous command output
        Args:
           None
        Returns:
           None
        """

        #Not required as paramiko is blocked call
        pass

    def set_prompt(self, prompt=None):
        """
        The function used to get the device prompt
        Args:
           None
        Returns:
           None
        """

        #Not required as paramiko is blocked call
        self.prompt=prompt

    def create_session(self, transport=None, username=None,
                       password=None, ipaddr=None, port=None, timeout=30, conn_cmd=None):
        """
        The function Initialize the session based on the transport type (eg: bash,ssh,telnet ..etc)
        Args:
          ipaddr : ipaddres used to connect to device
          port   : Port used for the ssh connection
          timeout : time to be waited before the connection termination
          username : Username to login the device
          password : Password to login the device
        Returns:
           Device handler for a ssh connectivity
        Raises:
           Exception will be raised specifing the type of connection Error
        """
        self.ipaddr = ipaddr
        self.username = username
        self.password = password
        self.port = port
        self.timeout = timeout
        self.interact= paramiko.SSHClient()
        self.interact.set_missing_host_key_policy(paramiko.AutoAddPolicy())

        try:
            self.interact.connect(self.ipaddr,username=self.username,password=self.password,port=self.port,timeout=self.timeout)
            # Send TCP keepalive packets every 20 seconds
            self.interact.get_transport().set_keepalive(20)
            # Create the required log files
            self.create_logfile(output_dir = self.output_dir)

        except paramiko.AuthenticationException:
            raise Exception("Authentication failed, please verify your credentials for: %s"% self.ipaddr)
        except paramiko.SSHException as sshException:
            raise Exception("Unable to establish SSH connection: %s" % sshException)
        except paramiko.BadHostKeyException as badHostKeyException:
            raise Exception("Unable to verify server's cmd_outputhost key: %s" % badHostKeyException)
        except Exception as e:
            #print 'Exception raised:', e
            self.interact.close()
            raise Exception(e)

    def send_recv(self, cmd,timeout=30):
        """
        The function used to Execute the command; wait for the device prompt;
        return output of the command. Returned output should not have any kernel messages
        Args:
          cmd: Command to be executed
          timeout: time before raising an Expection
        Returns:
          Output of the command executed
        Raises:
          timeour Error
        """

        try:
            return self.exec_cmd_log(cmd,timeout,'send_recv')
        except Exception as e:
            print(e)
            return False

    def send_line(self, cmd, send_block=False, timeout=30):
        """
        The function used to send command to the session
        Shall become obselete in later releases. Please refrain from using it
        Args:
           cmd : Command that needs to be executed
           send_block: True|False
                True: Behaves like a blocked call, Returns the output of the command
                False: Behaves like a non-blocked call, just sends the cmd and waits to expect
           timeout: time waited before rasing an expection
        Returns:
           Output of a command for a Blocked call
           True|False for a unBlocked call
        Raises:
           Raises timeout Exception on command failure

        """
        cmd = cmd.strip('\r\n')
        try:
            #new logic for handling block sessions
            if send_block:
                cmd_split = cmd.split()
                if cmd_split[0] not in ['kill']:
                    dev_shell = self.interact.invoke_shell()
                    #print("dev_shell is %s" %dev_shell)
                    dev_shell.settimeout=timeout
                    dev_shell.send("\r")
                    dev_shell.recv(9999)
                    cmd=cmd+"\r"
                    dev_shell.send(cmd.encode())
                    self.shell_id = self.shell_id + 1
                    self.shell_dict[self.shell_id] = dev_shell
                    return self.shell_id
                else:
                    dev_shell = self.shell_dict[int(cmd_split[-1])]
                    dev_shell.close()
                    self.shell_dict.pop(int(cmd_split[-1]))
                    del(dev_shell)
            else:
                self.cmd_output = self.exec_cmd_log(cmd, timeout, 'send_line')

        except Exception as err:
            print(str(err))
            return False


    def send_cmd(self, cmd, out_file = None, timeout = 30):
        '''
        This Function used to create a new session for the device and
            executes the command
        Args:
            cmd - command to be executed
            file_name(optional) - Name of the file to store output

        Return:
            process_id/id of the command executed.
            This shall be used later for fetching the output.
        Raises:
            Raises an SSH Exception
        '''
        ## If file_name specified
        #Push the output to the file of the device

        ## If file_name not specified
        #Store the output to the object variable.
        # Create a new session to the device for cmd execution in fore-ground
        session_id = paramiko.SSHClient()
        session_id.set_missing_host_key_policy(paramiko.AutoAddPolicy())

        try:
            session_id.connect(self.ipaddr,username=self.username,password=self.password,port=self.port,timeout=self.timeout)
            # Send TCP keepalive packets every 20 seconds
            session_id.get_transport().set_keepalive(20)
        except paramiko.AuthenticationException:
            raise Exception("Authentication failed, please verify your credentials: %s"% self.host)
        except paramiko.SSHException as sshException:
            raise Exception("Unable to establish SSH connection: %s" % sshException)
        except paramiko.BadHostKeyException as badHostKeyException:
            raise Exception("Unable to verify server's host key: %s" % badHostKeyException)
        except Exception as e:
            print(e)

        logger.dumpLog('New session has been created')

        ## Update the cmd based on out_file parameter
        if out_file == None:
            session_id.out_file = None
        else:
            session_id.out_file = out_file
            cmd = cmd + '>' + out_file + '&'    ;# TODO Will change as per OS
        #cmd = re.sub(r'\\', r'\\\\', cmd, flags=re.M)
        session_id.cmd = cmd
        session_id.date_time_now = datetime.now()

        ## Execute the command
        session_id.stdin, session_id.stdout, session_id.stderr = session_id.exec_command(cmd,get_pty=True)
        return session_id


    def recv_cmd(self, session_id, timeout = 30):
        """
        This Function used to get the output from the session_id passed.
        session_id is created through send_cmd()

        Args:
            id - process_id/id of the command executed.

        Returns:
            Output from the file if specified in send_line()
            Else output of the command executed
        Raises:
            None
        """
        ## Kill the cmd executed and close the session
        if self.os.kill_proc(session_id.cmd) is True:
            session_id.close()
        else:
            err_msg = 'Could not kill the process {}. Continue ...'.format(session_id.cmd)
            logger.error(err_msg)
            while not session_id.stdout.channel.exit_status_ready():
                session_id.close()
                time.sleep(1)

        ## Get the output
        output = session_id.stderr.read()
        if output == '':
            output = session_id.stdout.read()

        ## Write to file/ print to console
        output_indent = re.sub('^','\t', output, flags=re.M)
        output = '\n[{}] [command] [{}] [recv_cmd] {}\n{}'.format(session_id.date_time_now, self.name, session_id.cmd, output_indent)
        output = output.strip('\t')
        self.interact.logfile.write('\n########## Executed in background - Start ##########')
        self.interact.logfile.write('\n%s' % (output))
        self.interact.logfile.write('\n########## Executed in background - End ##########')
        self.interact.logfile.flush()

        self.interact.logfile_send.write('\n*[%s] %s' % (session_id.date_time_now, session_id.cmd))
        self.interact.logfile_read.write('\n########## Executed in background - Start ##########')
        self.interact.logfile_read.write('\n[%s] %s\n%s' % (session_id.date_time_now, session_id.cmd, output_indent))
        self.interact.logfile_read.write('\n########## Executed in background - End ##########')

        cprint('\n########## Executed in background - Start ##########', color=self.color)
        cprint(output, color=self.color)
        cprint('\n########## Executed in background - End ##########', color=self.color)

        ## Delete the session object
        del(session_id)
        return output


    def send_control(self, control, timeout=30):

        """
        The function used to send control command to the session
        Args:
           None
        Returns:
           None
        """

        # TODO Hex and dump
        #value = ord(control) - 96
        #control_string = hex(value)[2:].upper()
        #control = "\\x0%s"%control_string
        #stdin, stdout, stderr = self.interact.exec_command(control)

        #stdin, stdout, stderr = self.interact.exec_command("\x03")
        try:
            stdin, stdout, stderr = self.interact.exec_command("\x03",timeout=timeout)
        except Exception as err:
            print("error %s" %str(err))
            return False
        return True


    def recv_line(self, pattern, timeout=30, eof=False, timeout_err=False, exact=False):
        """
        The function used to receive the expected pattern from the session
                Shall become obselete in later releases. Please refrain from using it
        Args:
           Pattern : Pattern passed to expect a match for the send_line command
           exact : Matches the exact match for the output
           timeout : time to wait for the pattern to match

        Returns:
           ret_flag: True|False
                 True: Returns True for a match
                 False: Returns False for a match
           Raises:
              Raises timeout Exception on failure of pattern match
        """

        #receive the expected prompt from the session
        if sorted(pattern) == sorted(self.prompt):
            return True
        else:
            self.ret_val = re.search(pattern, self.cmd_output, re.DOTALL)
            if self.ret_val:
                return True
            else:
                return False


    def match(self, groupid):
        """
        The function used to Grep the value based on the passed group id
        Args:
           Groupid: regular expression group match from receive_line pattern
        Returns:
           value of the group match
        Raises:
           REgex error on mismatch of groupid

        """

        val = self.ret_val.group(groupid)
        return val

    def before(self):
        """
        The function used to Store the value for the expected prompt
        Args:
          None
        Returns:
          None
        """
        # Not Required
        pass

    def set_window_size(self, x, y):
        """
        The function used to Set the window size for console
        Args:
          None
        Returns:
          None
        """
        # Not Required
        pass

    def close_session(self):
        """
        The function used to Close the current active session of the device
        Args:
          None
        Returns:
          None
        """
        if self.interact.get_transport().is_active():
            self.interact.close()

    def copy_frm_cmd(self, local_path="", remote_path=""):
        """
        This Function is absolte use upload_file or download_file methods
        """
        suc=False
        try:
            transport = paramiko.Transport((self.ipaddr, 22))
            transport.connect(username = self.username, password = self.password)
            sftp = paramiko.SFTPClient.from_transport(transport)
            sftp.put(remote_path,local_path)
            suc = True
            print("sftp cmd success")
        except Exception as e:
            print(str(e))
            print("sftp cmd in not success")
        sftp.close()
        transport.close()
        return suc


    def upload_file(self, local_filepath='', remote_filepath=''):
        """
         This method uploads the file to remote machine
           [Execution PC] --> [remote]
         Args:
           local_filepath: Execution PC's file path(/home/mirafra/iperf.txt)
           remote_filepath: Remote machine file path (/home/wlan/iperf.txt)
        Return:
           True: On successfull copy
           False: Error in copying
        """
        result_flag = True
        try:
            ftp_client= self.interact.open_sftp()
            ftp_client.put(local_filepath, remote_filepath)
            ftp_client.close()
        except Exception,e:
            print '\nUnable to upload the file to the remote server', remote_filepath
            print 'Error:', e
            result_flag = False

        ftp_client.close()
        return result_flag

    def download_file(self,remote_filepath='', local_filepath=''):
        """
        This method downloads file from remote machine to execution PC
           [Execution PC] <-- [remote]
        Args:
           local_filepath: Execution PC's file path(/home/mirafra/iperf.txt)
           remote_filepath: Remote machine file path (/home/wlan/iperf.txt)
        Return:
           True: On successfull copy
           False: Error in copying
        """

        result_flag = True
        try:
            ftp_client= self.interact.open_sftp()
            ftp_client.get(remote_filepath, local_filepath)
            ftp_client.close()
        except Exception,e:
            print '\nUnable to download the file from the remote server', remote_filepath
            print 'Error:',e
            result_flag = False

        ftp_client.close()
        return result_flag


    def create_logfile(self, output_dir = output_dir , device = None):
        #Update the log_dir to passed value
        self.output_dir = output_dir

        '''Create the files for logging the execution'''
        if hasattr(self.interact, 'logfile') is True:
            self.interact.logfile.close()
        exec ('self.interact.logfile = open(os.path.join(output_dir,\'' + 'test.log\'),' + '\'a+\')')
        #self.interact.logfile = logger.handlers[0].stream
        #self.interact.logfile_send.close()
        if hasattr(self.interact, 'logfile_send') is True:
            self.interact.logfile_send.close()

        exec ('self.interact.logfile_send = open(os.path.join(output_dir,\'' + self.name + '_cmd.log\'),' + '\'a+\')')
        #self.interact.logfile_read.close()
        if hasattr(self.interact, 'logfile_read') is True:
            self.interact.logfile_read.close()
        exec ('self.interact.logfile_read = open(os.path.join(output_dir,\'' + self.name + '.log\'),' + '\'a+\')')


    def close_logfile(self, output_dir = output_dir , device = None):
        '''Close the files'''
        if hasattr(self.interact, 'logfile') is True:
            self.interact.logfile.close()
        if hasattr(self.interact, 'logfile_send') is True:
            self.interact.logfile_send.close()
        if hasattr(self.interact, 'logfile_read') is True:
            self.interact.logfile_read.close()


    def exec_cmd_log(self, cmd,timeout=30, func_name=None):
        '''Execute a command on the remote host and get the output and the return it'''
        try:
            date_time_now = datetime.now()
            stdin, stdout, stderr = self.interact.exec_command(cmd.encode(),timeout)
            while not stdout.channel.exit_status_ready() and not stdout.channel.recv_ready():
                time.sleep(1)

            #Store output to variable.
            stderr_value = stderr.read()
            stdout_value = stdout.read()
            if stderr_value is '':
                output = stdout_value
            else:
                output = stderr_value

        except socket.timeout as e:
            print "Command timed out.", cmd
            output = e
        except paramiko.SSHException as e:
            print "Failed to execute the command!",cmd
            output = e
        finally:
            # Write to file/ print to console
            output_indent = re.sub('^','\t', output, flags=re.M)
            cmd_output = '\n[{}] [command] [{}] [{}] {}\n{}'.format(date_time_now, self.name, func_name, cmd, output_indent)
            cmd_output = cmd_output.strip('\t')
            self.interact.logfile.write('%s' % (cmd_output))
            self.interact.logfile.flush()
            self.interact.logfile_send.write('\n[%s] %s' % (date_time_now, cmd))
            self.interact.logfile_read.write('\n[%s] %s\n%s' % (date_time_now, cmd, output_indent))
            cprint(cmd_output, color=self.color)
            return output

    def get_log_dir(self):
        '''Returns the current directory'''
        return self.output_dir

    def test_func(self):
        self.logger.dumpLog("Inside class %s" % self.__class__.__name__)
        self.logger.warning("Inside class %s" % self.__class__.__name__)
        self.logger.error("Inside class %s" % self.__class__.__name__)
        print ("test_func(): Inside class %s" % self.__class__.__name__)


if __name__ == "__main__":
    obj = InteractParamiko()
    obj.test_func()
    obj.create_session()
    a = obj.send_recv('uname')
    print(a)
    obj.send_line('date')
    obj.recv_line('Fri Feb (.*)')
    a= obj.search(1)
    print(a)
    a=obj.send_cmd('date')
    print(a)
    b=obj.recv_cmd(a)
    print(b)
