''' Class defination for Pexpect tool.'''
__author__ = "Intel Corporation"
__copyright__ = "Copyright 2019, Intel Corporation"
__version__ = "0.0.1"
__maintainer__ = "Mirafra"
__email__ = "framework@mirafra.com"
__status__ = "Development"
###########################################################
import pexpect
import re
import os
import time

from termcolor import cprint
from devices.interact_tools.interact import *
from datetime import datetime
from config import output_dir

class InteractPexpect(InteractTool):
    '''
    A class used to represent interaction tool for Pexpect

    ...

    Attributes
    ----------


    Methods
    -------
    '''

    def __init__(self, platform_type=None, color=None, name=None):
        """
        The constructor for Pexpect interactive class
        Args:
           platform_type: Specify the platform of the device(Linux/Windows)
           name: Specify the name of the device(lan/wlan/wan)
        Returns:
           None
        """

        self.platform_type = platform_type
        self.color = color
        self.name = name
        self.line_seperator = '\r\n'
        #self.line_seperator = os.linesep
        self.prompt = ['root\\@.*:.*#', '/ # ', ".*:~ #",'.*:~ >', '.*\\@.*:.*>', '.*:~ >', '.*:~.*\\$', '.*\\@.*:.*\\$']
        self.output_dir = output_dir
        self.match_output = None
        self.recv_line_prompt = None

    def config_update(self, os_handle=None, device_dict=None):
        self.os = os_handle
        self.dict = device_dict

    def flush_buffer(self):
        """
        The function to flush the buffer contents of previous command output
        Args:
           None
        Returns:
           None
        """
        self.interact.expect([pexpect.TIMEOUT], timeout =1)
        self.interact.expect(r'.*$')

    def recv_line2(self):
        '''Return the buffer content'''
        self.interact.expect([pexpect.TIMEOUT, r'.*EOF'], timeout = 1)
        ret_val = self.interact.buffer
        self.interact.expect(r'.*')
        match_pat = '(.*)' + self.prompt
        match = re.search(match_pat, ret_val, re.DOTALL)
        if match:
            ret_val = match.group(1)
            #print '###### Return Value is {0}'.format(match.group(1))
        return ret_val

    def set_prompt(self,prompt=None):
        """
        The function used to get the device prompt
        Args:
           None
        Returns:
           None
        """
        pass
        #self.interact.expect([pexpect.TIMEOUT], timeout=1)
        #self.interact.sendline('')
        #self.interact.expect([pexpect.TIMEOUT, r'.*'], timeout=1)
        #self.interact.expect([pexpect.TIMEOUT], timeout=1)
        #self.interact.sendline('')
        #self.interact.expect([pexpect.TIMEOUT, r'.*'], timeout=1)
        #self.prompt = self.interact.after

    def create_handle(self):
        """
        The function Initialize the session based on the transport type (eg: bash,ssh,telnet ..etc)
        Args:
           ipaddr : ipaddres used to connect to device
           port   : Port used for the ssh connection
           timeout : time to be waited before the connection termination
           username : Username to login the device
           password : Password to login the device
        Returns:
           Device handler for a ssh connectivity
        Raises:
           Exception will be raised specifing the type of connection Error
        """
        if self.transport == "ssh":
            if self.conn_cmd == 'None':
                cmd = eval("'%s@%s', '-p', '%s', '-o', 'StrictHostKeyChecking=no', '-o', 'UserKnownHostsFile=/dev/null'" % (self.username, self.ipaddr, self.port))
            else:
                cmd = self.conn_cmd
            pexpect_handle = pexpect.spawn(command=self.transport, args=list(cmd))
            # Decorate the pexpect.sendline for logging
            pexpect_handle.sendline = self.log_decorator(pexpect_handle.sendline)
            pexpect_handle.expect_exact = self.log_console_decorator(pexpect_handle.expect_exact)
            pexpect_handle.expect = self.log_console_decorator(pexpect_handle.expect)

            self.interact = pexpect_handle

            # Create the required log files
            self.create_logfile(output_dir= self.output_dir)

            try:
                result = pexpect_handle.expect([".*yes/no", ".*assword:", ".*Last login", pexpect.TIMEOUT, pexpect.EOF])
                if result == 0:
                    pexpect_handle.sendline("yes")
            except Exception as e:
                raise Exception("Device is in use (connection refused).")

            self.prompt = ['root\\@.*:.*#', '/ # ', ".*:~ #",'.*:~ >', '.*\\@.*:.*>', '.*:~ >', '.*:~.*\\$', '.*\\@.*:.*\\$']
            if result == 1 or result == 2:
                #assert self.password is not None, "Please add self.password in your json configuration file."
                pexpect_handle.sendline(self.password)
                pexpect_handle.expect(self.prompt,timeout=30)

        elif self.transport == "serial":
            try:
                if self.conn_cmd is not None:
                    cmd = eval("'-c', '%s'" % self.conn_cmd)

                    pexpect_handle = pexpect.spawn("/bin/bash", args=list(cmd))

                    try:
                        pexpect_handle.sendline("\n\n")
                        if 'cu' in self.conn_cmd:
                            result = pexpect_handle.expect([".*Connected.*", "----------------------------------------------------"])
                        if 'screen' in self.conn_cmd:
                            result = pexpect_handle.expect(".*:~#.*")
                    except Exception as e:
                        raise Exception("Board is in use (connection refused).")
            except Exception as err:
                raise Exception("Issue: '%s', when serial connection used." % err)

        elif self.transport == "telnet":
            pass
        else:
            pass

        # Set the prompt
        pexpect_handle.sendline('')
        pexpect_handle.expect([pexpect.TIMEOUT, r'.*'], timeout=1)
        pexpect_handle.expect([pexpect.TIMEOUT], timeout=1)
        pexpect_handle.sendline('')
        pexpect_handle.expect([pexpect.TIMEOUT, r'.*'], timeout=1)
        pexpect_handle.prompt = pexpect_handle.after.strip(self.line_seperator)

        return pexpect_handle


    def send_line(self, line, send_block=False):
        """
        The function used to send command to the session
                Shall become obselete in later releases. Please refrain from using it
        Args:
           cmd : Command that needs to be executed
           send_block: True|False
                True: Behaves like a blocked call, Returns the output of the command
                False: Behaves like a non-blocked call, just sends the cmd and waits to expect
        Returns:
           Output of a command for a Blocked call
           True|False for a unBlocked call
        Raises:
           Raises timeout Exception on command failure
        """

        if send_block is False:
            self.interact.sendline(line)
        elif send_block is True:
            self.interact.expect(r'.*')
            self.interact.sendline(line)
            #self.interact.expect([pexpect.TIMEOUT, r'.*' + self.prompt], timeout = 3)
            #self.prompt = '\r\nroot@OpenWrt:~# '
            self.interact.expect([pexpect.TIMEOUT, r'.*' + self.prompt], timeout = 3)
            ret_val = self.interact.after
            match_pat = line + '(' + self.line_seperator + ')?' + '(.*)' + self.prompt
            match_pat = re.sub('\|', '\|', match_pat, flags=re.DOTALL)
            match_pat = re.sub('\+', '\+', match_pat, flags=re.DOTALL)
            match = re.search(match_pat, ret_val, re.DOTALL)
            if match:
                #print '###### Return Value is {0}'.format(match.group(1))
                return match.group(2)
            else:
                self.logger.dumpLog('Error: Regexp match failed.\n Pattern: {0}\n Output: {1}'.format(match_pat, ret_val))
                return False
        return True

    def send_control(self, control):
        """
        The function used to send control command to the session
        Args:
           None
        Returns:
           None
        """
        try:
            self.interact.sendcontrol(control)
            return True
        except Exception as e:
            print(e)
            return False

    def recv_line(self, prompt, timeout=3, eof=False, timeout_err=False, exact=False):
        """
        The function used to receive the expected pattern from the session
                Shall become obselete in later releases. Please refrain from using it
        Args:
           Pattern : Pattern passed to expect a match for the send_line command
           exact : Matches the exact match for the output
           timeout : time to wait for the pattern to match
        Returns:
           ret_flag: True|False
                 True: Returns True for a match
                 False: Returns False for a match
           Raises:
              Raises timeout Exception on failure of pattern match
        """
        self.recv_line_prompt = prompt
	if prompt == self.interact.prompt:
            return True
        else:
            if not eof:
                if not timeout_err:
                    if not exact:
                        try:
                            ret_val = self.interact.expect(prompt, timeout=timeout)
                            self.match_output = self.interact.match.group(0)
                            self.interact.expect(self.interact.prompt, timeout=timeout)
                            if ret_val == 0:
                                ret_flag = True
                        except Exception as err:
                            ret_flag = False
                            self.flush_buffer()
                            self.logger.dumpLog("Expected prompt (%s) has not received, and err is %s" % (prompt, err))
                    else:
                        try:
                            ret_val = self.interact.expect_exact(prompt, timeout=timeout)
                            self.match_output = self.interact.match.group(0)
                            self.interact.expect(self.interact.prompt, timeout=timeout)
                            if ret_val == 0:
                                ret_flag = True
                        except Exception as err:
                            ret_flag = False
                            self.flush_buffer()
                            self.logger.dumpLog("Expected prompt (%s) has not received, and err is %s" % (prompt, err))
                else:
                    if not exact:
                        try:
                            self.interact.prompt.extend(["pexpect.TIMEOUT"])
                            ret_val = self.interact.expect(prompt, timeout=timeout)
                            self.match_output = self.interact.match.group(0)
                            self.interact.expect(self.interact.prompt, timeout=timeout)
                            if ret_val == 0:
                                ret_flag = True
                        except Exception as err:
                            ret_flag = False
                            self.flush_buffer()
                            self.logger.dumpLog("Expected prompt (%s) has not received, and err is %s" % (prompt, err))
                    else:
                        try:
                            self.interact.prompt.extend(["pexpect.TIMEOUT"])
                            ret_val = self.interact.expect_exact(prompt, timeout=timeout)
                            self.match_output = self.interact.match.group(0)
                            self.interact.expect(self.interact.prompt, timeout=timeout)
                            if ret_val == 0:
                                ret_flag = True
                        except Exception as err:
                            ret_flag = False
                            self.flush_buffer()
                            self.logger.dumpLog("Expected prompt (%s) has not received, and err is %s" % (prompt, err))
            else:
                if not timeout_err:
                    try:
                        self.interact.prompt.extend(["pexpect.EOF"])
                        ret_val = self.interact.expect(prompt, timeout=timeout)
                        self.match_output = self.interact.match.group(0)
                        self.interact.expect(self.interact.prompt, timeout=timeout)
                        if ret_val == 0:
                            self.match = self.interact.match.group(0)
                            ret_flag = True
                    except Exception as err:
                        ret_flag = False
                        self.flush_buffer()
                        self.logger.dumpLog("Expected prompt (%s) has not received, and err is %s" % (prompt, err))
                else:
                    try:
                        self.interact.prompt.extend(["pexpect.EOF", "pexpect.TIMEOUT"])
                        ret_val = self.interact.expect(prompt, timeout=timeout)
                        self.match_output = self.interact.match.group(0)
                        self.interact.expect(self.interact.prompt, timeout=timeout)
                        if ret_val == 0:
                           ret_flag = True
                    except Exception as err:
                        ret_flag = False
                        self.flush_buffer()
                        self.logger.dumpLog("Expected prompt (%s) has not received, and err is %s" % (prompt, err))

        return ret_flag

    def match(self, groupid):
        """
        The function used to Grep the value based on the passed group id
        Args:
           Groupid: regular expression group match from receive_line pattern
        Returns:
           value of the group match
        Raises:
           REgex error on mismatch of groupid

        """
        val = re.search(self.recv_line_prompt,self.match_output)

        if val:
            return val.group(groupid)
        else:
            self.logger.dumpLog("Expected groupid match was not able to find")
            return False

        #val = self.interact.match.group(groupid)
        #return val

    def before(self):
        """
        The function used to Store the value for the expected prompt
        Args:
          None
        Returns:
          None
        """

        val = self.interact.before()
        return val

    def set_window_size(self, x, y):
        """
        The function used to Set the window size for console
        Args:
          None
        Returns:
          None
        """

        val = self.interact.setwinsize(x, y)
        return val

    def close_session(self):
        """
        The function used to Close the current active session of the device
        Args:
          None
        Returns:
          None
        """
        try:
            if self.interact.isalive():
                self.interact.close()
        except Exception as e:
            print(e)
            return False
        return True

    def create_session(self, transport=None, username=None,
                       password=None, ipaddr=None, port=None, timeout=None, conn_cmd=None):
        """
        The function Initialize the session based on the transport type (eg: bash,ssh,telnet ..etc)
        Args:
          ipaddr : ipaddres used to connect to device
          port   : Port used for the ssh connection
          timeout : time to be waited before the connection termination
          username : Username to login the device
          password : Password to login the device
        Returns:
           Device handler for a ssh connectivity
        Raises:
           Exception will be raised specifing the type of connection Error
        """
        self.username = username
        self.password = password
        self.ipaddr = ipaddr
        self.port = port
        self.transport = transport
        self.timeout = timeout
        self.conn_cmd = conn_cmd
        self.interact = self.create_handle()


    def copy_frm_cmd(self, local_path="", remote_path=""):
        try:
            self.interact.sendline("pscp.exe %s@%s:%s %s \r\n" %(self.username, self.ipaddr,remote_path, local_path))
            n = self.interact.expect(["password:",".*"],timeout=30)
            if n == 0:
                self.interact.sendline("%s\r" % self.password)
            else:
                self.interact.sendline("y/r")#logic needs to be check for this
                self.interact.expect("password:",timeout=30)
                self.interact.sendline("%s\r" %self.password)
            self.interact.expect("100%")
            print("pscp.exe cmd sucess")
            return True
        except Exception as err:
            print("%s" %str(err))
            print("pscp.exe cmd sucess")
            return True


    def send_recv(self,cmd,timeout=10, eof=False, timeout_err=False, exact=False):
        """
        THe Function Execute the command; wait for the device prompt; return output of the command
            Returned output should not have any kernel messages.
        Arguments:
            cmd - command to be executed
        Returns:
           Output of the command executed
        Raises:
          timeour Error
        """
        cmd = cmd.strip('\r\n')
        self.flush_buffer()
        prompt_new = [self.interact.prompt]
        if timeout_err is True:
            prompt_new = prompt_new.append(pexpect.TIMEOUT)
        if eof is True:
            prompt_new = prompt_new.append(pexpect.EOF)

        self.interact.sendline(cmd)
        self.interact.expect(self.interact.prompt, timeout=timeout)

        match_pat = cmd + '(' + self.line_seperator + ')?' + '(.*)'
        match_pat = re.sub('\|', '\|', match_pat, flags=re.DOTALL)
        match_pat = re.sub('\-', '\-', match_pat, flags=re.DOTALL)
        match_pat = re.sub('\+', '\+', match_pat, flags=re.DOTALL)
        match = re.search(match_pat, self.interact.before, re.DOTALL)
        if match:
            #print '###### Return Value is {0}'.format(match.group(1))
            return match.group(2)
        else:
            self.logger.dumpLog('Error: Regexp match failed.\n Pattern: {0}\n Output: {1}'.format(match_pat, self.interact.before))
            return False


    def send_cmd(self,cmd,out_file = None):
        """
        This Function used to create a new session for the device and
            executes the command
        Args:
            cmd - command to be executed
            file_name(optional) - Name of the file to store output

        Return:
            process_id/id of the command executed.
            This shall be used later for fetching the output.
        Raises:
            Raises an timeout Exception
        """
        ## If file_name specified
        #Push the output to the file of the device

        ## If file_name not specified
        #Store the output to the object variable.
        # Create a new session to the device for cmd execution in fore-ground
        #new_prompt = self.prompt
        if self.transport is 'serial':
            print 'Warning: Using existing serial connection for command execution using file redirection'
            session_id = self
            if out_file == None:
                out_file =  'dut_cmd_log.txt'
        else:
            session_id = self.create_handle()

        if out_file == None:
            session_id.expect([pexpect.TIMEOUT], timeout=1)
            session_id.cmd = cmd
            session_id.sendline(cmd)
            session_id.out_file = None
        else:
            session_id.expect([pexpect.TIMEOUT], timeout=1)
            #Execute the command in the background; TODO OS
            session_id.cmd = cmd + ' &> ' + out_file + ' &'
            session_id.sendline(session_id.cmd)
            session_id.out_file = out_file

        #session_id.prompt = new_prompt
        session_id.expect_exact(session_id.prompt)
        #Return the session object
        return session_id


    def recv_cmd(self,session_id):
        """
        This Function used to get the output fom the process_id passed

        Args:
            id - process_id/id of the command executed.

        Returns:
            Output from the file if specified in send_line()
            Else output of the command executed
        Raises:
            Raises REgex imatch failed Error or timeout Error
        """
        if session_id.out_file is None:
            match_pat = session_id.cmd + '(' + self.line_seperator + ')?' + '(.*)'
            session_id.sendcontrol('c')
            prompt_new = [session_id.prompt] + [pexpect.TIMEOUT]
            session_id.expect_exact(prompt_new)
        else:
            session_id.expect_exact(session_id.prompt)
            #Kill the process id; TODO OS
            match = re.search(r'\[\d+\]\s+(\d+)\s+' , session_id.before, re.DOTALL)
            if match:
                session_id.sendline('kill ' + match.group(1))
                session_id.expect_exact(session_id.prompt)
            else:
                print 'Warning: Failed to get process id for killing. Buffer is:\n {0}'.format(session_id.before)
                return False

            #print the output; TODO OS
            session_id.sendline('cat ' + session_id.out_file)
            session_id.expect_exact(session_id.prompt)
            match_pat = 'cat ' + session_id.out_file + '(' + self.line_seperator + ')?' + '(.*)'
            match_pat = re.sub('\|', '\|', match_pat, flags=re.DOTALL)
            match_pat = re.sub('\+', '\+', match_pat, flags=re.DOTALL)

        #Strip the output of the command
        match = re.search(match_pat, session_id.before, re.DOTALL)
        if match:
            output = match.group(2)
        else:
            print 'Match Failed for: {0}'.format(session_id.before)

        #Close the session
        session_id.close()
        del(session_id)
        return output


    def create_logfile(self, output_dir = output_dir):
        '''Create the files for logging the execution'''
        if self.interact.logfile is not None:
            self.interact.logfile.close()
        exec ('self.interact.logfile = open(os.path.join(output_dir,\'' + 'test.log\'),' + '\'a+\')')

        if self.interact.logfile_send is not None:
            self.interact.logfile_send.close()
        exec ('self.interact.logfile_send = open(os.path.join(output_dir,\'' + self.name + '_cmd.log\'),' + '\'a+\')')

        if self.interact.logfile_read is not None:
            self.interact.logfile_read.close()
        exec ('self.interact.logfile_read = open(os.path.join(output_dir,\'' + self.name + '.log\'),' + '\'a+\')')


    def close_logfile(self, output_dir = output_dir , device = None):
        '''Close the files'''
        if self.interact.logfile is not None:
            self.interact.logfile.close()
        if self.interact.logfile_send is not None:
            self.interact.logfile_send.close()
        if self.interact.logfile_read is not None:
            self.interact.logfile_read.close()


    def log_decorator(self,func):
        '''Overloading the sendline function for logging
        '''
        def log_sendline(*args, **kwargs):
            date_time_now = datetime.now()
            self.interact.logfile.write('\n[%s]' % (date_time_now))
            self.interact.logfile.flush()
            self.interact.logfile_send.write('\n[%s]' % (date_time_now))
            self.interact.logfile_read.write('\n[%s]' % (date_time_now))
            func(*args, **kwargs)
        return log_sendline


    def log_console_decorator(self,func):
        '''Overloading expect/expect_exact function for printing to window
        '''
        def log_sendline(*args, **kwargs):
            date_time_now = datetime.now()
            output = func(*args, **kwargs)
            cprint(self.interact.before, color=self.color)
            cprint(self.interact.after, color=self.color)
            return output
        return log_sendline


    def get_log_dir(self):
        '''Returns the current directory'''
        return self.output_dir

    def test_func(self):
        self.logger.dumpLog("Inside class %s" % self.__class__.__name__)
        self.logger.warning("Inside class %s" % self.__class__.__name__)
        self.logger.error("Inside class %s" % self.__class__.__name__)
        print ("test_func(): Inside class %s" % self.__class__.__name__)

if __name__ == "__main__":
    obj = InteractPexpect()
    obj.test_func()
