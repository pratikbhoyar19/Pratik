''' Class defination for pyserial tool.'''
__author__ = "Intel Corporation"
__copyright__ = "Copyright 2019, Intel Corporation"
__version__ = "0.0.1"
__maintainer__ = "Mirafra"
__email__ = "framework@mirafra.com"
__status__ = "Development"
###########################################################
import serial
import re
import os
import threading
import inspect

from devices.interact_tools.interact import *
from datetime import datetime
from config import output_dir, runtime_para
from time import sleep
from termcolor import cprint
from log_creator import loggerObject as logger


class InteractPyserial(InteractTool):
    '''
    A class used to represent interaction tool for Pyserial

    ...

    Attributes
    ----------


    Methods
    -------
    '''

    def __init__(self, platform_type=None, color=None, name=None):
        """
        The constructor for Pyserial interactive class
        Args:
           platform_type: Specify the platform of the device(Linux/Windows)
           name: Specify the name of the device(lan/wlan/wan)
        Returns:
           None
        Raises:
           Exception on invalid arguments
        """

        self.platform_type = platform_type
        self.color = color
        self.name = name
        self.line_seperator = '\r\n'
        self.CR = '\r'
        self.prompt = '.*(\$|\#)\s+$'
        self.output_dir = output_dir

    def config_update(self, os_handle=None, device_dict=None):
        self.os = os_handle
        self.dict = device_dict

    def set_prompt(self, prompt=None):
        """
        The function used to get the device prompt
        Args:
           None
        Returns:
           None
        Raises:
           None
        """

        self.interact.flush()
        self.interact.write(self.CR)
        sleep(1)
        self.prompt = self.interact.read_all()

    def flush_buffer(self):
        """
        The function to flush the buffer contents of previous command output
        Args:
           None
        Returns:
           None
        Raises:
           None
        """

        #self.interact.flush()
        self.interact.read_all()

    def create_session(self, conn_cmd=None, transport=None, port=None, username=None, password=None,
                       timeout=60, timeout_w=5, baudrate=115200):
        """
        The function Initialize the session based on the transport type (eg: bash,ssh,telnet ..etc)
        Args:
          ipaddr : ipaddres used to connect to device
          port   : Port used for the ssh connection
          timeout : time to be waited before the connection termination
          username : Username to login the device
          password : Password to login the device
        Returns:
           Device handler for a ssh connectivity
        Raises:
           Exception will be raised specifing the type of connection Error
        """

        self.username = username
        self.password = password

        try:
            self.interact = serial.Serial(port=port, baudrate=baudrate, timeout=timeout, write_timeout = timeout_w)

            # Decorate the pexpect.sendline for logging
            self.interact.write = self.log_decorator(self.interact.write)
            self.interact.read_until = self.log_console_decorator(self.interact.read_until)
            self.interact.read_all = self.log_console_decorator(self.interact.read_all)

            # Create the required log files
            self.create_logfile(output_dir= self.output_dir)

            self.interact.write(self.CR)
            self.interact.write(self.CR)
            sleep(1)
            cmd_output = self.interact.read_all()
            if re.search('login:', cmd_output, re.IGNORECASE|re.DOTALL):
                self.interact.write(username + self.CR)
                sleep(1)
                if re.search('password:', self.interact.read_all(), re.IGNORECASE|re.DOTALL):
                    self.interact.write(password + self.CR)
                    sleep(1)
                    if re.search(self.prompt, self.interact.read_all(), re.IGNORECASE|re.DOTALL):
                        logger.dumpLog('DUT: Logged in successfully')
                        self.log_console_thread()
                    else:
                        logger.error('DUT: Login failed. Incorrect password')
                        return False
                else:
                    logger.error('DUT: Login failed. Failed to get password prompt')
                    return False
            elif re.search(self.prompt, cmd_output, re.IGNORECASE|re.DOTALL):
                logger.dumpLog('DUT: Logged in successfully without user/pwd')
                ##@ Start the thread for parallel logging
                if 'parallel_log_serial' not in runtime_para.keys():
                    self.log_console_thread()
                    logger.dumpLog('DUT: Thread for parallel logging enabled')
                elif runtime_para['parallel_log_serial'] is True:
                    self.log_console_thread()
                    logger.dumpLog('DUT: Thread for parallel logging enabled')
            else:
                logger.error('DUT: Login failed.')
                return False
        except Exception as e:
            print e
            raise Exception(e)

        return True


    def send_control(self, control):
        """
        The function used to send control command to the session
        Args:
           Contro: Control command to be sent
        Returns:
           None
        Raises:
          Exception on control command failure
        """
        # TODO
        try:
            self.interact.write("\x03")
        except Exception as err:
            print("error %s" %str(err))


    def exec_cmd_host(self, transport, cmd):
        # TODO
        pass

    def send_line(self, cmd, send_block=False):
        """
        The function used to send command to the session
                Shall become obselete in later releases. Please refrain from using it
        Args:
           cmd : Command that needs to be executed
           send_block: True|False
                True: Behaves like a blocked call, Returns the output of the command
                False: Behaves like a non-blocked call, just sends the cmd and waits to expect
           timeout: time waited before rasing an expection
        Returns:
           Output of a command for a Blocked call
           True|False for a Unblocked call
        Raises:
           Raises timeout Exception on command failure

        """
        self.cmd = cmd.strip('\r\n')
        self.flush_buffer()
        self.flag_read = False

        if send_block is False:
            self.interact.write(self.cmd.encode() + self.CR)
        elif send_block is True:
            self.interact.write(self.cmd.encode() + self.CR)
            ## if cmd is 'cd ...' than update prompt and return True
            if self.cmd.startswith('cd '):
                sleep(1)
                ret_val = self.interact.read_all()
                self.flag_read = True
                self.prompt_old = self.prompt
                self.prompt = ret_val.replace(self.cmd,'')
                return True
            else:
                ret_val = self.interact.read_until(self.prompt)
                self.flag_read = True
                match_pat = self.cmd + '(' + self.CR + ')?' + '(.*)' + self.prompt
                match = re.match(match_pat, ret_val, re.DOTALL)
                if match:
                    #print '###### Return Value is {0}'.format(match.group(1))
                    self.cmd_output = match.group(2)
                return 'Error: Regexp match failed.\n Pattern: {0}\n Output: {1}'.format(match_pat, ret_val)


    def recv_line(self, pattern=None, timeout=60, eof=False, timeout_err=False, exact=False, next_recv_line=False):
        """
        The function used to receive the expected pattern from the session
                Shall become obselete in later releases. Please refrain from using it
        Args:
           Pattern : Pattern passed to expect a match for the send_line command
           exact : Matches the exact match for the output
           timeout : time to wait for the pattern to match

        Returns:
           ret_flag: True|False
                 True: Returns True for a match
                 False: Returns False for a match
           Raises:
              Raises timeout Exception on failure of pattern match
        """
        ## if cmd is 'cd ...' than update prompt and return True
        if self.cmd.startswith('cd '):
            self.prompt_old = self.prompt
            sleep(1)
            ret_val = self.interact.read_all()
            self.prompt = ret_val.replace(self.cmd,'')
            return True

        ## Update the match pattern
        if type(pattern) == list:
            pattern = '|'.join(str(e) for e in pattern)
            ret_val = re.match(pattern, self.prompt, re.DOTALL)
            if ret_val:
                return True
        elif pattern is None:
            pattern = self.prompt

        ret_flag = True
        #Get the output till the match is found
        if exact is True:
            old_timeout = self.interact.timeout
            self.interact.timeout = timeout
            output = self.interact.read_until(pattern)
            self.interact.timeout = old_timeout
        else:
            output = self.interact.read_all()
            for i in range(timeout):
                self.ret_val = re.search(pattern, output, re.DOTALL)
                if self.ret_val is not None:
                    break
                sleep(1)
                output = output + self.interact.read_all()
            else:
                ret_flag = False

        if next_recv_line is False:
            self.flag_read = True
        return ret_flag


    def match(self, groupid):
        """
        The function used to Grep the value based on the passed group id
        Args:
           Groupid: regular expression group match from receive_line pattern
        Returns:
           value of the group match
        Raises:
          REgex error on mismatch of groupid
        """

        val = self.ret_val.group(groupid)
        return val

    def before(self):
        """
        The function used to Store the value for the expected prompt
        Args:
          None
        Returns:
          None
        Raises:
          None
        """
        # Not Required
        pass

    def set_window_size(self, x, y):
        """
        The function used to Set the window size for console
        Args:
          None
        Returns:
          None
        Raises:
          None
        """
        # Not Required
        pass

    def close(self):
        '''Close the Serial connection session'''
        if self.interact.isOpen() == True:
            self.interact.close()
            print ('Connection closed')
        else:
            print ('Connection already closed')
        pass


    def send_recv(self,cmd,timeout=60, eof=False, timeout_err=False):
        """
        The function used to Execute the command; wait for the device prompt;
        return output of the command. Returned output should not have any kernel messages
        Args:
          cmd: Command to be executed
        Returns:
          Output of the command executed
        Raises:
          timeour Error
        """
        cmd = cmd.strip('\r\n')
        old_timeout = self.interact.timeout
        self.interact.timeout = timeout
        self.interact.read_all()
        self.flag_read = False
        self.interact.write(cmd + self.CR)
        if cmd.startswith('cd '):
            self.prompt_old = self.prompt
            sleep(1)
            ret_val = self.interact.read_all()
            self.prompt = ret_val.replace(cmd,'')
        else:
            ret_val = self.interact.read_until(self.prompt)

        self.interact.timeout = old_timeout
        self.flag_read = True
        match_pat = cmd + '(' + self.CR + ')?' + '(.*)' + self.prompt
        match_pat = re.sub('\|', '\|', match_pat, flags=re.DOTALL)
        match_pat = re.sub('\+', '\+', match_pat, flags=re.DOTALL)
        match = re.search(match_pat, ret_val, re.DOTALL)
        if match:
            #print '###### Return Value is {0}'.format(match.group(1))
            return match.group(2)
        else:
            self.logger.dumpLog('Error: Regexp match failed.\n Pattern: {0}\n Output: {1}'.format(match_pat, ret_val))
            return False

    def send_cmd(self, cmd, out_file = None):
        """
        This Function used to create a new session for the device and
            executes the command
        Args:
            cmd - command to be executed
            file_name(optional) - Name of the file to store output

        Return:
            process_id/id of the command executed.
            This shall be used later for fetching the output.
        Raises:
            Raises an timeout Exception
        """
        ## If file_name not specified, create the file_name dynamically
        #Push the output to the file of the device
        self.out_file = out_file
        self.cmd = cmd
        self.flag_read = False

        if out_file == None:
            self.interact.write(cmd + self.CR)
        else:
            self.interact.write(cmd + ' &> ' + out_file + ' &' + self.CR)
            self.interact.read_until(self.prompt)
            self.flag_read = True
        return self.interact


    def recv_cmd(self, session_id):
        """
        This Function used to get the output fom the process_id passed

        Args:
            id - process_id/id of the command executed.

        Returns:
            Output from the file if specified in send_line()
            Else output of the command executed
        Raises:
            Raises REgex imatch failed Error or timeout Error
        """

        if self.out_file == None:
            ## If file doesn't exist
            #Store the output to the object variable.
            #Delete the object variable and return the output
            self.interact.write('\x03')
            ret_val = self.interact.read_until(self.prompt)
            self.flag_read = True
            match_pat = self.cmd + '(' + self.CR + ')?' + '(.*)' + self.prompt
            match_pat = re.sub('\|', '\|', match_pat, flags=re.DOTALL)
            match_pat = re.sub('\+', '\+', match_pat, flags=re.DOTALL)
            match = re.search(match_pat, ret_val, re.DOTALL)
            if match:
                #print '###### Return Value is {0}'.format(match.group(1))
                return match.group(2)
            else:
                self.logger.dumpLog('Error: Regexp match failed.\n Pattern: {0}\n Output: {1}'.format(match_pat, ret_val))
                return False
        else:
            ## If file exist
            #Pull the output from the file
            #Copy the file to the <log_location> of the execution PC
            #Delete the file from the device
            #send_control('c')
            #session_id.expect(self.prompt)
            self.flag_read = False
            self.interact.write('cat ' + self.out_file + self.CR)
            ret_val = self.interact.read_until(self.prompt)
            self.flag_read = True
            match_pat = 'cat ' + self.out_file + '(' + self.CR + ')?' + '(.*)' + self.prompt
            match_pat = re.sub('\|', '\|', match_pat, flags=re.DOTALL)
            match_pat = re.sub('\+', '\+', match_pat, flags=re.DOTALL)
            match = re.search(match_pat, ret_val, re.DOTALL)
            if match:
                #print '###### Return Value is {0}'.format(match.group(1))
                return match.group(2)
            else:
                self.logger.dumpLog('Error: Regexp match failed.\n Pattern: {0}\n Output: {1}'.format(match_pat, ret_val))
                return False

    def create_logfile(self, output_dir = output_dir , device = None):
        '''Create the files for logging the execution'''

        #Update the log_dir to passed value
        self.output_dir = output_dir

        if hasattr(self.interact, 'logfile') is True:
            self.interact.logfile.close()
        exec ('self.interact.logfile = open(os.path.join(output_dir,\'' + 'test.log\'),' + '\'a+\')')

        if hasattr(self.interact, 'logfile_send') is True:
            self.interact.logfile_send.close()
        exec ('self.interact.logfile_send = open(os.path.join(output_dir,\'' + self.name + '_cmd.log\'),' + '\'a+\')')

        if hasattr(self.interact, 'logfile_read') is True:
            self.interact.logfile_read.close()
        exec ('self.interact.logfile_read = open(os.path.join(output_dir,\'' + self.name + '.log\'),' + '\'a+\')')


    def close_logfile(self, output_dir = output_dir , device = None):
        '''Close the files'''
        if hasattr(self.interact, 'logfile') is True:
            self.interact.logfile.close()
        if hasattr(self.interact, 'logfile_send') is True:
            self.interact.logfile_send.close()
        if hasattr(self.interact, 'logfile_read') is True:
            self.interact.logfile_read.close()

    def log_decorator(self,func):
        '''Overloading the sendline function for logging
        '''
        def log_sendline(*args, **kwargs):
            func_name = inspect.stack()[1][3]
            self.date_time_now = datetime.now()
            cmd_output = '\n[{}] [command] [{}] [{}] '.format(self.date_time_now, self.name, func_name)
            self.interact.logfile.write('\n%s' % (cmd_output))
            self.interact.logfile.flush()
            cprint(cmd_output, color=self.color, end='')
            self.interact.logfile_send.write('\n[%s] %s' % (self.date_time_now, args[0]))
            func(*args, **kwargs)
        return log_sendline

    def log_console_decorator(self,func):
        '''Overloading expect/expect_exact function for printing to window
        '''
        def log_sendline(*args, **kwargs):
            output = func(*args, **kwargs)
            cmd_output = re.sub('^','\t', output, flags=re.M).strip('\t')
            self.interact.logfile.write('%s' % (cmd_output))
            self.interact.logfile.flush()
            self.interact.logfile_read.write('\n[%s] %s' % (self.date_time_now, cmd_output))
            cprint(cmd_output, color=self.color)
            return output
        return log_sendline

    def close_session(self):
        """
        The function used to Close the current active session of the device
        Args:
          None
        Returns:
          None
        """
        ##@ Stop the logging thread
        if 'parallel_log_serial' not in runtime_para.keys():
            self.log_console_disable()
        elif runtime_para['parallel_log_serial'] is True:
            self.log_console_disable()

        #Close the session
        if self.interact.isOpen() == True:
            self.interact.close()
            cprint ('Connection closed', color=self.color)
        else:
            cprint ('Connection already closed', color=self.color)


    def get_log_dir(self):
        '''Returns the current directory'''
        return self.output_dir

    def log_console_enable(self):
        '''
            Description:
                Enable logging of console output in the thread.
            Args: None
            Return: None
        '''
        sleep3 = 3
        self.flag_read = True

        while True:
            # Read only when the flag_read is True
            if self.flag_read is True:
                self.interact.read_all()
            sleep(sleep3)


    def log_console_disable(self):
        '''
            Description:
                Disable logging of console output and stop the thread
            Args: None
            Return: None

        '''
        print ('DUT: Stop the thread for logging')
	self.flag_read = False
        if  self.thread_log.isAlive():
            self.thread_log._Thread__stop()


    def log_console_thread(self):
        '''
            Description:
                Start the thread for console logging
            Args: None
            Return: None

        '''
        print ('DUT: Start the thread for logging')
        self.thread_log = threading.Thread(target=self.log_console_enable)
        self.thread_log.setDaemon(True)
        self.thread_log.start()


    def test_func(self):
        self.logger.dumpLog("Inside class %s" % self.__class__.__name__)
        self.logger.warning("Inside class %s" % self.__class__.__name__)
        self.logger.error("Inside class %s" % self.__class__.__name__)
        print ("test_func(): Inside class %s" % self.__class__.__name__)
