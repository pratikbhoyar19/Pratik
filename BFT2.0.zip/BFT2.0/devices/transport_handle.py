''' Class for create the transport object'''
__author__ = 'Intel Corporation'
__copyright__ = 'Copyright 2019, Intel Corporation'
__version__ = '0.0.1'
__maintainer__ = 'Mirafra'
__email__ = 'framework@mirafra.com'
__status__ = 'Development'

from devices.transport_types.local_serial_connection import *
from devices.transport_types.ssh_connection import *
from devices.transport_types.telnet_connection import *


class TransportLayer:
    def __init__(self,
                 name,
                 username,
                 password,
                 port='22',
                 conn_cmd=None,
                 platform_type=None,
                 transport_type="ssh"):

        self.name = name
        self.username = username
        self.password = password
        self.port = port
        self.conn_cmd = conn_cmd
        self.platform_type = platform_type
        self.transport_type = transport_type

        # Define the classes

        '''Define interact class name based on transport type'''
        self.transport_class = "Transport"+self.transport_type.capitalize()

    def handle_creation(self):

        if self.transport_class != "TransportLocalserial":
            ''' Transport specific class objects '''
            return eval("%s('%s', '%s', '%s', port='%s', conn_cmd='%s', platform_type='%s')"
                        % (self.transport_class, self.username, self.password, self.name,
                           self.port, self.conn_cmd, self.platform_type))
        else:
            ''' Transport specific class objects '''
            return eval("%s(conn_cmd='%s', port='%s', username='%s', password='%s', platform_type='%s')"
                        %(self.transport_class, self.conn_cmd, self.port, self.username, self.password, self.platform_type))

