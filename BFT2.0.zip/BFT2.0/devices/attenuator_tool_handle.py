''' Class for create the wlan tools object'''
__author__ = 'Intel Corporation'
__copyright__ = 'Copyright 2019, Intel Corporation'
__version__ = '0.0.1'
__maintainer__ = 'Mirafra'
__email__ = 'framework@mirafra.com'
__status__ = 'Development'

from lib.wlan.wlan_tools.attenuator_builder import attnutr_cmd


class AttnutrToolLayer:

    def __init__(self,
                 tool_name=None):
        self.tool_name = str(tool_name).capitalize()

    def handle_creation(self):
        # Initialize the object based on the defined classes
        self.attnutr_handle = attnutr_cmd(self.tool_name)

        return self.attnutr_handle

#Test Code
if __name__ == '__main__':
    obj = AttnutrToolLayer(tool_name="Labbric")
    handle = obj.handle_creation()
    handle.test_labbric()
    obj = AttnutrToolLayer(tool_name="Vaunix")
    handle = obj.handle_creation()
    handle.test_vaunix()
