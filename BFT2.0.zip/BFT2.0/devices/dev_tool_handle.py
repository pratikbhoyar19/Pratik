''' Class for create the wlan tools object'''
__author__ = 'Intel Corporation'
__copyright__ = 'Copyright 2019, Intel Corporation'
__version__ = '0.0.1'
__maintainer__ = 'Mirafra'
__email__ = 'framework@mirafra.com'
__status__ = 'Development'

from lib.wlan.dev_tool_handler import DevToolSelect
from lib.wlan.wlan_tools.config_tool_builder import tool_cmd


class DevToolLayer:

    def __init__(self,
                 primary_tool=None,
                 secondary_tool=None,
                 model=None):

        self.primary_tool = str(primary_tool).capitalize()
        self.secondary_tool = str(secondary_tool).capitalize()
        self.model = str(model).capitalize()
        # Initialize the object based on the defined classes

    def handle_creation(self):

        # Initialize the object based on the defined classes
        self.prim_handle = tool_cmd(tool_name=self.primary_tool, model_specific_name=self.model)
        self.sec_handle = tool_cmd(tool_name=self.secondary_tool, model_specific_name=self.model)

        return DevToolSelect(self.prim_handle, self.sec_handle)



#Test Code
if __name__ == '__main__':
    obj = DevToolLayer(primary_tool="iwconfig", secondary_tool="iw", model="intel8260")
    handle = obj.handle_creation()
    handle.test_func5()
