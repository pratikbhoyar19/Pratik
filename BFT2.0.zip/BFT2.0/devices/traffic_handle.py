''' Class for create the traffic object'''
__author__ = 'Intel Corporation'
__copyright__ = 'Copyright 2019, Intel Corporation'
__version__ = '0.0.1'
__maintainer__ = 'Mirafra'
__email__ = 'framework@mirafra.com'
__status__ = 'Development'

from lib.common.traffic_tools.traffic_ixchariot import *
from lib.common.traffic_tools.traffic_iperf import *
from lib.common.traffic_tools.traffic_stc import *

class TrafficLayer:
    '''
    A class used to create the traffic object

    ...

    Attributes
    ----------
    version : Traffic tool version

    Methods
    -------
    '''

    def __init__(self,
                 platform_type=None,
                 traffic_tool="iperf"):

        self.platform_type = platform_type
        self.traffic_tool = traffic_tool

        # Define the classes

        '''Define traffic tool class name based on traffic_tool'''
        self.traffic_class = "Traffic"+self.traffic_tool.capitalize()

    def handle_creation(self):
        ''' Traffic specific class objects '''
        return eval("%s(platform_type='%s')" % (self.traffic_class, self.platform_type))
