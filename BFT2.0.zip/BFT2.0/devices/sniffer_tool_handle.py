''' Class for create the wlan tools object'''
__author__ = 'Intel Corporation'
__copyright__ = 'Copyright 2019, Intel Corporation'
__version__ = '0.0.1'
__maintainer__ = 'Mirafra'
__email__ = 'framework@mirafra.com'
__status__ = 'Development'


from lib.common.sniff_tool_builder import sniffer_cmd


class SnifferToolLayer:

    def __init__(self,
                 tool_name=None,
                 model_name=None):
        self.tool_name = str(tool_name).capitalize()
        self.model_name = str(model_name).capitalize()

    def handle_creation(self):

        # Initialize the object based on the defined classes
        self.sniffer_handle = sniffer_cmd(tool_name=self.tool_name, model_specific_name=self.model_name)
        return self.sniffer_handle

#Test Code
if __name__ == '__main__':
    obj = SnifferToolLayer(tool_name="wireshark", model_name="intel8260")
    handle = obj.handle_creation()
    handle.test_wireshark()
    handle.set_channel()
    obj = SnifferToolLayer(tool_name="tcpdump", model_name="wcs")
    handle = obj.handle_creation()
    handle.test_tcpdump()
    handle.set_channel()
    obj = SnifferToolLayer(tool_name="omnipeek", model_name="intel8260")
    handle = obj.handle_creation()
    handle.test_omnipeek()
    handle.set_channel()
