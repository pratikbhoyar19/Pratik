import os
import logging
import inspect
import config
import time
import datetime

from termcolor import cprint

DUMP_LOG_LEVEL = 25
LOG_FORMAT = logging.Formatter('[%(asctime)s.%(msecs)06d] [%(levelname)s] [%(device)s] [%(func_name)s] %(message)s','%Y-%m-%d %H:%M:%S')
logging.addLevelName(DUMP_LOG_LEVEL, "LOG")

class logger():
    flag = 0
    test_class_name = ""
    fileHandler = None

    def __init__(self, device='test'):
        self.device = device
        self.thread = None

    def myLogger(self,name):
        if not logger.flag or device is not 'test':
            self.logger = logging.getLogger(name)
            self.logger.setLevel(DUMP_LOG_LEVEL)

            self.set_class_name(name)
            if self.device is 'test':
                if(isinstance(name,str)):
                    logger.fileHandler = logging.FileHandler(os.path.join(config.custom_tests_dir + os.sep, name + '.log'), 'a+')
                else:
                    logger.fileHandler = logging.FileHandler(name,'a+')

            # Write to file
            logger.fileHandler.setFormatter(LOG_FORMAT)
            self.logger.addHandler(logger.fileHandler)

            # Print to console
            consoleHandler = logging.StreamHandler()
            consoleHandler.setFormatter(LOG_FORMAT)
            self.logger.addHandler(consoleHandler)
    
            logger.flag = 1

    def getOuterFrameinfo(self, number):
        return inspect.getouterframes(inspect.currentframe())[number]

    def formatLogMessage(self, logString):
        (frame,filename,line_number,function_name, lines, index,) = self.getOuterFrameinfo(3)
        filename      = 'file: '     + filename
        function_name = 'function: ' + function_name
        line_number   = 'line: '     + str(line_number)
        logString     = filename     + ', '             + function_name + ', ' + \
        line_number + ' - ' + 'message: ' + logString
        return logString

    def dumpLog(self,log_msg, device=None, func_name=None, thread_id=None):
        log_dict = {}
        #Append the device name
        log_dict['device'] = self.device if device is None else device
        #Append the function name
        log_dict['func_name'] = inspect.stack()[1][3] if func_name is None else func_name

        #Append thread id, if applicable
        log_str = ''
        if thread_id is not None:
            log_str = '[' + thread_id + '] '
        elif log_dict['device'] is not 'test':
            from devices import *
            thread_id = eval(log_dict['device'] + '.logger.thread')
            if thread_id is not None:
                log_str = '[' + str(thread_id) + '] '
        log_str = log_str + log_msg

        self.logger.log(DUMP_LOG_LEVEL, log_str, extra=log_dict)
        # self.logger.handlers[0].stream.write('sunil')
        #print(log_str)


    def error(self,log_msg, device=None, func_name=None, thread_id=None):
        log_dict = {}
        #Append the device name
        log_dict['device'] = self.device if device is None else device
        #Append the function name
        log_dict['func_name'] = inspect.stack()[1][3] if func_name is None else func_name

        #Append thread id, if applicable
        log_str = ''
        if thread_id is not None:
            log_str = '[' + thread_id + '] '
        elif log_dict['device'] is not 'test':
            from devices import *
            thread_id = eval(log_dict['device'] + '.logger.thread')
            if thread_id is not None:
                log_str = '[' + str(thread_id) + '] '
        log_str = log_str + log_msg

        self.logger.log(logging.ERROR, log_str, extra=log_dict)


    def warning(self,log_msg, device=None, func_name=None, thread_id=None):
        log_dict = {}
        #Append the device name
        log_dict['device'] = self.device if device is None else device
        #Append the function name
        log_dict['func_name'] = inspect.stack()[1][3] if func_name is None else func_name

        #Append thread id, if applicable
        log_str = ''
        if thread_id is not None:
            log_str = '[' + thread_id + '] '
        elif log_dict['device'] is not 'test':
            from devices import *
            thread_id = eval(log_dict['device'] + '.logger.thread')
            if thread_id is not None:
                log_str = '[' + str(thread_id) + '] '
        log_str = log_str + log_msg

        self.logger.log(logging.WARNING, log_str, extra=log_dict)


    def dump_execution_time(self,string):
        self.logger.info(string)
        print(string)


    def dumpBanner(self,string):
        if not flag:
            self.myLogger("test")
            if string == "setUp" or string == "runTest" or string == "tearDown":
                self.logger.info ('\n'+"".center(100,"*"))
                self.logger.info(string.center(100," "))
                self.logger.info ("".center(100,"*")+"\n")
            flag=0
        else:
            if string == "setUp" or string == "runTest" or string == "tearDown":
                self.logger.info ('\n'+"".center(100,"*"))
                self.logger.info(string.center(100," "))
                self.logger.info ("".center(100,"*")+"\n")
            else:
                self.logger.info("\n"+string.center(100,"=")+" \n")

    def print_bold(self,msg):
        cprint(msg, None, attrs=['bold'])

    def print_board_info(self,x):
        for key in sorted(x):
            self.print_bold("  %s: %s" % (key, x[key]))

    def resetLog(self):
        logger.flag = 0

    def startLog(self,name):
        logger.flag = 0
        self.myLogger(name)

    def set_class_name(self, name):
        logger.test_class_name = name

    def get_class_name(self):
        return logger.test_class_name

    def get_current_time(self):
        ts = time.time()
        st = datetime.datetime.fromtimestamp(ts).strftime('%Y-%m-%d %H:%M:%S')
        return st

loggerObject = logger()
