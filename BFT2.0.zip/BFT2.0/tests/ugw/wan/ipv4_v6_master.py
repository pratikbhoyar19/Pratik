#Copyright(c) 2018 Intel Corporation
# All rights reserved.
#
# This file is distributed under the Clear BSD license.
# The full text can be found in LICENSE in the root directory.
# This file consist of classes for computing Throughput and Idle cpu
# cycles for upstream, downstream and birectional traffic

import unittest2
from tests import linux_boot
from devices.platform_types.linux import *
from devices import *
from globalVariables import *
from log_creator import loggerObject as logger
from log_creator import logger as logClass
from parallel_exec import *
from config import runtime_para, kpi_para
from framework.publish_info_to_html import publish_html

from time import *
import copy

class Ipv4v6Master(linux_boot.LinuxBootTest):
    """
    This class is master class for testing ipv4 and ipv6 sanity as well as performance for:
    @ All Acceleration modes
    @ All Directions i.e, upstream downstream and bidi
    @ Route and Bridge mode
    @ All wan modes and wan connections
    Also this class is parent class for testing following features:
    @ VPN - ipogre,eogre and l2tpv2
    @ IPSeC - ipsec and l2tp + ipsec
    @ IPV6 - Dslite and 6RD
    @ Multicast - IGMPV3 and MLD proxy
    @ QOS, Session management, Firewall, NAT, Routing, Bridging, stats and counters, config and debugging
    Attributes:
        None
    """

    @classmethod
    def setUpClass(cls):
        """
        The function to get Wan Ip, and to apply Grp level changes to DUT
        Args:
            None
        Returns:
            None
        """
        #creating essential params
        cls.user = None
        cls.password = None
        cls.vlan_id = None
        cls.accel_type = None
        cls.wan_conn = None
        cls.pckt_len = None
        cls.vpi = None
        cls.vci = None
        cls.performance = None
        cls.tun_name = None
        super(Ipv4v6Master, cls).setUpClass()
        ### Publish the test paramters to HTML report
        pub_qcid = "QC_1"
        pub_test_desc = "IPV4 sanity testing"
        param_dict = {'mode': cls.grp_level_params['mode']}
        if cls.mode == "route":
            param_dict.update({'wan_proto': cls.grp_level_params['wan_proto']})
            param_dict.update({'wan_conn': cls.grp_level_params['wan_conn']})
        pub_param_desc = param_dict

        publish_html(qcid=pub_qcid, test_desc=pub_test_desc, param_desc=pub_param_desc)
        logger.dumpLog("PTA:{}, PRT:{}, TUN:{}".format(runtime_para['PTA_SETUP'], runtime_para['PRT_SETUP'], runtime_para['TUN_SETUP']))

        if runtime_para['PTA_SETUP'] or runtime_para['PRT_SETUP'] or cls.wan_conn == "eth_tag":#cisco router will be used
            cls.w_iface = ("{}.{}").format(wan.dict['iface'], wan.dict['vlan_id'])
        else:#without cisco router
            cls.w_iface = wan.dict['iface']

        #getting lan ip
        cls.lan_ip = lan.os.get_interface_ipaddr(lan.dict['iface'])
        if not cls.lan_ip:
            cls.result_message = "Failed to get ip for iface {}".format(lan.dict['iface'])
            publish_html(comment=cls.result_message)
            cls.tearDownClass()
            raise unittest2.SkipTest(cls.result_message)

        #removing extra wan ifaces of DUT if present
        dut.tools.rm_extra_ifaces()

        if cls.wan_conn == "vdsl_ptm_17a" or cls.wan_conn == "adsl_atm" or cls.wan_conn == "vdsl_ptm_30":
            #setting dsl module in dut to full auto mode
            dut.tools.dsl_auto_mode_config()
            dut.tools.check_show_time()
            dslam.tools.configure_dslam(server_script=dslam.dict[cls.wan_conn])
            dut.tools.check_show_time()
        #checking show time in dut
        #creating wan connection and getting wan interface of dut
        cn_d = dut.tools.wan_create_conn(wan_conn=cls.wan_conn, vlan_id=cls.vlan_id, mode=cls.mode, vpi=cls.vpi, vci=cls.vci)
        if cn_d['result'] == 'fail':
            cls.result_message = "Failed to create wan connection - {}".format(cls.wan_conn)
            publish_html(comment=cls.result_message)
            cls.tearDownClass()
            raise unittest2.SkipTest(cls.result_message)
        cls.dut_wiface = cn_d['wan_iface']


        #restarting vlan script in case of tunnel setup
        if runtime_para['TUN_SETUP']:
            wan.os.restart_services()

        #creating bridge for bridge mode, once bridge is created, dut will automatically will get ip from router/bras/wan machine
        if cls.mode == "bridge":
            logger.dumpLog("Creating bridge")
            op_d = dut.tools.config_bridge_mode(bridge_name=dut.dict['br_name'], iface=cls.dut_wiface)
            if op_d['result'] == "fail":
                cls.result_message = "Failed to add {} iface in {} bridge".format(cls.dut_wiface, cls.dut_wiface)
                publish_html(comment=cls.result_message)
                cls.tearDownClass()
                raise unittest2.SkipTest(cls.result_message)

            logger.dumpLog("Setting ip for bridge in lan machine")
            op_d = lan.os.config_dhcp_ip(iface=lan.dict['iface'])
            if op_d['result'] == "fail":
                cls.result_message = "Failed to set ip for bridge on iface {}".format(lan.dict['iface'])
                publish_html(comment=cls.result_message)
                cls.tearDownClass()
                raise unittest2.SkipTest(cls.result_message)
            cls.ip_addr = op_d['ip']
            sleep(5)

        #route mode operations
        elif cls.mode == "route":
            logger.dumpLog("Applying the {} configs".format(cls.wan_proto))
            wan_m = dut.tools.wan_mode_config(wan_proto=cls.wan_proto,
                                              wan_iface=cls.dut_wiface,
                                              vlan_id=cls.vlan_id,
                                              user=cls.user,
                                              password=cls.password)
            if wan_m['result'] == "fail":
                cls.result_message = "Failed to Create dut wan iface {}".format(cls.dut_wiface)
                publish_html(comment=cls.result_message)
                cls.tearDownClass()
                raise unittest2.SkipTest(cls.result_message)

            if cls.wan_proto == "pppoe":
                ppp_d = dut.tools.get_ppp_iface()
                if ppp_d['result'] == 'fail':
                    cls.result_message = "Failed to get PPPoE iface"
                    publish_html(comment=cls.result_message)
                    cls.tearDownClass()
                    raise unittest2.SkipTest(cls.result_message)
                cls.dut_wiface = ppp_d['ppp_iface']
            #adding MASQ Rule
            logger.dumpLog("configuring MASQ rule for natting in DUT")
            dut.tools.add_msq_rule(iface=cls.dut_wiface)
            logger.dumpLog("Obtaining WAN IP addr for DUT")
            #Getting WAN IP in DUT
            wan_d = dut.tools.get_dut_wan_ip(wan_iface=cls.dut_wiface)
            if wan_d['result'] == "fail":
                cls.result_message = "Failed to get IPaddress for dut wan iface {}".format(cls.dut_wiface)
                publish_html(comment=cls.result_message)
                cls.tearDownClass()
                raise unittest2.SkipTest(cls.result_message)
            cls.ip_addr = wan_d['ipaddr']
        else:
            logger.dumpLog("Wrong mode passed , {} not recognized".format(cls.mode))

        sleep(5)
        publish_html(comment='Class test log', log_link=cls.cls_test_log)

    def setUp(self):
        """
        The function to apply parameter changes to DUT at case level
        Args:
            None
        Returns:
            None
        """
        super(Ipv4v6Master, self).setUp()

        ### Publish the test paramters to HTML report
        pub_qcid = "TC_"+str(self.case_id)
        pub_test_desc = "Verifying sanity with different combinations"
        param_dict = {'stream': self.stream,
                      'proto': self.proto}
        if self.accel_type != None:
            param_dict.update({'accel_type': self.accel_type})
        pub_param_desc =  param_dict

        publish_html(qcid=pub_qcid, test_desc=pub_test_desc, param_desc=pub_param_desc)

        if self.accel_type != None:
            logger.dumpLog("Start Setting Accelration Config")
            if self.accel_type == "MPE" or self.accel_type == "PAE":
                op_d = dut.tools.hw_accel_enable(wan_conn=self.wan_conn,
                                                 hw_type=self.accel_type,
                                                 mode=self.mode,
                                                 wan_iface=self.dut_wiface,
                                                 qos_action='A')
            elif self.accel_type == "sw_accel":
                op_d = dut.tools.sw_accleration_config(enable=True)

            elif self.accel_type == "cpu_path":
                op_d = dut.tools.enable_cpu_path()
            else:
                logger.dumpLog("No such accel type exsist - {}".format(self.accel_type))
                op_d = {}
                op_d['result'] = "fail"

            if op_d['result'] == "fail":
                self.result_message = "{} Accel enabling Failed".format(self.accel_type)
                publish_html(comment=self.result_message)
                self.tearDown()
                self.skipTest(self.result_message)

        ####### check connectivity ##########
        logger.dumpLog("Checking connectivity")

        ip_addr = wan.os.get_interface_ipaddr(self.w_iface)
        if not ip_addr:
            self.result_message = "Not able to get wan ip for iface {}".format(self.w_iface)
            publish_html(comment=self.result_message)
            self.tearDown()
            self.skipTest(self.result_message)
        self.wan_host_ip=ip_addr
        ####### Start ping from lan to wan ##########
        logger.dumpLog('Start pinging from lan to wan')
        if not lan.os.start_ping_p(ip=ip_addr):
            self.result_message = "Not able to ping wan ip {}".format(ip_addr)
            publish_html(comment=self.result_message)
            self.tearDown()
            self.skipTest(self.result_message)

        publish_html(comment='Case test log', log_link=self.case_test_log)


    def runTest(self):
        """
        The function to steps
        Args:
            None
        Returns:
            None
        """
        super(Ipv4v6Master, self).runTest()
        return True

    def step1(self):
        """
        The function to update traffic dict
        Args:
            None
        Returns:
            None
        """
        try:
            pub_qcid = "TC_"+str(self.case_id)+"_"+str(self.step_id)
        except Exception as err:
            pub_qcid = ""
        pub_test_desc = "updating traffic dict"

        publish_html(qcid=pub_qcid, test_desc=pub_test_desc)
        logger.dumpLog("Updating traffic dict for server-client pairs")
        self.traffic_dict = {}
        self.traffic_dict['pairs_list'] = ['pair1']
        self.traffic_dict['pair1'] = {}
        self.traffic_dict['pair1']['config'] = {}
        self.traffic_dict['pair1']['logfile'] = 'Pair1'
        self.traffic_dict['pair1']['config']['bandwidth'] = "1G"
        self.traffic_dict['pair1']['config']['duration'] = str(runtime_para['Traffic_duration'])
        self.traffic_dict['pair1']['config']['parallel_streams'] = '1'
        self.traffic_dict['pair1']['config']['proto'] = self.proto
        self.traffic_dict['pair1']['config']['windowsize'] = "4M"
        self.traffic_dict['pair1']['config']['WMM'] = "VO"
        self.traffic_dict['pair1']['config']['port'] = self.port
        self.traffic_dict['pair1']['trim_flag'] = False
        self.traffic_dict['pair1']["src_dev"] = lan
        self.traffic_dict['pair1']["dest_dev"] = wan
        self.traffic_dict['pair1']['config']['dest_ip'] = wan.os.get_interface_ipaddr(self.w_iface)
        if self.proto == "udp" and self.pckt_len != None:
            self.traffic_dict['pair1']['config']['bufferlen'] = self.pckt_len

        if self.stream == 'downstream':
            self.traffic_dict['stream'] = "downstream"
            self.traffic_dict['pair1']["src_dev"] = wan
            self.traffic_dict['pair1']["dest_dev"] = lan
            self.traffic_dict['pair1']['config']['dest_ip'] = self.ip_addr

        elif self.stream == 'bidi':
            self.traffic_dict['pairs_list'].append('pair2')
            self.traffic_dict['pair2'] = {}
            self.traffic_dict['pair2']['config'] = {}
            self.traffic_dict['pair2']['logfile'] = 'Pair2'
            self.traffic_dict['pair2']['config']['bandwidth'] = "1G"
            self.traffic_dict['pair2']['config']['duration'] = str(runtime_para['Traffic_duration'])
            self.traffic_dict['pair2']['config']['parallel_streams'] = '1'
            self.traffic_dict['pair2']['config']['proto'] = self.proto
            self.traffic_dict['pair2']['config']['windowsize'] = "4M"
            self.traffic_dict['pair2']['config']['WMM'] = "VO"
            self.traffic_dict['pair2']['config']['port'] = str(int(self.port)+1)
            self.traffic_dict['pair2']['trim_flag'] = False
            self.traffic_dict['pair2']["src_dev"] = wan
            self.traffic_dict['pair2']["dest_dev"] = lan
            self.traffic_dict['pair2']['config']['dest_ip'] = self.ip_addr
            if self.proto == "udp" and self.pckt_len != None:
                self.traffic_dict['pair2']['config']['bufferlen'] = self.pckt_len
        return True

    def step2(self):
        """
        The function to start traffic
        Args:
            None
        Returns:
            None
        """
        try:
            pub_qcid = "TC_"+str(self.case_id)+"_"+str(self.step_id)
        except Exception as err:
            pub_qcid = ""
        pub_test_desc = "Starting traffic"

        publish_html(qcid=pub_qcid, test_desc=pub_test_desc)

        self.result_dict = {}

        #exe_time is kept 300 sec to accomodate execution time of stc
        o_d = dut.tools.start_profiling_tool(exe_time=300)
        if o_d['result'] == 'fail':
            self.result_message = "Profiling tool Not started"
            publish_html(comment=self.result_message)
            publish_html(comment='Steps log', log_link=self.case_test_log)

        if self.mode == "route":
            if self.accel_type == "MPE" or self.accel_type == "PAE":
                self.message = ['msg','flag']
                parallel_exec(dut.tools.hw_accel_validate)(message=self.message,
                                                           proto=self.proto,
                                                           lan_host_eth_ip=self.lan_ip,
                                                           wan_host_eth_ip=self.wan_host_ip,
                                                           stream=self.stream,
                                                           hw_type=self.accel_type,
                                                           wan_conn=self.wan_conn,
                                                           loop_count=runtime_para['accel_loop_cnt'],
                                                           wait_time=runtime_para['accel_wait_time'],
                                                           tun_name=self.tun_name,
                                                           obj=dut)
        self.result_dict = lan.traffic.run_traffic(self.traffic_dict)
        #collecting hw accel thread status
        if self.mode == "route":
            if self.accel_type == "MPE" or self.accel_type == "PAE":
                output=end_parallel(timeout = (runtime_para['Traffic_duration'] + 10))

        #to stop profiling tool if still running
        dut.tools.kill_profiling_tool()

        if o_d['result'] == 'fail':
            return False

        return True

    def step3(self):
        """
        The function to compute throughput
        Args:
            None
        Returns:
            None
        """
        try:
            pub_qcid = "TC_"+str(self.case_id)+"_"+str(self.step_id)
        except Exception as err:
            pub_qcid = ""
        pub_test_desc = "Computing throughput"

        publish_html(qcid=pub_qcid, test_desc=pub_test_desc)
        rate = 0
        for pair in self.traffic_dict["pairs_list"]:
            s_obj = re.search(r'(\d+(?:.\d+)?)\s+(\S)bits/sec',self.result_dict[pair]["max_tput"])
            if s_obj != None:
                s_lst = s_obj.groups()
                if s_lst[1] == 'K':
                    rate += float(s_lst[0])/ 1000;
                elif s_lst[1] == 'G':
                    rate += float(s_lst[0]) * 1000;
                else:
                    rate += float(s_lst[0])
                self.result_message = "Overall Throughput is {} Mbps\n".format(rate)
            else:
                self.result_message = "Traffic tool failed\n"
                publish_html(comment=self.result_message)
                publish_html(comment='Steps log', log_link=self.case_test_log)
                return False

        publish_html(comment=self.result_message)
        ### Publish the test comments to HTML report
        publish_html(comment='Steps log', log_link=self.case_test_log)
        return True

    def step4(self):
        """
        The function to check acceleration
        Args:
            None
        Returns:
            None
        """
        try:
            pub_qcid = "TC_"+str(self.case_id)+"_"+str(self.step_id)
        except Exception as err:
            pub_qcid = ""

        pub_test_desc = "Validating Acceleration"

        publish_html(qcid=pub_qcid, test_desc=pub_test_desc)

        if self.mode == "route":
            if self.accel_type == "MPE" or self.accel_type == "PAE":
                if self.message[1] == "FAIL":
                    msg = self.message[0]
                    self.result_message = "Validating Acceleration Failed"
                    publish_html(comment=self.result_message)
                    publish_html(comment='Steps log', log_link=self.case_test_log)
                    return False
                else:
                    self.result_message = self.message[0]
            else:
                self.result_message = "Acceleration Module not enabled"
        else:
            self.result_message = "Acceleration validation criteria not avialable for bridge"

        publish_html(comment=self.result_message)
        ### Publish the test comments to HTML report
        publish_html(comment='Steps log', log_link=self.case_test_log)
        return True

    def step5(self):
        """
        The function to check CPU Core Usage
        Args:
            None
        Returns:
            None
        """
        try:
            pub_qcid = "TC_"+str(self.case_id)+"_"+str(self.step_id)
        except Exception as err:
            pub_qcid = ""

        pub_test_desc = "Checking CPU Core Usage"

        publish_html(qcid=pub_qcid, test_desc=pub_test_desc)

        o_d = dut.tools.get_cpu_usage()
        if o_d['result'] != 'fail':
            core0_usage = float(o_d['avg_core_0'])
            core1_usage = float(o_d['avg_core_1'])
            self.result_message = "Avg CPU Usage:\nCore0: %.2f\nCore1: %.2f" %(core0_usage, core1_usage)
        else:
            self.result_message = "Checking CPU Core Usage failed"
            publish_html(comment=self.result_message)
            publish_html(comment='Steps log', log_link=self.case_test_log)
            return False

        publish_html(comment=self.result_message)
        ### Publish the test comments to HTML report
        publish_html(comment='Steps log', log_link=self.case_test_log)
        return True

    def tearDown(self):
        """
        The function to do clean up in all machines before next case execution
        Args:
            None
        Returns:
            None:
        """
        if self.mode != "bridge":
            #removing default route
            if runtime_para['TUN_SETUP']:
                wan.os.restart_services()
        if self.accel_type != None:
            logger.dumpLog("Disabling Hw accel")
            if self.accel_type == "MPE" or self.accel_type == "PAE":
                dut.tools.hw_accel_disable(mode=self.mode)
            elif self.accel_type == "sw_accel":
                dut.tools.sw_accleration_config(enable=False)
            elif self.accel_type == "cpu_path":
                dut.tools.enable_cpu_path()
        super(Ipv4v6Master, self).tearDown()
        return True

    @classmethod
    def tearDownClass(cls):
        """
        The function to revert network configurations if changed
           Args:
               None
           returns:
               None
        """
        if cls.mode != "bridge":
            logger.dumpLog("Reverting Network config")
            dut.tools.reset_network_defaults(wan_proto=cls.wan_proto, wan_iface=cls.dut_wiface)
        else:
            logger.dumpLog("Removing iface from bridge")
            dut.tools.del_iface_bridge(bridge_name=dut.dict['br_name'], iface=cls.dut_wiface)
            logger.dumpLog("Reverting ip of lan machine to original ip")
            lan.os.release_dhcp_ip(iface=lan.dict['iface'])
            lan.os.config_static_ip(iface=lan.dict['iface'],
                                    static_ip=lan.dict['static_ip'],
                                    netmask=lan.dict['netmask'],
                                    gw=dut.dict['ipaddr'])
            sleep(5)
            dut.tools.rm_extra_ifaces()
        super(Ipv4v6Master, cls).tearDownClass()
        sleep(10)
        return True


