#Copyright(c) 2018 Intel CorporaTion
# All rights reserved.
#
# This file is distributed under the Clear BSD license.
# The full text can be found in LICENSE in the root directory.
# This file consist of classes for computing Throughput and Idle cpu
# cycles for upstream, downstream and birectional traffic

from tests import linux_boot
from devices.platform_types.linux import *
from devices import *
from globalVariables import *
from log_creator import loggerObject as logger
from log_creator import logger as logClass
from parallel_exec import *
from config import runtime_para, kpi_para
from framework.publish_info_to_html import publish_html

from time import *
import copy


class Ipv4v6MasterStc(linux_boot.LinuxBootTest):
    """
    This class is master class for testing ipv4 and ipv6 sanity as well as performance for:
    @ All Acceleration modes
    @ All Directions i.e, upstream downstream and bidi
    @ Route and Bridge mode
    @ All wan modes and wan connections
    Also this class is parent class for testing following features:
    @ VPN - ipogre,eogre and l2tpv2
    @ IPSeC - ipsec and l2tp + ipsec
    @ IPV6 - Dslite and 6RD
    @ Multicast - IGMPV3 and MLD proxy
    @ QOS, Session management, Firewall, NAT, Routing, Bridging, stats and counters, config and debugging
    Attributes:
        None
    """

    @classmethod
    def setUpClass(cls):
        super(Ipv4v6MasterStc, cls).setUpClass()
        ### Publish the test paramters to HTML report
        pub_qcid = "QC_1"
        pub_test_desc = "IPV4 Performace testing"
        publish_html(qcid=pub_qcid, test_desc=pub_test_desc)

    def setUp(self):
        """
        The function to apply parameter changes to DUT at case level
        Args:
            None
        Returns:
            None
        """

        #creating essential params
        self.user = None
        self.password = None
        self.vlan_id = None
        self.vpi = None
        self.vci = None
        self.tun_name = None
        self.mode = "route"
        self.min_val = '1'
        self.max_val = '1000'
        self.step_val = '10'
        self.start_val = '1000'
        self.loss_val = '5.1'

        super(Ipv4v6MasterStc, self).setUp()

        ### Publish the test paramters to HTML report
        pub_qcid = "TC_"+str(self.case_id)
        pub_test_desc = "Verifying sanity with different combinations"
        param_dict = {'stream': self.stream,
                      'proto': self.proto}
        if self.accel_type != None:
            param_dict.update({'accel_type': self.accel_type})
        pub_param_desc =  param_dict

        publish_html(qcid=pub_qcid, test_desc=pub_test_desc, param_desc=pub_param_desc)

        logger.dumpLog("PTA:{}, PRT:{}, TUN:{}".format(runtime_para['PTA_SETUP'], runtime_para['PRT_SETUP'], runtime_para['TUN_SETUP']))

        if runtime_para['PTA_SETUP'] or runtime_para['PRT_SETUP'] or self.wan_conn == "eth_tag":#cisco router will be used
            self.w_iface = ("{}.{}").format(wan.dict['iface'], wan.dict['vlan_id'])
        else:#without cisco router
            self.w_iface = wan.dict['iface']

        #getting lan ip
        self.lan_ip = lan.os.get_interface_ipaddr(lan.dict['iface'])
        if not self.lan_ip:
            self.result_message = "Failed to get ip for iface {}".format(lan.dict['iface'])
            publish_html(comment=self.result_message)
            self.tearDownClass()
            raise unittest2.SkipTest(self.result_message)

        #removing extra wan ifaces of DUT if present
        dut.tools.rm_extra_ifaces()

        if self.wan_conn == "vdsl_ptm_17a" or self.wan_conn == "adsl_atm" or self.wan_conn == "vdsl_ptm_30":
            #setting dsl module in dut to full auto mode
            dut.tools.dsl_auto_mode_config()
            dut.tools.check_show_time()
            dslam.tools.configure_dslam(server_script=dslam.dict[self.wan_conn])
            dut.tools.check_show_time()
        #checking show time in dut
        #creating wan connection and getting wan interface of dut
        cn_d = dut.tools.wan_create_conn(wan_conn=self.wan_conn, vlan_id=self.vlan_id, mode=self.mode, vpi=self.vpi, vci=self.vci)
        if cn_d['result'] == 'fail':
            self.result_message = "Failed to create wan connection - {}".format(self.wan_conn)
            publish_html(comment=self.result_message)
            self.tearDownClass()
            raise unittest2.SkipTest(self.result_message)
        self.dut_wiface = cn_d['wan_iface']


        #restarting vlan script in case of tunnel setup
        if runtime_para['TUN_SETUP']:
            wan.os.restart_services()

        if self.mode == "route":
            if  self.wan_proto.lower() == 'static':
                self.vlan_id = None
            logger.dumpLog("Applying the {} configs".format(self.wan_proto))
            wan_m = dut.tools.wan_mode_config(wan_proto=self.wan_proto,
                                              wan_iface=self.dut_wiface,
                                              vlan_id=self.vlan_id,
                                              user=self.user,
                                              password=self.password)
            if wan_m['result'] == "fail":
                self.result_message = "Failed to Create dut wan iface {}".format(self.dut_wiface)
                publish_html(comment=self.result_message)
                self.tearDownClass()
                raise unittest2.SkipTest(self.result_message)
        else:
            logger.dumpLog("Wrong mode passed , {} not recognized".format(self.mode))

        if self.accel_type == "MPE" or self.accel_type == "PAE":
            logger.dumpLog("Start Setting Accelration Config")
            op_d = dut.tools.hw_accel_enable(wan_conn=self.wan_conn, hw_type=self.accel_type, mode=self.mode)
            if op_d['result'] == "fail":
                self.result_message = "{} Accel enabling Failed".format(self.accel_type)
                publish_html(comment=self.result_message)
                self.tearDown()
                self.skipTest(self.result_message)

        self.lan_ip = stc.dict['LAN_EndpointIP']
        self.wan_host_ip = stc.dict['WAN_EndpointIP']
        sleep(5)
        #route mode related operations for downstream and bidi cases
        if self.stream != "upstream":# it will be route mode,
            logger.dumpLog("Updating pre route config")
            op_d = dut.tools.update_preroute(wan_ip=self.wan_host_ip, flag="A")
            if op_d['result'] == "fail":
                self.result_message = "Preroute addition failed for {}".format(self.wan_host_ip)
                publish_html(comment=self.result_message)
                self.tearDown()
                self.skipTest(self.result_message)
            logger.dumpLog("Modifying dmz")
            op_d = dut.tools.modify_dmz_rule(dest_ip=self.lan_ip, flag="ENABLE")
            if op_d['result'] == "fail":
               self.result_message = "Dmz modification failed for {}".format(self.lan_ip)
               publish_html(comment=self.result_message)
               self.tearDown()
               self.skipTest(self.result_message)

        publish_html(comment='Case test log', log_link=self.case_test_log)

    def runTest(self):
        """
        The function to steps
        Args:
            None
        Returns:
            None
        """
        super(Ipv4v6MasterStc, self).runTest()
        return True

    def step1(self):
        """
        The function to update traffic dict
        Args:
            None
        Returns:
            None
        """
        try:
            pub_qcid = "TC_"+str(self.case_id)+"_"+str(self.step_id)
        except Exception as err:
            pub_qcid = ""
        pub_test_desc = "updating traffic dict"

        publish_html(qcid=pub_qcid, test_desc=pub_test_desc)
        logger.dumpLog("Updating traffic dict for server-client pairs")
        self.traffic_dict = {}
        self.traffic_dict['pairs_list'] = ['pair1']
        self.traffic_dict['pair1'] = {}
        self.traffic_dict['pair1']['config'] = {}

        if self.proto == "udp" and self.pckt_len != None:
            self.traffic_dict['pair1']['config']['bufferlen'] = self.pckt_len

        self.traffic_dict['stream'] = "upstream"
        self.traffic_dict['stc_dev'] = stc
        self.traffic_dict['pair1']["endpoint_count"] = "2"
        self.traffic_dict['pair1']["trafficparam_count"] = "1"
        self.traffic_dict['pair1']["LAN_DUTPortID"] = "LAN"
        self.traffic_dict['pair1']["WAN_DUTPortID"] = "WAN"
        self.traffic_dict['pair1']["LAN_Name"] = "ELAN_1"
        self.traffic_dict['pair1']["WAN_Name"] = "BRAS_1"
        self.traffic_dict['pair1']["ClientEndpointName"] = "ELAN_1"
        self.traffic_dict['pair1']["ServerEndpointName"] = "BRAS_1"
        self.traffic_dict['pair1']["config"]["WAN_BRASEmulation"] = self.wan_proto
        self.traffic_dict['pair1']["config"]["L4ProtocolType"] = "udp"
        self.traffic_dict['pair1']["config"]["PairCount"] = "1"
        self.traffic_dict['pair1']["config"]["LossTolerance"] = self.loss_val
        self.traffic_dict['pair1']["config"]["DecimalPlaces"] = "3"
        self.traffic_dict['pair1']["config"]["IterativeSearchDuration"] = "10"
        self.traffic_dict['pair1']["config"]["MaxIterations"] = self.max_iter
        self.traffic_dict['pair1']["config"]["SearchMethod"] = "Binary"
        self.traffic_dict['pair1']["config"]["MinValue"] = self.min_val
        self.traffic_dict['pair1']["config"]["MaxValue"] = self.max_val
        self.traffic_dict['pair1']["config"]["StepValue"] = self.step_val
        self.traffic_dict['pair1']["config"]["StartValue"] = self.start_val

        if self.stream == 'downstream':
            self.traffic_dict['stream'] = "downstream"
            self.traffic_dict['pair1']["ClientEndpointName"] = "BRAS_1"
            self.traffic_dict['pair1']["ServerEndpointName"] = "ELAN_1"

        elif self.stream == 'bidi':
            self.traffic_dict['stream'] = "bidirectional"
        return True

    def step2(self):
        """
        The function to start traffic
        Args:
            None
        Returns:
            None
        """
        try:
            pub_qcid = "TC_"+str(self.case_id)+"_"+str(self.step_id)
        except Exception as err:
            pub_qcid = ""
        pub_test_desc = "Starting traffic"

        publish_html(qcid=pub_qcid, test_desc=pub_test_desc)

        self.result_dict = {}

        #exe_time is kept 300 sec to accomodate execution time of stc
        o_d = dut.tools.start_profiling_tool(exe_time=300)
        if o_d['result'] == 'fail':
            self.result_message = "Profiling tool Not started"
            publish_html(comment=self.result_message)
            publish_html(comment='Steps log', log_link=self.case_test_log)

        if self.mode == "route":
            if self.accel_type == "MPE" or self.accel_type == "PAE":
                self.message = ['msg','flag']
                parallel_exec(dut.tools.hw_accel_validate)(message=self.message,
                                                           proto=self.proto,
                                                           lan_host_eth_ip=self.lan_ip,
                                                           wan_host_eth_ip=self.wan_host_ip,
                                                           stream=self.stream,
                                                           hw_type=self.accel_type,
                                                           wan_conn=self.wan_conn,
                                                           loop_count=runtime_para['Traffic_duration'],
                                                           wait_time=runtime_para['accel_wait_time'],
                                                           tun_name=self.tun_name)
        self.result_dict = lan.traffic.run_traffic(self.traffic_dict)

        #collecting hw accel thread status
        if self.mode == "route":
            if self.accel_type == "MPE" or self.accel_type == "PAE":
                output=end_parallel(timeout=120)

        #to stop profiling tool if still running
        dut.tools.kill_profiling_tool()

        if o_d['result'] == 'fail':
            return False

        return True

    def step3(self):
        """
        The function to compute throughput
        Args:
            None
        Returns:
            None
        """
        try:
            pub_qcid = "TC_"+str(self.case_id)+"_"+str(self.step_id)
        except Exception as err:
            pub_qcid = ""
        pub_test_desc = "Computing throughput"

        publish_html(qcid=pub_qcid, test_desc=pub_test_desc)
        rate = 0
        for pair in self.traffic_dict["pairs_list"]:
            s_obj = re.search(r'(\d+(?:.\d+)?)\s+(\S)bits/sec',self.result_dict[pair]["max_tput"])
            if s_obj != None:
                s_lst = s_obj.groups()
                if s_lst[1] == 'K':
                    rate += float(s_lst[0])/ 1000;
                elif s_lst[1] == 'G':
                    rate += float(s_lst[0]) * 1000;
                else:
                    rate += float(s_lst[0])
                self.result_message = "Overall Throughput is {} Mbps\n".format(rate)
            else:
                self.result_message = "Traffic tool failed\n"
                publish_html(comment=self.result_message)
                publish_html(comment='Steps log', log_link=self.case_test_log)
                return False

        kpi_d = dut.tools.get_kpi_value(wan_conn=self.wan_conn,
                           mode=self.mode,
                           wan_proto=self.wan_proto,
                           accel_type=self.accel_type,
                           stream=self.stream,
                           proto=self.proto,
                           pckt_len=self.pckt_len)
        if kpi_d['result'] != 'fail':
            if rate >= kpi_d['kpi']:
                self.result_message = "Overall Throughput is {} Mbps, which is more than KPI: {} Mbps\n".format(rate,kpi_d['kpi'])
            else:
                self.result_message = "Overall Throughput is {} Mbps, which is less than KPI: {} Mbps\n".format(rate, kpi_d['kpi'])
                publish_html(comment=self.result_message)
                return False

        publish_html(comment=self.result_message)
        return True


    def step4(self):
        """
        The function to check acceleration
        Args:
            None
        Returns:
            None
        """
        try:
            pub_qcid = "TC_"+str(self.case_id)+"_"+str(self.step_id)
        except Exception as err:
            pub_qcid = ""

        pub_test_desc = "Validating Acceleration"

        publish_html(qcid=pub_qcid, test_desc=pub_test_desc)

        if self.mode == "route":
            if self.accel_type == "MPE" or self.accel_type == "PAE":
                if self.message[1] == "FAIL":
                    msg = self.message[0]
                    self.result_message = "Validating Acceleration Failed"
                    publish_html(comment=self.result_message)
                    return False
                else:
                    self.result_message = self.message[0]
            else:
                self.result_message = "Acceleration Module not enabled"
        else:
            self.result_message = "Acceleration validation criteria not avialable for bridge"

        publish_html(comment=self.result_message)
        ### Publish the test comments to HTML report
        return True

    def step5(self):
        """
        The function to check CPU Core Usage
        Args:
            None
        Returns:
            None
        """
        try:
            pub_qcid = "TC_"+str(self.case_id)+"_"+str(self.step_id)
        except Exception as err:
            pub_qcid = ""

        pub_test_desc = "Checking CPU Core Usage"

        publish_html(qcid=pub_qcid, test_desc=pub_test_desc)

        o_d = dut.tools.get_cpu_usage()
        if o_d['result'] != 'fail':
            core0_usage = float(o_d['avg_core_0'])
            core1_usage = float(o_d['avg_core_1'])
            self.result_message = "Avg CPU Usage:\nCore0: %.2f\nCore1: %.2f" %(core0_usage, core1_usage)
        else:
            self.result_message = "Checking CPU Core Usage failed"
            publish_html(comment=self.result_message)
            publish_html(comment='Steps log', log_link=self.case_test_log)
            return False

        publish_html(comment=self.result_message)
        ### Publish the test comments to HTML report
        publish_html(comment='Steps log', log_link=self.case_test_log)
        return True

    def tearDown(self):
        """
        The function to do clean up in all machines before next case execution
        Args:
            None
        Returns:
            None:
        """
        if self.mode == "route":
            logger.dumpLog("Reverting Network config")
            dut.tools.reset_network_defaults(wan_proto=self.wan_proto, wan_iface=self.dut_wiface)

            #removing default route
            if runtime_para['TUN_SETUP']:
                wan.os.restart_services()

        if self.accel_type == "MPE" or self.accel_type == "PAE":
            logger.dumpLog("Disabling Hw accel")
            dut.tools.hw_accel_disable(mode=self.mode)

        self.lan_ip = stc.dict['LAN_EndpointIP']
        self.wan_host_ip = stc.dict['WAN_EndpointIP']

        if self.stream != "upstream":
            logger.dumpLog("Deleting pre route from dut")
            dut.tools.update_preroute(wan_ip=self.wan_host_ip, flag="D")
            logger.dumpLog("Disabling DMZ in dut")
            dut.tools.modify_dmz_rule(dest_ip=self.lan_ip, flag="DISABLE")

        super(Ipv4v6MasterStc, self).tearDown()
        sleep(10)
        return True

    @classmethod
    def tearDownClass(cls):
        """
        The function to revert network configurations if changed
           Args:
               None
           returns:
               None
        """
        super(Ipv4v6MasterStc, cls).tearDownClass()
        sleep(10)
        return True


