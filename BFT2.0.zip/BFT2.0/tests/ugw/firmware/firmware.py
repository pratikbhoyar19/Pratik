#Copyright(c) 2018 Intel Corporation
# All rights reserved.
#
# This file is distributed under the Clear BSD license.
# The full text can be found in LICENSE in the root directory.
# This file consist of classes for upgrading the firmware of the DUT

import lib
import re
from distutils.util import strtobool
import unittest2
from tests import linux_boot
from devices import *
from globalVariables import *
from log_creator import loggerObject as logger
from time import *
from parallel_exec import *
import config
from framework.process_params import process_setup, process_setupclass, process_output
from config import runtime_para, kpi_para
from framework.publish_info_to_html import publish_html

class FirmwareUpgrade(linux_boot.LinuxBootTest):
    """
    This is a class for FirmwareUpgrade of the DUT and check the wan connectivty after Upgrade

    Attributes :
    None
    """
    @classmethod
    def setUpClass(cls):
        """
        The function calls and updates the required Parametrs 
        Args:
            None
        Returns:
            None
        """
        #creating essential params
        cls.user = None
        cls.password = None
        cls.vlan_id = None
        cls.hw_type = None
        cls.wan_conn = None
        cls.wlan_ap = 'False'
        cls.nand_boot_update = 'False'

        super(FirmwareUpgrade, cls).setUpClass()
        #removing extra wan ifaces of DUT if present
        dut.tools.rm_extra_ifaces()
        #creating wan connection and getting wan interface of dut     
        cn_d = dut.tools.wan_create_conn(wan_conn=cls.wan_conn, vlan_id=cls.vlan_id)
        if cn_d['result'] == 'fail':
            cls.result_message = "Failed to create wan connection - {}".format(cls.wan_conn)
            publish_html(comment=cls.result_message)
            cls.tearDownClass()
            raise unittest2.SkipTest(cls.result_message)
        cls.dut_wiface = cn_d['wan_iface']

    def setUp(self):
        """
        The function is used to check the ip addr for br-lan and connectivty to the tftp server
        Args:
           None
        Returns:
            True/False

        """
        super(FirmwareUpgrade, self).setUp()
        #### Publish the test paramters to HTML report
        pub_qcid = "TC_"+str(self.case_id)
        pub_test_desc = "Update the Firmware of the DUT"
        param_dict = {'Flash_version': self.flash_version}
        pub_param_desc = param_dict
        publish_html(qcid=pub_qcid, test_desc=pub_test_desc, param_desc=pub_param_desc)

        if dut.dict['br_name'] == None:
            dut.dict['br_name'] = "br-lan"
        self.ipaddr = dut.os.get_interface_ipaddr(interface =  dut.dict['br_name'])
        if not self.ipaddr:
            logger.dumpLog("Failed to get the ipaddr for %s interface"% dut.dict['br_name'])
            self.result_message = "SETUP ERROR: Failed to get the ip address"
            ### Publish the test comments to HTML report
            publish_html(comment=self.result_message)
            self.tearDown()
            self.skipTest(self.result_message)
        logger.dumpLog("the ipaddr for %s interface is %s" % ( dut.dict['br_name'],self.ipaddr))
        logger.dumpLog("Checking the connectivity to the tftp server")
        if not dut.os.start_ping_p(ip=dut.dict['tftp_server_ip']):
            logger.dumpLog("Failed to Ping the tftp server , Please check the connectivty")
            self.result_message = "SETUP ERROR: Failed to Ping the ip address"
            ### Publish the test comments to HTML report
            publish_html(comment=self.result_message)

            self.tearDown()
            self.skipTest(self.result_message)

        logger.dumpLog("tftp server is reachbale from the dut")
        return True

    def runTest(self):
        """
        The function is used to Upgrade the dut firmware as step1 and
        check the wan mode config post upgrade as step2
        Args:
           None
        Returns:
            None
        """
        super(FirmwareUpgrade, self).runTest()

    def step1(self):
        """
        This step is used for firmware upgrade for the tftpboot
        Args:
          None
        Returns:
            True/False
        """
        logger.dumpLog("Upgrading the Dut Firmware")
        try:
            pub_qcid = "TC_"+str(self.case_id)+"_"+str(self.step_id)
        except Exception as err:
            pub_qcid = ""
        pub_test_desc = "Upgrading the Dut Firmware"

        publish_html(qcid=pub_qcid, test_desc=pub_test_desc)

        #Break into uboot and, set environment variable and flashes the image
        if not dut.swdist.burn_image(dut.dict['tftp_server_ip'],self.flash_version,
                                     strtobool(self.wlan_ap),strtobool(self.nand_boot_update)):
            logger.dumpLog("ERROR : Failed to upgrade the Firmware")
            self.result_message = "Image flash to dut got failed"
            ### Publish the test comments to HTML report
            publish_html(comment=self.result_message)
            return False
        logger.dumpLog("Dut Firmware upgrade has done successfully")

        for i in range(5):
            try:
                dut.session.send_line('mount')
                dut.session.recv_line('overlayfs:/overlay on / type overlay')
            except BaseException:
                if i == 4:
                    logger.dumpLog("WARN: Overlay still not mounted")
                else:
                     pass
            else:
                 break
        return True

    def step2(self):
        """
        This step is used to check the wan mode connectivty after dut firmware upgrade
        Args:
            None
        Returns:
            True/False
        """
        logger.dumpLog("Obtaining WAN IP addr for DUT")
        try:
            pub_qcid = "TC_"+str(self.case_id)+"_"+str(self.step_id)
        except Exception as err:
            pub_qcid = ""
        pub_test_desc = "Obtaning the Ip addr for the DUT"

        publish_html(qcid=pub_qcid, test_desc=pub_test_desc)
         #removing extra wan ifaces of DUT if present
        dut.tools.rm_extra_ifaces()
 
        #creating wan connection and getting wan interface of dut     
        cn_d = dut.tools.wan_create_conn(wan_conn=self.wan_conn, vlan_id=self.vlan_id)
        if cn_d['result'] == 'fail':
            self.result_message = "Failed to create wan connection - {}".format(self.wan_conn)
            publish_html(comment=self.result_message)
            return False
        self.dut_wiface = cn_d['wan_iface']


        logger.dumpLog("Applying the {} configs".format(self.wan_proto))
        wan_m = dut.tools.wan_mode_config(wan_proto=self.wan_proto,
                                          wan_iface=self.dut_wiface,
                                          vlan_id=self.vlan_id,
                                          user=self.user,
                                          password=self.password)
        if wan_m['result'] == "fail":
            self.result_message = "Failed to Create dut wan iface {}".format(self.dut_wiface)
            publish_html(comment=self.result_message)
            self.tearDown()
            raise unittest2.SkipTest(self.result_message)

        if self.wan_proto == "pppoe":
            ppp_d = dut.tools.get_ppp_iface()
            if ppp_d['result'] == 'fail':
                self.result_message = "Failed to get PPPoE iface"
                publish_html(comment=self.result_message)
                self.tearDownClass()
                raise unittest2.SkipTest(cls.result_message)
            self.dut_wiface = ppp_d['ppp_iface']
        logger.dumpLog("Obtaining WAN IP addr for DUT")
        #Getting WAN IP in DUT
        wan_d = dut.tools.get_dut_wan_ip(wan_iface=self.dut_wiface)
        if wan_d['result'] == "fail":
            self.result_message = "Failed to get IPaddress for dut wan iface {} after image flashing".format(self.dut_wiface)
            publish_html(comment=self.result_message)
            self.tearDown()
            raise unittest2.SkipTest(cls.result_message)

        self.ip_addr = wan_d['ipaddr']
        if self.ip_addr != None:
            logger.dumpLog("Obtained the ipaddress %s for the wan mode after image flushing"%self.ip_addr)
            self.result_message = "Obtained the ipaddress {} for the wan mode after image flushing".format(self.ip_addr)
            publish_html(comment=self.result_message)
            return True
        else:
            logger.dumpLog("Failed to Obtained the ipaddress for the wan mode after image flushing")
            self.result_message = "Failed to obtain the ipaddress for the wan mode after image flushing"
            publish_html(comment=self.result_message)
            return False

    def tearDown(self):
        """
        This is the end of the firmware upgrade test case
        Args:
            None
        Returs:
            None
        Raises:
            None

        """
        logger.dumpLog("tearDown called susscesfully")

        super(FirmwareUpgrade, self).tearDown()
        return True

    @classmethod
    def tearDownClass(cls):
        """
        The function to revert network configurations if changed 
           Args:
               None
           returns:
               None
        """
        logger.dumpLog("Reverting Network config")
        dut.tools.reset_network_defaults(wan_proto=cls.wan_proto, wan_iface=cls.dut_wiface)
        sleep(10)
        logger.dumpLog("tearDown called susscesfully")
        super(FirmwareUpgrade, cls).tearDownClass()
        return True 



