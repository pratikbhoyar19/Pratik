#Copyright(c) 2018 Intel Corporation
# All rights reserved.
#
# This file is distributed under the Clear BSD license.
# The full text can be found in LICENSE in the root directory.
# This file consist of classes for computing Throughput and Idle cpu
# cycles for upstream, downstream and birectional traffic

from tests.ugw.wan.ipv4_v6_master import Ipv4v6Master
from devices.platform_types.linux import *
from devices import *
from globalVariables import *
from log_creator import loggerObject as logger
from log_creator import logger as logClass
from time import *
from config import runtime_para, kpi_para
from framework.publish_info_to_html import publish_html

class PacketFilter(Ipv4v6Master):
    """ This class is used for packet filtering functionality """ 
      
    @classmethod
    def setUpClass(cls):
        """
        The function to get Wan Ip, and to apply Grp level changes to DUT
        Args:
            None
        Returns:
            None
        """
        super(PacketFilter, cls).setUpClass()
        return True
     
    def setUp(self):
        """
        The function to apply parameter changes to DUT at case level
        Args:
            proto(str):protocol(tcp/tcp)
            port(str):port number 
            rule_name(str):ACCEPT/REJECT
        Returns:
            result_dict["result"]:pass/fail
        """
        self.stream = 'upstream'
        super(PacketFilter, self).setUp()
        
    def runTest(self):
        """
        The function to steps
        Args:
            None
        Returns:
            None  
        """
        super(PacketFilter, self).runTest()
        return True

    def step4(self):
        try:
            pub_qcid = "TC_"+str(self.case_id)+"_"+str(self.step_id)
        except Exception as err:
            pub_qcid = ""
        pub_test_desc = "Enabling packet filtering for {}".format(self.proto)

        publish_html(qcid=pub_qcid, test_desc=pub_test_desc)
        #apply packet filter rule
        op_d = dut.tools.add_packet_filtering_rule(proto=self.proto, port=self.port, rule_name = "REJECT")
        if op_d['result'] == "fail":
            self.result_message = "Failed to Enable Packet Filtering on Dut"
            publish_html(comment=self.result_message)
            return False
        logger.dumpLog("Enabled Packet Filtering on dut for {}".format(self.proto))
        return True
 
    def step5(self):            
        """
        The function to start servers
        Args:
            None
        Returns:
            None  
        """
        try:
            pub_qcid = "TC_"+str(self.case_id)+"_"+str(self.step_id)
        except Exception as err:
            pub_qcid = ""
        pub_test_desc = "Starting traffic after enabling packet filtering"
        try:
            super(PacketFilter, self).step2()
            s_obj = re.search(r'(\d+(?:.\d+)?)\s+(\S)bits/sec',self.result_dict[pair]["max_tput"])
            s_lst = s_obj.groups()
            if int(s_lst[0]) == 0:
                logger.dumpLog("connection not established")
                self.result_message = "Packets got filtered successfully\n"
                publish_html(comment=self.result_message)
                ### Publish the test comments to HTML report
                publish_html(comment='Steps log', log_link=self.case_test_log)
                return True
            self.result_message = "Packets filtering got failed\n"
            publish_html(comment=self.result_message)
            ### Publish the test comments to HTML report
            publish_html(comment='Steps log', log_link=self.case_test_log)
            return False
        except:
            logger.dumpLog("connection not established")
            self.result_message = "Packets got filtered successfully\n"
            publish_html(comment=self.result_message)
            ### Publish the test comments to HTML report
            publish_html(comment='Steps log', log_link=self.case_test_log)
            return True
 
    def tearDown(self):
        """
        The function to do clean up in all machines before next case execution
        Args:  
            None
        Returns:
            None:
        """
        #Disabling Packet Filtering on DUT
        logger.dumpLog("Disabling Packet Filtering on DUT")
        dut.tools.del_packet_filtering_rule(proto=self.proto, port=self.port, rule_name = "ACCEPT")
        super(PacketFilter, self).tearDown()
        return True
        
    @classmethod
    def tearDownClass(cls):
        """
        The function to revert network configurations if changed 
           Args:
               None
           returns:
               None
        """
        super(PacketFilter, cls).tearDownClass()
        return True       
