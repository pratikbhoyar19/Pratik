from tests.ugw.wan.ipv4_v6_master import Ipv4v6Master
from devices.platform_types.linux import *
from devices import *
from globalVariables import *
from log_creator import loggerObject as logger
from log_creator import logger as logClass
from time import *
from config import runtime_para, kpi_para
from framework.publish_info_to_html import publish_html

class PortMapping(Ipv4v6Master):
    """"
    This class is for configuring port mapping functionality
   
    """
    @classmethod
    def setUpClass(cls):
        """
        The function to get Wan Ip, and to apply Grp level changes to DUT
        Args:
            None
        Returns:
            None
        """
        super(PortMapping, cls).setUpClass()
        return True
     
    def setUp(self):
        """
        The function to apply parameter changes to DUT at case level 
        Args:
            proto(str):protocol(tcp/udp)
            port(str):port number 
            ip_addr(str):host ip address 
            iface(str):Dut_WAN interface
        Returns:
            result_dict["result"]:pass/fail    
        """
        self.stream = 'downstream'
        super(PortMapping, self).setUp()
        #enabling port forwarding in dut
        logger.dumpLog("Enabling port forwarding in dut")
        op_d = dut.tools.add_forward_traffic_rule(proto=self.proto, port=self.port, ip_addr=self.lan_ip, iface=self.dut_wiface)      
        if op_d['result'] == "fail":
            self.result_message = "Failed to enable port forwarding"
            publish_html(comment=self.result_message)
            self.tearDown()
            self.skipTest(self.result_message)
        
        logger.dumpLog("Enabled port forwarding on dut interface {}".format(self.dut_wiface))   

    def runTest(self):
        """
        The function to steps
        Args:
            None
        Returns:
            None  
        """
        super(PortMapping, self).runTest()
        return True

    def tearDown(self):
        """
        The function to do clean up in all machines before next case execution
        Args:  
            None
        Returns:
            None:
        """
        #Disabling port forwarding in DUT 
        dut.tools.del_forward_traffic_rule(proto=self.proto, port=self.port, ip_addr=self.lan_ip, iface=self.dut_wiface)
        logger.dumpLog("Port forwarding disabled on dut interface {}".format(self.dut_wiface))
        
        super(PortMapping, self).tearDown()
        return True
        
    @classmethod
    def tearDownClass(cls):
        """
        The function to revert network configurations if changed 
           Args:
               None
           returns:
               None
        """
        super(PortMapping, cls).tearDownClass()
        return True       
