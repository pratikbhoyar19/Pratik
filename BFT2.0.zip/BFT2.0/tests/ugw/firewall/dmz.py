#Copyright(c) 2018 Intel Corporation
# All rights reserved.
#
# This file is distributed under the Clear BSD license.
# The full text can be found in LICENSE in the root directory.
# This file consist of classes for computing Throughput and Idle cpu
# cycles for upstream, downstream and birectional traffic

from tests.ugw.wan.ipv4_v6_master import Ipv4v6Master
from devices.platform_types.linux import *
from devices import *
from globalVariables import *
from log_creator import loggerObject as logger
from log_creator import logger as logClass
from time import *
from config import runtime_para, kpi_para
from framework.publish_info_to_html import publish_html

class Dmz(Ipv4v6Master):
    """
    The class function is to enable DMZ in DUT and can perform sanity and performance:
    Attributes:
        None
    """

    @classmethod
    def setUpClass(cls):
        """
        The function to get Wan Ip, and to apply Grp level changes to DUT
        Args:
            None
        Returns:
            None
        """
        super(Dmz, cls).setUpClass()
        return True

    def setUp(self):
        """
        The function to apply parameter changes to DUT at case level
        Args:
            None
        Returns:
            None
        """

        super(Dmz, self).setUp()
        #This code snippet is needed to update endpoints as per STC
        if lan.device_dict['traffic_tool'].lower() == 'stc':
            self.ip_addr = stc.dict['WAN_EndpointIP']
            self.lan_ip = stc.dict['LAN_EndpointIP']

        #route mode related operations for downstream and bidi cases
        if self.stream != "upstream":# it will be route mode,
            logger.dumpLog("Updating pre route config")
            op_d = dut.tools.update_preroute(wan_ip=self.ip_addr, flag="A")
            if op_d['result'] == "fail":
                self.result_message = "Preroute addition failed for {}".format(self.ip_addr)
                publish_html(comment=self.result_message)
                self.tearDown()
                self.skipTest(self.result_message)

            logger.dumpLog("Modifying dmz")
            op_d = dut.tools.modify_dmz_rule(dest_ip=self.lan_ip, flag="ENABLE")
            if op_d['result'] == "fail":
                self.result_message = "Dmz modification failed for {}".format(self.lan_ip)
                publish_html(comment=self.result_message)
                self.tearDown()
                self.skipTest(self.result_message)
        return True


    def runTest(self):
        """
        The function to steps
        Args:
            None
        Returns:
            None
        """
        super(Dmz, self).runTest()
        return True

    def tearDown(self):
        """
        The function to do clean up in all machines before next case execution
        Args:
            None
        Returns:
            None:
        """
        #This code snippet is needed to update endpoints as per STC
        if lan.device_dict['traffic_tool'].lower() == 'stc':
            self.ip_addr = stc.dict['WAN_EndpointIP']
            self.lan_ip = stc.dict['LAN_EndpointIP']

        if self.stream != "upstream":
            logger.dumpLog("Deleting pre route from dut")
            dut.tools.update_preroute(wan_ip=self.ip_addr, flag="D")
            logger.dumpLog("Disabling DMZ in dut")
            dut.tools.modify_dmz_rule(dest_ip=self.lan_ip, flag="DISABLE")

        super(Dmz, self).tearDown()
        return True

    @classmethod
    def tearDownClass(cls):
        """
        The function to revert network configurations if changed
           Args:
               None
           returns:
               None
        """

        super(Dmz, cls).tearDownClass()
        return True


