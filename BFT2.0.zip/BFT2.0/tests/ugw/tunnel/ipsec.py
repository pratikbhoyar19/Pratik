# Copyright(c) 2019 Intel Corporation
# All rights reserved.
#
# This file is distributed under the Clear BSD license.
# The full text can be found in LICENSE in the root directory.

import re
from tests.ugw.firewall.dmz import Dmz
from log_creator import loggerObject as logger
from log_creator import logger as logClass
from devices import *
from globalVariables import *
from time import *
from config import runtime_para, kpi_para
from framework.publish_info_to_html import publish_html

class Ipsec(Dmz):
    '''
    The Class function is ipsec functional verification between DUT and WAN
    '''
    @classmethod
    def setUpClass(cls):
        """
        The function to get Wan Ip, and to apply Grp level changes to DUT
        Args:
            None
        Returns:
            None
        """
        super(Ipsec, cls).setUpClass()
        #Enabling tunnel between Wan & Dut

        cls.wan_host_ip = wan.os.get_interface_ipaddr(cls.w_iface)

        logger.dumpLog("Creating Ipsec tunnel")
        #Deleting previous present ipsec file
        op_d = wan.os.ipsec_rm_config()
        if op_d['result'] == "fail":
            cls.result_message = "failed to delete ipsec file"
            publish_html(comment=cls.result_message)
            cls.tearDownClass()
            cls.skipTest(cls.result_message)
            logger.dumpLog("failed to delete ipsec file")

        #wan ipsec configurations
        op_w = wan.os.ipsec_config(left_ip=cls.wan_host_ip,
                                   right_ip=cls.ip_addr,
                                   left_subnet=cls.subnet1,
                                   left_id=cls.wan_host_ip,
                                   right_subnet=cls.subnet2,
                                   right_id=cls.ip_addr,
                                   mode=cls.ipsec_mode,
                                   pwd=cls.pwd,
                                   local_ip=cls.wan_host_ip,
                                   remote_ip=cls.ip_addr)
        if op_w['result'] == "fail":
            cls.result_message = "failed to config ipsec in wan"
            publish_html(comment=cls.result_message)
            cls.tearDownClass()
            cls.skipTest(cls.result_message)
            logger.dumpLog("failed to config ipsec in wan")

        #Deleting previous present ipsec file
        op_d = dut.os.ipsec_rm_config()
        if op_d['result'] == "fail":
            cls.result_message = "failed to delete ipsec file"
            publish_html(comment=cls.result_message)
            cls.tearDownClass()
            cls.skipTest(cls.result_message)
            logger.dumpLog("failed to delete ipsec file")

        #dut ipsec configurations
        op_w = dut.os.ipsec_config(left_ip=cls.ip_addr,
                                   right_ip=cls.wan_host_ip,
                                   left_subnet=cls.subnet2,
                                   left_id=cls.ip_addr,
                                   right_subnet=cls.subnet1,
                                   right_id=cls.wan_host_ip,
                                   mode=cls.ipsec_mode,
                                   pwd=cls.pwd,
                                   local_ip=cls.ip_addr,
                                   remote_ip=cls.wan_host_ip)
        if op_w['result'] == "fail":
            cls.result_message = "failed to config ipsec files in dut"
            publish_html(comment=cls.result_message)
            cls.tearDownClass()
            cls.skipTest(cls.result_message)
            logger.dumpLog("failed to config ipsec files in dut")

        #To start the Ipsec in wan
        srt_ipsec = wan.os.restart_ipsec()
        if srt_ipsec['result'] == "fail":
            cls.result_message = "failed to restart ipsec in wan"
            publish_html(comment=cls.result_message)
            cls.tearDownClass()
            cls.skipTest(cls.result_message)
            logger.dumpLog("failed to restart ipsec in wan")

        #To start the Ipsec in dut
        srt_ipsec = dut.os.restart_ipsec()
        if srt_ipsec['result'] == "fail":
            cls.result_message = "failed to restart ipsec in dut"
            publish_html(comment=cls.result_message)
            cls.tearDownClass()
            cls.skipTest(cls.result_message)
            logger.dumpLog("failed to restart ipsec in dut")

        #To check the ipsec status in wan
        srt_ipsec = wan.os.check_ipsec_status()
        if srt_ipsec['result'] == "fail":
            cls.result_message = "failed to start ipsec tunnel in wan"
            publish_html(comment=cls.result_message)
            cls.tearDownClass()
            cls.skipTest(cls.result_message)
            logger.dumpLog("failed to start ipsec tunnel in wan")
        cls.w_iface = wan.dict['ipsec_iface']

        #To check the ipsec status in dut
        srt_ipsec = dut.os.check_ipsec_status()
        if srt_ipsec['result'] == "fail":
            cls.result_message = "failed to start ipsec tunnel in dut"
            publish_html(comment=cls.result_message)
            cls.tearDownClass()
            cls.skipTest(cls.result_message)
            logger.dumpLog("failed to start ipsec tunnel in dut")
        cls.w_iface = wan.dict['ipsec_iface']
        return True

    def setUp(self):
        """
        The function to apply parameter changes to DUT at case level
        Args:
            None
        Returns:
            result_dict["result"]:pass/fail
        """
        super(Ipsec, self).setUp()
        #configure firewall for ipsec in dut
        logger.dumpLog("configuring firewall for ipsec in dut")
        op_f = dut.tools.add_ipsec_firewall(remote_ip=self.wan_host_ip, wan_ip=self.ip_addr)
        if op_f['result'] == "fail":
            cls.result_message = "failed to configure firewall for ipsec"
            publish_html(comment=cls.result_message)
            cls.tearDownClass()
            raise unittest2.SkipTest(cls.result_message)
        return True

    def runTest(self):
        """
        The function to steps
        Args:
            None
        Returns:
            None
        """
        self.tun_name = "IPSEC"
        super(Ipsec, self).runTest()
        return True

    def tearDown(self):
        """
        The function to do clean up in all machines before next case execution
        Args:
            None
        Returns:
            None:
        """
        #remove firewall for ipsec in dut
        logger.dumpLog("removing  firewall for ipsec in dut")
        op_f = dut.tools.del_ipsec_firewall(remote_ip=self.wan_host_ip, wan_ip=self.ip_addr)
        if op_f['result'] == "fail":
            cls.result_message = "failed to remove firewall configuration for ipsec"
            publish_html(comment=cls.result_message)
            cls.tearDownClass()
            raise unittest2.SkipTest(cls.result_message)
        super(Ipsec, self).tearDown()
        return True

    @classmethod
    def tearDownClass(cls):
        """
        The function to revert network configurations if changed
           Args:
               None
           returns:
               None
        """
        #Disabling tunnel between Wan & Dut
        logger.dumpLog("stoping ipsec tunnel in wan")
        #stoping ipsec in wan
        op_r = wan.os.stop_ipsec()
        if op_r['result'] == "fail":
            cls.result_message = "fail to stop ipsec in wan"
            publish_html(comment=cls.result_message)
            cls.tearDownClass()
            raise unittest2.SkipTest(cls.result_message)
        logger.dumpLog("fail to stop ipsec in wan")
        #Removing ipsec config file from wan
        op_rm = wan.os.ipsec_rm_config()
        if op_rm['result'] == "fail":
            cls.result_message = "failed to remove ipsec config file"
            publish_html(comment=cls.result_message)
            cls.tearDownClass()
            raise unittest2.SkipTest(cls.result_message)
        logger.dumpLog("failed to remove ipsec config file")
        #stoping ipsec in dut
        op_s = dut.os.stop_ipsec()
        if op_s['result'] == "fail":
            cls.result_message = "failed to stop ipsec in dut"
            publish_html(comment=cls.result_message)
            cls.tearDownClass()
            raise unittest2.SkipTest(cls.result_message)
        logger.dumpLog("fail to stop ipsec in wan")
        #Removing ipsec config file from dut
        op_rd = dut.os.ipsec_rm_config()
        if op_rd['result'] == "fail":
            cls.result_message = "failed to remove ipsec in dut"
            publish_html(comment=cls.result_message)
            cls.tearDownClass()
            raise unittest2.SkipTest(cls.result_message)
        logger.dumpLog("failed to remove ipsec config file")

        super(Ipsec, cls).tearDownClass()
        return True
