# Copyright(c) 2019 Intel Corporation
# All rights reserved.
#
# This file is distributed under the Clear BSD license.
# The full text can be found in LICENSE in the root directory.

import re
from tests.ugw.firewall.dmz import Dmz
from log_creator import loggerObject as logger
from log_creator import logger as logClass
from devices.platform_types.linux import *
from devices import *
from globalVariables import *
from log_creator import loggerObject as logger
from time import *
from config import runtime_para, kpi_para
from framework.publish_info_to_html import publish_html

class L2tp(Dmz):
    '''The Class function is l2tp functional verification between DUT and WAN'''

    @classmethod

    def setUpClass(cls):
        """
        The function to get Wan Ip, and to apply Grp level changes to DUT
        Args:
            None
        Returns:
            None
        """
        super(L2tp, cls).setUpClass()
        cls.wan_host_ip = wan.os.get_interface_ipaddr(cls.w_iface)
        #wan l2tp configurations
        # remove previous files from wan
        op_rm = wan.os.l2tp_rm_files_client()
        if op_rm['result'] == "fail":
            cls.result_message = "failed to remove previous files from wan"
            publish_html(comment=cls.result_message)
            cls.tearDownClass()
            raise unittest2.SkipTest(cls.result_message)

        #create xl2tpd.conf file
        op_cf = wan.os.create_xl2tpd_conf_client(lns_addr=cls.wan_host_ip, 
                                                 local_ip=cls.local_ip,
                                                  ip_start=cls.ip_start,
                                                  ip_end=cls.ip_end)
        if op_cf['result'] == "fail":
            cls.result_message = "failed to create xl2tpd.conf file at wan side"
            publish_html(comment=cls.result_message)
            cls.tearDownClass()
            raise unittest2.SkipTest(cls.result_message)

        #create options.xl2tpd file
        op_ops = wan.os.create_xl2tpd_options_client()
        if op_ops['result'] == "fail":
            cls.result_message = "failed to create options.xl2tpd file at wan side"
            publish_html(comment=cls.result_message)
            cls.tearDownClass()
            raise unittest2.SkipTest(cls.result_message)

        #create option file
        op_w = wan.os.create_xl2tpd_ppp_options_client()
        if op_w['result'] == "fail":
            cls.result_message = "failed to create options file"
            publish_html(comment=cls.result_message)
            cls.tearDownClass()
            raise unittest2.SkipTest(cls.result_message)

        #dut l2tp configurations
        #remove previous file from dut
        op_rmd = dut.tools.l2tp_rm_files_server()
        if op_rmd['result'] == "fail":
            cls.result_message = "failed to remove previous files from dut"
            publish_html(comment=cls.result_message)
            cls.tearDownClass()
            raise unittest2.SkipTest(cls.result_message)

        #create xl2tpd.conf file
        op_cfd = dut.tools.create_xl2tpd_conf_server(lns_addr=cls.wan_host_ip)
        if op_cfd['result'] == "fail":
            cls.result_message = "failed to create xl2tpd.conf file at dut side"
            publish_html(comment=cls.result_message)
            cls.tearDownClass()
            raise unittest2.SkipTest(cls.result_message)

        #create options.xl2tpd file
        op_opd = dut.tools.create_xl2tpd_options_server()
        if op_opd['result'] == "fail":
            cls.result_message = "failed to create options.xl2tpd file at dut side"
            publish_html(comment=cls.result_message)
            cls.tearDownClass()
            raise unittest2.SkipTest(cls.result_message)

        #copy xl2tpd.conf file to temp
        op_tmp = dut.tools.xl2tpd_copy_tmp_server()
        if op_tmp['result'] == "fail":
            cls.result_message = "failed to copy the xl2tpd.conf file at dut side"
            publish_html(comment=cls.result_message)
            cls.tearDownClass()
            raise unittest2.SkipTest(cls.result_message)

        #start the l2tp server
        dut.tools.start_l2tp_server()

        #start the l2tp client
        wan.os.start_l2tp_client()

        #start l2tp.control server
        op_e = dut.tools.l2tp_pppd_echo_server(ip_addr=cls.wan_host_ip)
        if op_e['result'] == "fail":
            cls.result_message = "failed to start l2tp-control"
            publish_html(comment=cls.result_message)
            cls.tearDownClass()
            raise unittest2.SkipTest(cls.result_message)

        #get ppp iface from wan
        w_ppp_dict = wan.os.get_ppp_iface()
        if w_ppp_dict['result'] == 'fail':
            cls.result_message = "get ppp iface from wan failed"
            publish_html(comment=cls.result_message)
            cls.tearDownClass()
            raise unittest2.SkipTest(cls.result_message)

        # get ppp iface from dut
        d_ppp_dict = dut.os.get_ppp_iface()
        if d_ppp_dict['result'] == 'fail':
            cls.result_message = "get ppp iface from dut failed"
            publish_html(comment=cls.result_message)
            cls.tearDownClass()
            raise unittest2.SkipTest(cls.result_message)

        cls.w_ppp_iface = w_ppp_dict['ppp_iface']
        cls.d_ppp_iface = d_ppp_dict['ppp_iface']

        # add the route in wan side of ppp interface generated in dut
        op_r = wan.os.add_route_client(nw_addr=cls.nw_addr, iface=cls.w_ppp_iface)
        if op_r['result'] == "fail":
            cls.result_message = "failed to add route"
            publish_html(comment=cls.result_message)
            cls.tearDownClass()
            raise unittest2.SkipTest(cls.result_message)

        #updating specific cls variables for l2tp tunnel, after tunnel creation
        cls.w_iface = cls.w_ppp_iface
        cls.ip_addr = cls.tunnel_ipaddr
        #cls.wan_host_ip = cls.tun_bras_ip
        #adding MASQ Rule specific to L2tp tunnel
        logger.dumpLog("configuring MASQ rule for natting in DUT")
        dut.tools.add_msq_rule(iface=cls.d_ppp_iface)
        return True

    def setUp(self):
        """
        The function to apply parameter changes to DUT at case level
        Args:
            None
        Returns:
            None
        """
        super(L2tp, self).setUp()
        return True

    def runTest(self):
        """
        The function to steps
        Args:
            None
        Returns:
            None
        """
        #updating tunnel variable to validate L2TP tunnel
        self.tun_name = "L2TP"
        super(L2tp, self).runTest()
        return True

    def tearDown(self):
        """
        The function to do clean up in all machines before next case execution
        Args:
            None
        Returns:
            None
        """
        super(L2tp, self).tearDown()
        return True

    @classmethod
    def tearDownClass(cls):
        """
        The function to revert network configurations if changed
           Args:
               None
           returns:
               None
        """
        #remove previous file from dut
        op_rmd = dut.tools.l2tp_rm_files_server()
        if op_rmd['result'] == "fail":
            cls.result_message = "failed to remove previous files from dut"
            publish_html(comment=cls.result_message)
            cls.tearDownClass()
            raise unittest2.SkipTest(cls.result_message)

        #remove previous file from wan
        op_rmw = wan.os.l2tp_rm_files_client()
        if op_rmw['result'] == "fail":
            cls.result_message = "failed to remove previous files from wan"
            publish_html(comment=cls.result_message)
            cls.tearDownClass()
            raise unittest2.SkipTest(cls.result_message)

        # del the route in wan side of ppp interface generated in dut
        op_r = wan.os.del_route_client(nw_addr=cls.nw_addr, iface=cls.w_ppp_iface)
        if op_r['result'] == "fail":
            cls.result_message = "failed to del route"
            publish_html(comment=cls.result_message)
            cls.tearDownClass()
            raise unittest2.SkipTest(cls.result_message)
        super(L2tp, cls).tearDownClass()
        return True


