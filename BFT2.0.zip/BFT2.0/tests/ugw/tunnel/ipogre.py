#Copyright(c) 2018 Intel Corporation
# All rights reserved.
#
# This file is distributed under the Clear BSD license.
# The full text can be found in LICENSE in the root directory.
# This file consist of classes for computing Throughput and Idle cpu
# cycles for upstream, downstream and birectional traffic

#from tests.ugw.wan.ipv4_v6_master import Ipv4v6Master
from tests.ugw.firewall.dmz import Dmz
from devices import *
from globalVariables import *
from log_creator import loggerObject as logger
from log_creator import logger as logClass
from time import *
from config import runtime_para, kpi_para
from framework.publish_info_to_html import publish_html

class Ipogre(Dmz):
    """
    The class function is to create tunnel between wan and dut

    """
    @classmethod
    def setUpClass(cls):
        """
        The function to get Wan Ip, and to apply Grp level changes to DUT
        Args:
            None
        Returns:
            None
        """
        super(Ipogre, cls).setUpClass()

        #updating specific cls variables for IPoGRE tunnel, before tunnel creation
        cls.wan_host_ip = wan.os.get_interface_ipaddr(cls.w_iface) 

        #Creating IPoGre Tunnel between WAN and DUT
        op_d = {}
        op_d['result'] = "pass"
        logger.dumpLog("Creating IPoGre Tunnel DUT side")        
        op_d = dut.os.create_ipogre(
                   local_ip=cls.ip_addr,
                   remote_ip=cls.wan_host_ip,
                   tun_ip=cls.tun_dut_ip,
                   tun_nw=cls.tun_nw,
                   mtu=cls.mtu_dut)

        if op_d['result'] == "fail":
            cls.result_message = "Failed to create IPoGre tunnel DUT side"
            publish_html(comment=cls.result_message)
            cls.tearDownClass()
            raise unittest2.SkipTest(cls.result_message)

        logger.dumpLog("Creating IPoGre Tunnel WAN side")
        op_w = wan.os.create_ipogre(
                   local_ip=cls.wan_host_ip,
                   remote_ip=cls.ip_addr,
                   tun_nw=cls.tun_nw,
                   tun_ip=cls.tun_bras_ip,
                   mtu=cls.mtu_dut)
        if op_w['result'] == "fail":
            cls.result_message = "Failed to create IPoGre tunnel WAN side"
            publish_html(comment=cls.result_message)
            cls.tearDownClass()
            raise unittest2.SkipTest(cls.result_message)

        logger.dumpLog("IPoGre Tunnel created successfully between WAN and DUT")   
        
        #updating specific cls variables for IPoGRE tunnel, after tunnel creation
        cls.w_iface = 'tunIPoGre'
        cls.ip_addr = cls.tun_dut_ip
        #cls.wan_host_ip = cls.tun_bras_ip 
        
        #adding MASQ Rule specific to IPoGRE tunnel 
        logger.dumpLog("configuring MASQ rule for natting in DUT")
        dut.tools.add_msq_rule(iface=cls.w_iface)

        return True 
		
    def setUp(self):
        """
        The function to apply parameter changes to DUT at case level 
        Args:
            None
        Returns:
            None
        """
        super(Ipogre, self).setUp()
        dut.session.send_recv("ppacmd addwan -i {}".format(self.w_iface))
		
    def runTest(self):
        """
        The function to steps
        Args:
            None
        Returns:
            None  
        """
        #updating tunnel variable to validate ipogre tunnel
        self.tun_name = "GRE"
        super(Ipogre, self).runTest()
        return True

    def tearDown(self):
        """
        The function to do clean up in all machines before next case execution
        Args:  
            None
        Returns:
            None:
        """
       
        dut.session.send_recv("ppacmd delwan -i {}".format(self.w_iface))
        super(Ipogre, self).tearDown()
        return True
		
    @classmethod
    def tearDownClass(cls):
        """
        The function to revert network configurations if changed 
           Args:
               None
           returns:
               None
        """

        #Deleting IPoGre Tunnel from WAN and DUT
        logger.dumpLog("Deleting IpoGre Tunnel DUT side")
        dut.os.delete_ipogre(tun_nw=cls.tun_nw)
        logger.dumpLog("IPoGre Tunnel deleted DUT side")

        logger.dumpLog("Deleting IpoGre Tunnel WAN side")
        wan.os.delete_ipogre(tun_nw=cls.tun_nw)
        logger.dumpLog("IPoGre Tunnel deleted WAN side")
                    
        super(Ipogre, cls).tearDownClass()
        return True
