#Copyright(c) 2018 Intel Corporation
# All rights reserved.
# This file is distributed under the Clear BSD license.
# The full text can be found in LICENSE in the root directory.
# This file consist of classes for computing Throughput and Idle cpu
# cycles for upstream, downstream and birectional traffic

from tests.ugw.firewall import Dmz
from tests.ugw.wan.ipv4_v6_master import Ipv4v6Master
from devices import *
from globalVariables import *
from log_creator import loggerObject as logger
from log_creator import logger as logClass
from time import *
from config import runtime_para, kpi_para
from framework.publish_info_to_html import publish_html


class Eogre(Dmz):
    """
    This class function is used to create Eogre tunnel between DUT and WAN

    """
    @classmethod
    def setUpClass(cls):
        """
        This function to get Wan ip, and to apply Group level changes to DUT.
        Args:
            None
        Returns:
            None
        """
        super(Eogre, cls).setUpClass()

        #updating specific cls variables for IPoGRE tunnel, before tunnel creation
        cls.wan_host_ip = wan.os.get_interface_ipaddr(cls.w_iface)

        #Deleting IPoGre Tunnel from WAN and DUT
        logger.dumpLog("Deleting EoGre Tunnel DUT side")
        dut.tools.delete_eogre_dut(ip_addr=cls.ip_addr, wan_host_ip=cls.wan_host_ip)
        logger.dumpLog("EoGre Tunnel deleted DUT side")

        logger.dumpLog("Deleting EoGre Tunnel WAN side")
        wan.os.delete_eogre_bras(br_ip=cls.br_ip)
        logger.dumpLog("EoGre Tunnel deleted WAN side")


        #Creating EoGre Tunnel between WAN and DUT
        op_d = {}
        op_d['result'] = "pass"
        logger.dumpLog("Creating Eogre tunnel DUT side")
        op_d = dut.tools.create_eogre_dut(
                   ip_addr=cls.ip_addr,
                   wan_host_ip=cls.wan_host_ip,
                   tun_dut_ip=cls.tun_dut_ip,
                   netmask=cls.netmask)

        if op_d['result'] == "fail":
            cls.result_message = "Failed to create EoGre tunnel DUT side"
            publish_html(comment=cls.result_message)
            cls.tearDownClass()
            raise unittest2.SkipTest(cls.result_message)

        logger.dumpLog("Creating Eogre Tunnel WAN side")
        op_w = wan.os.create_eogre_bras(
                   wan_host_ip=cls.wan_host_ip,
                   ip_addr=cls.ip_addr,
                   br_ip=cls.br_ip,
                   tun_bras_ip=cls.tun_bras_ip,
                   netmask=cls.netmask)
        if op_w['result'] == "fail":
            cls.result_message = "Failed to create EoGre tunnel WAN side"
            publish_html(comment=cls.result_message)
            cls.tearDownClass()
            raise unittest2.SkipTest(cls.result_message)

        logger.dumpLog("EoGre Tunnel created successfully between WAN and DUT")

        #adding MASQ Rule specific to EoGRE tunnel
        logger.dumpLog("configuring MASQ rule for natting in DUT")
        dut.tools.add_msq_rule(iface='tunEoGre')
        cls.w_iface = 'br0'
        return True

    def setUp(self):
        """
        The function to apply parameter changes to DUT at case level
        Args:
            None
        Returns:
            None
        """
        super(Eogre, self).setUp()
        #self.w_iface = 'tunEoGre'
        dut.session.send_recv("ppacmd addwan -i {}".format('tunEoGre'))
        dut.session.send_recv("echo enable > /proc/ppa/api/bridged_flow_learning")

    def runTest(self):
        """
        The function to steps
        Args:
            None
        Returns:
            None
        """
        #updating tunnel variable to validate eogre tunnel
        self.tun_name = "GRE"
        super(Eogre, self).runTest()
        return True

    def tearDown(self):
        """
        The function to clean up in all machines before next case execution
        Args:
            None
        Returns:
            None
        """
        dut.session.send_recv("echo disable > /proc/ppa/api/bridged_flow_learning")
        dut.session.send_recv("ppacmd delwan -i {}".format('tunEoGre'))
        super(Eogre, self).tearDown()
        return True

    @classmethod
    def tearDownClass(cls):
        """
        The function to revert network configurations if changed
        Args:
            None
        Returns:
           None
        """
        #Deleting IPoGre Tunnel from WAN and DUT
        logger.dumpLog("Deleting EoGre Tunnel DUT side")
        dut.tools.delete_eogre_dut(ip_addr=cls.ip_addr, wan_host_ip=cls.wan_host_ip)
        logger.dumpLog("EoGre Tunnel deleted DUT side")

        logger.dumpLog("Deleting EoGre Tunnel WAN side")
        wan.os.delete_eogre_bras(br_ip=cls.br_ip)
        logger.dumpLog("EoGre Tunnel deleted WAN side")

        super(Eogre, cls).tearDownClass()
        return True
