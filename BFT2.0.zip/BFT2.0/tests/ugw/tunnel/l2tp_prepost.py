from devices.platform_types.linux import dev_ip_obj
from devices.platform_types.windows import dev_ip_obj
from devices.platform_types.andriod import dev_ip_obj
from config import runtime_para

for dev_obj in dev_ip_obj:
    exec("from devices import "+dev_obj)

class L2tpPrepost(object):
    def pre_setupclass(self):
        print("presetup method is called")
        return True

    def pre_runtest(self):
        print("preruntest method is called")
        return True

    def post_runtest(self):
        print("post runtest method is called")
        return True

    def post_setupclass(self):
        print("post setupclass method is called")
        return True
