from devices.platform_types.linux import dev_ip_obj
from devices.platform_types.windows import dev_ip_obj
from devices.platform_types.andriod import dev_ip_obj
from config import runtime_para
from framework.publish_info_to_html import publish_html
from datetime import datetime
for dev_obj in dev_ip_obj:
    exec("from devices import "+dev_obj)


class WlanSuitePrepost(object):

    def pre_suite(self):
        print("PreSuite method is called ")
        publish_html(qcid="PS_01", test_desc="Pre/post suite config")
        if runtime_para['dut_reboot'] == "True":
            if dut.session.reboot():
                publish_html(comment="Device has rebooted successfully")
                return True
            else:
                publish_html(comment="ERROR in Device reboot")
                return False
        publish_html(comment="Pre suite has configured successfully")
        return True

    def post_suite(self):
        print("Post suite method is called")
        publish_html(comment="Post suite has configured successfully")
        return True
