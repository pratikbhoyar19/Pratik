from devices.platform_types.linux import dev_ip_obj
from devices.platform_types.windows import dev_ip_obj
from devices.platform_types.andriod import dev_ip_obj
from config import runtime_para
from framework.publish_info_to_html import publish_html

for dev_obj in dev_ip_obj:
    exec("from devices import "+dev_obj)

class WifiPrepost(object):
    def pre_setupclass(self):
        print("pre setupclass method is called")
        publish_html(comment="Pre setUpClass has configured successfully")
        return True

    def pre_runtest(self):
        print("preruntest method is called")
        print("Start system cleanup")
        ### Remove STA1, STA2, LAN server report
        wlan_obj_lst=[wlan2g, wlan5g]
        for w_obj in wlan_obj_lst:
            w_obj.os.remove_server_report()
        print("rm server rpt success")
        ### Stop traffic at DUT, STA1, STA2 and LAN
        dut.os.stop_trafficgen_mpstat()
        lan.os.stop_trafficgen_mpstat()
        for w_obj in wlan_obj_lst:
            w_obj.os.stop_trafficgen_mpstat()
        print("End system cleanup")
        publish_html(comment="Pre runTest has configured successfully")
        return True

    def post_runtest(self):
        print("post runtest method is called")
        print("Start system cleanup")
        wlan_obj_lst=[wlan2g, wlan5g]
        ### Remove STA1, STA2, LAN server report
        for w_obj in wlan_obj_lst:
            w_obj.os.remove_server_report()

        ### Stop traffic at DUT, STA1, STA2 and LAN
        dut.os.stop_trafficgen_mpstat()
        lan.os.stop_trafficgen_mpstat()
        for w_obj in wlan_obj_lst:
            w_obj.os.stop_trafficgen_mpstat()
        print("End system cleanup")
        publish_html(comment="Post runTest has configured successfully")
        return True

    def post_setupclass(self):
        print("post setupclass method is called")
        publish_html(comment="Post setUpClass has configured successfully")
        return True