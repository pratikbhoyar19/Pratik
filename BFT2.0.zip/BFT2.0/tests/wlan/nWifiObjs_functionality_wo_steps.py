#Copyright(c) 2018 Intel Corporation
# All rights reserved.
#
# This file is distributed under the Clear BSD license.
# The full text can be found in LICENSE in the root directory.
# This file consist of classes for computing Throughput and Idle cpu
# cycles for upstream, downstream and birectional traffic

import lib
import copy
import re
import unittest2
from tests import linux_boot
from devices import *
from globalVariables import *
from log_creator import loggerObject as logger
from time import *
from parallel_exec import *
import config
from lib.wlan.test_lib.global_params import radio2g_params, wifi_grp_level_changes_ap, wifi_case_level_changes_ap
from framework.process_params import process_setup, process_setupclass, process_output
from config import runtime_para, kpi_para
from framework.publish_info_to_html import publish_html

class WifiAssociationWoSteps(linux_boot.LinuxBootTest):
    """Wifi association general class with n number of Wireless STAs"""

    @classmethod
    def setUpClass(cls):
        '''To apply parameter changes to AP and WSTAs at group level, asscotiation will take place here
           Arguments:  cls  - This argument is class object to wifiAssociation class'''

        super(WifiAssociationWoSteps, cls).setUpClass()

        ### Publish the test paramters to HTML report
        pub_qcid = "QC_1"
        pub_test_desc = "Verify the WLAN clients asscotiation with AP/DUT"
        param_dict = {'wlan_enc': cls.grp_level_params['wlan_enc']}
        pub_param_desc = param_dict

        publish_html(qcid=pub_qcid, test_desc=pub_test_desc, param_desc=pub_param_desc)

        #do AP and STA configuration in parallel and check assoc in all STAs
        logger.dumpLog("setUpClass")
        logger.dumpLog("Starting dumpLog")
        ### AP Radio Radio parameters
        radio_params1 = copy.deepcopy(radio2g_params)
        cls.radio_params = radio_params1
        logger.dumpLog("Obtaining AP MAC Addr")
        cls.ap_mac_addr = dut.os.get_mac_addr(interface=dut.dict['wlan2g_iface'])
        logger.dumpLog("Obtaining AP MAC Addr")

        if not cls.ap_mac_addr:
            cls.result_message = (
                'SETUPCLASS ERROR: Getting AP mac addr with Radio %s ghz failed' %
                cls.ap_radio)
            ### Publish the test comments to HTML report
            publish_html(comment=cls.result_message)
            cls.skiptest_cases()

        ########### Identifying Group Level changes and updating wifi dict ###############
        if not wifi_grp_level_changes_ap(cls, cls.radio_params, ap_radio=cls.ap_radio):
            cls.result_message="SETUPCLASS ERROR: wifi grp level changes get method failed"
            ### Publish the test comments to HTML report
            publish_html(comment=cls.result_message)
            cls.skiptest_cases()

        ########### Configure AP in separate Thread ###############
        logger.dumpLog("Start Configuring AP/DUT")
        parallel_exec(dut.tools.configure_ap)(cls.radio_params, ap_radio=cls.ap_radio, caller_api = "setUpClass")
        logger.dumpLog("End Configuring AP/DUT")
        ########### Setting Radio as Global parameter ###############
        if not dut.tools.set_global_ap_radio(cls.ap_radio):
            cls.result_message="SETUPCLASS ERROR: Not able to set radio global param"
            ### Publish the test comments to HTML report
            publish_html(comment=cls.result_message)
            cls.skiptest_cases()

        ######## Configure WLAN STAs ###################
        logger.dumpLog("Configuring WLAN STA")
        logger.dumpLog('SETUPCLASS: Associating STA in Radio %s ghz' % cls.ap_radio)
        logger.dumpLog("started parallel execution")
        cls.wlan_str_lst= [wlan2g.dict['name'], wlan5g.dict['name']]
        cls.wlan_obj_lst = [wlan2g, wlan5g]
        cls.wlan_iface_lst = [wlan2g.dict['wlan_iface'], wlan5g.dict['wlan_iface']]
        cls.radio_param_lst = [cls.radio_params, cls.radio_params]

        for w_obj,w_iface in zip(cls.wlan_obj_lst, cls.wlan_iface_lst):
            w_obj.tools.stop_wlan_tools(wlan_iface=w_iface)

        for w_str,w_obj,w_iface,w_radio_p in zip(cls.wlan_str_lst, cls.wlan_obj_lst, cls.wlan_iface_lst, cls.radio_param_lst):
            parallel_exec(w_obj.tools.configure_wlan_stas)(w_radio_p, ap_radio=cls.ap_radio,wlan_iface=w_iface)

        logger.dumpLog("wlan sta config successfull")
        output=end_parallel(timeout=120)
        if not process_output(output):
            cls.result_message="SETUPCLASS ERROR: STAs or AP Configuration Failed, check output dict"
            ### Publish the test comments to HTML report
            publish_html(comment=cls.result_message)
            cls.skiptest_cases()
        logger.dumpLog("ending parallel execution")
        logger.dumpLog("Configuring WLAN STA")

        sleep(5)
        for w_str,w_obj,w_iface,w_radio_p in zip(cls.wlan_str_lst, cls.wlan_obj_lst, cls.wlan_iface_lst, cls.radio_param_lst):
            parallel_exec(w_obj.tools.connect_ap)(cls.radio_params, wlan_iface=w_iface)

        output=end_parallel(timeout=120)
        if not process_output(output):
            cls.result_message="SETUPCLASS ERROR: Connection to AP fails, check output dict"
            ### Publish the test comments to HTML report
            publish_html(comment=cls.result_message)
            cls.skiptest_cases()


        ######## Checking WLAN Associations ###################
        for w_str,w_obj,w_iface,w_radio_p in zip(cls.wlan_str_lst, cls.wlan_obj_lst, cls.wlan_iface_lst, cls.radio_param_lst):
            parallel_exec(w_obj.tools.verify_assoc)(cls.ap_mac_addr, wlan_iface=w_iface)

        output=end_parallel(timeout=150)
        if not process_output(output):
            cls.result_message="SETUPCLASS ERROR: Association verification fails, check output dict"
            ### Publish the test comments to HTML report
            publish_html(comment=cls.result_message)
            cls.skiptest_cases()
        ######## Getting dynamic IP at WLAN STAs ###################
        for w_str,w_obj,w_iface,w_radio_p in zip(cls.wlan_str_lst, cls.wlan_obj_lst, cls.wlan_iface_lst, cls.radio_param_lst):
            parallel_exec(w_obj.os.assign_dhcp_ip)(wlan_iface=w_iface)

        output=end_parallel(timeout=120)
        if not process_output(output):
            cls.result_message="SETUPCLASS ERROR: Not able to get ip, check output dict"
            ### Publish the test comments to HTML report
            publish_html(comment=cls.result_message)
            cls.skiptest_cases()

        ### Publish the test comments to HTML report
        publish_html(comment='Class test log', log_link=cls.cls_test_log)

    def setUp(self):
        '''To apply parameter changes to AP at case level, Re-asscotiation will take place here
           Arguments:  self  - This argument is self object to wifiAssociation class'''
        super(WifiAssociationWoSteps, self).setUp()
        ### Publish the test paramters to HTML report
        pub_qcid = "TC_"+str(self.case_id)
        pub_test_desc = "Checking WLAN Re-Associations after changing case params"
        param_dict = {'wlan_channel': self.case_level_params['wlan_channel']}
        pub_param_desc =  param_dict

        publish_html(qcid=pub_qcid, test_desc=pub_test_desc, param_desc=pub_param_desc)
        #Get case level changes
        if not wifi_case_level_changes_ap(self, radio_params=self.radio_params, ap_radio=self.ap_radio):
            self.result_message="SETUP ERROR: Not able to get case level changes"
            ### Publish the test comments to HTML report
            publish_html(comment=self.result_message)
            self.tearDown()
            self.skipTest(self.result_message)

        #Apply case level changes
        if not dut.tools.configure_ap(self.radio_params, ap_radio=self.ap_radio, caller_api ="setUp"):
            self.result_message="SETUP ERROR: Not able to apply case level changes"
            ### Publish the test comments to HTML report
            publish_html(comment=self.result_message)
            self.tearDown()
            self.skipTest(self.result_message)

        logger.dumpLog("configure ap setup success")
        ######## Checking WLAN Re-Associations after changing case params ###################
        for w_str,w_obj,w_iface,w_radio_p in zip(self.wlan_str_lst, self.wlan_obj_lst, self.wlan_iface_lst, self.radio_param_lst):
            parallel_exec(w_obj.tools.verify_assoc)(self.ap_mac_addr, wlan_iface=w_iface)

        logger.dumpLog("configure reassoc success")
        output=end_parallel(timeout=120)
        if not process_output(output):
            self.result_message="SETUP ERROR: verify Reassoc failed, check output dict"
            ### Publish the test comments to HTML report
            publish_html(comment=self.result_message)
            self.tearDown()
            self.skipTest(self.result_message)

        ### Publish the test comments to HTML report
        publish_html(comment='Case test log', log_link=self.case_test_log)

    def runTest(self):
        '''To check ping connectivity and execute iperf servers and clients to get throughput
           Arguments:  self  - This argument is self object to wifiAssociation class'''

        super(WifiAssociationWoSteps, self).runTest()
        try:
            pub_qcid = "TC_"+str(self.case_id)+"_1"
        except Exception as err:
            pub_qcid = ""
        pub_test_desc= "Verifying iperf trafffic and collecting server report when  WLAN clients\
                                 are associated with AP/DUT"
        publish_html(qcid=pub_qcid, test_desc=pub_test_desc)
        result = True

        logger.dumpLog("getting lan ip for ping command to execute")
        self.server_ip = lan.os.get_interface_ipaddr(interface=lan.dict['iface'])
        if not self.server_ip:
            self.result_message="RUNTEST ERROR: Not able to get Server IP"
            publish_html(comment=self.result_message)
            #self.skipTest(self.result_message
            result = False

        self.percent = [1, 1]
        ####### Start ping from WLAN STAs to LAN ##########
        logger.dumpLog('RUNTEST : start pinging from wlan STAs to lan')
        for w_obj,w_str in zip(self.wlan_obj_lst, self.wlan_str_lst):
            parallel_exec(w_obj.os.start_ping_p)(ip=self.server_ip)
        output=end_parallel(timeout=120)
        if not process_output(output):
            self.result_message="RUNTEST ERROR: PING Command failed, check output dict"
            publish_html(comment=self.result_message)
            result = False

         ##### Getting STAs IP ######
        "Getting WLAN stations IPs"
        for w_str,w_obj,w_iface in zip(self.wlan_str_lst,self.wlan_obj_lst, self.wlan_iface_lst):
            parallel_exec(w_obj.os.get_interface_ipaddr)(interface=w_iface)

        output=end_parallel(timeout=120)
        if not process_output(output):
            self.result_message="RUNTEST ERROR: Not able to get Clients  Ip, check output dict"
            publish_html(comment=self.result_message)
            result = False

        w_ser_dict = output[1]
        self.wlan_ip_lst=['0','0']
        for key,val in w_ser_dict.iteritems():
            for i,w_str in enumerate(self.wlan_str_lst):
                str1=w_str+"."
                if str1 in key:
                    self.wlan_ip_lst[i]=str(val)


        ##### Getting Ports for Server/Clients , with initial port as defined ######
        self.port_list = list()
        port_init=int(5003)
        for w_obj in self.wlan_obj_lst:
            self.port_list.append(str(port_init))
            port_init = port_init + 1

        ##### Start Servers ######
        logger.dumpLog("Start iperf servers on Wlan clients")
        for w_str,w_obj,w_port in zip(self.wlan_str_lst,self.wlan_obj_lst, self.port_list):
            logger.dumpLog("%s %s %s" %(w_str,w_obj,w_port))
            parallel_exec(w_obj.traffic.start_server)(parallel_stream=True, time=self.time, proto=self.proto, port=w_port)

        output=end_parallel(timeout=120)
        if not process_output(output):
            self.result_message="RUNTEST ERROR: Not able to start iperf severs , check output dict"
            publish_html(comment=self.result_message)
            result = False

        ##### Start Clients in serial ######
        logger.dumpLog("Start iperf client on lan host")
        for w_ip,w_port in zip(self.wlan_ip_lst, self.port_list):
            logger.dumpLog("%s %s" %(w_ip,w_port))
            if not lan.traffic.start_client(ip=w_ip, parallel_stream=True, time=self.time, proto=self.proto, port=w_port):
                self.result_message="not able to start client"
                publish_html(comment=self.result_message)
                result = False

        logger.dumpLog("Waiting for iperf time ..............")
        sleep(int(self.time)+10)
        ####### Parse Iperf server report at WSTAs
        logger.dumpLog("Start fetching server reports")
        for w_str,w_obj in zip(self.wlan_str_lst,self.wlan_obj_lst):
            parallel_exec(w_obj.os.parse_iperf_server_report)(proto=self.proto, report_name=tsv_server_report_name)
        output=end_parallel(timeout=120)
        if not process_output(output):
            self.result_message="RUNTEST ERROR: Not able to parse traffic server report, check output dict"
            publish_html(comment=self.result_message)
            result = False

        throughput = ['0','0']
        throughput_dict = output[1]
        for key,val in throughput_dict.iteritems():
            for i,w_str in enumerate(self.wlan_str_lst):
                str1=w_str+"."
                if str1 in key:
                    throughput[i]=str(val)
        msg = ""
        for w_str,th in zip(self.wlan_str_lst, throughput):
            msg+="%s throughput is %s Mbps\n" %(w_str,th)
        self.result_message = msg
        publish_html(comment=self.result_message)
        ### Publish the test comments to HTML report
        publish_html(comment='Steps log', log_link=self.case_test_log)
        return result

    def tearDown(self):
        '''To do clean up in all machines before next case execution
           Arguments:  self  - This argument is self object to wifiAssociation class'''
        logger.dumpLog("tearDown")
        super(WifiAssociationWoSteps, self).tearDown()
        return True

    @classmethod
    def tearDownClass(cls):
        '''To revert parameter changes to AP and WSTAs at group level, diasscotiation will take place here
           Arguments:  cls  - This argument is class object to wifiAssociation class'''
        logger.dumpLog("Inside tearDownClass")
        logger.dumpLog("deleting wlan sta configurations")
        for w_str, w_obj,w_iface in zip(cls.wlan_str_lst, cls.wlan_obj_lst, cls.wlan_iface_lst):
            parallel_exec(w_obj.tools.deassoc_ap)(wlan_iface=w_iface)
        logger.dumpLog("Reverting AP wlan configurations")
        parallel_exec(dut.tools.config_ap_to_org)(cls.radio_params, ap_radio=cls.ap_radio, caller_api = "tearDownClass")
        output=end_parallel(timeout=120)
        super(WifiAssociationWoSteps, cls).tearDownClass()
        sleep(10)

