# Copyright (c) 2015
#
# All rights reserved.
#
# This file is distributed under the Clear BSD license.
# The full text can be found in LICENSE in the root directory.

import time
import unittest2
from framework.common import test_msg
import sys
import traceback
import config
import os
from devices import *
from framework.parameters_to_json import log_class_setup_info, log_test_setup_info,log_test_teardown_info, \
    log_class_teardown_info
from framework.parameters_to_json import log_test_case_steps_info, publish_result_and_endtime, publish_result
from framework.publish_info_to_html import get_test_details, publish_comments_text_publish
from framework.process_params import process_setup, process_setupclass
from datetime import datetime
from log_creator import LOG_FORMAT,loggerObject
import logging
from devices import *
import re
import tests
from framework.json_parser import generate_case_json
from framework.json_to_csv import generate_child_csv


class LinuxBootTest(unittest2.TestCase):
    global key # To get the master class name
    i = 0  # Class attribute used for parsing each para list
    grp_level_params={}
    case_level_params={}

    def __init__(self, config, steps_to_run):
        super(LinuxBootTest, self).__init__("testWrapper")
        self.config = config
        self.reset_after_fail = True
        self.dont_retry = False
        self.logged = dict()
        self.steps_to_run = steps_to_run

    def id(self):
        return self.__class__.__name__

    @classmethod
    def setUpClass(cls):
        global key
        key = re.search('method (.*)\.id', str(cls.id)).group(1)
        # Initializing the case to be failed flag when setUpClass has failed..
        cls.fail_to_setup = False
        cls.case_name_lst = []
        # Parse the required test parameters
        if not process_setupclass(cls):
            cls.result_message="SETUPCLASS ERROR: Not able to process setupClass params"
            cls.tearDownClass()
            raise unittest2.SkipTest(cls.result_message)

        loggerObject.dumpLog("========== %s: Begin ==========" % cls.testClassId)

        # Create directory, if required
        cls.sucls_output_dir = os.path.join(config.output_dir, cls.testClassId + '_setUpClass')
        if not os.path.isdir(cls.sucls_output_dir):
            os.makedirs(cls.sucls_output_dir)

        # Create the required file handle
        reset_logpath(os.path.join(cls.sucls_output_dir, 'test.log'))
        # Create log files for individual devices
        for device in config.devices:
            exec (device + '.session.create_logfile(cls.sucls_output_dir)')

        cls.cls_test_log = os.path.join(cls.sucls_output_dir, "test.log")

        log_class_setup_info([
            ("test_comments", []),
            ("test_type", "Test"),
            ("test_name", cls.testClassId),
            ("time_started", datetime.now().strftime("%H:%M:%S"))  # time_string = datetime.strftime(" %H:%M:%S, t)

        ])
        # publish the test details into HTML report
        get_test_details(test_name=cls.testClassId, test_type="test")

        # Run pre_setupclass(), if exist
        if config.prepost_file:
            cls.pp_dir_name =  ".".join(config.prepost_file[key].split(".")[0:-1])
            cls.pp_cls_name = config.prepost_file[key].split(".")[-1]
            exec("import tests.%s" % cls.pp_dir_name)
            exec("cls.prepost_cls_obj = getattr(tests.%s,\'%s\')" % (cls.pp_dir_name, cls.pp_cls_name))

            if not cls.prepost_cls_obj().pre_setupclass():
                cls.prepost_cls_obj().post_setupclass()
                raise unittest2.SkipTest("Skipping test --- Presetup has failed")
        else:
            print("Prepost class file has not configured")

    @classmethod
    def tearDownClass(cls):
        # Create directory, if required
        cls.tdcls_output_dir = os.path.join(config.output_dir, cls.testClassId + '_tearDownClass')
        if not os.path.isdir(cls.tdcls_output_dir):
            os.makedirs(cls.tdcls_output_dir)
        # publish the test details into HTML report
        get_test_details(test_name=cls.testClassId, test_type="test")
        # Create the required file handle
        reset_logpath(os.path.join(cls.tdcls_output_dir, 'test.log'))
        for device in config.devices:
            exec (device + '.session.create_logfile(cls.tdcls_output_dir)')
        if config.prepost_file:
        	cls.prepost_cls_obj().post_setupclass()
        log_class_teardown_info([
          ("test_name", cls.testClassId),
          ("time_ended", datetime.now().strftime("%H:%M:%S")),
          ("log_link", cls.cls_test_log)# time_string = datetime.strftime(" %H:%M:%S", t)
        ])
        loggerObject.dumpLog("========== %s: End ==========" % cls.testClassId)

    def setUp(self):
        # Marked test case failed flag as False
        self.mark_case_failed = False
        group_id = 1

        if not process_setup(self,self.__class__):
            self.result_message="SETUP ERROR: Not able to process setup params"

        if not self.fail_to_setup:
            # Create directory, if required
            self.tst_dir_name = re.match(r'(.*_case[0-9]*).*', self.testClassId).group(1)

            self.su_output_dir = os.path.join(config.output_dir, self.tst_dir_name)

            if not os.path.isdir(self.su_output_dir):
                os.makedirs(self.su_output_dir)

            # Create the required file handle
            reset_logpath(os.path.join(self.su_output_dir, 'test.log'))
            for device in config.devices:
                exec (device + '.session.create_logfile(self.su_output_dir)')

            self.case_test_log = os.path.join(self.su_output_dir, "test.log")

        if self.__class__.__name__ != 'endofgroup':
            self.tstclass_name = re.match(r'(.*)_case.*', self.testClassId).group(1)
            self.tstcase_name = re.match(r'.*(case[0-9]*).*', self.testClassId).group(1)
            self.case_name_lst.append(self.tstcase_name)
            group_id = self.case_name_lst.count(self.tstcase_name)
            if group_id > 1:
                self.test_name = self.tstclass_name + "." + self.tstcase_name + "_grp" + str(group_id)
                self.tst_dir_name = self.test_name
            else:
                self.test_name  = self.tstclass_name + "." + self.tstcase_name
            self.case_id = re.match(r'case(.*)', self.tstcase_name).group(1)
            if not self.fail_to_setup:
                loggerObject.dumpLog("========== %s: Begin ==========" % self.tst_dir_name)

            log_test_setup_info([
                ("QCID", ""),
                ("test_comments", []),
                ("test_description", ""),
                ("test_type","Case"),
                ("test_name", self.test_name),
                ("time_started", datetime.now().strftime("%H:%M:%S"))# time_string = datetime.strftime(" %H:%M:%S", t)
            ])

            # publish the test details into HTML report
            get_test_details(test_name=self.test_name, test_type="case")

            if self.fail_to_setup:
                self.tearDown()
                self.skipTest("Skipped the setUp execution")
        else:
            self.case_name_lst = []

    def tearDown(self):
        if not self.fail_to_setup:
            log_test_teardown_info([
              ("test_name", self.test_name),
              ("time_ended", datetime.now().strftime("%H:%M:%S")),# time_string = datetime.strftime(" %H:%M:%S", t)
              ("log_link", self.case_test_log)
            ])
        else:
            log_test_teardown_info([
                ("test_name", self.test_name),
                ("time_ended", datetime.now().strftime("%H:%M:%S")),  # time_string = datetime.strftime(" %H:%M:%S", t)
                ("log_link", "")
            ])

        if self.mark_case_failed:
            publish_result([

                ('test_name', self.test_name),
                ('result', 'Fail'),
                ('test_type', 'case')

            ])
        # Generating JSON file at case level
        generate_case_json()
        # Generating CSV file at case level
        generate_child_csv()

        if not self.fail_to_setup:
            loggerObject.dumpLog("========== %s: End ==========" % self.tst_dir_name)

    def runTest(self):
        """
        Execute the following code only when test case is having the definition of steps methods
        """
        try:
            test_step_name = self.test_step_name
        except Exception as err:
            if "no attribute" in str(err):
                test_step_name = ""

        try:
            start_time = self.start_time
        except Exception as err:
            if "no attribute" in str(err):
                start_time = "00:00:00"
        try:
            case_log = self.case_test_log
        except Exception as err:
            if "no attribute" in str(err):
                case_log = ""

        log_test_case_steps_info([
                ("grade", "Fail"),
                ("QCID", ""),
                ("test_type","Teststep"),
                ("test_comments", []),
                ("test_name", test_step_name),
                ("time_started", start_time),    # time_string = datetime.strftime(" %H:%M:%S", t)
                ("time_ended", "00:00:00"),      # time_string = datetime.strftime(" %H:%M:%S", t)
                ("test_description", ""),
                ("log_link", case_log)
        ])

        # publish the test details into HTML report
        get_test_details(test_name=test_step_name, test_type="step")

        if self.methods_to_run:
            self.result = eval(self.run_step)
        elif self.steps_to_run.isdigit():
            self.result_message = "WARNING: Configured step" + str(self.steps_to_run) + " has not present\
             in the test case"
            # Publish the test comments to HTML report
            publish_comments_text_publish([
                ('test_name', self.test_name),
                ('test_comments', self.result_message),
                ('test_comments_link',''),
                ('test_type','case')
            ])

    def publish_stepsinfo_to_html(self):
        '''
        Publish steps related QC ID, test description, comments, result, execution time..etc into HTML
        '''
        if type(self.result) is bool:
            if self.result:
                self.result_final = "Pass"
            else:
                self.result_final = "Fail"
        elif isinstance(None, type(self.result)):
            self.result_final = "Fail"
        else:
            self.result_final = "Skipped"

        try:
            test_step_name = self.test_step_name
        except Exception as err:
            if "no attribute" in str(err):
                test_step_name = ""

        try:
            end_time = self.end_time
        except Exception as err:
            if "no attribute" in str(err):
                end_time = "00:00:00"

        publish_result_and_endtime([
            ('test_name', test_step_name),
            ('result', self.result_final),
            ('time_ended', end_time),
            ('test_type','step')
        ])

    def find_methods_to_run(self):
        """
        Find the methods to run from the testcase based on the runTest YAML file configuration
        """
        method_list = [func for func in dir(self) if callable(getattr(self, func))]
        method_list = [func for func in method_list if not func.find('step')]
        new_method_list = {}
        step_num = []
        for i in method_list:
            step_num = re.search('[0-9]+',i).group(0)
            new_method_list[int(step_num)] = i

        method_list = []
        self.methods_to_run = []
        new_methods_to_exec = []
        # Sorting the dict based on key stepvalues and appending to method_list
        for i, k in sorted(new_method_list.items()):
            method_list.append(new_method_list[i])
        if self.steps_to_run == 'FULL':
            self.methods_to_run = method_list
        else:
            for step_to_exec in self.steps_to_run.split(';'):
                if int(step_to_exec) > len(method_list) or int(step_to_exec) <= 0:
                    loggerObject.dumpLog(' Step not in range')
                    self.result_message="RUNTEST ERROR: Given step(s) to be ran have not in range of\
                     this test case steps"
                    # Publish the test comments to HTML report
                    publish_comments_text_publish([
                        ('test_name', self.test_name),
                        ('test_comments', self.result_message),
                        ('test_comments_link',''),
                        ('test_type','case')
                    ])

                else:
                    for step in method_list:
                        if step.find('Must') > 0:
                            if step not in new_methods_to_exec:
                                new_methods_to_exec.append(step)
                        elif step.find('step'+step_to_exec) == 0:
                            new_methods_to_exec.append(step)
                    self.methods_to_run = new_methods_to_exec

    @classmethod
    def skiptest_cases(cls):
        #Setting the case to be failed flag when setUpClass has failed..
        cls.fail_to_setup = True
        return True

    def wan_setup(self):
        None

    def lan_setup(self):
        None

    def wlan_setup(self):
        None

    def wan_cleanup(self):
        None

    def lan_cleanup(self):
        None

    def wlan_cleanup(self):
        None

    def testWrapper(self):
        '''
        if not board.isalive():
            self.result_grade = "SKIP"
            self.skipTest("Board is not alive")
            raise
        '''
        if self.__class__.__name__ != 'endofgroup':
            try:
                #@ WIRED may need to be uncommented
                '''
                if wan and hasattr(self, 'wan_setup'):
                    self.wan_setup()
                if lan and hasattr(self, 'lan_setup'):
                    self.lan_setup()
                if wlan and hasattr(self, 'wlan_setup'):
                    self.wlan_setup()
                '''
                if self.config.retry and not self.dont_retry:
                    retry = self.config.retry
                else:
                    retry = 0

                while retry >= 0:
                    try:
                        self.result_grade = "FAIL"
                        if config.prepost_file:
                            # publish the test details into HTML report
                            get_test_details(test_name=self.test_name, test_type="case")
                            if not self.prepost_cls_obj().pre_runtest():
                                self.prepost_cls_obj().post_runtest()
                                raise unittest2.SkipTest("Skipping test's --- Preruntest has failed")
                        self.find_methods_to_run()
                        # Compatible to execute the test case with/without steps methods
                        if self.methods_to_run:
                            for step in self.methods_to_run:
                                self.run_step = 'self.' + step+'()'
                                self.step_id = re.match('step([0-9]*)', step).group(1)
                                self.test_step_name = self.test_name + ".step" + self.step_id
                                loggerObject.dumpLog("========== %s: Begin ==========" % step)
                                self.start_time = datetime.now().strftime("%H:%M:%S")
                                self.runTest()
                                self.end_time = datetime.now().strftime("%H:%M:%S")
                                # Publish steps information to html
                                self.publish_stepsinfo_to_html()
                                loggerObject.dumpLog("========== %s: Result - %s ==========" % (step, self.result_final))
                        else:
                            self.test_step_name = self.test_name + ".runTest"
                            loggerObject.dumpLog("========== runTest: Begin ==========")
                            self.start_time = datetime.now().strftime("%H:%M:%S")
                            self.result = self.runTest()
                            self.end_time = datetime.now().strftime("%H:%M:%S")
                            # Publish steps information to html
                            self.publish_stepsinfo_to_html()
                            loggerObject.dumpLog("========== runTest: Result - %s ==========" % self.result_final)
                        if config.prepost_file:
                            # publish the test details into HTML report
                            get_test_details(test_name=self.test_name, test_type="case")
                            if not self.prepost_cls_obj().post_runtest():
                                self.mark_case_failed = True
                        retry = -1
                    except Exception as e:
                        retry = retry - 1
                        if(retry > 0):
                            print(e.get_trace())
                            print("\n\n----------- Test failed! Retrying in 5 seconds... -------------")
                            time.sleep(5)
                        else:
                            raise
                #@ WIRED may need to be uncommented
                '''
                if wan and hasattr(self, 'wan_cleanup'):
                    self.wan_cleanup()
                if lan and hasattr(self, 'lan_cleanup'):
                    self.lan_cleanup()
                if wlan and hasattr(self, 'wlan_cleanup'):
                    self.wlan_cleanup()
                '''

                if hasattr(self, 'committed_failure'):
                    self.result_grade = "FAIL"
                elif hasattr(self, 'expected_failure') and self.expected_failure:
                    self.result_grade = "Unexp OK"
                else:
                    self.result_grade = "PASS"
                    #self.result_grade = "OK"
            except unittest2.case.SkipTest:
                print("\n\n=========== Test skipped! Moving on... =============")
                self.result_grade = "FAIL"
                #self.result_grade = "SKIP"
                raise
            except Exception as e:
                if hasattr(self, 'expected_failure') and self.expected_failure:
                    self.result_grade = "Exp FAIL"
                else:
                    self.result_grade = "FAIL"
                print("\n\n=========== Test failed! Running recovery ===========")
                if e.__class__.__name__ == "TIMEOUT":
                    print(e.get_trace())
                else:
                    print(e)
                    traceback.print_exc(file=sys.stdout)
                self.recover()
                raise
        else:
            pass

    def recover(self):
        if self.__class__.__name__ == "LinuxBootTest":
            print("aborting tests, unable to boot..")
            sys.exit(1)
        print("ERROR: No default recovery!")
        raise Exception("No default recovery!")


def reset_logpath(logpath):
    """
    Reset logpath to path to the required dir
    """
    ## Create new file handler for logging
    fileHandler = logging.FileHandler(logpath)
    fileHandler.setFormatter(LOG_FORMAT)
    consoleHandler = logging.StreamHandler()
    consoleHandler.setFormatter(LOG_FORMAT)

    ## remove old handlers
    for handler in loggerObject.logger.handlers:
        handler.close()
        #loggerObject.logger.removeHandler(handler)
    loggerObject.logger.handlers = []

    ## remove old handlers for devices
    for device in config.devices:
        handler_list = eval('config.' + device + '.logger.logger.handlers')
        for handler in handler_list:
            handler.close()
            #exec (device + '.logger.logger.removeHandler(handler)')
        exec(device + '.logger.logger.handlers = []')

    ## Add new handler to logger object
    loggerObject.logger.addHandler(fileHandler)
    loggerObject.logger.addHandler(consoleHandler)

    ## Add new handler to each device logger object
    for device in config.devices:
        exec (device + '.logger.logger.addHandler(fileHandler)')
        exec (device + '.logger.logger.addHandler(consoleHandler)')
