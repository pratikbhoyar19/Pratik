''' SampleParallel test class'''
__author__ = "Intel Corporation"
__copyright__ = "Copyright 2019, Intel Corporation"
__version__ = "0.0.1"
__maintainer__ = "Mirafra"
__email__ = "framework@mirafra.com"
__status__ = "Sample"
###########################################################

from tests import linux_boot
from devices import *
from log_creator import loggerObject as logger
from globalVariables import measure_exe_time
from datetime import datetime
from parallel_exec import *
from config import runtime_para, kpi_para
from framework.publish_info_to_html import publish_html

class SampleParallel(linux_boot.LinuxBootTest):

    @classmethod
    def setUpClass(cls):
        """
           The setUpClass is where the group level Configurations  will be applied
           using the group level pararmaters and will be excueted once per instance
        """
        super(SampleParallel, cls).setUpClass()
        logger.dumpLog("SampleParallel: setUpClass Begins")
        ret_val = True

        ##@ Publish qcid and description to HTML report (Mandatory)
        #Parameter to be published should be in dict format
        pub_qcid = "QC_2"
        pub_test_desc = "Verify the working sample parallel script"
        pub_param_desc = {'parallel_timeout':'60'}
        publish_html(qcid=pub_qcid, test_desc=pub_test_desc, param_desc=pub_param_desc)

        #################### Test Code start ####################
        ## Verify the ping from devices in parallel
        parallel_exec(dut.os.start_ping_p)(ip="127.0.0.1", ping_count="3")
        parallel_exec(lan.os.start_ping_p)(ip="127.0.0.1", ping_count="3")
        parallel_exec(wlan.os.start_ping_p)(ip="127.0.0.1", ping_count="3")
        #Timeout of 10 sec for all the threads to execute and join back
        output=end_parallel(timeout=10)
        print output
        if not output[0]:
            self.result_message="SETUP ERROR: Ping to devices failed"
            ##@ Publish the test comments to HTML report (Optional)
            publish_html(comment=self.result_message)
            self.tearDown()
            self.skipTest(self.result_message)
            ret_val = False
        ####################  Test Code end  ####################

        logger.dumpLog("SampleParallel: setUpClass Ends")
        ##@ Return value should be True/False
        return ret_val


    def setUp(self):
        """
           The setUp is where the case level Configurations will be applied by
           using the case level parameters (including group level parameters)
        """
        super(SampleParallel, self).setUp()
        logger.dumpLog("SampleParallel: setUp Begins")
        ret_val = True

        ##@ Publish qcid and description to HTML report (mandatory)
        #Parameter to be published should be in dict format
        pub_qcid = "TC_"+str(self.case_id)
        pub_test_desc = "Get the dir of directory"
        pub_param_desc = {}
        publish_html(qcid=pub_qcid, test_desc=pub_test_desc, param_desc=pub_param_desc)

        #################### Test Code start ####################
        ##
        file_list = lan.session.send_recv('dir')
        logger.dumpLog("lan: files are %s" %file_list)

        ##@ Publish the test comments with file link to HTML report
        publish_html(comment='Case test log', log_link=self.case_test_log)
        ####################  Test Code end  ####################

        logger.dumpLog("SampleParallel: setUp Ends")
        ##@ Return value should be True/False
        return ret_val


    def runTest(self):
        """
        runtest method will trigger all/some steps as mentioned in runtest.yaml
        Please avoid updating this function.
        """
        logger.dumpLog("SampleParallel: runtest: Begins")
        super(SampleParallel, self).runTest()
        logger.dumpLog("SampleParallel: runtest Ends ")


    def step1Must(self):
        """
           step*_Must are the methods which will be executed irespective
           of the steps mentioend in runtest.yaml
        """
        logger.dumpLog("SampleParallel: step1must: Begins")
        ret_val = True

        ##@ Publish qcid and description to HTML report (mandatory)
        try:
            pub_qcid = "TC_"+str(self.case_id)+"_"+str(self.step_id)
        except Exception as err:
            pub_qcid = ""
        pub_test_desc = "Getting LAN IP for ping command to execute"
        publish_html(qcid=pub_qcid, test_desc=pub_test_desc)

        #################### Test Code start ####################
        ##Dut: Verify the mac address
        # dut.dict['wlan2g_iface'] gives the interface from testbed.yaml
        ap_mac_addr = dut.os.get_mac_addr(interface = dut.dict['wlan2g_iface'])
        if (ap_mac_addr == dut.dict['hwaddr']):
            logger.dumpLog("dut: step1Must: mac address obtained %s"%ap_mac_addr)
        else:
            comment_msg = "dut: step1Must: Error: Invalid mac address obtained %s"%ap_mac_addr
            logger.dumpLog(comment_msg)
            publish_html(comment=comment_msg)
            ret_val = False
        ####################  Test Code end  ####################

        logger.dumpLog("SampleParallel: step1Must: Ends")
        ##@ Return value should be True/False
        return ret_val


    def step2(self):
        """
           step*_Must are the methods which will be executed irespective
           of the steps mentioend in runtest.yaml
        """
        logger.dumpLog("SampleParallel: step2: Begins")
        ret_val = True

        ##@ Publish qcid and description to HTML report (mandatory)
        try:
            pub_qcid = "TC_"+str(self.case_id)+"_"+str(self.step_id)
        except Exception as err:
            pub_qcid = ""
        pub_test_desc = "Getting the address of the interface"
        publish_html(qcid=pub_qcid, test_desc=pub_test_desc)

        #################### Test Code start ####################
        #Verify the ip address for devices lan,wlan,dut
        # dut.dict['wlan2g_iface'] gives the interface from testbed.yaml
        # lan.dict['iface']gives the interface from testbed.yaml
        # wlan.dict['iface']gives the interface from testbed.yaml
        parallel_exec(dut.os.get_interface_ipaddr)(interface = dut.dict['wlan2g_iface'])
        parallel_exec(lan.os.get_interface_ipaddr)(interface = lan.dict['iface'])
        parallel_exec(wlan.os.get_interface_ipaddr)(interface = wlan.dict['iface'])
        #Timeout of 10 sec for all the threads to execute and join back
        output=end_parallel(timeout=30)
        print output
        if not output[0]:
            self.result_message="step2: ERROR: Failed to get ip addr for 1 or interface"
            ##@ Publish the test comments to HTML report (Optional)
            publish_html(comment=self.result_message)
            ret_val = False
        ####################  Test Code end  ####################

        logger.dumpLog("SampleParallel: step2: Ends")
        ##@ Return value should be True/False
        return ret_val


    def tearDown(self):
        """
           The tearDown is used to revert the configurations at case level
        """
        super(SampleParallel, self).tearDown()
        logger.dumpLog("SampleParallel:tearDown: Begins")
        ret_val = True

        #################### Test Code start ####################
        ##Devices cleanup
        lan.os.remove_server_report()
        dut.os.stop_trafficgen_mpstat()
        ####################  Test Code end  ####################

        logger.dumpLog("SampleParallel:tearDown: Ends")
        return ret_val


    @classmethod
    def tearDownClass(cls):
        """
           The tearDownClass is the place where group level configurations  will be reverted back
           using the group level pararmaters and will be excueted once per instance
        """
        super(SampleParallel, cls).tearDownClass()
        logger.dumpLog("SampleParallel:tearDownClass: starts")
        ret_val = True

        #################### Test Code start ####################
        ##Verify the ping from devices after test execution
        parallel_exec(dut.os.start_ping_p)(ip="127.0.0.1", ping_count="3")
        parallel_exec(lan.os.start_ping_p)(ip="127.0.0.1", ping_count="3")
        parallel_exec(wlan.os.start_ping_p)(ip="127.0.0.1", ping_count="3")
        #Wait for default timeout
        output=end_parallel()
        print output
        ####################  Test Code end  ####################

        logger.dumpLog("SampleParallel:tearDownClass: ends")
        return ret_val

