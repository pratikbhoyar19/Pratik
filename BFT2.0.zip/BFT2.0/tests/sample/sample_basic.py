''' SampleBasic test class'''
__author__ = "Intel Corporation"
__copyright__ = "Copyright 2019, Intel Corporation"
__version__ = "0.0.1"
__maintainer__ = "Mirafra"
__email__ = "framework@mirafra.com"
__status__ = "Sample"
###########################################################

from tests import linux_boot
from devices import *
from log_creator import loggerObject as logger
from globalVariables import measure_exe_time
from datetime import datetime
from config import runtime_para, kpi_para
from framework.publish_info_to_html import publish_html

class SampleBasic(linux_boot.LinuxBootTest):

    @classmethod
    def setUpClass(cls):
        """
           The setUpClass is where the group level Configurations  will be applied
           using the group level pararmaters and will be executed once per instance
        """
        super(SampleBasic, cls).setUpClass()
        logger.dumpLog("SampleBasic: setUpClass: Begins")

        ##@ Publish qcid and description to HTML report (Mandatory)
        pub_qcid = "QC_1"
        pub_test_desc = "Verify working of basic sample script"
        publish_html(qcid=pub_qcid, test_desc=pub_test_desc)

        #################### Test Code start ####################
        ## Verify the ping from devices 
        dut.os.start_ping_p(ip="127.0.0.1", ping_count="3")
        lan.os.start_ping_p(ip="127.0.0.1", ping_count="3")
        wlan.os.start_ping_p(ip="127.0.0.1", ping_count="3")

        logger.dumpLog('Verify the working of logger module API')
        logger.warning('Verify the working of logger module API')
        logger.error('Verify the working of logger module API')

        dut.logger.dumpLog('Verify the working of logger module API')
        dut.logger.warning('Verify the working of logger module API')
        dut.logger.error('Verify the working of logger module API')
        ####################  Test Code end  ####################

        logger.dumpLog("SampleBasic: setUpClass: Ends")
        return True


    def setUp(self):
        """
           The setUp is where the case level Configurations will be applied by 
           using the case level parameters (including group level parameters)
        """
        super(SampleBasic, self).setUp()
        logger.dumpLog("SampleBasic: setUp: Begins")

        ##@ Publish qcid and description to HTML report (mandatory)
        pub_qcid = "TC_"+str(self.case_id)
        pub_test_desc = "Get the list of files from directory"
        publish_html(qcid=pub_qcid, test_desc=pub_test_desc)

        #################### Test Code start ####################
        ##Assume lan as Linux platform; Get the files list
        dir = lan.session.send_recv('dir')
        logger.dumpLog("lan: Output of dir contents are as follows %s" %dir)

        logger.dumpLog('Verify the working of logger module API')
        logger.warning('Verify the working of logger module API')
        logger.error('Verify the working of logger module API')

        lan.logger.dumpLog('Verify the working of logger module API')
        lan.logger.warning('Verify the working of logger module API')
        lan.logger.error('Verify the working of logger module API')
        ####################  Test Code end  ####################

        logger.dumpLog("SampleBasic: setUp: Ends")
        return True


    def runTest(self):
        """
            runtest method will trigger all/some steps as mentioned in runtest.yaml
            Please avoid updating this function.
        """
        logger.dumpLog("SampleBasic: runtest: Begins")
        super(SampleBasic, self).runTest()
        logger.dumpLog("SampleBasic: runtest: Ends ")


    def step1Must(self):
        """
           step*Must are the methods which will be executed irespective 
           of the steps mentioned in runtest.yaml
        """
        logger.dumpLog("SampleBasic: step1must: Begins")
        ret_val = True

        ##@ Publish qcid and description to HTML report (mandatory)
        try:
            pub_qcid = "TC_"+str(self.case_id)+"_"+str(self.step_id)
        except Exception as err:
            pub_qcid = ""
        pub_test_desc = "Get mac address of the interface"
        publish_html(qcid=pub_qcid, test_desc=pub_test_desc)

        #################### Test Code start ####################
        ##Dut: Verify the mac address
        # dut.dict['wlan2g_iface'] gives the interface from testbed.yaml
        ap_mac_addr = dut.os.get_mac_addr(interface = dut.dict['wlan2g_iface'])
        if (ap_mac_addr == dut.dict['hwaddr']):
            comment_msg = "dut: step1Must: Mac address obtained is %s"%ap_mac_addr
            logger.dumpLog(comment_msg)
            ##@ Publish the test comments to HTML report (Optional)
            publish_html(comment=comment_msg)
        else:
            logger.dumpLog("dut: step1Must: Error: Invalid mac address obtained %s"%ap_mac_addr)
            ret_val = False
        ####################  Test Code end  ####################

        logger.dumpLog("SampleBasic: step1Must: Ends")
        return ret_val


    def step2(self):
        """
           Test execution logic applied in steps
        """
        logger.dumpLog("SampleBasic:step2: Begins")
        ret_val = True

        ##@ Publish qcid and description to HTML report (mandatory)
        try:
            pub_qcid = "TC_"+str(self.case_id)+"_"+str(self.step_id)
        except Exception as err:
            pub_qcid = ""
        pub_test_desc = "Get lan ip address of the interface"
        publish_html(qcid=pub_qcid, test_desc=pub_test_desc)

        #################### Test Code start ####################
        ##Wan: Verify the ipaddress from the eth1 interface
        logger.dumpLog("lan: step2: Get lan ip for the given interface")
        eth_ip = lan.os.get_interface_ipaddr(interface=lan.dict['iface'])
        if not eth_ip:
            self.result_message="RUNTEST ERROR: Not able to get the IP address for the interface"
            ##@ Publish the test comments to HTML report (Optional)
            publish_html(comment=self.result_message)
            #self.skipTest(self.result_message)
            ret_val = False
        else:
            logger.dumpLog("lan: step2: ip address obatined for the interface is %s" %eth_ip)
        ####################  Test Code end  ####################

        logger.dumpLog("SampleBasic:step2: Ends")
        return ret_val


    def tearDown(self):
        """
            The tearDown is used to revert the configurations at case level
        """
        super(SampleBasic, self).tearDown()
        logger.dumpLog("SampleBasic:tearDown: Begins")

        #################### Test Code start ####################
        ##devices cleanup
        lan.os.remove_server_report()
        dut.os.stop_trafficgen_mpstat()
        ####################  Test Code end  ####################

        logger.dumpLog("SampleBasic:tearDown: Ends")


    @classmethod
    def tearDownClass(cls):
        """
           The tearDownClass is the place where group level configurations  will be reverted back
           using the group level pararmaters and will be excueted once per instance
        """
        super(SampleBasic, cls).tearDownClass()
        logger.dumpLog("SampleBasic:tearDownClass: starts")

        #################### Test Code start ####################
        ##Verify the ping from devices after test execution
        dut.os.start_ping_p(ip="127.0.0.1", ping_count="3")
        lan.os.start_ping_p(ip="127.0.0.1", ping_count="3")
        wlan.os.start_ping_p(ip="127.0.0.1", ping_count="3")

        logger.dumpLog('Verify the working of logger module API')
        logger.warning('Verify the working of logger module API')
        logger.error('Verify the working of logger module API')

        wlan.logger.dumpLog('Verify the working of logger module API')
        wlan.logger.warning('Verify the working of logger module API')
        wlan.logger.error('Verify the working of logger module API')
        ####################  Test Code end  ####################

        logger.dumpLog("SampleBasic:tearDownClass: ends")
        return True

