from devices.platform_types.linux import dev_ip_obj
from devices.platform_types.windows import dev_ip_obj
from devices.platform_types.andriod import dev_ip_obj
from log_creator import loggerObject as logger

for dev_obj in dev_ip_obj:
    exec("from devices import "+dev_obj)

class SamplePrepost(object):
    def pre_suite(self):
        print("preSuite method - Begins")
        logger.dumpLog('Verify the working of logger module API')
        logger.warning('Verify the working of logger module API')
        logger.error('Verify the working of logger module API')

        dut.logger.dumpLog('Verify the working of logger module API')
        dut.logger.warning('Verify the working of logger module API')
        dut.logger.error('Verify the working of logger module API')

        print("preSuite method - Ends")
        return True

    def pre_setupclass(self):
        print("preSetupClass method - Begins")
        logger.dumpLog('Verify the working of logger module API')
        logger.warning('Verify the working of logger module API')
        logger.error('Verify the working of logger module API')

        dut.logger.dumpLog('Verify the working of logger module API')
        dut.logger.warning('Verify the working of logger module API')
        dut.logger.error('Verify the working of logger module API')

        print("preSetupClass method - Ends")
        return True

    def pre_runtest(self):
        print("preRunClass method - Begins")
        logger.dumpLog('Verify the working of logger module API')
        logger.warning('Verify the working of logger module API')
        logger.error('Verify the working of logger module API')

        dut.logger.dumpLog('Verify the working of logger module API')
        dut.logger.warning('Verify the working of logger module API')
        dut.logger.error('Verify the working of logger module API')

        print("preRunClass method - Ends")
        return True

    def post_runtest(self):
        print("postRunClass method - Begins")
        logger.dumpLog('Verify the working of logger module API')
        logger.warning('Verify the working of logger module API')
        logger.error('Verify the working of logger module API')

        dut.logger.dumpLog('Verify the working of logger module API')
        dut.logger.warning('Verify the working of logger module API')
        dut.logger.error('Verify the working of logger module API')

        print("postRunClass method - Ends")
        return True

    def post_setupclass(self):
        print("postSetupClass method - Begins")
        logger.dumpLog('Verify the working of logger module API')
        logger.warning('Verify the working of logger module API')
        logger.error('Verify the working of logger module API')

        dut.logger.dumpLog('Verify the working of logger module API')
        dut.logger.warning('Verify the working of logger module API')
        dut.logger.error('Verify the working of logger module API')

        print("postSetupClass method - Ends")
        return True

    def post_suite(self):
        print("postSuite method - Begins")
        logger.dumpLog('Verify the working of logger module API')
        logger.warning('Verify the working of logger module API')
        logger.error('Verify the working of logger module API')

        dut.logger.dumpLog('Verify the working of logger module API')
        dut.logger.warning('Verify the working of logger module API')
        dut.logger.error('Verify the working of logger module API')

        print("postSuite method - Ends")
        return True

