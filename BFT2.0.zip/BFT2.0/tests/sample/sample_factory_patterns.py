''' SampleFactoryPatterns test class'''
__author__ = "Intel Corporation"
__copyright__ = "Copyright 2019, Intel Corporation"
__version__ = "0.0.1"
__maintainer__ = "Mirafra"
__email__ = "framework@mirafra.com"
__status__ = "Sample"
###########################################################

from tests import linux_boot
from devices import *
from log_creator import loggerObject as logger
from globalVariables import measure_exe_time
from datetime import datetime
from config import runtime_para, kpi_para
from framework.publish_info_to_html import publish_html

class SampleFactoryPatterns(linux_boot.LinuxBootTest):
    """
    This class is master class for demonstrating following factory patterns:
    @ <DEVICE>.device_dict[<KEY>]: To get device specific information from testbed_factory_patterns.yaml
    @ <DEVICE>.os.<API>: To call Device OS/platform related APIs 
    @ <DEVICE>.tools.<API>: To call Device configuration related APIs
    @ <DEVICE>.traffic.<API>: To call traffic related APIs
    @ dut.swdist.<API>: To call DUT sofware distribution specific API
    Attributes:
        None
    """

    @classmethod
    def setUpClass(cls):
    	"""
           The setUpClass is where the group level Configurations  will be applied
           using the group level pararmaters and will be executed once per instance
        """
        logger.dumpLog("SampleFactoryPatterns: setUpClass: Begins")
        super(SampleFactoryPatterns, cls).setUpClass()

        ##@ Publish qcid and description to HTML report (Mandatory)
        pub_qcid = "QC_1"
        pub_test_desc = "Function to verify factory patterns"
        publish_html(qcid=pub_qcid, test_desc=pub_test_desc)
        
        #################### Test Code start ####################
        ########### Nothing To do ###############################
        ####################  Test Code end  ####################
        
        logger.dumpLog("SampleFactoryPatterns: setUpClass: Ends")
        return True


    def setUp(self):
    	"""
           The setUp is where the case level Configurations will be applied by 
           using the case level parameters (including group level parameters)
        """
        logger.dumpLog("SampleFactoryPatterns: setUp: Begins")
        super(SampleFactoryPatterns, self).setUp()

        ##@ Publish qcid and description to HTML report (mandatory)
        pub_qcid = "TC_"+str(self.case_id)
        pub_test_desc = ""
        publish_html(qcid=pub_qcid, test_desc=pub_test_desc)

        #################### Test Code start ####################
        ########### Nothing To do ###############################
        ####################  Test Code end  ####################

        logger.dumpLog("SampleFactoryPatterns: setUp: Ends")
        return True


    def runTest(self):
    	"""
            runtest method will trigger all/some steps as mentioned in runtest.yaml
            Please avoid updating this function.
        """
        logger.dumpLog("SampleFactoryPatterns: runtest: Begins")
        super(SampleFactoryPatterns, self).runTest()
        logger.dumpLog("SampleFactoryPatterns: runtest: Ends ")

    def step1(self): 
        """
        The function to check device_dict factory pattern
        Args:
            None
        Returns:
            None  
        """
        try:
            pub_qcid = "TC_"+str(self.case_id)+"_"+str(self.step_id)
        except Exception as err:
            pub_qcid = ""
        pub_test_desc = "Checking device_dict factory pattern"

        publish_html(qcid=pub_qcid, test_desc=pub_test_desc)

        ##@ Using <DEVICE>.device_dict[<key>] factory pattern to fetch <DEVICE> related testbed attributes
        logger.dumpLog("Management Ip For Lan Machine is {}".format(lan.device_dict['ipaddr'])) 
        logger.dumpLog("DUT Lan IP is {}".format(dut.device_dict['ipaddr'])) 
        return True
    
    def step2(self): 
        """
        The function to check OS factory pattern
        Args:
            None
        Returns:
            None  
        """
        try:
            pub_qcid = "TC_"+str(self.case_id)+"_"+str(self.step_id)
        except Exception as err:
            pub_qcid = ""
        pub_test_desc = "Checking OS factory pattern"
 
        publish_html(qcid=pub_qcid, test_desc=pub_test_desc)

        ##@ Using <DEVICE>.os.<API> factory pattern to call <DEVICE> os APIs
        lan.os.test_func() 
        dut.os.test_func() 
        return True
    
    def step3(self): 
        """
        The function to check tools factory pattern
        Args:
            None
        Returns:
            None  
        """
        try:
            pub_qcid = "TC_"+str(self.case_id)+"_"+str(self.step_id)
        except Exception as err:
            pub_qcid = ""

        pub_test_desc = "Checking tools factory pattern"

        publish_html(qcid=pub_qcid, test_desc=pub_test_desc)

        ##@ Using <DEVICE>.tools.<API> factory pattern to call <DEVICE> tool specific APIs
        dut.tools.test_func() 
        lan.tools.test_func() 
        return True

    def step4(self): 
        """
        The function to check sw dist API
        Args:
            None
        Returns:
            None  
        """
        try:
            pub_qcid = "TC_"+str(self.case_id)+"_"+str(self.step_id)
        except Exception as err:
            pub_qcid = ""
        pub_test_desc = "Checking sw distribution factory pattern"

        publish_html(qcid=pub_qcid, test_desc=pub_test_desc)
        
        ##@ Using dut.swdist.<API> factory pattern to call dut sw distribution specific APIs
        dut.swdist.test_func()
        return True

    def step5(self): 
        """
        The function to check Traffic API
        Args:
            None
        Returns:
            None  
        """
        try:
            pub_qcid = "TC_"+str(self.case_id)+"_"+str(self.step_id)
        except Exception as err:
            pub_qcid = ""
        pub_test_desc = "Checking traffic factory pattern"

        publish_html(qcid=pub_qcid, test_desc=pub_test_desc)

        ##@ Using <DEVICE>.traffic.<API> factory pattern to call <DEVICE> traffic APIs
        lan.traffic.test_func()
        dut.traffic.test_func()
        return True

    def tearDown(self):
    	"""
            The tearDown is used to revert the configurations at case level
        """
        logger.dumpLog("SampleFactoryPatterns:tearDown: Begins")

        #################### Test Code start ####################
        ########### Nothing To do ###############################
        ####################  Test Code end  ####################

        super(SampleFactoryPatterns, self).tearDown()
        logger.dumpLog("SampleFactoryPatterns:tearDown: Ends")
        return True

    @classmethod
    def tearDownClass(cls):
    	"""
           The tearDownClass is the place where group level configurations  will be reverted back
    	   using the group level pararmaters and will be excueted once per instance
        """
        logger.dumpLog("SampleFactoryPatterns:tearDownClass: starts")

        #################### Test Code start ####################
        ########### Nothing To do ###############################
        ####################  Test Code end  ####################

        super(SampleFactoryPatterns, cls).tearDownClass()
        logger.dumpLog("SampleFactoryPatterns:tearDownClass: ends")
        return True

