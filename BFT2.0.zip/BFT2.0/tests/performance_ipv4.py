#Copyright(c) 2018 Intel Corporation
# All rights reserved.
#
# This file is distributed under the Clear BSD license.
# The full text can be found in LICENSE in the root directory.
# This file consist of classes for computing Throughput and Idle cpu
# cycles for upstream, downstream and birectional traffic

import lib
import copy
import re
import unittest2
from tests import linux_boot
from devices.platform_types.linux import *
from devices import *
from globalVariables import *
from log_creator import loggerObject as logger
from time import *
from parallel_exec import *
import config
from framework.process_params import process_setup, process_setupclass, process_output
#exec("from tests.wlan.prepost.%s import *" % config.prepost_file)

class ipv4Performance(linux_boot.LinuxBootTest):
    """performance test from LAN to WAN"""
    i = 0  # Class attribute used for parsing each para list
    grp_level_params={}
    case_level_params={}

    @classmethod
    def clsVarCreate(cls):
        '''To create class variables
           Arguments:  cls  - This argument is class object to ipv4Performance class'''
        #### Parameterized
        ##### DUT, LAN, STA1 and STA2 objects
        cls.dut = dut
        cls.lan = lan
        cls.wan = wan
        ### Iperf parameters
        cls.proto = tsv_proto_tcp
        cls.wan_proto=tsv_ip_proto_dhcp
        cls.wan_conn=tsv_ethwan_untagged
        cls.stream=tsv_upstream
        cls.bi_iface=tsv_wan_interface_name
        cls.eth_iface=tsv_wan_interface_name
        cls.server_STA1_port = '5001'
        cls.time = tsv_iperf_time
        cls.wan_interface=dut_wan_interface
        cls.wan_netmask=tsv_wan_netmask
        cls.server_report_name = tsv_server_report_name
        cls.ping_count = tsv_ping_count
        #### Timeout parameters
        cls.timeout_5 = tsv_timeout_5
        cls.timeout_10 = tsv_timeout_10
        cls.timeout = tsv_timeout
        cls.client = lan
        cls.server = wan

    @classmethod
    def setUpClass(cls):
        '''To get Wan Ip, To Grp level apply changes to DUT
           Arguments:  cls  - This argument is class object to ipv4Performance class'''
        print("Inside setUpClass")
        cls.clsVarCreate()
        super(ipv4Performance, cls).setUpClass()
        #Will update Grp level params
        if not process_setupclass(cls):
            cls.result_message="SETUPCLASS ERROR: Not able to process setupClass params"
            cls.tearDownClass()
            raise unittest2.SkipTest(cls.result_message)

        #do DUT Config
        logger.dumpLog("setUpClass")
        logger.dumpLog("Starting dumpLog")
        logger.dumpLog("Obtaining WAN IP addr for DUT")
        cls.ip_addr = dut.tools.wan_mode_config(wan_proto=cls.wan_proto, wan_interface=cls.wan_interface, wan_netmask=cls.wan_netmask, wan_conn=cls.wan_conn)
        if not cls.ip_addr:
            cls.result_message = ("Failed to get IPaddress %s" % cls.wan_proto)
            cls.tearDownClass()
            raise unittest2.SkipTest(cls.result_message)
        logger.dumpLog("Stopping mpstat/traffic generators")
        wan.os.stop_trafficgen_mpstat()
        lan.os.stop_trafficgen_mpstat()
        dut.os.stop_trafficgen_mpstat()
        logger.dumpLog("Stopping mpstat/traffic generators")

    def setUp(self):
        '''To apply parameter changes to DUT at case level
           Arguments:  self  - This argument is self object to ipv4Performance class'''
        ###### process case related parameters in store in class dict, will update case level params  ################
        if not process_setup(self,ipv4Performance):
            self.result_message="SETUP ERROR: Not able to process setup params"
            self.tearDown()
            self.skipTest(self.result_message)
        super(ipv4Performance, self).setUp(self.testClassId)
        logger.startLog(self.testClassId)
        logger.dumpLog("#########################")
        logger.dumpLog("Executing %s "% self.stream)
        #print (self.stream)
        logger.dumpLog("#########################")
        logger.dumpLog("Start system setup")
        if self.stream != "upstream":
            #logger.dumpLog("config for downstream")
            self.server = lan
            self.client = wan
            self.eth_iface=tsv_lan_host_eth_interface
            dest_ip= self.server.os.get_interface_ipaddr(self.eth_iface)
            dut.tools.add_remove_dmz_rule_firewall(dest_ip=dest_ip, enable=tsv_dmz_actiavte,param="forward", forward_rule="ACCEPT")
            dut_wan_interface_ip=dut.os.get_interface_ipaddr(self.wan_conn)
            wan.os.add_gw_route(dut_wan_interface_ip)
        ### Remove STA1, STA2, LAN server report
        wan.os.remove_server_report()
        ### Stop traffic at DUT, STA1, STA2 and LAN
        dut.os.stop_trafficgen_mpstat()
        self.client.os.stop_trafficgen_mpstat()
        self.server.os.stop_trafficgen_mpstat()
        logger.dumpLog("End system cleanup")

    def runTest(self):
        '''To check ping connectivity and execute iperf servers and clients to get throughput
           Arguments:  self  - This argument is self object to ipv4Performance class'''
        logger.dumpLog("runTest")
        logger.dumpLog("checking connectivity")
        logger.dumpLog("getting lan ip for ping command to execute")
        server_ip = self.server.os.get_interface_ipaddr(self.eth_iface)
        client_ip = self.client.os.get_interface_ipaddr(self.bi_iface)
        if not server_ip:
            self.result_message="RUNTEST ERROR: Not able to get Server IP"
            self.skipTest(self.result_message)
        if not client_ip:
            self.result_message="RUNTEST ERROR: Not able to get Client IP"
            self.skipTest(self.result_message)

        ####### Start ping from lan to wan ##########
        logger.dumpLog('RUNTEST : start pinging from lan to wan')
        if not self.client.os.start_ping_p(ip=server_ip):
            self.result_message="RUNTEST ERROR: Not able to ping Server IP"
            self.skipTest(self.result_message)

        ##### Start Server ######
        logger.dumpLog("Start iperf servers on {} clients".format(self.server))
        if not self.server.traffic.start_server(parallel_stream=True, time=(str(int(self.time)+5)), proto=self.proto, port=self.server_STA1_port):

            self.result_message="RUNTEST ERROR: Not able to start server"
            self.skipTest(self.result_message)

        ##### Start Client ######
        logger.dumpLog("Start iperf client on {} host".format(self.client))
        sleep(5)
        if not self.client.traffic.start_client(ip=server_ip, parallel_stream=True, time=self.time, proto=self.proto, port=self.server_STA1_port):
            self.result_message="not able to start client"
            self.skipTest(self.result_message)

        logger.dumpLog("Waiting for iperf time ..............")
        sleep(int(self.time)+10)
         
        ####### Parse Iperf server report at server side
        logger.dumpLog("Start fetching server reports")
        rate = self.server.os.parse_iperf_server_report(proto=self.proto, report_name=self.server_report_name)
        print (rate)
        if not rate:
            self.result_message="RUNTEST ERROR: Not able to parse traffic server report"
            self.skipTest(self.result_message)

        if self.stream == "bidi":
             ##### Start Server ######
             logger.dumpLog("Start iperf servers on %s clients" % self.server)
             if not self.client.traffic.start_server(parallel_stream=True, time=str(int(self.time) + 5), proto=self.proto, port=self.server_STA1_port):

                 self.result_message="RUNTEST ERROR: Not able to start server"
                 self.skipTest(self.result_message)
             #sleep(5)
             ##### Start Client ######
             logger.dumpLog("Start iperf client on {} host".format(self.client))
             if not self.server.traffic.start_client(ip=client_ip, parallel_stream=True, time=str(int(self.time) - 5), proto=self.proto, port=self.server_STA1_port):
                 self.result_message="not able to start client"
                 self.skipTest(self.result_message)
             ####### Parse Iperf server report at server side
             logger.dumpLog("Start fetching server reports")
             rate_bidi = self.client.os.parse_iperf_server_report(proto=self.proto, report_name=self.server_report_name)
             rate= str(float(rate) + float(rate_bidi))
             if not rate_bidi:
                 self.result_message="RUNTEST ERROR: Not able to parse traffic server report"
                 self.skipTest(self.result_message)
        msg = ""
        msg ="Throughput is %s Mbps\n" %(rate)
        self.result_message = msg

    def tearDown(self):
        '''To do clean up in all machines before next case execution
           Arguments:  self  - This argument is self object to ipv4Performance class'''
        logger.dumpLog("tearDown")
        logger.dumpLog("Start system cleanup")
        ### Remove server report
        self.server.os.remove_server_report()

        ### Stop traffic at DUT Wan and LAN
        dut.os.stop_trafficgen_mpstat()
        lan.os.stop_trafficgen_mpstat()
        wan.os.stop_trafficgen_mpstat()
        logger.dumpLog("End system cleanup")
        super(ipv4Performance, self).tearDown(self.testClassId)
        return True

    def recover(self, client=lan, server=wan):
        dut.session.send_control('c')
        lan.session.send_control('c')
        wan.session.send_control('c')
        dut.os.stop_iperf_mpstat()
        lan.os.stop_iperf_mpstat()
        wan.os.stop_iperf_mpstat()

    @classmethod
    def tearDownClass(cls):
        '''To revert parameter changes to AP and WSTAs at group level, diasscotiation will take place here
           Arguments:  cls  - This argument is class object to ipv4Performance class'''
        print("Inside tearDownClass")
        logger.dumpLog("Start Reverting Network config")
        dut.tools.reset_network_defaults()
        logger.dumpLog("End Reverting Network config")
        super(ipv4Performance, cls).tearDownClass()

