#Copyright(c) 2018 Intel Corporation
# All rights reserved.
#
# This file is distributed under the Clear BSD license.
# The full text can be found in LICENSE in the root directory.
# This file consist of classes for computing Throughput and Idle cpu
# cycles for upstream, downstream and birectional traffic


from tests import linux_boot

class endofgroup(linux_boot.LinuxBootTest):

    @classmethod
    def setUpClass(cls):
        pass

    @classmethod
    def tearDownClass(cls):
        pass

    def setUp(self):
        pass
    def runTest(self):
        pass
    def tearDown(self):
        pass

