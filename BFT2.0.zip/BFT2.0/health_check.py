'''Libary defination pertaining to health check. '''


__author__ = "Intel Corporation"
__copyright__ = "Copyright 2019, Intel Corporation"
__version__ = "0.0.1"
__maintainer__ = "Mirafra"
__email__ = "framework@mirafra.com"
__status__ = "Development"

from globalVariables import *
from log_creator import loggerObject as logger
from devices.platform_types.linux import dev_ip_obj
from devices.platform_types.windows import dev_ip_obj
from devices.platform_types.andriod import dev_ip_obj
from parallel_exec import *

for dev_obj in dev_ip_obj:
    exec("from devices import "+dev_obj)

def check_device_health():
    '''
    Method Name      : Os_info
    Description      : Getting the os information for all the available devices defined in the testbed
    Input parameters : None
    Output           : None
    '''

    logger.dumpLog("Health check initiated")

    #For each device get the OS type using parallel execution
    for dev_obj in dev_ip_obj:
       eval("parallel_exec(%s.os.get_os_info)()"%(dev_obj))

    output=end_parallel()
    logger.dumpLog(str(output))

    if output[0] == 'Fail':
        return False
    return True

