from devices.platform_types.linux import dev_ip_obj
from devices.platform_types.windows import dev_ip_obj
from devices.platform_types.andriod import dev_ip_obj

for dev_obj in dev_ip_obj:
    exec("from devices import "+dev_obj)

def pre_suite():
    print("PreSuite method is called ")


def pre_setupclass():
    print("presetup method is called")
    return True


def pre_runtest():
    print("preruntest method is called")


def post_runtest():
    print("post runtest method is called")

def post_setupclass():
    print("post setupclass method is called")

def post_suite():
    print("Post suite method is called")


'''
suit_started = False
def suit_start(func):
    def wrapper(*args, **kwargs):
        if suit_started == False:
            func(*args, **kwargs)
            global suit_started
            suit_started = True
        else:
            return ("suite already called")
    return wrapper

def suit_stop(func):
    def wrapper(*args, **kwargs):
        if suit_started == True:
            func(*args, **kwargs)
            global suit_started
            suit_started = False
'''
