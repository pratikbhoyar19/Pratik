import json
import os
import re
from collections import OrderedDict
from config import output_dir


def format_params_tag(params):
    if params:
        tag = '<br><br><i>Params:<br>-----------<br>'
        for key, value in sorted(dict(params).items()):
            tag += '{0}: {1}<br>'.format(key, value)
        tag += '</i>'
        return tag
    return ''


def format_result(result):
    if result == 'Pass':
        return '<b style="color: green;">Pass</b>'
    elif result == "Fail":
        return '<b style="color: red;">Fail</b>'
    elif result == 'Skipped':
        return '<b style="color: orange;">Skipped</b>'
    else:
        return ''

def json_to_html():
    json_file = os.path.join(output_dir, "result.json")
    html_file = os.path.join(output_dir, "result.html")
    with open(json_file) as f:
        x = OrderedDict()
        x = json.loads(f.read(), object_pairs_hook=OrderedDict)

        # constructing html base and styles
        html1 = """<html>
                    <head>

                        <link href="../../html/bootstrap_v3.3.5.min.css" rel="stylesheet" />
                        <style>
                            body {
                                margin: 0px;
                                padding: 20px 8px;
                            }
                            table {
                                font-family: arial, sans-serif;
                                border-collapse: collapse;
                                width: 100%;
                            }
                            td, th {
                                border: 1px solid #dddddd;
                                text-align: left;
                                padding: 6px;
                                font-size: 13px;
                            }

                            .caserow {
                                background-color: #d9eef7;
                            }

                            .grey {
                                background-color: #dddd;
                            }

                            .heading {
                                color: black;
                                font-family: arial, sans-serif;
                                text-underline-position:right;

                            }
                            .case_c1 {
                                padding-left: 30px;
                            }
                            .step_c1 {
                                padding-left: 45px;
                            }
                            th {
                                background-color: #87ceeb;
                            }
                            .red {
                                color: red;
                            }
                            .red:hover {
                                color: red;
                            }
                        </style>
                    </head>
                <body>

                <div class="check-width">
                    <script src="../../html/jquery_v4.3.0.min.js"></script>
                    <script src="../../html/bootstrap_v3.3.5.min.js"></script>
                    <div>
                        <h3>
                            <span class="heading">Request Details:</span>
                        </h3>
                    </div>
                    <table style="width: 50%;" border="1">
                        <thead>
        """

        # constructing First table with test suite details
        html2 = ''
        for header_left,header_right in x.items():

            if header_left != "test_results":
                header_left = header_left.replace('_',' ')
                header_left = header_left.capitalize()
                html1 += '<tr>' \
                            '<td class="col-xs-2"><b>{0}</b></td>'\
                            '<td class="col-xs-2">{1}</td>'\
                          '</tr>'.format(header_left,header_right)

            # constructing test resport table starts here
            if header_left == "test_results":
                html2+='<table  style="width: 100%;" border="1"><tbody>'

                # creating table header
                html2+="<thead>"\
                            "<tr >"\
                                "<th class='col-xs-2'>QCID</th>"\
                                "<th class='col-xs-1'>Test Name</th>"\
                                "<th class='col-xs-4'>Test Description</th>"\
                                "<th class='col-xs-1'>Test Time</th>"\
                                "<th class='col-xs-1'>Result</th>"\
                                "<th class='col-xs-3'>Comments</th>"\
                            "</tr>"\
                        "</thead>"

                # generating row with test details
                for i in range(len(header_right)):
                    text_test = ''

                    if header_right[i].get('time',False) == False :
                        html2 += '<tr class="testrow">'\
                                    '<td class="col-xs-2"><b>{0}</b></td>'\
                                    '<td class="col-xs-1">'\
                                        '<a href = "{5}">{1}</a>'\
                                    '</td>'\
                                    '<td class="col-xs-4">{2}{6}</td>'\
                                    '<td class="col-xs-1">{3}</td>'\
                                    '<td class="col-xs-1">{4}</td>'\
                                '<td class="col-xs-3">'.format(header_right[i].get('QCID', ''),
                                                header_right[i].get('test_name', ''),
                                                re.sub('\n', '<br>', header_right[i].get('test_description', '')),
                                                '',
                                                format_result(header_right[i].get('Result', '')),
                                                '',
                                                format_params_tag(header_right[i].get('test_params', '')),
                                            )

                        for d in header_right[i]['test_comments']:
                            text_color = ''
                            if re.search('error', d.get('comment', ''), re.IGNORECASE):
                                text_color = 'red'


                            if d.get('link', ''):
                                if d.get('comment', ''):
                                    text = '<a target="_blank" class="{2}" href="{1}">{0}</a></br>'.format(re.sub('\n', '<br>', d.get('comment', '')), d.get('link', ''), text_color)
                                else:
                                    text = '<a target="_blank" href="{1}">{0}</a></br>'.format(os.path.basename(d.get('link', '')), d.get('link', ''))
                            else:
                                text = '<span class="{0}">{1}</span></br>'.format(text_color, re.sub('\n', '<br>', d.get('comment', '')))
                            html2 += text
                        html2 += "</td></tr>"

                    else:
                        html2 += '<tr class="testrow">'\
                                    '<td class="col-xs-2"><b>{0}</b></td>'\
                                    '<td class="col-xs-1">'\
                                        '<a href = "{5}">{1}</a>'\
                                    '</td>'\
                                    '<td class="col-xs-4">{2}{6}</td>'\
                                    '<td class="col-xs-1">{3}</td>'\
                                    '<td class="col-xs-1">{4}</td>'\
                                '<td class="col-xs-3">'.format(header_right[i].get('QCID', ''), header_right[i].get('test_name', ''),
                                                re.sub('\n', '<br>', header_right[i].get('test_description', '')),
                                                header_right[i].get('time', ''),
                                                format_result(header_right[i].get('Result', '')),
                                                header_right[i].get('log_link', ''),
                                                format_params_tag(header_right[i].get('test_params', '')),
                                            )
                        for d in header_right[i]['test_comments']:
                            text_color = ''
                            if re.search('error', d.get('comment', ''), re.IGNORECASE):
                                text_color = 'red'


                            if d.get('link', ''):
                                if d.get('comment', ''):
                                    text = '<a target="_blank" class="{2}" href="{1}">{0}</a></br>'.format(re.sub('\n', '<br>', d.get('comment', '')), d.get('link', ''), text_color)
                                else:
                                    text = '<a target="_blank" href="{1}">{0}</a></br>'.format(os.path.basename(d.get('link', '')), d.get('link', ''))
                            else:
                                text = '<span class="{0}">{1}</span></br>'.format(text_color, re.sub('\n', '<br>', d.get('comment', '')))
                            html2 += text
                        html2 += "</td></tr>"

                    # creating rows for test cases
                    for j in range(len(header_right[i]["test_cases"])):
                        text_case = ''

                        # if the test case result is pass
                        if header_right[i]["test_cases"][j].get('Result', None) == "Pass" :
                            html2 += '<tr class="collapsed caserow" data-toggle="collapse" data-target="#case'+str(i)+str(j)+'" aria-expanded="false" aria-controls="#case'+str(i)+str(j)+'">'\
                                        '<td class="col-xs-2 case_c1">{0}</td>'\
                                        '<td class="col-xs-1">'\
                                            '<a href = "{5}">{1}</a>'\
                                        '</td>'\
                                        '<td class="col-xs-4">{2}{6}</td>'\
                                        '<td class="col-xs-1">{3}</td>'\
                                        '<td class="col-xs-1" style="color:green;"><b>{4}</b></td>'\
                                    '<td class="col-xs-3">'.format(header_right[i]["test_cases"][j].get('QCID', ''),
                                                    header_right[i]["test_cases"][j].get('test_name', ''),
                                                    re.sub('\n', '<br>', header_right[i]["test_cases"][j].get('test_description', '')),
                                                    header_right[i]["test_cases"][j].get('time', ''),
                                                    header_right[i]["test_cases"][j].get('Result', ''),
                                                    header_right[i]["test_cases"][j].get('log_link', ''),
                                                    format_params_tag(header_right[i]["test_cases"][j].get('test_params', '')),
                                                )
                            for d in header_right[i]["test_cases"][j].get('test_comments', ''):
                                text_color = ''
                                if re.search('error', d.get('comment', ''), re.IGNORECASE):
                                    text_color = 'red'


                                if d.get('link', ''):
                                    if d.get('comment', ''):
                                        text = '<a target="_blank" class="{2}" href="{1}">{0}</a></br>'.format(re.sub('\n', '<br>', d.get('comment', '')), d.get('link', ''), text_color)
                                    else:
                                        text = '<a target="_blank" href="{1}">{0}</a></br>'.format(os.path.basename(d.get('link', '')), d.get('link', ''))
                                else:
                                    text = '<span class="{0}">{1}</span></br>'.format(text_color, re.sub('\n', '<br>', d.get('comment', '')))
                                html2 += text
                            html2 += '</td></tr><tbody class="collapse"'+ 'id="case'+str(i)+str(j)+'" data-parent="#accordion" aria-labelledby="heading'+str(i)+str(j)+'">'
                        else:

                            # if the test case result is fail
                            if header_right[i]["test_cases"][j].get('Result', None) == "Fail":

                                html2 += '<tr class="collapsed caserow" data-toggle="collapse" data-target="#case'+str(i)+str(j)+'" aria-expanded="false" aria-controls="#case'+str(i)+str(j)+'">'\
                                            '<td class="col-xs-2 case_c1">{0}</td>'\
                                            '<td class="col-xs-1">'\
                                                '<a href = "{5}">{1}</a>'\
                                            '</td>'\
                                            '<td class="col-xs-4">{2}{6}</td>'\
                                            '<td class="col-xs-1">{3}</td>'\
                                            '<td class="col-xs-1" style="color:red;"><b>{4}</b></td>'\
                                        '<td class="col-xs-3">'.format(header_right[i]["test_cases"][j].get('QCID', ''),
                                                        header_right[i]["test_cases"][j].get('test_name', ''),
                                                        re.sub('\n', '<br>', header_right[i]["test_cases"][j].get('test_description', '')),
                                                        header_right[i]["test_cases"][j].get('time', ''),
                                                        header_right[i]["test_cases"][j].get('Result', ''),
                                                        header_right[i]["test_cases"][j].get('log_link', ''),
                                                        format_params_tag(header_right[i]["test_cases"][j].get('test_params', '')),
                                                    )
                                for d in header_right[i]["test_cases"][j].get('test_comments', ''):
                                    text_color = ''
                                    if re.search('error', d.get('comment', ''), re.IGNORECASE):
                                        text_color = 'red'


                                    if d.get('link', ''):
                                        if d.get('comment', ''):
                                            text = '<a target="_blank" class="{2}" href="{1}">{0}</a></br>'.format(re.sub('\n', '<br>', d.get('comment', '')), d.get('link', ''), text_color)
                                        else:
                                            text = '<a target="_blank" href="{1}">{0}</a></br>'.format(os.path.basename(d.get('link', '')), d.get('link', ''))
                                    else:
                                        text = '<span class="{0}">{1}</span></br>'.format(text_color, re.sub('\n', '<br>', d.get('comment', '')))
                                    html2 += text
                                html2 += '</td></tr><tbody class="collapse"'+ 'id="case'+str(i)+str(j)+'" data-parent="#accordion" aria-labelledby="heading'+str(i)+str(j)+'">'

                            # if the result not comes under either pass or fail ( In case of Skipped )
                            else:
                                html2 += '<tr class="collapsed caserow" data-toggle="collapse" data-target="#case'+str(i)+str(j)+'" aria-expanded="false" aria-controls="#case'+str(i)+str(j)+'">'\
                                            '<td class="col-xs-2 case_c1">{0}</td>'\
                                            '<td class="col-xs-1"><a href = "{5}">{1}</a></td>'\
                                            '<td class="col-xs-4">{2}{6}</td>'\
                                            '<td class="col-xs-1">{3}</td>'\
                                            '<td class="col-xs-1" style="color:orange"></td>'\
                                        '<td class="col-xs-3">'.format(header_right[i]["test_cases"][j].get('QCID', ''),
                                                        header_right[i]["test_cases"][j].get('test_name', ''),
                                                        re.sub('\n', '<br>', header_right[i]["test_cases"][j].get('test_description', '')),
                                                        header_right[i]["test_cases"][j].get('time', ''),
                                                        header_right[i]["test_cases"][j].get('Result', ''),
                                                        header_right[i]["test_cases"][j].get('log_link', ''),
                                                        format_params_tag(header_right[i]["test_cases"][j].get('test_params', '')),
                                                    )
                                for d in header_right[i]["test_cases"][j].get('test_comments', ''):
                                    text_color = ''
                                    if re.search('error', d.get('comment', ''), re.IGNORECASE):
                                        text_color = 'red'


                                    if d.get('link', ''):
                                        if d.get('comment', ''):
                                            text = '<a target="_blank" class="{2}" href="{1}">{0}</a></br>'.format(re.sub('\n', '<br>', d.get('comment', '')), d.get('link', ''), text_color)
                                        else:
                                            text = '<a target="_blank" href="{1}">{0}</a></br>'.format(os.path.basename(d.get('link', '')), d.get('link', ''))
                                    else:
                                        text = '<span class="{0}">{1}</span></br>'.format(text_color, re.sub('\n', '<br>', d.get('comment', '')))
                                    html2 += text
                                html2 += '</td></tr><tbody class="collapse"'+ 'id="case'+str(i)+str(j)+'" data-parent="#accordion" aria-labelledby="heading'+str(i)+str(j)+'">'

                        # creating rows for case steps
                        for k in range(len(header_right[i]["test_cases"][j]["test_steps"])):

                            if k%2:
                                row_class = 'grey'
                            else:
                                row_class = ''

                            # if the step result is Pass
                            if header_right[i]["test_cases"][j]["test_steps"][k].get('grade', None) == "Pass":

                                html2 += '<tr class="'+row_class+'"'+'>'\
                                            '<td class="col-xs-2 step_c1">{0}</td>'\
                                            '<td class="col-xs-1">{1}</td>'\
                                            '<td class="col-xs-4">{2}{5}</td>'\
                                            '<td class="col-xs-1">{3}</td>'\
                                            '<td class="col-xs-1" style="color:green;"><b>{4}</b></td>'\
                                        '<td class="col-xs-3">'.format(header_right[i]["test_cases"][j]["test_steps"][k].get('QCID', ''),
                                                        header_right[i]["test_cases"][j]["test_steps"][k].get('test_name', ''),
                                                        re.sub('\n', '<br>', header_right[i]["test_cases"][j]["test_steps"][k].get('test_description', '')),
                                                        header_right[i]["test_cases"][j]["test_steps"][k].get('time', ''),
                                                        header_right[i]["test_cases"][j]["test_steps"][k].get('grade', ''),
                                                        format_params_tag(header_right[i]["test_cases"][j]["test_steps"][k].get('test_params', '')),
                                                    )
                                for d in header_right[i]["test_cases"][j]["test_steps"][k].get('test_comments', ''):
                                    text_color = ''
                                    if re.search('error', d.get('comment', ''), re.IGNORECASE):
                                        text_color = 'red'


                                    if d.get('link', ''):
                                        if d.get('comment', ''):
                                            text = '<a target="_blank" class="{2}" href="{1}">{0}</a></br>'.format(re.sub('\n', '<br>', d.get('comment', '')), d.get('link', ''), text_color)
                                        else:
                                            text = '<a target="_blank" href="{1}">{0}</a></br>'.format(os.path.basename(d.get('link', '')), d.get('link', ''))
                                    else:
                                        text = '<span class="{0}">{1}</span></br>'.format(text_color, re.sub('\n', '<br>', d.get('comment', '')))
                                    html2 += text
                                html2 += "</td></tr>"

                            # if the step result is Fail
                            else:
                                if header_right[i]["test_cases"][j]["test_steps"][k].get('grade', None) == "Fail":
                                    html2 += '<tr class="'+row_class+'"'+'>'\
                                                '<td class="col-xs-2 step_c1">{0}</td>'\
                                                '<td class="col-xs-1">{1}</td>'\
                                                '<td class="col-xs-4">{2}{5}</td>'\
                                                '<td class="col-xs-1" >{3}</td>'\
                                                '<td class="col-xs-1" style="color:red;"><b>{4}</b></td>'\
                                            '<td class="col-xs-3">'.format(header_right[i]["test_cases"][j]["test_steps"][k].get('QCID', ''),
                                                            header_right[i]["test_cases"][j]["test_steps"][k].get('test_name', ''),
                                                            re.sub('\n', '<br>', header_right[i]["test_cases"][j]["test_steps"][k].get('test_description', '')),
                                                            header_right[i]["test_cases"][j]["test_steps"][k].get('time', ''),
                                                            header_right[i]["test_cases"][j]["test_steps"][k].get('grade', ''),
                                                            format_params_tag(header_right[i]["test_cases"][j]["test_steps"][k].get('test_params', '')),
                                                        )
                                    for d in header_right[i]["test_cases"][j]["test_steps"][k].get('test_comments', ''):
                                        text_color = ''
                                        if re.search('error', d.get('comment', ''), re.IGNORECASE):
                                            text_color = 'red'


                                        if d.get('link', ''):
                                            if d.get('comment', ''):
                                                text = '<a target="_blank" class="{2}" href="{1}">{0}</a></br>'.format(re.sub('\n', '<br>', d.get('comment', '')), d.get('link', ''), text_color)
                                            else:
                                                text = '<a target="_blank" href="{1}">{0}</a></br>'.format(os.path.basename(d.get('link', '')), d.get('link', ''))
                                        else:
                                            text = '<span class="{0}">{1}</span></br>'.format(text_color, re.sub('\n', '<br>', d.get('comment', '')))
                                        html2 += text
                                    html2 += "</td></tr>"

                                # if the step result does not comes under either Pass or Fail ( In case of Skipped )
                                else:
                                    html2 += '<tr class="'+row_class+'"'+'>'\
                                                '<td class="col-xs-2 step_c1">{0}</td>'\
                                                '<td class="col-xs-1">{1}</td>'\
                                                '<td class="col-xs-4">{2}{5}</td>'\
                                                '<td class="col-xs-1" >{3}</td>'\
                                                '<td class="col-xs-1" style="color:orange;"><b>Skipped</b></td>'\
                                            '<td class="col-xs-3">'.format(header_right[i]["test_cases"][j]["test_steps"][k].get('QCID', ''),
                                                            header_right[i]["test_cases"][j]["test_steps"][k].get('test_name', ''),
                                                            re.sub('\n', '<br>', header_right[i]["test_cases"][j]["test_steps"][k].get('test_description', '')),
                                                            header_right[i]["test_cases"][j]["test_steps"][k].get('time', ''),
                                                            header_right[i]["test_cases"][j]["test_steps"][k].get('grade', ''),
                                                            format_params_tag(header_right[i]["test_cases"][j]["test_steps"][k].get('test_params', '')),
                                                        )
                                    for d in header_right[i]["test_cases"][j]["test_steps"][k].get('test_comments', ''):
                                        text_color = ''
                                        if re.search('error', d.get('comment', ''), re.IGNORECASE):
                                            text_color = 'red'


                                        if d.get('link', ''):
                                            if d.get('comment', ''):
                                                text = '<a target="_blank" class="{2}" href="{1}">{0}</a></br>'.format(re.sub('\n', '<br>', d.get('comment', '')), d.get('link', ''), text_color)
                                            else:
                                                text = '<a target="_blank" href="{1}">{0}</a></br>'.format(os.path.basename(d.get('link', '')), d.get('link', ''))
                                        else:
                                            text = '<span class="{0}">{1}</span></br>'.format(text_color, re.sub('\n', '<br>', d.get('comment', '')))
                                        html2 += text
                                    html2 += "</td></tr>"
                        html2 += '</tbody>'

                # Closing the test report table
                html2+="</tbody></table><div>&nbsp;</div>"

        # completing the html by adding all the components
        html1 +="</thead></table><div>&nbsp;</div></div>"
        html = html1+html2

        # writing the html content to a file and creating the result.html
        with open(html_file,'w') as f:
            f.write(html)
        return html_file


def gen_case_dir_path(text):
    case_name = re.sub(r'[\W_]+', '_', text)
    case_dir = os.path.join(output_dir, case_name)
    if not os.path.exists(case_dir):
        os.mkdir(case_dir)
    return case_dir


# this method is to generate seperate json for each cases from parent json(result.json)
def generate_case_json():
    json_file = os.path.join(output_dir, "result.json")
    fp = open(json_file, 'r')
    json_value = fp.read()
    raw_data = json.loads(json_value)
    fp.close()
    d = {}
    for key, value in raw_data.items():
        if type(value) in (str, int, float):
            d[key] = value
    for test in raw_data.get("test_results", None):
       for case in test.get("test_cases", None):
            file_dir = gen_case_dir_path(case.get("test_name", 'un_named_case'))
            child_json_file = os.path.join(file_dir, "result.json")
            f = open(child_json_file, "w+")
            d.update(case)
            f.write(json.dumps(d))
            f.close()
            #print("JSON generated @ %s" % child_json_file)
