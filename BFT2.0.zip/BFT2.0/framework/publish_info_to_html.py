'''Method defination for Framework library'''
__author__ = 'Intel Corporation'
__copyright__ = 'Copyright 2019, Intel Corporation'
__version__ = '0.0.1'
__maintainer__ = 'Mirafra'
__email__ = 'framework@mirafra.com'
__status__ = 'Development'

from parameters_to_json import publish_comments_text_publish, publish_description, publish_qcid, publish_params


class publish_html(object):

    def get_test_details(self, test_name=None, test_type=None):
        self.test_name = test_name
        self.test_type = test_type

    def publish_to_html(self, qcid=None, test_desc=None, param_desc=None, comment=None, log_link=None):
        self.qcid = qcid
        self.test_desc = test_desc
        self.param_desc = param_desc
        self.comment = comment
        self.log_link = log_link

        ### Publish QC ID to HTML report
        if self.qcid is not None:
            publish_qcid([

                ('test_name', self.test_name),
                ('QCID', self.qcid),
                ('test_type', self.test_type)

            ])

        ### Publish test description to HTML report
        if self.test_desc is not None:
            publish_description([

                    ('test_name', self.test_name),
                    ('test_description', self.test_desc),
                    ('test_type', self.test_type)

            ])

        ### Publish param description to HTML report
        if self.param_desc is not None:
            publish_params([
                    ('test_name', self.test_name),
                    ('test_params', self.param_desc),
                    ('test_type', self.test_type)

            ])

        ### Publish Comments text with log link to HTML report
        if self.comment is not None and self.log_link is self.log_link is None:
          publish_comments_text_publish([
                        ('test_name', self.test_name),
                        ('test_comments', self.comment),
                        ('test_comments_link', ""),
                        ('test_type', self.test_type)
            ])
        elif self.comment is None and self.log_link is not None:
            publish_comments_text_publish([
                        ('test_name', self.test_name),
                        ('test_comments', "log_link"),
                        ('test_comments_link', self.log_link),
                        ('test_type', self.test_type)
            ])
        elif self.comment is not None and self.log_link is not None:
            publish_comments_text_publish([
                        ('test_name', self.test_name),
                        ('test_comments', self.comment),
                        ('test_comments_link', self.log_link),
                        ('test_type', self.test_type)
            ])
        else:
            pass

# class object variable used for publish information to HTML report
publish_cls_obj = publish_html()
# this class variable is used to publish user defined information
publish_html =  publish_cls_obj.publish_to_html
# this class variable to get the test_name and test_type information to publish HTML results.
get_test_details = publish_cls_obj.get_test_details

if  __name__ == "__main__":
    obj = publish_html()
    obj.get_test_details(test_name="sample", test_type="test")
    obj.publish_to_html(qc_id="TC_1")
    obj.publish_to_html(test_desc="Test description")
    obj.publish_to_html(comment="Test comments")


