import json
from collections import OrderedDict
import copy
import os
from config import output_dir
import datetime
from json_parser import json_to_html, generate_case_json
from datetime import timedelta
import threading

total_tests_passed = 0
total_tests_failed = 0
total_test_cases_executed = 0
case_result = 'Fail'

json_lock = threading.Lock()

def lock_control(func):
    def wrapper(args):
        global json_lock
        json_lock.acquire()
        func(args)
        json_lock.release()
    return wrapper

# Method to setup test suit
@lock_control
def log_suit_setup_info(args):
    json_file = os.path.join(output_dir, "result.json")
    if not os.path.exists(json_file):
        x = OrderedDict()
    else:
        file_obj , x = file_open()
        file_close(file_obj)
    for key in args:
        x[key[0]] = key[1]
    file_obj_to_write = file_open_to_write_json(x)
    file_close(file_obj_to_write)
    create_html()


# Method to setup new test
@lock_control
def log_class_setup_info(args):
    test_results_list = []
    ordered_dict = OrderedDict()
    for i in args:
        ordered_dict[i[0]]=i[1]
    test_results_list.append(ordered_dict)
    table(test_results_list,"Test")


# Method to setup new test case
@lock_control
def log_test_setup_info(args):
    test_results_list = []
    ordered_dict = OrderedDict()
    for i in args:
        ordered_dict[i[0]]=i[1]
    test_results_list.append(ordered_dict)
    table(test_results_list,"Case")

# Method to update test case teardown info
@lock_control
def log_test_teardown_info(args):
    global case_result
    global total_tests_passed
    global total_tests_failed
    global total_test_cases_executed
    file_obj , x = file_open()
    file_close(file_obj)
    if args[0][0] == "test_name":
        test_name = args[0][1].split('.')[0]
        test_case_name = args[0][1].split('.')[0]+'.'+args[0][1].split('.')[1]
        for i in x["test_results"]:
            if i["test_name"] == test_name:
                for j in i["test_cases"]:
                    if j["test_name"] == test_case_name:
                        l = []
                        start_time = datetime.datetime.strptime(j["time_started"],'%H:%M:%S')
                        end_time= datetime.datetime.strptime(args[1][1],'%H:%M:%S')
                        j["time"] = time_calculator(start_time,end_time)
                        j["Result"] = case_result
                        j["log_link"]  = args[2][1]
                        for r in range(len(j["test_steps"])):
                            l.append(j["test_steps"][r]['grade'])
                        total_test_cases_executed = total_test_cases_executed+1
                        if ('Fail' in l) or ('Skipped' in l) or (('None' in l) or ('' in l) or (len(l) == 0)):
                            j['Result'] = 'Fail'
                            total_tests_failed = total_tests_failed + 1
                        else:
                            j['Result'] = 'Pass'
                            total_tests_passed = total_tests_passed+1
        x["total_tests_passed"] = total_tests_passed
        x["total_tests_failed"] = total_tests_failed
        x["total_test_cases_executed"] = total_test_cases_executed
    file_obj_to_write = file_open_to_write_json(x)
    file_close(file_obj_to_write)
    create_html()
    generate_case_json()


# Method to update test teardown info
@lock_control
def log_class_teardown_info(args):
    file_obj , x = file_open()
    file_close(file_obj)
    if args[0][0] == "test_name":
        test_name = args[0][1]
        for i in x["test_results"]:
            if i["test_name"] == test_name:
                start_time = datetime.datetime.strptime(i["time_started"],'%H:%M:%S')
                end_time= datetime.datetime.strptime(args[1][1],'%H:%M:%S')
                i["time"] = time_calculator(start_time,end_time)
                i["log_link"] = args[2][1]
    file_obj_to_write = file_open_to_write_json(x)
    file_close(file_obj_to_write)
    create_html()


# Method to update test suit teardown info
@lock_control
def log_suit_teardown_info(args):
    file_obj , x = file_open()
    file_close(file_obj)
    start_time_in_12_hours = datetime.datetime.strptime(x["test_start_time"], '%H:%M:%S').strftime('%I:%M:%S %p')
    start_time = datetime.datetime.strptime(x["test_start_time"], '%H:%M:%S')
    end_time = datetime.datetime.strptime(args[0][1], '%H:%M:%S')
    if args[0][0] == "test_end_time":
        end_time_in_12_hours = datetime.datetime.strptime(args[0][1], '%H:%M:%S').strftime('%I:%M:%S %p')
        x["test_end_time"] = args[0][1]
    x["total_execution_time"] = time_calculator(start_time,end_time)
    file_obj_to_write = file_open_to_write_json(x)
    file_close(file_obj_to_write)
    create_html()

def time_calculator(start_time,end_time):
    complete_execution_timedelta = end_time-start_time
    if complete_execution_timedelta.days < 0:
        complete_execution_timedelta = timedelta(days=0,
                seconds=complete_execution_timedelta.seconds, microseconds=complete_execution_timedelta.microseconds)
    time_seconds = complete_execution_timedelta.total_seconds()
    day = time_seconds // (24 * 3600)
    time_seconds = time_seconds % (24 * 3600)
    hour = time_seconds // 3600
    time_seconds %= 3600
    minutes = time_seconds // 60
    time_seconds %= 60
    seconds = time_seconds
    if day:
        return str(int(day))+"D:"+str(int(hour))+":"+str(int(minutes))+":"+str(int(seconds))
    return str(int(hour))+"H:"+str(int(minutes))+"M:"+str(int(seconds))+"S"


# Method to setup new case steps
@lock_control
def log_test_case_steps_info(args):
    test_results_list = []
    ordered_dict = OrderedDict()
    for i in args:
        ordered_dict[i[0]]=i[1]
    test_results_list.append(ordered_dict)
    table(test_results_list,"Teststep")

def table(args,row_name):
    file_obj , x = file_open()
    file_close(file_obj)
    global case_result
    if row_name == "Test" and len(x.get("test_results",[])) == 0:
        x["test_results"] = []
    for i in args:
        if i["test_type"] == "Test":

            i["test_cases"] = []
            x["test_results"].append(i)
        elif row_name == "Case" :
            for_case(x,i)
        elif row_name == "Teststep" :
            for_step(x,i)
        for key,value in i.items():
            pass
    file_obj_to_write = file_open_to_write_json(x)
    file_close(file_obj_to_write)
    create_html()

def for_case(x,list_to_append):
    test_case_parent_row_name = list_to_append["test_name"].split('.')[0]
    for number,tests in enumerate(x["test_results"]):
        if tests["test_name"] == test_case_parent_row_name:
            list_to_append["test_steps"]=[]
            x["test_results"][number]["test_cases"].append(list_to_append)

def for_step(x,list_to_append):
    test_step_parent_row_name = list_to_append["test_name"].split('.')[0]+'.'+list_to_append["test_name"].split('.')[1]
    test_case_parent_row_name = list_to_append["test_name"].split('.')[0]
    for number,tests in enumerate(x["test_results"]):
        if tests["test_name"] == test_case_parent_row_name:
            for number1,tests in enumerate(x["test_results"][number]["test_cases"]):
                if tests["test_name"] == test_step_parent_row_name:
                    start_time = datetime.datetime.strptime(list_to_append["time_started"], '%H:%M:%S')
                    end_time = datetime.datetime.strptime(list_to_append["time_ended"], '%H:%M:%S')
                    list_to_append["time"] = time_calculator(start_time,end_time)
                    # del list_to_append["time_started"]
                    #del list_to_append["time_ended"]
                    x["test_results"][number]["test_cases"][number1]["test_steps"].append(list_to_append)

def log_test_exception_handle_info(test_name,test_case_name,test_case_skip):
    file_obj , x = file_open()
    file_close(file_obj)
    for number,i in enumerate(x["test_results"]):
        if i["test_name"] == test_name[1]:
            for number1, j in enumerate(x["test_results"][number]["test_cases"]):
                if j["test_name"] == test_case_name[1]:
                   j["Result"]  = "Skip"
    file_obj_to_write = file_open_to_write_json(x)
    file_close(file_obj_to_write)
    create_html()

def file_open():
    json_file = os.path.join(output_dir, "result.json")
    f = open(json_file)
    x = OrderedDict()
    x = json.loads(f.read(), object_pairs_hook=OrderedDict)
    return f,x

def file_open_to_write_json(x):
    json_file = os.path.join(output_dir, "result.json")
    f = open(json_file,"w")
    f.write(json.dumps(x))
    return f

def file_close(file_obj):
    file_obj.close()

def create_html():
    json_to_html()

@lock_control
def log_hyperlink_info(args):
    file_obj , x = file_open()
    file_close(file_obj)
    x["log_link"] = args[1]
    file_obj_to_write = file_open_to_write_json(x)
    file_close(file_obj_to_write)

@lock_control
def publish_description(args):
    file_obj , x = file_open()
    file_close(file_obj)
    if args[2][1] == 'test':
        test_name = args[0][1]
        for i in x["test_results"]:
            if i["test_name"] == test_name:
                i['test_description'] = i.get('test_description', '')+ '\n'+args[1][1]
    if args[2][1] == 'case':
        test_case_name = args[0][1]
        test_name = test_case_name.split('.')[0]
        for i in x["test_results"]:
            if i["test_name"] == test_name:
                for j in i['test_cases']:
                    if j['test_name'] == test_case_name:
                        j['test_description'] = j.get('test_description', '') + '\n'+ args[1][1]
    if args[2][1] == 'step':
        name = args[0][1]
        test_step_name = name
        test_case_name = name.split('.')[0]+'.'+name.split('.')[1]
        test_name = name.split('.')[0]
        for i in x["test_results"]:
            if i["test_name"] == test_name:
                #print(test_name)
                for j in i['test_cases']:
                    if j['test_name'] == test_case_name:
                        #print(test_case_name)
                        for k in j['test_steps']:
                            if k['test_name'] == test_step_name:
                                #print(test_step_name)
                                k['test_description'] = k.get('test_description', '') + '\n '+args[1][1]
    file_obj_to_write = file_open_to_write_json(x)
    file_close(file_obj_to_write)
    create_html()

@lock_control
def publish_qcid(args):
    file_obj , x = file_open()
    file_close(file_obj)
    if args[2][1] == 'test':
        test_name = args[0][1]
        for i in x["test_results"]:
            if i["test_name"] == test_name:
                i['QCID'] = args[1][1]
    if args[2][1] == 'case':
        test_case_name = args[0][1]
        test_name = test_case_name.split('.')[0]
        for i in x["test_results"]:
            if i["test_name"] == test_name:
                for j in i['test_cases']:
                    if j['test_name'] == test_case_name:
                        j['QCID'] = args[1][1]
    if args[2][1] == 'step':
        name = args[0][1]
        test_step_name = name
        test_case_name = name.split('.')[0]+'.'+name.split('.')[1]
        test_name = name.split('.')[0]
        for i in x["test_results"]:
            if i["test_name"] == test_name:
                for j in i['test_cases']:
                    if j['test_name'] == test_case_name:
                        for k in j['test_steps']:
                            if k['test_name'] == test_step_name:
                                k['QCID'] = args[1][1]
    file_obj_to_write = file_open_to_write_json(x)
    file_close(file_obj_to_write)
    create_html()


@lock_control
def publish_result(args):
    global total_tests_passed
    global total_tests_failed
    file_obj , x = file_open()
    file_close(file_obj)
    if args[2][1] == 'test':
        test_name = args[0][1]
        for i in x["test_results"]:
            if i["test_name"] == test_name:
                i['Result'] = args[1][1]
    if args[2][1] == 'case':
        test_case_name = args[0][1]
        test_name = test_case_name.split('.')[0]
        for i in x["test_results"]:
            if i["test_name"] == test_name:
                for j in i['test_cases']:
                    if j['test_name'] == test_case_name:
                        j['Result'] = args[1][1]
    if args[2][1] == 'step':
        name = args[0][1]
        test_step_name = name
        test_case_name = name.split('.')[0]+'.'+name.split('.')[1]
        test_name = name.split('.')[0]
        for i in x["test_results"]:
            if i["test_name"] == test_name:
                for j in i['test_cases']:
                    if j['test_name'] == test_case_name:
                        for k in j['test_steps']:
                            if k['test_name'] == test_step_name:
                                k['grade'] = args[1][1]
    if args[1][1] == "Fail":
        print("total_test_cases_executed: %s" % x["total_test_cases_executed"])
        print("total_tests_passed: %s" % x['total_tests_passed'])
        print("total_tests_failed: %s" % x['total_tests_failed'] )
        if x["total_test_cases_executed"] != x['total_tests_failed']:
            x['total_tests_passed'] = x['total_tests_passed'] - 1
            total_tests_passed = total_tests_passed - 1
            x['total_tests_failed'] = x['total_tests_failed'] + 1
            total_tests_failed = total_tests_failed + 1
    else:
        pass
    file_obj_to_write = file_open_to_write_json(x)
    file_close(file_obj_to_write)
    create_html()


@lock_control
def publish_result_and_endtime(args):
    file_obj , x = file_open()
    file_close(file_obj)
    if args[3][1] == 'test':
        test_name = args[0][1]
        for i in x["test_results"]:
            if i["test_name"] == test_name:
                i['Result'] = args[1][1]
                start_time = datetime.datetime.strptime(i["time_started"],'%H:%M:%S')
                end_time= datetime.datetime.strptime(args[2][1],'%H:%M:%S')
                i["time"] = time_calculator(start_time,end_time)
    if args[3][1] == 'case':
        test_case_name = args[0][1]
        test_name = test_case_name.split('.')[0]
        for i in x["test_results"]:
            if i["test_name"] == test_name:
                for j in i['test_cases']:
                    if j['test_name'] == test_case_name:
                        j['Result'] = args[1][1]
                        start_time = datetime.datetime.strptime(j["time_started"],'%H:%M:%S')
                        end_time= datetime.datetime.strptime(args[2][1],'%H:%M:%S')
                        j["time"] = time_calculator(start_time,end_time)
    if args[3][1] == 'step':
        name = args[0][1]
        test_step_name = name
        test_case_name = name.split('.')[0]+'.'+name.split('.')[1]
        test_name = name.split('.')[0]
        for i in x["test_results"]:
            if i["test_name"] == test_name:
                for j in i['test_cases']:
                    if j['test_name'] == test_case_name:
                        for k in j['test_steps']:
                            if k['test_name'] == test_step_name:
                                k['grade'] = args[1][1]
                                start_time = datetime.datetime.strptime(k["time_started"],'%H:%M:%S')
                                end_time= datetime.datetime.strptime(args[2][1],'%H:%M:%S')
                                k["time"] = time_calculator(start_time,end_time)
    file_obj_to_write = file_open_to_write_json(x)
    file_close(file_obj_to_write)
    create_html()

@lock_control
def publish_params(args):
    file_obj , x = file_open()
    file_close(file_obj)
    if args[2][1] == 'test':
        test_name = args[0][1]
        for i in x["test_results"]:
            if i["test_name"] == test_name:
                params = i.get('test_params', {})
                params.update(args[1][1])
                i['test_params'] = params
    if args[2][1] == 'case':
        test_case_name = args[0][1]
        test_name = test_case_name.split('.')[0]
        for i in x["test_results"]:
            if i["test_name"] == test_name:
                for j in i['test_cases']:
                    if j['test_name'] == test_case_name:
                        params = j.get('test_params', {})
                        params.update(args[1][1])
                        j['test_params'] = params
    if args[2][1] == 'step':
        name = args[0][1]
        test_step_name = name
        test_case_name = name.split('.')[0]+'.'+name.split('.')[1]
        test_name = name.split('.')[0]
        for i in x["test_results"]:
            if i["test_name"] == test_name:
                for j in i['test_cases']:
                    if j['test_name'] == test_case_name:
                        for k in j['test_steps']:
                            if k['test_name'] == test_step_name:
                                params = k.get('test_params', {})
                                params.update(args[1][1])
                                k['test_params'] = params
    file_obj_to_write = file_open_to_write_json(x)
    file_close(file_obj_to_write)
    create_html()

@lock_control
def publish_to_csv(args):
    file_obj , x = file_open()
    file_close(file_obj)
    if args[2][1] == 'test':
        test_name = args[0][1]
        for i in x["test_results"]:
            if i["test_name"] == test_name:
                params = i.get('user_defined', {})
                params.update(args[1][1])
                i['user_defined'] = params
    if args[2][1] == 'case':
        test_case_name = args[0][1]
        test_name = test_case_name.split('.')[0]
        for i in x["test_results"]:
            if i["test_name"] == test_name:
                for j in i['test_cases']:
                    if j['test_name'] == test_case_name:
                        params = j.get('user_defined', {})
                        params.update(args[1][1])
                        j['user_defined'] = params
    if args[2][1] == 'step':
        name = args[0][1]
        test_step_name = name
        test_case_name = name.split('.')[0]+'.'+name.split('.')[1]
        test_name = name.split('.')[0]
        for i in x["test_results"]:
            if i["test_name"] == test_name:
                for j in i['test_cases']:
                    if j['test_name'] == test_case_name:
                        for k in j['test_steps']:
                            if k['test_name'] == test_step_name:
                                params = k.get('user_defined', {})
                                params.update(args[1][1])
                                k['user_defined'] = params
    file_obj_to_write = file_open_to_write_json(x)
    file_close(file_obj_to_write)
    create_html()

@lock_control
def publish_comments_text_publish(args):
    file_obj , x = file_open()
    file_close(file_obj)
    d = {}
    if args[3][1] == 'test':
        test_name = args[0][1]
        for i in x["test_results"]:
            if i["test_name"] == test_name:
                if args[2][1]:
                    comment = {'comment':args[1][1], "link":'file:///' + args[2][1]}
                else:
                    comment = {'comment':args[1][1], "link":''}
                existing_test_comments = i.get('test_comments', None)
                if existing_test_comments and type(existing_test_comments) == list:
                    existing_test_comments.append(comment)
                    i['test_comments'] = existing_test_comments
                else:
                    i['test_comments'] = [comment]
    if args[3][1] == 'case':
        test_case_name = args[0][1]
        test_name = test_case_name.split('.')[0]
        for i in x["test_results"]:
            if i["test_name"] == test_name:
                for j in i['test_cases']:
                    if j['test_name'] == test_case_name:
                        if args[2][1]:
                            comment = {'comment':args[1][1], "link":'file:///' + args[2][1]}
                        else:
                            comment = {'comment':args[1][1], "link":''}
                        existing_test_comments = j.get('test_comments', None)
                        if existing_test_comments and type(existing_test_comments) == list:
                            existing_test_comments.append(comment)
                            j['test_comments'] = existing_test_comments
                        else:
                            j['test_comments'] = [comment]
    if args[3][1] == 'step':
        name = args[0][1]
        test_step_name = name
        test_case_name = name.split('.')[0]+'.'+name.split('.')[1]
        test_name = name.split('.')[0]
        l = []
        for i in x["test_results"]:
            if i["test_name"] == test_name:
                for j in i['test_cases']:
                    if j['test_name'] == test_case_name:
                        for k in j['test_steps']:
                            if k['test_name'] == test_step_name:
                                if args[2][1]:
                                    comment = {'comment':args[1][1], "link":'file:///' + args[2][1]}
                                else:
                                    comment = {'comment':args[1][1], "link":''}
                                existing_test_comments = k.get('test_comments', None)
                                if existing_test_comments and type(existing_test_comments) == list:
                                    existing_test_comments.append(comment)
                                    k['test_comments'] = existing_test_comments
                                else:
                                    k['test_comments'] = [comment]
    file_obj_to_write = file_open_to_write_json(x)
    file_close(file_obj_to_write)
    create_html()
