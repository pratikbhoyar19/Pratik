from datetime import datetime

from parameters_to_json import (log_suit_setup_info, log_class_setup_info, log_test_setup_info, log_test_case_steps_info,
                                log_suit_teardown_info, log_test_teardown_info,log_class_teardown_info,
                                log_test_exception_handle_info, log_hyperlink_info,publish_description,
                                publish_comments_text_publish, create_html, publish_qcid, publish_params,
                                publish_to_csv, publish_result_and_endtime)
from json_to_csv import json_to_csv, generate_child_csv
from json_parser import json_to_html, generate_case_json

generate_child_csv()
json_to_csv()

log_suit_setup_info([

   ('submitter', 'Durgesh') ,
   ('image', 'OpenWRT'),
   ('platform','GRX550'),
   ("test_start_time", "10:10:10"),# time_string = time.strftime(" %H:%M:%S,", t)
   ('code_version','ANY'),
   ('DUT_platform','ANY')

])

log_class_setup_info([

    ("test_comments", []),
    ("test_type","Test"),
    ("test_name","test"),
    ("time_started", "13:10:15")

])

publish_description([

    ('test_name','test'),
    ('test_description','test description publish for test'),
    ('test_type','test')

])

publish_qcid([

    ('test_name','test'),
    ('QCID','test qcid'),
    ('test_type','test')

])


publish_params([

    ('test_name','test'),
    ('test_params',{'key1': 'value1', 'key2': 'value2', 'key3': 'value3'}),
    ('test_type','test')

])


publish_to_csv([

    ('test_name','test'),
    ('test_params',{'key1': 'value1', 'key2': 'value2', 'key3': 'value3'}),
    ('test_type','test')

])

publish_comments_text_publish([

    ('test_name','test'),
    ('test_comments','comment_1 for test1'),
    ('test_comments_link',''),
    ('test_type','test')

])

log_test_setup_info([

    ("QCID","sample_id"),
    ("test_comments", []),
    ("test_description", "Test description case"),
    ("test_type","Case"),
    ("test_name","test.case1"),
    ("time_started", "20:00:00")
])

publish_description([

    ('test_name','test.case1'),
    ('test_description','test description publish for test.case1'),
    ('test_type','case')

])

publish_qcid([

    ('test_name','test.case1'),
    ('QCID','test.case1 qcid'),
    ('test_type','case')

])

publish_params([

    ('test_name','test.case1'),
    ('test_params',{'key1': 'value1', 'key2': 'value2', 'key3': 'value3'}),
    ('test_type','case')

])

publish_to_csv([

    ('test_name','test.case1'),
    ('test_params',{'key1': 'value1', 'key2': 'value2', 'key3': 'value3'}),
    ('test_type','case')

])

publish_comments_text_publish([

    ('test_name','test.case1'),
    ('test_comments','comment_1 for test.case1'),
    ('test_comments_link','home/mirafra/rishi/intel/results/result.json'),
    ('test_type','case')
])

log_test_case_steps_info([

    ("grade","Pass"),
    ("QCID","sample_id"),
    ("test_type","Teststep"),
    ("test_comments", []),
    ("test_name","test.case1.step1"),
    ("time_started", "23:00:00"),    # time_string = datetime.strftime(" %H:%M:%S", t)
    ("time_ended", "05:00:00"),      # time_string = datetime.strftime(" %H:%M:%S", t)
    ("test_description", "Test description Step"),
    ("log_link","file:///C:/Users/blrcom/Downloads/step")

])

publish_description([

    ('test_name','test.case1.step1'),
    ('test_description','test description publish for test.case1.step1'),
    ('test_type','step')

])

publish_qcid([

    ('test_name','test.case1.step1'),
    ('QCID','test.case1.step1 qcid'),
    ('test_type','step')

])


publish_params([

    ('test_name','test.case1.step1'),
    ('test_params',{'key1': 'value1', 'key2': 'value2', 'key3': 'value3'}),
    ('test_type','step')

])


publish_to_csv([

    ('test_name','test.case1.step1'),
    ('test_params',{'key1': 'value1', 'key2': 'value2', 'key3': 'value3'}),
    ('test_type','step')

])


publish_comments_text_publish([

    ('test_name','test.case1.step1'),
    ('test_comments','comment1 publish for test.case1.step1'),
    ('test_comments_link','home/mirafra/rishi/intel/results/result.json'),
    ('test_type','step')

])

log_test_teardown_info([

    ("test_name","test.case1"),
    #("time_started", "23:00:00"),# time_string = datetime.strftime(" %H:%M:%S", t)
    ("time_ended", "05:00:00"),# time_string = datetime.strftime(" %H:%M:%S", t)
    ("log_link","file:///C:/Users/blrcom/Downloads/case")

])

##5
### arguments must be sent in same order
log_class_teardown_info([

    ("test_name","test"),
    #("time_started", "13:10:10"),# time_string = datetime.strftime(" %H:%M:%S", t)

    ("time_ended","13:12:12" ),# time_string = datetime.strftime(" %H:%M:%S", t)# time_string = time.strftime(" %H:%M:%S , %m/%d/%Y,", t)
    ("log_link","file:///C:/Users/blrcom/Downloads/")

])


publish_result_and_endtime([
    ('test_name','test.case1.step1'),
    ('result', "Fail"),
    ('time_ended', "06:00:00"),
    ('test_type','step')
])


# json_to_csv()
# create_html()

# generate_case_json()
