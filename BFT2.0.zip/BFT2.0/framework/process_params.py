'''Method defination for Framework library'''
__author__ = 'Intel Corporation'
__copyright__ = 'Copyright 2019, Intel Corporation'
__version__ = '0.0.1'
__maintainer__ = 'Mirafra'
__email__ = 'framework@mirafra.com'
__status__ = 'Development'


import re
import config
def process_setupclass(obj):
    '''To process group level parameters and store in class dict "grp_level_params"
       Arguments: obj       - This argument is class object to class'''
    #Initialize the flag to call process_setup function
    config.processed_setup_para = 0
    try:
        from parseTestArgs import *
        testParaList = eval(obj.__name__ + '_list'+'[' + str(obj.i) + ']')
        obj.testId = testParaList[0]
        tname_lst = obj.testId.split("_")
        tname_lst.insert(0, config.TEST_SUITE)
        obj.testClassId  = "_".join(tname_lst)
        obj.testClassId = re.search('(.*)_case.*',obj.testClassId, re.IGNORECASE).group(1)
        testParaLen = len(testParaList)
        if testParaLen > 1 :
            for j in range(1,testParaLen):
                if "sc_" in testParaList[j]:
                    exec('obj.' + testParaList[j][3:])
                    temp=testParaList[j][3:].split("=")
                    obj.grp_level_params[temp[0]]=temp[1].replace("'", "")
        return True
    except:
        return False

def process_setup(obj,cls_obj):
    '''To process case level parameters and store in class dict "case_level_params"
       Arguments: obj       - This argument is self object to class
                  cls_obj   - This argument is class object to class '''
    try:
        from parseTestArgs import *
        testParaList = eval(obj.__class__.__name__ + '_list'+'[' + str(cls_obj.i) + ']')
        cls_obj.i = cls_obj.i + 1
        # Setting the flag once process_setup function called
        config.processed_setup_para = 1
        obj.testId = testParaList[0]
        try:
            obj.caseId =  re.match(r'.*(case[0-9]*)', obj.testId).group(1)
            obj.testClassId =  obj.testClassId + "_" + obj.caseId
        except:
            obj.testClassId =  obj.testClassId
        testParaLen = len(testParaList)

        if testParaLen > 1 :
            for j in range(1,testParaLen):
                if "sc_" not in testParaList[j]:
                    exec('obj.' + testParaList[j])
                    temp=testParaList[j].split("=")
                    obj.case_level_params[temp[0]]=temp[1].replace("'", "")
        return True
    except:
        return False

def process_output(output):
    """This proc will process output dictionary, received after thread execution"""
    print output
    try:
        op=output[0]
        if op == 'Pass' or op == 'True':
            return True
        elif op == 'Fail' or op == 'Error':
            return False
    except:
        print("Issue with processing output")
        return False
