import sys
import json
import csv
import os
from config import output_dir
from arguments import convert_unicode_to_str
#
from collections import OrderedDict
from json_parser import gen_case_dir_path

def json_to_csv():
#
    json_file = os.path.join(output_dir, "result.json")
    fp = open(json_file, 'r')
    json_value = fp.read()
    raw_data = json.loads(json_value)
    fp.close()

    csv_file = os.path.join(output_dir, "result.csv")

    f = csv.writer(open(csv_file, "wb+"))

    f.writerow(convert_unicode_to_str([ \
                "Submitter",
                "Image",
                "platform",
                "Test Start Time",
                "Code Version",
                "DUT Platform",
                "Total tests Passed",
                "Total Tests Failed",
                "Total test cases executed",
                "Test end time",
                "Total execution time",
                "Test QCID",
                "Test Name",
                "Test Description",
                "Test time",
                "Test log link",
                "Test Started Time",
                "Test Comments",
                "Case QCID",
                "Case Name",
                "Case Description",
                "Case Time",
                "Case Log Link",
                "Case Started Time",
                "Case Comments",
                "Case Result",
                "Step QCID",
                "Step Name",
                "Step Description",
                "Step Time",
                "Step Log Link",
                "Step Started Time",
                "Step Comments",
                "Step Result",
                ]))

    for test in raw_data.get("test_results", None):
        for case in test.get("test_cases", None):
            for step in case.get("test_steps"):
                f.writerow(convert_unicode_to_str([
                            raw_data.get("submitter", ''),
                            raw_data.get("image", ''),
                            raw_data.get("platform", ''),
                            raw_data.get("test_start_time", ''),
                            raw_data.get("code_version", ''),
                            raw_data.get("DUT_platform", ''),
                            raw_data.get("total_tests_passed", ''),
                            raw_data.get("total_tests_failed", ''),
                            raw_data.get("total_test_cases_executed", ''),
                            raw_data.get("test_end_time", ''),
                            raw_data.get("total_execution_time", ''),
                            test.get("QCID", ''),
                            test.get("test_name", ''),
                            test.get("test_description", ''),
                            test.get("time", ''),
                            test.get("log_link", ''),
                            test.get("time_started", ''),
                            test.get("test_comments", ''),
                            case.get("QCID", ''),
                            case.get("test_name", ''),
                            case.get("test_description", ''),
                            case.get("time", ''),
                            case.get("log_link", ''),
                            case.get("time_started", ''),
                            case.get("test_comments", ''),
                            case.get("Result", ''),
                            step.get("QCID", ''),
                            step.get("test_name", ''),
                            step.get("test_description", ''),
                            step.get("time", ''),
                            step.get("log_link", ''),
                            step.get("time_started", ''),
                            step.get("test_comments", ''),
                            step.get("grade", ''),
                            ]))
    return csv_file

def generate_csv(value, new_line=False):
    csv_file = os.path.join(output_dir, "result.csv")
    if not os.path.exists(csv_file):
        f = open(csv_file, "w+")
    else:
        f = open(csv_file, "a")
        f.write(',')
    if new_line:
        f.write('\n')
    f.write(value)
    f.close()


def generate_child_csv():
    json_file = os.path.join(output_dir, "result.json")
    fp = open(json_file, 'r')
    json_value = fp.read()
    raw_data = json.loads(json_value)
    fp.close()
    data = {}
    for key, value in raw_data.items():
        if type(value) in (str, int, float):
            data[key] = value
    for test in raw_data.get("test_results", None):
        if not os.path.exists(output_dir):
            os.mkdir(output_dir)
        for case in test.get("test_cases", None):
            file_dir = gen_case_dir_path(case.get("test_name", 'un_named_case'))
            child_json_file = os.path.join(file_dir, "result.csv")
            f = open(child_json_file, "wb+")
            data.update(case)

            f = csv.writer(open(child_json_file, "wb+"))

            keys = [
                    "Submitter",
                    "Image",
                    "platform",
                    "Test Start Time",
                    "Code Version",
                    "DUT Platform",
                    "Total tests Passed",
                    "Total Tests Failed",
                    "Total test cases executed",
                    "Test end time",
                    "Total execution time",
                    "Case QCID",
                    "Case Name",
                    "Case Description",
                    "Case Time",
                    "Case Log Link",
                    "Case Started Time",
                    "Case Comments",
                    "Case Result",
                    ]

            values = [
                        raw_data.get("submitter", ''),
                        raw_data.get("image", ''),
                        raw_data.get("platform", ''),
                        raw_data.get("test_start_time", ''),
                        raw_data.get("code_version", ''),
                        raw_data.get("DUT_platform", ''),
                        raw_data.get("total_tests_passed", ''),
                        raw_data.get("total_tests_failed", ''),
                        raw_data.get("total_test_cases_executed", ''),
                        raw_data.get("test_end_time", ''),
                        raw_data.get("total_execution_time", ''),
                        data.get("QCID", ''),
                        data.get("test_name", ''),
                        data.get("test_description", ''),
                        data.get("time", ''),
                        data.get("log_link", ''),
                        data.get("time_started", ''),
                        data.get("test_comments", ''),
                        data.get("Result", ''),
                    ]

            for key, value in data.get('user_defined', {}).items():
                keys.append(key)
                values.append(value)


            for number, step in enumerate(data.get("test_steps")):
                step_keys = [
                        "Step_" + str(number+1) + " QCID",
                        "Step_" + str(number+1) + " Name",
                        "Step_" + str(number+1) + " Description",
                        "Step_" + str(number+1) + " Time",
                        "Step_" + str(number+1) + " Log Link",
                        "Step_" + str(number+1) + " Started Time",
                        "Step_" + str(number+1) + " Comments",
                        "Step_" + str(number+1) + " Result",
                    ]
                keys.extend(step_keys)


                step_values = [
                            step.get("QCID", ''),
                            step.get("test_name", ''),
                            step.get("test_description", ''),
                            step.get("time", ''),
                            step.get("log_link", ''),
                            step.get("time_started", ''),
                            step.get("test_comments", ''),
                            step.get("grade", ''),
                        ]
                values.extend(step_values)
            data_to_csv = convert_unicode_to_str([keys, values])

            for item in zip(*data_to_csv):
                f.writerow(item)
            #print("CSV generated @ %s" % child_json_file)
