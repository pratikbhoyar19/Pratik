#!/usr/bin/env python
__author__ = "Intel Corporation"
__copyright__ = "Copyright 2019, Intel Corporation"
__version__ = "0.0.1"
__maintainer__ = "Mirafra"
__email__ = "framework@mirafra.com"
__status__ = "Development"

'''Libary file having defination for parallel execution of functions

This file can also be imported as a module and contains the following
functions:
    * parallel() - Add and execute the function as thread.
    * end_parallel() - Wait till execution of all threads is done.
'''
###########################################################
import datetime
import exceptions
import re

from threading import Thread
from log_creator import loggerObject as logger

thread_list = []  #@started threads are stored
thread_id=1

class ThreadWithReturnValue(Thread):
    '''
    Class Name  : ThreadWithReturnValue
    Description : Instantiate a thread and create a function name
    '''

    def __init__(self, group=None, name=None, target=None, device=None,
                 *args, **kwargs):
        self.target = target
        self.device = device
        self._return = None
        #@ Create the function name as '<object>.<func>'
        #func_name = target.__self__.name + '.' + target.__name__
        func_name= name
        Thread.__init__(self, group, target, func_name, kwargs['args'][0:], kwargs['kwargs'])

    def run(self):
        if self._Thread__target is not None:
            try:
                self._return = self._Thread__target(*self._Thread__args,
                                                **self._Thread__kwargs)
            except Exception as e:
                self._return = e

    def join(self, timeout):
        Thread.join(self, timeout)
        return [self.name, self._return]


def parallel_exec(func):
    '''
    Description       : Start the thread
    Input parameters  : Function name
    Output parameters : None
    '''

    global thread_list

    #Set the device name to correct value    
    device = None
    if hasattr(func, '__self__') is True:
        if hasattr(func.__self__, 'dname') is True:
            device = func.__self__.dname
 
    def wrapper(*args, **kwargs):
        global thread_id
        Fname = func.__name__
        if device is None:
            logger.dumpLog("Thread initiated", func_name=Fname, thread_id = str(thread_id))
            thd_val = ThreadWithReturnValue(target=func, timeout=None, name=Fname,args=args, kwargs=kwargs)
        else:
            logger.dumpLog("Thread initiated", device = device, func_name=Fname, thread_id = str(thread_id))
            Fname = func.__self__.dname + '.' + func.__name__
            #Set the thread id to <device>.logger.thread
            exec ('from devices import *;' + func.__self__.dname + '.logger.thread = ' + str(thread_id)) in {}
            #Execute the function as thread
            thd_val = ThreadWithReturnValue(target=func, timeout=None, name=Fname, device=device, args=args, kwargs=kwargs)

        thread_id=thread_id+1
        thd_val.start()
        thread_list.append(thd_val)
    return wrapper


def end_parallel(timeout=300):
    '''
    Description       : Wait for all threads to finish
    Input parameters  : None
    Output parameters : function name with return value in dictionary format along its thread value
    '''
    from devices import *

    global thread_list, thread_id
    thread_val={}
    result ='True'
    for proc in thread_list:
        ret_val=proc.join(timeout)

        # Kill the thread if its still active after timeout
        if proc.isAlive():
            proc._Thread__stop()
            ret_val[1]='Thread Incomplete'

        #Create new key if the function name is same
        func_name = ret_val[0]
        i = 1
        while True:
            if thread_val.has_key(func_name) is False:
                break
            func_name = ret_val[0] + '_' + str(i+1)
            i = i +1

        #Create the entry in dict
        thread_val[func_name] = ret_val[1]
        if type(ret_val[1]) is exceptions.TypeError:
            result = 'Fail'
        elif len(re.findall('(?i)fail|error|false|None', str(ret_val[1])))>=1:
            result = 'Fail'

        #Set <device>.logger.thread to None at the end of thread execution
        if proc.device is not None:
            exec (proc.device + '.logger.thread = None')

    logger.dumpLog("Parallel execution terminated")

    # Revert the thread list and value to orignal
    thread_id=1
    thread_list=[]

    return result, thread_val
