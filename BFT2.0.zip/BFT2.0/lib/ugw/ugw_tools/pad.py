

class Pad:
    """This class will provide pad related Apis"""


    def __init__(self):
        pass

    def config_update(self, os_handle, session_handle, prompt, device_dict=None):
        self.os = os_handle
        self.session = session_handle
        self.prompt = prompt
        self.dict = device_dict
