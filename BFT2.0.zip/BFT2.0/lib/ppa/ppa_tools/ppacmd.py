

class Ppacmd:
    """This class will provide ppacmd related Apis"""


    def __init__(self):
        pass

    def config_update(self, os_handle, session_handle, prompt, device_dict=None):
        self.os = os_handle
        self.session = session_handle
        self.prompt = prompt
        self.dict = device_dict

    def test_func(self):
        print("method inside in this class %s" % self.__class__.__name__)


if __name__ == "__main__":
    obj = Ppacmd()
    obj.test_func()
