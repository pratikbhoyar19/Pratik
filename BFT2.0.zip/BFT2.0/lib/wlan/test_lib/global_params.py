# Copyright(c) 2018 Intel Corporation
# All rights reserved.
#
# This file is distributed under the Clear BSD license.
# The full text can be found in LICENSE in the root directory.

from globalVariables import *

radio2g_params = {
    "wlan_iface": tsv_wlan_iface,
    "wlan_ifname": tsv_wlan_ifname,
    "wlan_beacon_interval": tsv_wlan_beacon_interval,
    "wlan_radio_disable": tsv_wlan_radio_disable,
    "wlan_channel": tsv_wlan_channel,
    "wlan_ssid": tsv_wlan_ssid,
    "wlan_enc": tsv_wlan_enc,
    "wlan_key": tsv_wlan_key,
    "wlan_wpa_grpkey": tsv_wlan_wpa_grpkey,
    "wlan_wps_config": tsv_wlan_wps_config,
    "wlan_wps_pin": tsv_wlan_wps_pin,
    "wlan_wps_device_name": tsv_wlan_wps_device_name,
    "wlan_wpa_pushbutton": tsv_wlan_wpa_pushbutton,
    "wlan_wmm": tsv_wlan_wmm,
    "wlan_isolate": tsv_wlan_isolate,
    "wlan_wds": tsv_wlan_wds,
    "wlan_hidden": tsv_wlan_hidden,
    "wlan_maxassoc_sta": tsv_wlan_maxassoc_sta,
    "wlan_iface_disable": tsv_wlan_iface_disable,
    "wlan_key1": "",
    "wlan_macpolicy": tsv_macpolicy_disable,
    "wlan_freq": tsv_wlan_2g_freq,
    "wlan_cdb": False,
    "wlan_mac_addr": tsv_wlan_mac_addr,
    "wlan_con_mode": tsv_wlan_explicit_method,
    "wlan_mode" : tsv_ap_mode,
    "wlan_bssid" : ""
}

radio5g_params = {
    "wlan_iface": tsv_wlan5g_iface,
    "wlan_ifname": tsv_wlan5g_ifname,
    "wlan_beacon_interval": tsv_wlan5g_beacon_interval,
    "wlan_radio_disable": tsv_wlan5g_radio_disable,
    "wlan_channel": tsv_wlan5g_channel,
    "wlan_ssid": tsv_wlan5g_ssid,
    "wlan_enc": tsv_wlan5g_enc,
    "wlan_key": tsv_wlan5g_key,
    "wlan_wpa_grpkey": tsv_wlan5g_wpa_grpkey,
    "wlan_wps_config": tsv_wlan5g_wps_config,
    "wlan_wps_pin": tsv_wlan5g_wps_pin,
    "wlan_wps_device_name": tsv_wlan5g_wps_device_name,
    "wlan_wpa_pushbutton": tsv_wlan5g_wpa_pushbutton,
    "wlan_wmm": tsv_wlan5g_wmm,
    "wlan_isolate": tsv_wlan5g_isolate,
    "wlan_wds": tsv_wlan5g_wds,
    "wlan_hidden": tsv_wlan5g_hidden,
    "wlan_maxassoc_sta": tsv_wlan5g_maxassoc_sta,
    "wlan_iface_disable": tsv_wlan5g_iface_disable,
    "wlan_key1": "",
    "wlan_macpolicy": tsv_macpolicy_disable,
    "wlan_freq": tsv_wlan_5g_freq,
    "wlan_cdb": False,
    "wlan_mac_addr": tsv_wlan5g_mac_addr,
    "wlan_con_mode": tsv_wlan_explicit_method,
    "wlan_mode" : tsv_ap_mode,
    "wlan_bssid" : ""
}

wlan_key_dict = {
    "psk2+aes": tsv_wlan_wpa2_enc_key,
    "psk+tkip": tsv_wlan_wpa_enc_key,
    "psk-mixed+tkip+aes": tsv_wlan_wpa_wpa2_enc_key,
    "wep64": tsv_wlan_wep64_enc_key,
    "wep128": tsv_wlan_wep128_enc_key
}

def wifi_case_level_changes_ap(obj, radio_params, ap_radio=tsv_ap_radio2g):
    '''To apply case level changes to ap, and will be called by setUp
       Arguments: obj       - This argument is self object to  class
                  radio_params - This argument is dictionary having changes
                  ap_radio - This argument is radio information'''
    try:
        for o_key, o_val in obj.case_level_params.iteritems():
            for r_key, r_val in obj.radio_params.iteritems():
                if o_key == r_key:
                    obj.radio_params[r_key] = obj.case_level_params[r_key]

        #self.configure_ap(radio_params, ap_radio=ap_radio, caller_api ="setUp")
        return True
    except:
        return False

def wifi_grp_level_changes_ap(obj, radio_params, ap_radio=tsv_ap_radio2g):
    '''To apply group level changes to ap, and will be called by setUpClass
       Arguments: obj       - This argument is self object to  class
                  radio_params - This argument is dictionary having changes
                  ap_radio - This argument is radio information'''
    try:
        for o_key, o_val in obj.grp_level_params.iteritems():
            for r_key, r_val in obj.radio_params.iteritems():
                if o_key == r_key:
                    obj.radio_params[r_key] = obj.grp_level_params[r_key]
        return True
    except:
        return False

