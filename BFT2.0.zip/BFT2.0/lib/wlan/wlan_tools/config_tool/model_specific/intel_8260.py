

class Intel8260:


    def __init__(self):
        pass

    def set_channel(self):
        print("channel is set for intel8260 chipset, wlan tools")
