import os
from globalVariables import *
from lib.wlan.test_lib.global_params import *
import time


class Netsh:
    """This class will provide netsh related Apis"""

    def __init__(self):
        pass

    def stop_wlan_tools(self, wlan_iface=tsv_wlan_host_iface):
        '''To kill the wifi supplicant in system
           Arguments: system     - This argument is the object where to kill supplicant, default object is wlan
                      wlan_iface - This argument is the iface name, default name is tsv_wlan_host_iface'''
        self.session.send_line("netsh wlan delete profile name=*")
        try:
            self.session.recv_line(self.prompt, timeout=30)
            return True
        except:
            return False

    def configure_wlan_stas(self,
            radio_params,
            ap_radio=tsv_ap_radio2g,
            wlan_iface=tsv_wlan_host_iface):
        '''To Push the wifi configurations from the ssid_name.xml file to the cliet'''
        ssid_f_name="%s" %radio_params['wlan_ssid'] + ".xml"
        self.os.xml_creator(ssid_name=radio_params['wlan_ssid'],ens_cap=radio_params['wlan_enc'])
        xml_path=self.dict['xml_remote_path'] + "\\%s" %ssid_f_name
        test_path=os.path.dirname(os.path.abspath("bft")) + "/" + ssid_f_name
        if not self.os.copy_from(local_path=xml_path, remote_path=test_path):
            return False
        self.session.send_line("netsh interface set interface \"{}\" Disable" .format(wlan_iface))
        self.session.recv_line(self.prompt, timeout=30)
        time.sleep(5)
        self.session.send_line("netsh interface set interface \"{}\" Enable" .format(wlan_iface))
        self.session.recv_line(self.prompt, timeout=30)
        time.sleep(5)
        self.session.send_line("netsh wlan delete profile name=*")
        self.session.recv_line(self.prompt, timeout=30)
        fail_c = 0
        for i in range(0,2):
            fail_c += 1
            self.session.send_line("netsh wlan add profile \"%s\" interface=\"%s\"" %(xml_path, wlan_iface))
            try:
                self.session.recv_line("is added on interface %s" %wlan_iface,timeout=30)
                break
            except BaseException:
                self.session.send_line("net stop wlansvc")
                self.session.send_line("net start wlansvc")
        if fail_c >=2:
            return False
        return True


    def connect_ap(self, radio_params, wlan_iface=tsv_wlan_host_iface):
        fail_c=0
        try:
            self.session.send_line('netsh wlan connect name=%s interface=\"%s\"' %(radio_params['wlan_ssid'], wlan_iface))
            for i in range(0,3):
                try:
                    self.session.recv_line("Connection request was completed successfully",timeout=30)
                    break
                except:
                    print("connection chekcing retry")
                    fail_c +=1
                    continue
            if fail_c >=3:
                return False

            return True
        except:
            print("windows connect ap")
            return False

    def verify_assoc(
            self,
            ap_mac_addr,
            wlan_iface=tsv_wlan_host_iface):
        '''To get wifi AP MAC addr
           Arguments: ap_mac_addr   - This argument is the AP MAC addr
                      wlan_iface    - This argument is the wlan iface name, default name is tsv_wlan_host_iface
                      system        - This argument is the object where to get AP MAC addr, default object is wlan'''
        fail_counter=0
        for i in range(0,3):
            self.session.send_line('netsh wlan show interface')
            try:
                self.session.recv_line('BSSID\s+:\s+([0-9a-z:]+)',timeout=50)
                rcv_mac_addr=self.session.match(1)
                print("ap_mac_addr.lower=%s , type=%s" %(ap_mac_addr.lower(),type(ap_mac_addr.lower())))
                if rcv_mac_addr.lower() == ap_mac_addr.lower():
                    self.logger.dumpLog("windows assoc successful")
                    break
            except Exception as e:
                time.sleep(tsv_timeout_5)
                fail_counter+=1
                continue
        if fail_counter >= 3:
            return False
        else:
            return True

    def assign_dhcp_ip(self, wlan_iface=tsv_wlan_host_iface):
        return True


    def wifi_get_lan_ip(self, eth_iface=tsv_lan_host_eth_interface):
        '''To get the wifi lan IP addr
           Arguments: system    - This argument is the object where to get LAN IP, default object is lan
                      eth_iface - This argument is the iface name, default name is tsv_lan_host_eth_interface'''
        return self.wifi_get_wlan_ip(wlan_iface=eth_iface)


    def wifi_get_wlan_ip(self, wlan_iface=tsv_wlan_host_iface):
        '''To get the wifi wlan IP addr
           Arguments: system     - This argument is the object where to get WLAN IP, default object is wlan
                      wlan_iface - This argument is the iface name, default name is tsv_wlan_host_iface'''
        return self.os.get_interface_ipaddr(wlan_iface)


    def deassoc_ap(self, wlan_iface=tsv_wlan_host_iface):
        '''To delete the wifi sta configs in system
           Arguments: system          - This argument is the object where configurations has to delete, default object is wlan
                      wlan_host_iface - This argument is the wlan host iface name, default name is tsv_wlan_host_iface'''
        self.session.send_line('netsh wlan delete profile name=*')
        self.session.recv_line(self.prompt, timeout=30)
        return True

    def test_func(self):
        self.logger.dumpLog("method inside in this class %s" % self.__class__.__name__)

    def test_netsh(self):
        print("netsh is tested, wlan tools")

if __name__ == "__main__":
    obj = Netsh()
    obj.test_func()
