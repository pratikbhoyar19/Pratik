from globalVariables import *
from lib.wlan.test_lib.global_params import *
import time


class Wpasupplicant:
    """This class will provide Wpa-supplicant related Apis"""


    def __init__(self):
        pass


    def connect_ap(self, radio_params, wlan_iface=tsv_wlan_host_iface):
        try:
            self.session.send_line("wpa_cli -i%s enable_network 0" % wlan_iface)
            self.session.recv_line(self.prompt, timeout=int(tsv_timeout_20))
            self.session.send_line("wpa_cli -i%s status" % wlan_iface)
            self.session.recv_line(self.prompt, timeout=int(tsv_timeout_20))
            return True
        except:
            print("linux conenct ap")
            return False

    def config_sta_wpa(
            self,
            radio_params,
            wlan_host_iface=tsv_wlan_host_iface):
        '''To configure the wifi with encryption mechanism WPA/WPA2/mix mode
           Arguments: radio_parms     - This argument is a dictionary with radio parameters which has to configure
                      system          - This argument is the object where configurations has to do, default object is wlan
                      wlan_host_iface - This argument is the wlan host iface name, default name is tsv_wlan_host_iface'''
        self.logger.dumpLog("config_sta_wpa")
        self.session.set_window_size(200, 200)
        if not self.config_sta_gen(
                radio_params,
                wlan_host_iface=wlan_host_iface):
            return False
        try:
            self.session.send_line("wpa_cli -i%s add_network" % wlan_host_iface)
            self.session.recv_line(self.prompt, timeout=int(tsv_timeout_20))
            self.session.send_line(
                "wpa_cli -i%s set_network 0 ssid \'\"%s\"\'" %
                (wlan_host_iface, radio_params['wlan_ssid']))
            self.session.recv_line(self.prompt, timeout=int(tsv_timeout_20))
            self.session.send_line(
                "wpa_cli -i%s set_network 0 psk \'\"%s\"\'" %
                (wlan_host_iface, radio_params['wlan_key']))
            self.session.recv_line(self.prompt, timeout=int(tsv_timeout_20))
            self.session.send_line("wpa_cli -i%s set_network 0 scan_freq \'%s\'" %(wlan_host_iface, radio_params['wlan_channel']))
            self.session.recv_line(self.prompt, timeout=int(tsv_timeout_20))
            self.session.send_line("wpa_cli -i%s set_network 0 scan_ssid \'1\'" %wlan_host_iface)
            self.session.recv_line(self.prompt, timeout=int(tsv_timeout_20))
            #self.session.send_line("wpa_cli -i%s enable_network 0" % wlan_host_iface)
            #self.session.recv_line(self.prompt, timeout=int(tsv_timeout_20))
            return True
        except BaseException:
            return False


    def config_sta_open(
            self,
            radio_params,
            wlan_host_iface=tsv_wlan_host_iface):
        '''To configure the wifi with encryption mechanism open mode
           Arguments: radio_parms     - This argument is a dictionary with radio parameters which has to configure
                      system          - This argument is the object where configurations has to do, default object is wlan
                      wlan_host_iface - This argument is the wlan host iface name, default name is tsv_wlan_host_iface'''
        self.session.set_window_size(200, 200)
        if not self.config_sta_gen(
                radio_params,
                wlan_host_iface=wlan_host_iface):
            return False
        try:
            self.session.send_line("wpa_cli -i%s scan" % wlan_host_iface)
            self.session.recv_line(self.prompt, timeout=int(tsv_timeout_20))
            self.session.send_line("wpa_cli -i%s add_network" % wlan_host_iface)
            self.session.recv_line(self.prompt, timeout=int(tsv_timeout_20))
            self.session.send_line(
                "wpa_cli -i%s set_network 0 ssid \'\"%s\"\'" %
                (wlan_host_iface, radio_params['wlan_ssid']))
            self.session.recv_line(self.prompt, timeout=int(tsv_timeout_20))
            self.session.send_line(
                "wpa_cli -i%s set_network 0 key_mgmt NONE" %
                (wlan_host_iface))
            self.session.recv_line(self.prompt, timeout=int(tsv_timeout_20))
            self.session.send_line("wpa_cli -i%s set_network 0 scan_freq \'%s\'" %(wlan_host_iface, radio_params['wlan_channel']))
            self.session.recv_line(self.prompt, timeout=int(tsv_timeout_20))
            #self.session.send_line("wpa_cli -i%s enable_network 0" % wlan_host_iface)
            #self.session.recv_line(self.prompt, timeout=int(tsv_timeout_20))
            #self.session.send_line("wpa_cli -i%s status" % wlan_host_iface)
            #self.session.recv_line(self.prompt, timeout=int(tsv_timeout_20))
            return True
        except BaseException:
            return False


    def config_sta_security(
            self,
            radio_params,
            wlan_host_iface=tsv_wlan_host_iface):
        '''To update the wifi sta configs in system
           Arguments: radio_parms     - This argument is a dictionary with radio parameters which has to configure
                      system          - This argument is the object where configurations has to do, default object is wlan
                      wlan_host_iface - This argument is the wlan host iface name, default name is tsv_wlan_host_iface'''
        try:
            self.session.send_line("ifconfig %s down" % wlan_host_iface)
            self.session.recv_line(self.prompt, timeout=int(tsv_timeout_30))
            self.session.send_line("ifconfig %s up" % wlan_host_iface)
            self.session.recv_line(self.prompt, timeout=int(tsv_timeout_30))
            self.session.send_line("dhclient -r %s" % (wlan_host_iface))
            self.session.recv_line(self.prompt, timeout=int(tsv_timeout_20))
        except BaseException:
            return False

        self.logger.dumpLog("config_sta_security")
        if(radio_params['wlan_con_mode'] == tsv_wlan_explicit_method):
            enc_type = radio_params['wlan_enc']
            if(enc_type == tsv_wlan_wpa2_enc_type or enc_type == tsv_wlan_wpa_enc_type or enc_type == tsv_wlan_wpa_wpa2_enc_type):
                if not self.config_sta_wpa(
                        radio_params,
                        wlan_host_iface=wlan_host_iface):
                    return False
            elif(enc_type == tsv_wlan_wep64_enc_type or enc_type == tsv_wlan_wep128_enc_type):
                iwobj = Iwconfig()
                if not iwobj.config_sta_wep(
                        radio_params,
                        wlan_host_iface=wlan_host_iface):
                    return False
            elif(enc_type == tsv_wlan_open_enc_type):
                if not self.config_sta_open(
                        radio_params,
                        wlan_host_iface=wlan_host_iface):
                    return False
            else:
                self.logger.dumpLog("this is type of enc is not supported")
                return False
        return True


    def configure_wlan_stas(
            self,
            radio_params,
            ap_radio=tsv_ap_radio2g,
            wlan_iface=tsv_wlan_host_iface):
        '''To add the wifi sta configs in system
           Arguments: radio_parms     - This argument is a dictionary with radio parameters which has to configure
                      system          - This argument is the object where configurations has to do, default object is wlan
                      ap_radio        - This argument is the type of accesspoint, default type is tsv_ap_radio2g
                      wlan_host_iface - This argument is the wlan host iface name, default name is tsv_wlan_host_iface'''
        self.logger.dumpLog("configure_wlan_stas")
        if not self.config_sta_security(
                radio_params,
                wlan_host_iface=wlan_iface):
            return False
        return True


    def start_deassoc(self, wlan_host_iface=tsv_wlan_host_iface):
        '''To delete the wifi sta configs in system
           Arguments: system          - This argument is the object where configurations has to delete, default object is wlan
                      wlan_host_iface - This argument is the wlan host iface name, default name is tsv_wlan_host_iface'''
        self.stop_wlan_tools(wlan_iface=wlan_host_iface)
        try:
            self.session.send_line("ifconfig %s down" % wlan_host_iface)
            self.session.recv_line(self.prompt, timeout=int(tsv_timeout_30))
            self.session.send_line("ifconfig %s up" % wlan_host_iface)
            self.session.recv_line(self.prompt, timeout=int(tsv_timeout_30))
            return True
        except BaseException:
            return False


    def deassoc_ap(self, wlan_iface=tsv_wlan_host_iface):
        '''To delete the wifi sta configs in system
           Arguments: system          - This argument is the object where configurations has to delete, default object is wlan
                      wlan_host_iface - This argument is the wlan host iface name, default name is tsv_wlan_host_iface'''

        if not self.start_deassoc(wlan_host_iface=wlan_iface):
            return False
        return True


    def stop_wlan_tools(self, wlan_iface=tsv_wlan_host_iface):
        '''To kill the wifi supplicant in system
           Arguments: system     - This argument is the object where to kill supplicant, default object is wlan
                      wlan_iface - This argument is the iface name, default name is tsv_wlan_host_iface'''
        try:
            self.session.send_control('c')
            self.session.send_line("killall -9 wpa_supplicant")
            self.session.recv_line(self.prompt, timeout=int(tsv_timeout_20))
            time.sleep(int(tsv_timeout_5))
            return True
        except BaseException:
            return False


    def config_sta_gen(
            self,
            radio_params,
            wlan_host_iface=tsv_wlan_host_iface):
        '''To configure the wpa supplicant in WSTA
           Arguments: radio_parms     - This argument is a dictionary with radio parameters which has to configure
                      system          - This argument is the object where configurations has to do, default object is wlan
                      wlan_host_iface - This argument is the wlan host iface name, default name is tsv_wlan_host_iface'''
        self.logger.dumpLog("config_sta_gen")
        try:
            self.session.set_window_size(200, 200)
            self.stop_wlan_tools(wlan_iface=wlan_host_iface)

            self.session.send_line("wpa_supplicant -g/var/run/wpa_supplicant-global -B")
            self.session.recv_line(self.prompt, timeout=int(tsv_timeout_30))
            self.session.send_line(
                "wpa_cli -g/var/run/wpa_supplicant-global interface_add %s %s %s" %
                (wlan_host_iface, "\"\"", "nl80211 /var/run/wpa_supplicant"))
            #print("wpa_cli -g/var/run/wpa_supplicant-global interface_add %s %s %s" %(wlan_host_iface, "\"\"", "nl80211 /var/run/wpa_supplicant"))
            self.session.recv_line(self.prompt, timeout=int(tsv_timeout_30))
            return True
        except BaseException:
            return False

    def config_sta_wep(
            self,
            radio_params,
            wlan_host_iface=tsv_wlan_host_iface):
        '''To configure the wifi with encryption mechanism WEP mode
           Arguments: radio_parms     - This argument is a dictionary with radio parameters which has to configure
                      system          - This argument is the object where configurations has to do, default object is wlan
                      wlan_host_iface - This argument is the wlan host iface name, default name is tsv_wlan_host_iface'''
        self.session.set_window_size(200, 200)
        self.stop_wlan_tools(wlan_iface=wlan_host_iface)
        try:
            self.session.send_line(
                "iwconfig %s essid %s key %s" %
                (wlan_host_iface,
                 radio_params['wlan_ssid'],
                 radio_params['wlan_key1']))
            return True
        except BaseException:
            return False


    def verify_assoc(
            self,
            ap_mac_addr,
            wlan_iface=tsv_wlan_host_iface):
        '''To get wifi AP MAC addr
           Arguments: ap_mac_addr   - This argument is the AP MAC addr
                      wlan_iface    - This argument is the wlan iface name, default name is tsv_wlan_host_iface
                      system        - This argument is the object where to get AP MAC addr, default object is wlan'''
        fail_counter = 0
        for i in range(0,3):
            try:
                self.session.send_control('c')
                self.session.send_line("iwconfig %s" % wlan_iface)
                self.session.recv_line("Access Point:\s+([0-9A-Za-z:]+)",timeout=50)
                mac_addr_rcv = self.session.match(1)
                if mac_addr_rcv  == ap_mac_addr:
                    break
            except BaseException as err:
                fail_counter = fail_counter + 1
                time.sleep(tsv_timeout_5)
                continue
        if fail_counter >=3:
            self.logger.dumpLog("fail counter %d" %fail_counter)
            self.logger.dumpLog("linux assoc failed")
            return False
        else:
            self.logger.dumpLog("linux assoc success")
            return True


    def test_func2(self):
        print("method inside in this class %s" % self.__class__.__name__)

    def test_wpa(self):
        print("wpa tested")


if __name__ == "__main__":
    obj = Wpasupplicant()
    obj.test_func2()

