

class Iw:
    """This class will provide iw related Apis"""

    def __init__(self):
        pass

    def test_func4(self):
        print("method inside in this class %s" % self.__class__.__name__)

    def test_iw(self):
        print("iw tested")

if __name__ == "__main__":
    obj = Iw()
    obj.test_func4()

