from globalVariables import *
from lib.wlan.test_lib.global_params import *
import time


class Iwconfig:
    """This class will provide iwconfig related Apis"""


    def __init__(self):
        pass

    def config_sta_wep(
            self,
            radio_params,
            wlan_host_iface=tsv_wlan_host_iface):
        '''To configure the wifi with encryption mechanism WEP mode
           Arguments: radio_parms     - This argument is a dictionary with radio parameters which has to configure
                      system          - This argument is the object where configurations has to do, default object is wlan
                      wlan_host_iface - This argument is the wlan host iface name, default name is tsv_wlan_host_iface'''
        self.session.set_window_size(200, 200)
        self.stop_wlan_tools(wlan_iface=wlan_host_iface)
        try:
            self.session.send_line(
                "iwconfig %s essid %s key %s" %
                (wlan_host_iface,
                 radio_params['wlan_ssid'],
                 radio_params['wlan_key1']))
            return True
        except BaseException:
            return False


    def verify_assoc(
            self,
            ap_mac_addr,
            wlan_iface=tsv_wlan_host_iface):
        '''To get wifi AP MAC addr
           Arguments: ap_mac_addr   - This argument is the AP MAC addr
                      wlan_iface    - This argument is the wlan iface name, default name is tsv_wlan_host_iface
                      system        - This argument is the object where to get AP MAC addr, default object is wlan'''
        fail_counter = 0
        for i in range(0,3):
            try:
                self.session.send_control('c')
                self.session.send_line("iwconfig %s" % wlan_iface)
                self.session.recv_line("Access Point:\s+([0-9A-Za-z:]+)",timeout=50)
                a=self.session.match(1)
                #print(a)
                if a == ap_mac_addr:
                    break
            except BaseException:
                fail_counter = fail_counter + 1
                time.sleep(tsv_timeout_5)
                continue
        if fail_counter >=3:
            print("fail counter %d" %fail_counter)
            print("linux assoc failed")
            return False
        else:
            print("linux assoc success")
            return True


    def test_func2(self):
        print("method inside in this class %s" % self.__class__.__name__)


    def test_iwconfig(self):
        print("iwconfig tested")

if __name__ == "__main__":
    obj = Iwconfig()
    obj.test_func2()
