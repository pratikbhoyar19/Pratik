import os
import inspect
import config_tool
import config_tool.model_specific 
from config_tool import *
from config_tool.model_specific import *
from log_creator import loggerObject as logger


def tool_method_builder(cls):
    def __init__(self, class_list=None):
        #calling init functions of all parent classes
        for c_obj in list(class_list.split(",")):
            for ele in inspect.getmembers(eval(c_obj)):
                if "__init__" in ele:
                    eval(c_obj).__init__(self)

    __init__.__name__ = "__init__"
    setattr(cls,__init__.__name__,__init__)

    def config_update(self, os, session, prompt, device_dict=None,
                      dname=None, logger=logger):
        self.os = os
        self.session = session
        self.prompt = prompt
        self.dict = device_dict
        self.dname = dname
        self.logger = logger

    config_update.__name__ = "config_update"
    setattr(cls,config_update.__name__,config_update)


def tool_cmd(tool_name="",model_specific_name=""):
    tool_class_list = tool_list_builder(tool_name, model_specific_name)
    exec ('class ToolCmdHolder(' + tool_class_list + '): pass')
    #This dynamic class is formed with multiple inheritance, Hence Lib writter should not use
    #same attribute names accross classes
    tool_method_builder(ToolCmdHolder)
    return ToolCmdHolder(class_list=tool_class_list)

def tool_list_builder(tool_name,model_specific_name):
    '''Return string of classes in config_tool and model_specific'''
    cls_list=''
    for name, obj in inspect.getmembers(config_tool):
        if inspect.isclass(obj):
            if name == tool_name:
                cls_list = cls_list + ',' + name

    if model_specific_name:
        for name, obj in inspect.getmembers(config_tool.model_specific):
            if inspect.isclass(obj):
                if name == model_specific_name:
                    cls_list = cls_list + ',' + name

    return cls_list.strip(',')

if __name__ == '__main__':
    obj=tool_cmd(tool_name="Wpasupplicant",model_specific_name="Wcs")
    obj.test_wpa()
    obj.set_channel()
    obj=tool_cmd(tool_name="Wpasupplicant",model_specific_name="Intel8260")
    obj.test_wpa()
    obj.set_channel()
    obj=tool_cmd(tool_name="Wpasupplicant")
    obj.test_wpa()
    obj=tool_cmd(tool_name="Iw",model_specific_name="Wcs")
    obj.test_iw()
    obj.set_channel()
    obj=tool_cmd(tool_name="Iw",model_specific_name="Intel8260")
    obj.test_iw()
    obj.set_channel()
    obj=tool_cmd(tool_name="Iw")
    obj.test_iw()
    obj=tool_cmd(tool_name="Iwconfig",model_specific_name="Wcs")
    obj.test_iwconfig()
    obj.set_channel()
    obj=tool_cmd(tool_name="Iwconfig",model_specific_name="Intel8260")
    obj.test_iwconfig()
    obj.set_channel()
    obj=tool_cmd(tool_name="Iwconfig")
    obj.test_iwconfig()
    obj=tool_cmd(tool_name="Netsh",model_specific_name="Wcs")
    obj.test_netsh()
    obj.set_channel()
    obj=tool_cmd(tool_name="Netsh",model_specific_name="Intel8260")
    obj.test_netsh()
    obj.set_channel()
    obj=tool_cmd(tool_name="Netsh")
    obj.test_netsh()
