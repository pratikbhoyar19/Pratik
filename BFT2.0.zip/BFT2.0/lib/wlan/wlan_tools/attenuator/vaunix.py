

class Vaunix:
    """This class will provide vaunix attenuator related Apis"""


    def __init__(self):
        pass

    def test_func(self):
        print("method inside in this class %s" % self.__class__.__name__)

    def test_vaunix(self):
        print("vaunix tested")

if __name__ == "__main__":
    obj = Vaunix()
    obj.test_func()
