

class Labbric:
    """This class will provide Labbric attenuator related Apis"""


    def __init__(self):
        pass

    def test_func(self):
        print("method inside in this class %s" % self.__class__.__name__)

    def test_labbric(self):
        print("labbric tested")

if __name__ == "__main__":
    obj = Labbric()
    obj.test_func()
