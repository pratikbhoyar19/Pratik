import os
import inspect
import attenuator
from attenuator import *
from log_creator import loggerObject as logger

def attnutr_method_builder(cls):
    def __init__(self, class_list=None):
        #calling init functions of all parent classes
        for c_obj in list(class_list.split(",")):
            for ele in inspect.getmembers(eval(c_obj)):
                if "__init__" in ele:
                    eval(c_obj).__init__(self)

       
    __init__.__name__ = "__init__"
    setattr(cls,__init__.__name__,__init__)

    def config_update(self, os, session, prompt, device_dict=None,
                      dname=None, logger=logger):
        self.os = os
        self.session = session
        self.prompt = prompt
        self.dict = device_dict
        self.dname = dname
        self.logger = logger
    config_update.__name__ = "config_update"
    setattr(cls,config_update.__name__,config_update)


def attnutr_cmd(attnutr_name):
    attnutr_class_list = attnutr_list_builder(attnutr_name)
    exec ('class AttnutrHolder(' + attnutr_class_list + '): pass')
    #This dynamic class is formed with multiple inheritance, Hence Lib writter should not use
    #same attribute names accross classes
    attnutr_method_builder(AttnutrHolder)
    return AttnutrHolder(class_list=attnutr_class_list)

def attnutr_list_builder(attnutr_name):
    '''Return string of classes in attenuator'''
    cls_list=''
    for name, obj in inspect.getmembers(attenuator):
        if inspect.isclass(obj):
            if name == attnutr_name:
                cls_list = cls_list + ',' + name

    return cls_list.strip(',')

if __name__ == '__main__':
    obj=attnutr_cmd("Labbric")
    obj.test_labbric()
    obj=attnutr_cmd("Vaunix")
    obj.test_vaunix()
