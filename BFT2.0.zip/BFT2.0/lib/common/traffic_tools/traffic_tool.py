''' Class defination for traffic tool.'''
__author__ = "Sunil"
__copyright__ = "Copyright 2019, Intel Corporation"
__version__ = "0.0.1"
__maintainer__ = "Mirafra"
__email__ = "framework@mirafra.com"
__status__ = "Development"
###########################################################
import re
from globalVariables import *
from devices.interact_tools.interact_pexpect import *
from devices.interact_tools.interact_paramiko import *


class TrafficTool:
    '''
    A class used to represent traffic tool

    ...vvvv

    Attributes
    ----------


    Methods
    -------
    '''

    def start_client(self, ip):
        pass

    def start_server(self):
        pass

    def check_traffic_tool(self):
        pass

    def parse_output(self, temp_rate):
        pass

    def test_func(self):
        print("method inside in this class %s" % self.__class__.__name__)

if __name__ == "__main__":
    obj = TrafficTool()
    obj.test_func()
