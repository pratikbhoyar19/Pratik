''' Class defination for Iperf traffic tool.'''
__author__ = "Sunil"
__copyright__ = "Copyright 2019, Intel Corporation"
__version__ = "0.0.1"
__maintainer__ = "Mirafra"
__email__ = "framework@mirafra.com"
__status__ = "Development"
import operator
###########################################################
import os
import re
import traceback

from devices.interact_tools.interact_paramiko import *
from devices.interact_tools.interact_pexpect import *
from framework.publish_info_to_html import publish_html
from globalVariables import *
from lib.common.traffic_tools.traffic_tool import *


class TrafficIperf(TrafficTool):
    """
    A class used to represent traffic tool

    Attributes
    ----------
    Methods
    -------
    """

    def __init__(self, platform_type=None):

        self.platform_type = platform_type

    def config_update(self, platform_handle, interact_handle, prompt, device_dict=None, dname=None):
        '''Get the interact tool handle'''
        self.os = platform_handle
        self.session = interact_handle
        self.prompt = prompt
        self.dict = device_dict
        self.dname = dname

    def init_traffic(self, device_list):
        """
        Initialize the Port number and killing all previous running Iperf process on the devices
        Args:
            device_list (list): list of devices where the iperf process running would be killed
        Returns:
            None
        """
        self.PORT = 10001
        self.__bg_dict = {}
        self.logger.dumpLog('Killing iperf process on all the devices...')
        for device in device_list:
            device.os.kill_process('iperf')

    def run_traffic(self, traffic_dict):
        """
        It would run the traffic as per the parameters passed in the test suite, then stop and parse the iperf result
        Args:
            traffic_dict (dict): Input dictionary to pass parameters to run traffic for each pair (client, server)
            Mandatory args:
                traffic_dict[pair] (list): List of pairs between which traffic would run
                traffic_dict[pair]["src_dev"] : client device object for iperf traffic
                traffic_dict[pair]["dest_dev"] : server device object for iperf traffic
                traffic_dict[pair]["config"] : Config dictionary to config the traffic parameters
            Optional args:
                traffic_dict[pair]["logfile"] : logfile name to collect the iperf traffic logs for the pair
                traffic_dict[pair]["trim_flag"] : True| False, if True traffic would be trimmed for trim_value period before calculating tput value for runtime period.
                init_traffic_check (boolean): True|False if user want to check initial tput values for each pair, default - False

                Eg:{'pair1': {'dest_dev': <devices.station_builder.StationBuilder instance at 0x0496E918>, 'src_dev': <devices.station_builder.StationBuilder instance at 0x049AEBC0>, 'logfile': 'Pair1', 'config': {'parallel_streams': '4', 'proto': 'tcp', 'windowsize': '4M', 'bandwidth': '1M', 'WMM': 'VO', 'duration': '30', 'dest_ip': '192.168.1.196'}, 'trim_flag': False}
        Returns:
            result_dict (dict): dictionary as below
                pair: { min_tput: min_value }
                pair: { max_tput: max_value }}
                pair: { avg_tput: avg_value }}
                pair: { tput_list: tput_no_s_in_list}}
                pair: { dict_for_stalls: {zero_stall_occurred_at: number_of_zero_stalls}}
                pair: { iperf_samples: total_iperf_time_from_to_to}}
                pair: { last_line_present: True|False}}
                eg: {'pair1': {'max_tput': '31.9 Mbits/sec', 'avg_tput': '11.90625 Mbits/sec', 'min_tput': '0.0 Mbits/sec', 'iperf_samples': 16, 'last_line_present': False, 'dict_for_stalls': {'4th sec': 2, '10th sec': 3}}

        Raises:
            Raises KeyError, ValueError if key or value is not found in the input argument or the format is incorrect.
            Exception when the iperf doesn't start on either client or server for any pair.
        """
        # initializing by killing prev iperf process, and initializing _bg_dict
        device_list = []
        for pair in traffic_dict["pairs_list"]:
            device_list.append(traffic_dict[pair]["src_dev"])
            device_list.append(traffic_dict[pair]["dest_dev"])
        self.init_traffic(device_list)
        # start traffic with params from traffic dict.
        self.start_traffic(traffic_dict, init_traffic_check=False)
        # to stop the traffic after the traffic duration, thus keeping the wait flag True
        result_dict = self.stop_traffic(traffic_dict, wait_flag=True)
        return result_dict

    def _generate_iperf_cmd(self, traffic_dict, key):
        """
        A method to construct the iperf command for both server and client based on the key argument
        Args:
            traffic_dict (dict): input dictionary for each pair with config info
            Mandatory arguments:
                traffic_dict["proto"]: protocol of the traffic tcp | udp | mcast
                traffic_dict["dest_ip"]: IP of the device where iperf server is running
                key (string): (Mandatory) 'send' | 'receive' to generate command for client | server.
            Optional arguments:
                traffic_dict["bandwidth"]: bandwidth for udp protocol traffic
                traffic_dict["duration"]: (optional) traffic runtime, default is 60 seconds
                traffic_dict["parallel_streams"]: (optional) for running parallel stream traffic
                traffic_dict["WMM"]: (optional) to run WMM traffic - Voic, video, best effort, background
                traffic_dict["interval"]: (optional) to set interval of data transfer, default is 1 second
                traffic_dict["windowsize"]: (optional) to set the windowsize for iperf traffic, default is 256K
                traffic_dict["bufferlen"]: (optional) to set bufferlength
                traffic_dict["port"]: (optional) to set port number for each pair of traffic stream, default is 10001
        Return:
            it returns the iperf generated command in string format for both server and clent based on the key passed in args.
        Exceptions:
            Raises KeyError, ValueError if key or value is not found in the input argument or the format is incorrect.

        """

        try:

            iperf_cmd = 'iperf'
            if key == 'send':
                if 'proto' in traffic_dict and traffic_dict['proto'] == 'udp':
                    iperf_cmd += ' -u -c ' + str(traffic_dict['dest_ip']) + ' -f m '
                    # to test the bandwidth of the network.
                    if 'bandwidth' in traffic_dict:
                        iperf_cmd += '-b ' + traffic_dict['bandwidth'] + ' '
                    else:
                        iperf_cmd += '-b 2000m '
                elif 'proto' in traffic_dict and traffic_dict['proto'] == 'mcast':
                    iperf_cmd += ' -c ' + str(traffic_dict['mcastaddress']) + " -n " + str(
                        traffic_dict['numofbytes']) + ' -f m '
                else:
                    iperf_cmd += ' -c ' + str(traffic_dict['dest_ip']) + ' -f m '

                if 'duration' in traffic_dict:
                    iperf_cmd += ' -t ' + str(traffic_dict['duration']) + ' '
                else:
                    iperf_cmd += ' -t 60 '
                if 'parallel_streams' in traffic_dict:
                    iperf_cmd += ' -P ' + str(traffic_dict['parallel_streams']) + ' '
                if 'WMM' in traffic_dict:
                    if traffic_dict['WMM'] == 'BE':
                        iperf_cmd += ' -S 0x00 '
                    elif traffic_dict['WMM'] == 'BK':
                        iperf_cmd += ' -S 0x30 '
                    elif traffic_dict['WMM'] == 'BK2':
                        iperf_cmd += ' -S 0x40 '
                    elif traffic_dict['WMM'] == 'EE':
                        iperf_cmd += ' -S 0x60 '
                    elif traffic_dict['WMM'] == 'CL':
                        iperf_cmd += ' -S 0x80 '
                    elif traffic_dict['WMM'] == 'VI':
                        iperf_cmd += ' -S 0xA0 '
                    elif traffic_dict['WMM'] == 'VO':
                        iperf_cmd += ' -S 0xC0 '
                    elif traffic_dict['WMM'] == 'NC':
                        iperf_cmd += ' -S 0xE0 '

            elif key == 'receive':
                iperf_cmd = 'iperf -s '

                if ('proto' in traffic_dict and traffic_dict['proto'] == 'udp'):
                    iperf_cmd += ' -u -f m '
                elif 'proto' in traffic_dict and traffic_dict['proto'] == 'mcast':
                    iperf_cmd += ' -u -B ' + str(traffic_dict['mcastaddress']) + ' -f m '
                else:
                    iperf_cmd += ' -f m '

            if 'interval' in traffic_dict:
                iperf_cmd += ' -i ' + str(traffic_dict['interval']) + ' '
            else:
                iperf_cmd += ' -i 1 '

            if 'windowsize' in traffic_dict:
                iperf_cmd += '-w ' + traffic_dict['windowsize'] + ' '
            else:
                iperf_cmd += ' -w 256K'

            if 'bufferlen' in traffic_dict:
                iperf_cmd += ' -l ' + traffic_dict['bufferlen'] + ' '

            if 'port' in traffic_dict:
                iperf_cmd += ' -p' + str(traffic_dict['port']) + ' '

            return iperf_cmd

        except (KeyError, TypeError, AttributeError) as ex:
            publish_html(comment="ERROR: Error in _generate_iperf_cmd ")
            self.logger.dumpLog("{}".format(traceback.format_exc()))
            raise

    def start_traffic(self, traffic_dict, init_traffic_check=False):
        """
        Function to start the traffic.

        Args:
            traffic_dict (dict): Input dictionary to pass parameters to run traffic for each pair (client, server) as below
            Mandatory args:
                traffic_dict[pair] (list): List of pairs between which traffic would run
                traffic_dict[pair]["src_dev"] : client device object for iperf traffic
                traffic_dict[pair]["dest_dev"] : server device object for iperf traffic
                traffic_dict[pair]["config"] : Config dictionary to config the traffic parameters
            Optional args:
                traffic_dict[pair]["logfile"] : logfile name to collect the iperf traffic logs for the pair
                traffic_dict[pair]["trim_flag"] : True| False, if True traffic would be trimmed for trim_value period before calculating tput value for runtime period.
                init_traffic_check (boolean): True|False if user want to check initial tput values for each pair, default - False

                Eg:{'pair1': {'dest_dev': <devices.station_builder.StationBuilder instance at 0x0496E918>, 'src_dev': <devices.station_builder.StationBuilder instance at 0x049AEBC0>, 'logfile': 'Pair1', 'config': {'parallel_streams': '4', 'proto': 'tcp', 'windowsize': '4M', 'bandwidth': '1M', 'WMM': 'VO', 'duration': '30', 'dest_ip': '192.168.1.196'}, 'trim_flag': False}
        Returns:
            dictionary if init_traffic_check is True else None
            dictionary as below:
                pair: { min_tput: min_value }
                pair: { max_tput: max_value }}
                pair: { avg_tput: avg_value }}
                pair: { tput_list: tput_no_s_in_list}}
                pair: { dict_for_stalls: {zero_stall_occurred_at: number_of_zero_stalls}}
                pair: { iperf_samples: total_iperf_time_from_to_to}}
                pair: { last_line_present: True|False}}
        Raises:
            Exception when the iperf doesn't start on either client or server for any pair.
        """

        try:

            # SERVER-CONFIGURATION -constructing iperf cmd for server side and then pushing it to the server device
            for pair in traffic_dict["pairs_list"]:
                # mcast not supported in Windows
                if (str(traffic_dict[pair]['dest_dev'].os)).lower == 'windows' and (
                        str(traffic_dict[pair]['config']['proto'])).lower == 'mcast':
                    publish_html(comment='ERROR: mcast not supported in Windows!!')
                    raise TypeError
                self.__bg_dict[pair] = {}
                # defining port for each pair if not provided in traffic_dict by the user
                if 'port' not in traffic_dict[pair]['config']:
                    traffic_dict[pair]['config']['port'] = self.PORT
                    self.logger.dumpLog('PORT for server {} : {}'.format(pair, traffic_dict[pair]['config']['port']))
                    self.PORT += 1
                if 'trim_flag' in traffic_dict[pair] and traffic_dict[pair]['trim_flag'] is True:
                    self.__bg_dict[pair]['trim_seconds'] = 10
                    traffic_dict[pair]['config']['duration'] = int(traffic_dict[pair]['config']['duration']) + \
                                                               self.__bg_dict[pair]['trim_seconds']
                else:
                    traffic_dict[pair]['trim_flag'] = False
                self.logger.dumpLog('runtime for the traffic: {}'.format(traffic_dict[pair]['config']['duration']))

                traffic_dict[pair]['dest_dev'] = traffic_dict[pair]['dest_dev']
                server_cmd = self._generate_iperf_cmd(traffic_dict[pair]['config'], "receive")

                # creating iperf server logfile name, if not provided in the traffic_dict by the user
                if "logfile" in traffic_dict[pair]:
                    server_logfile = 'iperflogs_' + (traffic_dict[pair]['logfile']).strip('.txt') + '_server.txt'
                else:
                    server_logfile = '_'.join(
                        ['iperflogs', str(pair), 'to', str(traffic_dict[pair]['src_dev'].dict['name']),
                         str(traffic_dict[pair]['dest_dev'].dict['name']), traffic_dict[pair]['config']['proto'],
                         '_server.txt'])
                self.__bg_dict[pair]['server_logfile_path'] = traffic_dict[pair][
                                                                  'dest_dev'].os.log_path() + server_logfile

                # Issuing the constructed Iperf command to server device and verifying that server has started listening
                server_cmd = server_cmd + " > " + self.__bg_dict[pair]['server_logfile_path']
                self.logger.dumpLog("server: {}".format(server_cmd))
                iperf_server_start = False
                for count in range(1, 4):
                    if iperf_server_start is False:
                        self.__bg_dict[pair]["dest_session_id"] = traffic_dict[pair]['dest_dev'].session.send_cmd(
                            server_cmd)
                        self.__bg_dict[pair]["dest_iperf_pid"] = traffic_dict[pair]['dest_dev'].os.get_process_id(
                            'iperf')
                        time.sleep(0.2)
                        self.__bg_dict[pair]['init_server_log'] = traffic_dict[pair]['dest_dev'].os.get_file_content(
                            self.__bg_dict[pair]['server_logfile_path'])
                        if len(self.__bg_dict[pair]['init_server_log']) > 0:
                            self.logger.dumpLog(
                                'Iperf process on Server for pair: {} has started successfully on device: {}'.format(
                                    pair, traffic_dict[pair]['dest_dev'].dict['name']))
                            iperf_server_start = True
                            break
                        self.logger.dumpLog('Iperf on server: {} of pair: {} not started yet, retrying .... {}'.format(
                            traffic_dict[pair]['dest_dev'].dict['name'], pair, count))
                        time.sleep(0.5)
                if iperf_server_start is False:
                    publish_html(comment='ERROR: Failed to start the Iperf server for pair: {} on the device: {}'.format(pair,
                                                                                                                   traffic_dict[
                                                                                                                       pair][
                                                                                                                       'dest_dev'].dict[
                                                                                                                       'name']))
                    self.logger.dumpLog("{}".format(traceback.format_exc()))
                    raise Exception("ERROR: Failed to start Iperf on Server for pair: {} !!".format(pair))

            # CLIENT CONFIGURATION - constructing iperf cmd for client side and then pushing it to the client device.
            for pair in traffic_dict["pairs_list"]:
                self.__bg_dict[pair]["client_cmd"] = self._generate_iperf_cmd(traffic_dict[pair]['config'], "send")
                # creating iperf client logfile name, if not provided in the traffic_dict
                if "logfile" in traffic_dict[pair]:
                    client_logfile = 'iperflogs_' + (traffic_dict[pair]['logfile']).strip('.txt') + '_client.txt'
                else:
                    client_logfile = '_'.join(
                        ['iperflogs', str(pair), 'to', str(traffic_dict[pair]['src_dev'].dict['name']),
                         str(traffic_dict[pair]['dest_dev'].dict['name']), traffic_dict[pair]['config']['proto'],
                         '_client.txt'])
                self.__bg_dict[pair]['client_logfile_path'] = traffic_dict[pair][
                                                                  'src_dev'].os.log_path() + client_logfile
                self.__bg_dict[pair]["client_cmd"] = self.__bg_dict[pair]["client_cmd"] + " > " + self.__bg_dict[pair][
                    'client_logfile_path']
                self.logger.dumpLog("client : {}".format(self.__bg_dict[pair]["client_cmd"]))

                self.__bg_dict[pair]["src_iperf_pid"] = traffic_dict[pair]['src_dev'].os.get_process_id('iperf')
                self.__bg_dict[pair]["src_session_id"] = traffic_dict[pair]['src_dev'].session.send_cmd(
                    self.__bg_dict[pair]["client_cmd"])
                time.sleep(0.3)
                self.__bg_dict[pair]['init_client_log'] = traffic_dict[pair]['src_dev'].os.get_file_content(
                    self.__bg_dict[pair]['client_logfile_path'])

                # if the iperf process starts on client log it, else kill the iperf session on the client device
                if len(self.__bg_dict[pair]['init_client_log']) > 0:
                    self.__bg_dict[pair]["client_start_time"] = time.time()
                    self.logger.dumpLog(
                        'Iperf process on Client for pair: {} has started successfully on client device: {}'.format(
                            pair, traffic_dict[pair]['src_dev'].dict['name']))
                else:
                    self.logger.dumpLog(
                        'Iperf on client: {} of pair: {} not started, Killing the iperf session .... '.format(
                            traffic_dict[pair]['src_dev'].dict['name'], pair))
                    traffic_dict[pair]['src_dev'].session.recv_cmd(self.__bg_dict[pair]["src_session_id"])

            # verifying that iperf process to started on client device, if not retrying 2 more times
            for pair in traffic_dict["pairs_list"]:
                if len(self.__bg_dict[pair]['init_client_log']) == 0:
                    iperf_client_start = False
                    self.logger.dumpLog('Iperf on client: {} of pair: {} not started yet, retrying .... '.format(
                        traffic_dict[pair]['src_dev'].dict['name'], pair))
                    for count in range(1, 3):
                        self.__bg_dict[pair]["src_session_id"] = traffic_dict[pair]['src_dev'].session.send_cmd(
                            self.__bg_dict[pair]["client_cmd"])
                        time.sleep(0.2)
                        self.__bg_dict[pair]['init_client_log'] = traffic_dict[pair]['src_dev'].os.get_file_content(
                            self.__bg_dict[pair]['client_logfile_path'])
                        if iperf_client_start is False:
                            if len(self.__bg_dict[pair]['init_client_log']) > 0:
                                iperf_client_start = True
                                self.__bg_dict[pair]["client_start_time"] = time.time()
                                self.logger.dumpLog(
                                    'Iperf process on Client for pair: {} has started successfully on client device: {}'.format(
                                        pair, traffic_dict[pair]['src_dev'].dict['name']))
                                break
                            else:
                                self.logger.dumpLog(
                                    'Iperf on client: {} of pair: {} not started yet, retrying .... {}'.format(
                                        traffic_dict[pair]['src_dev'].dict['name'], pair, count))
                                traffic_dict[pair]['src_dev'].session.recv_cmd(self.__bg_dict[pair]["src_session_id"])
                                time.sleep(0.3)
                    if iperf_client_start is False:
                        publish_html(comment=
                            'ERROR: Failed to start the Iperf Client for pair: {} on the device: {}'.format(pair,
                                                                                                            traffic_dict[
                                                                                                                pair][
                                                                                                                'src_dev'].dict[
                                                                                                                'name']))
                        raise Exception("ERROR: Failed to start Iperf on client for Pair: {} !!".format(pair))

            # get the initial content of client iperflogs
            time.sleep(5)
            for pair in traffic_dict["pairs_list"]:
                self.__bg_dict[pair]['init_client_log'] = traffic_dict[pair]['src_dev'].os.get_file_content(
                    self.__bg_dict[pair]['client_logfile_path'])
            self.logger.dumpLog(' Printing the bg_dict : {}'.format(self.__bg_dict))
            if init_traffic_check:
                init_traffic_dict = {}
                for pair in traffic_dict["pairs_list"]:
                    init_traffic_dict[pair] = {}
                    init_tput_data = self.__bg_dict[pair]['init_client_log']
                    traffic_lines = init_tput_data.split('\r\n')
                    tput_result = self.get_iperf_results(traffic_lines, False, pair, return_tput_list=True)
                    init_traffic_dict.update(tput_result)
                return init_traffic_dict
        except:
            self.logger.dumpLog("Exception in start_traffic_module {}".format(traceback.format_exc()))
            raise Exception

    def stop_traffic(self, traffic_dict, wait_flag=True):
        """
        Method to stop Iperf traffic
        Args:
            traffic_dict (dict): Dictionary with parameters to validate the traffic generated.
            traffic_dict["pairs_list"] (list): list of pairs for which traffic needs to be stopped.
            traffic_dict[pair]["duration"]: duration in seconds to stop the traffic on each pair.
            wait_flag (boolean): default is True it would wait for complete duration to elapse before killing the iperf process to stop traffic	False - to kill the iperf process immediately.
            Eg: {'pair1': {'max_tput': '31.9 Mbits/sec', 'avg_tput': '11.90625 Mbits/sec', 'min_tput': '0.0 Mbits/sec', 'iperf_samples': 16, 'last_line_present': False, 'dict_for_stalls': {'4th sec': 2, '10th sec': 3}}
        Returns:
            result_dict (dict): contains traffic values in terms of avg, min, max and zero stalls if any.
        Exception:
            Raises exception for failure to copy the iperf server log files to the MasterPC.
        """
        try:

            pair_order, client_device_list, wait_time, pair_length = [], [], 0, len(traffic_dict["pairs_list"])
            for pair in traffic_dict["pairs_list"]:
                client_device_list.append([pair, traffic_dict[pair]['src_dev']])
            if wait_flag:
                for pair in traffic_dict["pairs_list"]:
                    max_wait_time = max(wait_time, traffic_dict[pair]['config']['duration'])
                else:
                    current_time = time.time()
                    wait_time = int(max_wait_time) - (
                            int(current_time) - int(self.__bg_dict[pair]["client_start_time"]))
                self.logger.dumpLog(
                    " Iperf runtime is {}, waiting for {} seconds to complete Iperf traffic. . . . . ".format(
                        traffic_dict[pair]['config']['duration'], wait_time))
                time.sleep(wait_time)
                temp_list = client_device_list
                wait_for_kill = 20 if 'parallel_streams' in traffic_dict[pair]['config'] else 10
                for timer in range(1, wait_for_kill + 1, 1):
                    if temp_list == []:
                        break
                    for each_client in client_device_list:
                        if each_client[1].os.process_id_exist(self.__bg_dict[each_client[0]]['dest_iperf_pid'],
                                                              'iperf') is False:
                            temp_list.remove(each_client)
                        time.sleep(1)
                else:
                    if temp_list:
                        self.logger.dumpLog("Iperf process did not stop on {} after {} seconds".format(
                            ", ".join([device.dict['name'] for device in client_device_list]), str(wait_for_kill)))
                        for each_client in temp_list:
                            each_client[1].session.recv_cmd(self.__bg_dict[pair]["src_session_id"])

            # killing iperf process sessions on the server devices for every pair
            for pair in traffic_dict["pairs_list"]:
                traffic_dict[pair]['dest_dev'].session.recv_cmd(self.__bg_dict[pair]["dest_session_id"])
            remote_file_path = self.session.get_log_dir()
            pairs_avg_value = []
            pairs_min_value = []
            pairs_max_value = []
            result_dict = {}
            for pair in traffic_dict["pairs_list"]:
                x = re.split('\\\\|/', self.__bg_dict[pair]['server_logfile_path'])
                self.__bg_dict[pair]['server_iperflog_file_path'] = os.path.join(str(remote_file_path), str(
                    re.split('\\\\|/', self.__bg_dict[pair]['server_logfile_path'])[-1]))
                self.__bg_dict[pair]['client_iperflog_file_path'] = os.path.join(str(remote_file_path), str(
                    re.split('\\\\|/', self.__bg_dict[pair]['client_logfile_path'])[-1]))
                self.logger.dumpLog('Logs folder path: {}'.format(remote_file_path))
                # copying the client and server logfiles to the MasterPC
                traffic_dict[pair]['client_file_status'] = traffic_dict[pair]['src_dev'].session.download_file(
                    local_filepath=self.__bg_dict[pair]['client_iperflog_file_path'],
                    remote_filepath=self.__bg_dict[pair]['client_logfile_path'])
                traffic_dict[pair]['server_file_status'] = traffic_dict[pair]['dest_dev'].session.download_file(
                    local_filepath=self.__bg_dict[pair]['server_iperflog_file_path'],
                    remote_filepath=self.__bg_dict[pair]['server_logfile_path'])

                if traffic_dict[pair]['client_file_status'] is False:
                    publish_html(comment=
                        'ERROR: Error in copying the Client: {} of pair: {} iperLogs to the Logs folder !!!'.format(
                            traffic_dict[pair]['src_dev'].dict['name'], pair))
                else:
                    self.logger.dumpLog(
                        'Iperf log files of Client: {} of pair: {} copied to the Logs folder Successfully !!'.format(
                            traffic_dict[pair]['src_dev'].dict['name'], pair))
                if traffic_dict[pair]['server_file_status'] is False:
                    publish_html(comment=
                        'ERROR: Error in copying the Server: of pair: {} iperLogs to the Logs folder !!!'.format(
                            traffic_dict[pair]['dest_dev'].dict['name'], pair))
                    raise IOError('Failed to copy server logs !!!')
                else:
                    self.logger.dumpLog(
                        'Iperf log files of Server: {} of pair: {} copied to the Logs folder Successfully !!'.format(
                            traffic_dict[pair]['dest_dev'].dict['name'], pair))

                with open(self.__bg_dict[pair]['server_iperflog_file_path'], 'r') as traffic_report:
                    traffic_lines = traffic_report.readlines()
                    result_dict.update(self.get_iperf_results(traffic_lines, traffic_dict[pair]['trim_flag'], pair,
                                                              return_tput_list=False))

                pairs_avg_value.append(float(result_dict[pair]["avg_tput"].split()[0]))
                pairs_min_value.append(float(result_dict[pair]["min_tput"].split()[0]))
                pairs_max_value.append(float(result_dict[pair]["max_tput"].split()[0]))
            # calculating avg, min and max combined for all the pairs
            if pair_length > 1:
                result_dict["all_pairs_avg"] = '{} Mbits/sec'.format(round(sum(pairs_avg_value) / len(pairs_avg_value)))
                result_dict["all_pairs_min"] = "{} Mbits/sec".format(round(min(pairs_min_value)), 2)
                result_dict["all_pairs_max"] = "{} Mbits/sec".format(round(max(pairs_max_value)), 2)
            self.logger.dumpLog('result_dict: {}'.format(result_dict))

            # publishing the tput numbers with links
            for key, value in result_dict.items():
                key_printed = False
                print_list = ['avg_tput', 'min_tput', 'max_tput']
                temp_print_list = []
                self.logger.dumpLog("pair: {}".format(key))
                if "all_pairs" in key:
                    publish_html(comment="{} : {}".format(key.upper(), value))
                else:
                    traffic_dict[key]['traffic_key'] = "{} -> {}".format(traffic_dict[key]['src_dev'].dict['name'],
                                                                         traffic_dict[key]['dest_dev'].dict['name'])
                if type(value) == dict:
                    for key1, value1 in value.items():
                        self.logger.dumpLog("{}: {}".format(key1, value1))
                        if key_printed is False:
                            publish_html(comment="{} : {}".format(key, traffic_dict[key]['traffic_key']))
                            publish_html(comment="=" * 18)
                            key_printed = True
                        if key1 in print_list:
                            publish_html(comment="{} : {}".format(str(key1.strip("_tput")).upper(), value1))
                            temp_print_list.append(key1)
                    if set(temp_print_list) == set(print_list):
                        publish_html(
                            comment="{}".format(re.split('\\\\|\/\/', self.__bg_dict[pair]['server_logfile_path'])[-1]),
                            log_link=self.__bg_dict[key]['server_iperflog_file_path'])
                        publish_html(
                            comment="{}".format(re.split('\\\\|\/\/', self.__bg_dict[pair]['client_logfile_path'])[-1]),
                            log_link=self.__bg_dict[key]['client_iperflog_file_path'])
            return result_dict
        except(KeyError, ValueError, Exception) as err:
            self.logger.dumpLog("{}".format(traceback.format_exc()))
            raise Exception

    def get_iperf_results(self, traffic_lines, trim_flag, traffic_pair, return_tput_list=False):

        """
        Function to get the iperf results

        Args:
            traffic_lines: list of lines in the from server traffic log
            trim_flag: True|False based on traffic log trimming requirement
            traffic_pair:
        Returns:
            dictionary as below
                pair: { min_tput: min_value }
                pair: { max_tput: max_value }}
                pair: { avg_tput: avg_value }}
                pair: { tput_list: tput_no_s_in_list}}
                pair: { dict_for_stalls: {zero_stall_occurred_at: number_of_zero_stalls}}
                pair: { iperf_samples: total_iperf_time_from_to_to}}
                pair: { last_line_present: True|False}}
                eg: {'pair1': {'max_tput': '31.9 Mbits/sec', 'avg_tput': '11.90625 Mbits/sec', 'min_tput': '0.0 Mbits/sec', 'iperf_samples': 16, 'last_line_present': False, 'dict_for_stalls': {'4th sec': 2, '10th sec': 3}}

        Raises:
            ValueError : traffic log has no data for pair
        """

        try:

            if trim_flag is True:
                trim_value = self.__bg_dict[traffic_pair]["trim_seconds"]
                trim_bitrate_values = []
                trim_sec_values = []
            ref_sec_list = []
            bandwidth_values = []
            bandwidth_results = {}
            data = []
            result_dict = {}
            result_dict[traffic_pair] = {}
            result_dict[traffic_pair]['last_line_present'] = False
            sum_pattern_count = str(traffic_lines).count("SUM")
            data_pattern_line = r"\s+(\d{1,3}.\d{1,3})\sMbits/sec"
            if sum_pattern_count > 1:
                # when parallel streams are run only [SUM] values are considered for tput calculation
                for line in traffic_lines:
                    if re.search('0.0.*-[ ]*([0-9]{}2,)\.[0-9] sec[ ]+[0-9]+.*Bytes (.*)([MK]bits/sec)',
                                 line) is not None:
                        result_dict[traffic_pair]['last_line_present'] = True
                    if "SUM" in line:
                        data.append(re.findall(data_pattern_line, line))
            else:
                for line in traffic_lines:
                    if re.search('0.0.*-[ ]*([0-9]{}2,)\.[0-9] sec[ ]+[0-9]+.*Bytes (.*)([MK]bits/sec)',
                                 line) is not None:
                        result_dict[traffic_pair]['last_line_present'] = True
                    if sum_pattern_count > 1 and "SUM" in line:
                        data.append(re.findall(data_pattern_line, line))
                    elif sum_pattern_count == 1:
                        data.append(re.findall(data_pattern_line, line))
                    else:
                        data.append(re.findall(data_pattern_line, line))
            try:
                bit_rates = [float(i) for i in reduce(operator.concat, filter(None, data))]
            except:
                if return_tput_list is False:
                    bit_rates = []
                    self.logger.dumpLog("traffic log has no data for pair: {}, path: {}".format(traffic_pair,
                                                                                           self.__bg_dict[traffic_pair][
                                                                                               'server_iperflog_file_path']))
                    self.logger.dumpLog("data: {}".format(data))
                    result_dict[traffic_pair]['max_tput'] = result_dict[traffic_pair]['min_tput'] = \
                        result_dict[traffic_pair]['avg_tput'] = '0'
                    return result_dict
            if trim_flag:
                ref_sec_list = [i for i in range(len(bit_rates))]
                trim_bitrate_values = bit_rates[trim_value: -trim_value]
                trim_sec_values = ref_sec_list[trim_value: -trim_value]
                bandwidth_values = trim_bitrate_values
                if len(bandwidth_values) == 0:
                    publish_html(comment="ERROR: Iperf traffic data is not available to calculate max,min,avg after trim")
                    return result_dict
                else:
                    zero_list = [trim_sec_values[i] for i in range(len(bandwidth_values)) if
                                 bandwidth_values[i] == 0.00]
            else:
                bandwidth_values = bit_rates
                zero_list = [i for i in range(len(bandwidth_values)) if bandwidth_values[i] == 0.00]
            result_dict[traffic_pair]['min_tput'] = "{} Mbits/sec".format(round(min(bandwidth_values)), 2)
            result_dict[traffic_pair]['max_tput'] = "{} Mbits/sec".format(round(max(bandwidth_values)), 2)
            result_dict[traffic_pair]['avg_tput'] = "{} Mbits/sec".format(
                round(sum(bandwidth_values) / len(bandwidth_values)), 2)
            result_dict[traffic_pair]["iperf_samples"] = len(bit_rates)
            instances = {}
            count = 0
            zero_instances_count = 0
            sec = 0
            if len(zero_list):
                self.logger.dumpLog("consecutive zero bandwidth traffic observed..")
                for i in range(len(zero_list)):
                    if i + 1 < len(zero_list):
                        if zero_list[i] == (zero_list[i + 1] - 1):
                            count = count + 1
                        else:
                            if count == 0:
                                zero_instances_count = count + 1
                                sec = i
                                instances[str(zero_list[sec]) + "th sec"] = zero_instances_count

                            else:
                                zero_instances_count = count + 1
                                sec = i - count
                                instances[str(zero_list[sec]) + "th sec"] = zero_instances_count
                                count = zs = 0
                    else:
                        if count:
                            sec = i - count
                            zero_instances_count = count + 1
                            instances[str(zero_list[sec]) + "th sec"] = zero_instances_count
                        else:
                            sec = i
                            instances[str(zero_list[sec]) + "th sec"] = zero_instances_count + 1
            else:
                self.logger.dumpLog("No consecutive zero bandwidth traffic observed")

            result_dict[traffic_pair]['dict_for_stalls'] = instances
            if return_tput_list:
                result_dict[traffic_pair]['tput_list'] = bit_rates
            return result_dict
        except (KeyError, ValueError, Exception) as ex:
            self.logger.dumpLog("{}".format(traceback.format_exc()))
            raise Exception

    def start_client(
            self,
            ip=dut_lan_ip,
            proto=tsv_proto_tcp,
            connections=tsv_iperf_conns,
            time=tsv_iperf_time,
            port=tsv_iperf_port_default,
            udp_bandwidth=tsv_proto_udp_bandwidth,
            udp_packet_len=tsv_default_udp_packet_len, ipv6_enable=False, parallel_stream=False,
            tool_specific=""):
        '''To start the Iperf client to IP address in system
           Arguments: system        - This argument is the object where the Iperf client has to be started, default object is board
                      ip            - This argument is the Multicast IP address, default IP is dut_lan_ip
                      proto         - This argument is the trasport layer protocol, default proto is tsv_proto_tcp
                      connections   - This argument is the no. of parallel Iperf connections, default no. is tsv_iperf_conns
                      time          - This argument is the time value of Iperf, default value is tsv_iperf_time
                      port          - This argument is the port number, default port number is tsv_iperf_port_default
                      udp_bandwidth - This argument is the udp bandwidth, default value is tsv_proto_udp_bandwidth
                      udp_packet_len - This argument is the udp packet length value, default packet length is tsv_default_udp_packet_len'''

        return self.start_iperf_client(
            ip,
            proto,
            connections,
            time,
            port,
            udp_bandwidth,
            udp_packet_len, ipv6_enable, parallel_stream=parallel_stream)

    def start_server(
            self,
            proto=tsv_proto_tcp,
            connections=tsv_iperf_conns,
            time=tsv_iperf_time,
            port=tsv_iperf_port_default,
            udp_bandwidth=tsv_proto_udp_bandwidth,
            udp_packet_len=tsv_default_udp_packet_len, ipv6_enable=False, parallel_stream=False):
        '''To start the Iperf client to IP address
           Arguments: system        - This argument is the object where the Iperf client has to be started, default object is board
                      proto         - This argument is the trasport layer protocol, default proto is tsv_proto_tcp
                      connections   - This argument is the no. of parallel Iperf connections, default no. is tsv_iperf_conns
                      time          - This argument is the time value of Iperf, default value is tsv_iperf_time
                      port          - This argument is the port number, default port number is tsv_iperf_port_default
                      udp_bandwidth - This argument is the udp bandwidth, default value is tsv_proto_udp_bandwidth
                      udp_packet_len - This argument is the udp packet length value, default packet length is tsv_default_udp_packet_len'''

        return self.start_iperf_server(
            proto,
            connections,
            time,
            port,
            udp_bandwidth,
            udp_packet_len, ipv6_enable, parallel_stream=parallel_stream)

    def start_iperf_client(
            self,
            ip,
            proto=tsv_proto_tcp,
            connections=tsv_iperf_conns,
            time=tsv_iperf_time,
            port=tsv_iperf_port_default,
            udp_bandwidth=tsv_proto_udp_bandwidth,
            udp_packet_len=tsv_default_udp_packet_len, ipv6_enable=False, parallel_stream=False):
        '''To start the Iperf client to IP address in system
           Arguments: system        - This argument is the object where the Iperf client has to be started, default object is board
                      ip            - This argument is the Multicast IP address, default IP is dut_lan_ip
                      proto         - This argument is the trasport layer protocol, default proto is tsv_proto_tcp
                      connections   - This argument is the no. of parallel Iperf connections, default no. is tsv_iperf_conns
                      time          - This argument is the time value of Iperf, default value is tsv_iperf_time
                      port          - This argument is the port number, default port number is tsv_iperf_port_default
                      udp_bandwidth - This argument is the udp bandwidth, default value is tsv_proto_udp_bandwidth
                      udp_packet_len - This argument is the udp packet length value, default packet length is tsv_default_udp_packet_len'''
        if proto == tsv_proto_udp:
            proto_opts = "-u -M 1400 -b %s" % (udp_bandwidth)
        elif proto == tsv_proto_tcp:
            proto_opts = ""
        if port == tsv_iperf_port_default:
            port_opts = ""
        else:
            port_opts = "-p %s" % (port)
        if udp_packet_len == tsv_default_udp_packet_len:
            len_opts = ""
        else:
            len_opts = "-l %s" % (udp_packet_len)
        iperf_present = self.iperf_install()
        if ipv6_enable:
            if iperf_present:
                self.session.send_line(
                    "iperf -V -c %s -t %s -P %s %s %s %s | grep -v SUM" %
                    (ip, time, connections, proto_opts, port_opts, len_opts))
            return True
        elif iperf_present:
            if parallel_stream == True:

                self.logger.dumpLog(
                    "iperf -c %s -t %s -P %s %s %s %s -i 1" % (ip, time, connections, proto_opts, port_opts, len_opts))
                self.session.send_line(
                    "iperf -c %s -t %s -P %s %s %s %s -i 1" % (ip, time, connections, proto_opts, port_opts, len_opts),
                    send_block=True)
                # self.session.send_control('c')
            else:
                self.session.send_line("iperf -c %s -t %s -P %s %s %s %s | grep -v SUM" % (
                    ip, time, connections, proto_opts, port_opts, len_opts))
            return True
        else:
            return False

    def start_iperf_server(
            self,
            proto=tsv_proto_tcp,
            connections=tsv_iperf_conns,
            time=tsv_iperf_time,
            port=tsv_iperf_port_default,
            udp_bandwidth=tsv_proto_udp_bandwidth,
            udp_packet_len=tsv_default_udp_packet_len, ipv6_enable=False, parallel_stream=False):
        '''To start the Iperf client to IP address
           Arguments: system        - This argument is the object where the Iperf client has to be started, default object is board
                      proto         - This argument is the trasport layer protocol, default proto is tsv_proto_tcp
                      connections   - This argument is the no. of parallel Iperf connections, default no. is tsv_iperf_conns
                      time          - This argument is the time value of Iperf, default value is tsv_iperf_time
                      port          - This argument is the port number, default port number is tsv_iperf_port_default
                      udp_bandwidth - This argument is the udp bandwidth, default value is tsv_proto_udp_bandwidth
                      udp_packet_len - This argument is the udp packet length value, default packet length is tsv_default_udp_packet_len'''

        if proto == tsv_proto_udp:
            proto_opts = "-u -M 1400 -b %s" % (udp_bandwidth)
        elif proto == tsv_proto_tcp:
            proto_opts = ""
        if port == tsv_iperf_port_default:
            port_opts = ""
        else:
            port_opts = "-p %s" % (port)
        if udp_packet_len == tsv_default_udp_packet_len:
            len_opts = ""
        else:
            len_opts = "-l %s" % (udp_packet_len)
        mode = "s"
        iperf_present = self.iperf_install()
        if ipv6_enable:
            if iperf_present:
                try:
                    self.session.send_line(
                        "iperf -s -V -t %s -P %s %s %s %s &" %
                        (time, connections, proto_opts, port_opts, len_opts))
                    self.session.recv_line(self.prompt, timeout=10)
                    return True
                except BaseException:
                    self.logger.dumpLog("Failed to start Iperf server")
                    return False
        elif iperf_present:
            try:
                if parallel_stream == False:
                    self.session.send_line(
                        "iperf -s -t %s -P %s %s %s %s &" %
                        (time, connections, proto_opts, port_opts, len_opts))
                    self.session.recv_line(self.prompt, timeout=10)
                else:
                    if self.platform_type.lower() == "linux":
                        self.logger.dumpLog("iperf -s -t %s -P %s %s %s %s >/tmp/%s" % (
                            time, connections, proto_opts, port_opts, len_opts, tsv_server_report_name))
                        self.session.send_line("iperf -s -t %s -P %s %s %s %s >/tmp/%s" % (
                            time, connections, proto_opts, port_opts, len_opts, tsv_server_report_name),
                                               send_block=True)
                        self.session.recv_line(self.prompt, timeout=10)
                    elif self.platform_type.lower() == "windows":
                        self.logger.dumpLog("iperf -s -t %s -P %s %s %s %s >%s\\%s" % (
                            time, connections, proto_opts, port_opts, len_opts, tsv_win_rpt_path,
                            tsv_server_report_name))
                        self.session.send_line("iperf -s -t %s -P %s %s %s %s >%s\\%s" % (
                            time, connections, proto_opts, port_opts, len_opts, tsv_win_rpt_path,
                            tsv_server_report_name),
                                               send_block=True)
                        self.session.recv_line(self.prompt, timeout=10)

                return True
            except BaseException:
                self.logger.dumpLog("Failed to start Iperf server")
                return False
        else:
            return False

    def iperf_install(self):
        '''To check if iperf is present on the system
           Arguments: system      - This argument is the object where the iperf presence have to check'''
        # self.session.send_line('iperf -v')
        # if self.session.recv_line(['iperf version',
        #                  'currently not installed',
        #                  'not found'],
        #                 timeout=10) == 0:
        #    iperf_present = True
        # else:
        #    iperf_present = False
        # self.session.recv_line(self.prompt,timeout=10)
        # return iperf_present
        return True

    def test_func(self):
        print("method inside in this class %s" % self.__class__.__name__)


if __name__ == "__main__":
    obj = TrafficIperf()
    obj.test_func()
