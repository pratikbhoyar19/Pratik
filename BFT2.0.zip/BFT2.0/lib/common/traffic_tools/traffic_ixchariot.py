''' Class defination for Ixchariot traffic tool.'''
__author__ = "Sunil"
__copyright__ = "Copyright 2019, Intel Corporation"
__version__ = "0.0.1"
__maintainer__ = "Mirafra"
__email__ = "framework@mirafra.com"
__status__ = "Development"
###########################################################
import re
from globalVariables import *
from lib.common.traffic_tools.traffic_tool import *
from devices.interact_tools.interact_pexpect import *
from devices.interact_tools.interact_paramiko import *


class TrafficIxchariot(TrafficTool):
    '''
    A class used to represent traffic tool

    ...

    Attributes
    ----------


    Methods
    -------
    '''

    def __init__(self,
                 platform_type=None):

        self.platform_type = platform_type

    def config_update(self, platform_handle, interact_handle, prompt, device_dict=None, dname=None):
        '''Get the interact tool handle'''
        self.platform =platform_handle
        self.session = interact_handle
        self.prompt = prompt
        self.dict = device_dict
        self.dname = dname

    def start_client(self, ip):
        pass

    def start_server(self):
        pass

    def check_traffic_tool(self):
        pass

    def parse_output(self, temp_rate):
        pass

    def test_func(self):
        print("method inside in this class %s" % self.__class__.__name__)

if __name__ == "__main__":
    obj = TrafficIxchariot()
    obj.test_func()
