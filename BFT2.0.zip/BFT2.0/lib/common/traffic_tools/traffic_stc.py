"""
Class definition for stc traffic tool.
"""
__author__ = "Sunil"
__copyright__ = "Copyright 2019, Intel Corporation"
__version__ = "0.0.1"
__maintainer__ = "Mirafra"
__email__ = "framework@mirafra.com"
__status__ = "Development"

###########################################################
import os
import re
import operator
import traceback

from devices.interact_tools.interact_paramiko import *
from devices.interact_tools.interact_pexpect import *
from framework.publish_info_to_html import publish_html
from globalVariables import *
from lib.common.traffic_tools.traffic_tool import *
from log_creator import logger as logClass
from log_creator import loggerObject as logger


class TrafficStc(TrafficTool):
    """
    A class used to represent traffic tool for Spirent traffic

    Attributes
    ----------
    Methods
    -------
    """
    def __init__(self, platform_type=None):
        """
        Initializes the platform for the stc class
        Args:
            None
        Returns:
            None
        """
        self.platform_type = platform_type

    def config_update(self, platform_handle, interact_handle, prompt, device_dict=None, dname=None):
        """
        Get the interact tool handle
        Args:
            pltaform_handle: Used to get the platform type(Linux|Windows)
            interact_handle: Used to get the transport handle(Pexcept|Paramiko)
            device_dict     : Carries the device details as a dict
        Returns:
            None
        """
        self.platform = platform_handle
        self.session = interact_handle
        self.prompt = prompt
        self.dict = device_dict
        self.dname = dname

    def init_traffic(self, traffic_dict):
        """
        Initialize the self.traffic_params and end_params for stc
        Args:
            traffic_dict: traffic_dict having spirent varaibes
            traffic_dict['stc_dev'] : STC device object Used to execute the tclsh script
        Returns: (boolean)
            True : On successfully initialization of stc Variables
            False : On failure of updating self.traffic_params and end_params
        Raises:
            None
        """
        try:
            self.tcl_path = traffic_dict['stc_dev'].dict["TCL_path"]
            self.td_stc_udp_performance_script = traffic_dict['stc_dev'].dict["TCL_script"]
            self.special_param = "endpoint_count " + traffic_dict['pair1']["endpoint_count"] + " " + \
                                 "trafficparam_count " + traffic_dict['pair1']["trafficparam_count"]
            # Updates the Lan endpoint parametrs for tclsh Script
            self.end_point_param_1 = "Name " + traffic_dict['pair1']["LAN_Name"] + " "
            self.end_point_param_1 += "PhyIfName " + traffic_dict['stc_dev'].dict["LAN_PhyIfName"] + " "
            self.end_point_param_1 += "DUTPortID " + traffic_dict['pair1']["LAN_DUTPortID"] + " "
            self.end_point_param_1 += "EndpointIP " + traffic_dict['stc_dev'].dict["LAN_EndpointIP"] + " "
            self.end_point_param_1 += "DUTPortIPAddr " + traffic_dict['stc_dev'].dict["LAN_DUTPortIPAddr"]
            # Updates the Wan endpoints parameters for tclsh script
            self.end_point_param_2 = "Name " + traffic_dict['pair1']["WAN_Name"] + " "
            self.end_point_param_2 += "PhyIfName " + traffic_dict['stc_dev'].dict["WAN_PhyIfName"] + " "
            self.end_point_param_2 += "DUTPortID " + traffic_dict['pair1']["WAN_DUTPortID"] + " "
            self.end_point_param_2 += "EndpointIP " + traffic_dict['stc_dev'].dict["WAN_EndpointIP"] + " "
            self.end_point_param_2 += "DUTPortIPAddr " + traffic_dict['stc_dev'].dict["WAN_DUTPortIPAddr"] + " "
            self.end_point_param_2 += "VLANID " + traffic_dict['stc_dev'].dict["WAN_VLANID"] + " "
            self.end_point_param_2 += "BRASEmulation " + traffic_dict['pair1']["config"]["WAN_BRASEmulation"] + " "
            # Updates the traffic_params for the tclsh script
            self.traffic_param = "ServerEndpointName " + traffic_dict['pair1']["ServerEndpointName"] + " "
            self.traffic_param += "ClientEndpointName " + traffic_dict['pair1']["ClientEndpointName"] + " "
            self.traffic_param += "PairCount " + traffic_dict['pair1']["config"]["PairCount"] + " "
            self.traffic_param += "L4ProtocolType " + traffic_dict['pair1']["config"]["L4ProtocolType"] + " "
            self.traffic_param += "TrafficDirection " + traffic_dict['stream'] + " "
            self.traffic_param += "LossTolerance " + traffic_dict['pair1']["config"]["LossTolerance"] + " "
            self.traffic_param += "DecimalPlaces " + traffic_dict['pair1']["config"]["DecimalPlaces"] + " "
            self.traffic_param += "IterativeSearchDuration " + \
                                  traffic_dict['pair1']["config"]["IterativeSearchDuration"] + " "
            self.traffic_param += "MaxIterations " + traffic_dict['pair1']["config"]["MaxIterations"] + " "
            self.traffic_param += "SearchMethod " + traffic_dict['pair1']["config"]["SearchMethod"] + " "
            self.traffic_param += "MinValue " + traffic_dict['pair1']["config"]["MinValue"] + " "
            self.traffic_param += "MaxValue " + traffic_dict['pair1']["config"]["MaxValue"] + " "
            self.traffic_param += "StepValue " + traffic_dict['pair1']["config"]["StepValue"] + " "
            self.traffic_param += "StartValue " + traffic_dict['pair1']["config"]["StartValue"] + " "
            self.traffic_param += "udp_packet_len " + "{" + traffic_dict['pair1']['config']['bufferlen'] + "}"
            return True
        except (KeyError, ValueError, Exception) as e:
            self.logger.dumpLog(str(e))
            return False

    def run_traffic(self, traffic_dict):
        """
        It would run the stc traffic as per the parameters passed in the test suite, then stop and parse
        the stc throughput
        Args:
            traffic_dict (dict): Input dictionary to pass parameters to run traffic for stc tool (client, server)
            Mandatory Args:
                traffic_dict['stc_dev'] : STC device object Used to execute the tclsh script
		traffic_dict['stc_dev'].dict["TCL_path"] : TCL_path denotes directory path where TCL script present
		traffic_dict['stc_dev'].dict["TCL_script"] : TCL_script contains STC libraries to connect/start/verify STC traffic
		traffic_dict['pair1']["endpoint_count"]	: endpoint_count denotes number of end points connected to STC
		traffic_dict['pair1']["trafficparam_count"] : trafficparam_count denotes how many traffic parameters we are passing
		traffic_dict['pair1']["LAN_Name"] : LAN_Name denotes name of the LAN device we are using
		traffic_dict['stc_dev'].dict["LAN_PhyIfName"] :	LAN_PhyIfName denotes interface name connected to STC from LAN device
		traffic_dict['pair1']["LAN_DUTPortID"] : LAN_DUTPortID denotes ID for the LAN port connected to STC
		traffic_dict['stc_dev'].dict["LAN_EndpointIP"] : LAN_EndpointIP denotes inteface IP connected to STC from LAN device
		traffic_dict['stc_dev'].dict["LAN_DUTPortIPAddr"] : LAN_DUTPortIPAddr denotes inteface IP connected to DUT to LAN device
		traffic_dict['pair1']["WAN_Name"] : WAN_Name denotes name of the WAN device we are using
		traffic_dict['stc_dev'].dict["WAN_PhyIfName"] : WAN_PhyIfName denotes interface name connected to STC from WAN device
		traffic_dict['pair1']["WAN_DUTPortID"] : WAN_DUTPortID denotes ID for the WAN port connected to STC
		traffic_dict['stc_dev'].dict["WAN_EndpointIP"] : WAN_EndpointIP denotes inteface IP connected to STC from WAN device
		traffic_dict['stc_dev'].dict["WAN_DUTPortIPAddr"] : WAN_DUTPortIPAddr denotes inteface IP connected to DUT to WAN device
		traffic_dict['stc_dev'].dict["WAN_VLANID"] : WAN_VLANID denotes vlan which we are using when communicating with STC from WAN
		traffic_dict['pair1']["config"]["WAN_BRASEmulation"] : WAN_BRASEmulation denotes WAN mode which we want to communicate with STC                traffic_dict['pair1']["ServerEndpointName"] : ServerEndpointName denotes server name
		traffic_dict['pair1']["ClientEndpointName"] : ClientEndpointName denotes client name
		traffic_dict['pair1']["config"]["PairCount"] : PairCount denotes number of pairs we are using
		traffic_dict['pair1']["config"]["L4ProtocolType"] : L4ProtocolType denotes which protocol we are using like udp
		traffic_dict['stream'] : stream denotes which direction traffic should flow like upstream/downstream/bidi
		traffic_dict['pair1']["config"]["LossTolerance"] : LossTolerance denotes how much failure rate we need to tolerate before fail
		traffic_dict['pair1']["config"]["DecimalPlaces"] : DecimalPlaces denotes how many decimal places need to show when calcuating traffic
		traffic_dict['pair1']["config"]["IterativeSearchDuration"] : IterativeSearchDuration denotes duration for searching output
		traffic_dict['pair1']["config"]["MaxIterations"] : MaxIterations denotes number of iterations we need to check for traffic
		traffic_dict['pair1']["config"]["SearchMethod"] : SearchMethod denotes which method we need to use for checking the traffic
		traffic_dict['pair1']["config"]["MinValue"] : MinValue denotes minimum value to be used for checking the traffic
		traffic_dict['pair1']["config"]["MaxValue"] : MaxValue denotes maximum value to be used for checking the traffic
		traffic_dict['pair1']["config"]["StepValue"] : StepValue denotes step value to be used for checking the traffic
		traffic_dict['pair1']["config"]["StartValue"] : StartValue denotes start value to be used for checking the traffic
		traffic_dict['pair1']['config']['bufferlen'] : bufferlen denotes packet length to be used for checking the traffic
        Returns:
            result_dict (dict): dictionary as below
        Raises:
            Raises KeyError, ValueError if key or value is not found in the input argument or the format is incorrect.
            Exception when the iperf doesn't start on either client or server for any pair.
        """
        try:
            # initializing the self.traffic_param and end_params
            if not self.init_traffic(traffic_dict):
                publish_html(comment="ERROR: Unable to update the Stc Configuration Variables")
                raise Exception("ERROR: Unable to update the Stc Configuration Variables")
            # Start traffic with params from traffic_dict and return the output
            self.start_traffic(traffic_dict)
            # Stop the traffic and fetch the results in a dict and return the dict
            result_dict = self.stop_traffic(traffic_dict)
            return result_dict
        except Exception as e:
            self.logger.dumpLog("Unable to run the stc Traffic Successfully")
            publish_html(comment="ERROR: Unable to run the stc Traffic Successfully")
            raise Exception("ERROR: Unable to run the Stc Traffic Successfully")

    def start_traffic(self, traffic_dict):
        """
        Generates the tclsh command and execute the tclash Script on stc machine
        Args:
           traffic_dict (dict): Input dictionary to pass parameters to run traffic for stc tool (client, server)
        Returns:
           None
        """
        self.logger.dumpLog("Executing the tclsh Script : {}".format(self.td_stc_udp_performance_script))
        # Generate the sct execution command
        stc_command = self._generate_stc_cmd()
        self.logger.dumpLog("{}".format(stc_command))
        # time for the tclsh script to execute
        self.time_out = int(traffic_dict['pair1']["config"]["MaxIterations"]) * 100
        if self.time_out <= 700:
            self.time_out = 700
        else:
            self.time_out = self.time_out
        # Starts the tclsh Script
        traffic_dict['stc_dev'].session.send_line(stc_command,timeout=self.time_out)

    def stop_traffic(self, traffic_dict):
        """
        Waits for the tcl Script to finish and greps the output and return's in a dict(result_dict['max_tput'])
        Args:
            traffic_dict : traffic_dict having the stc configurable parameters
        Returns:
            Returns a dict having 'max_tput'
        """
        result_dict = {}
        result_dict['pair1'] = {}
        if traffic_dict['stream'].lower() == "upstream":
            try:
                traffic_dict['stc_dev'].session.recv_line('THROUGHPUT.*UPSTREAM\s+(\d+.\d+)', timeout=30)
                result_dict['pair1']['max_tput'] = str(float(traffic_dict['stc_dev'].session.match(1))) + \
                                                   " " + "Mbits/sec"
            except:
                result_dict['pair1']['max_tput'] = str(None)
                self.logger.dumpLog("Error : While fetching  the upstream output: {}".format
                                    (result_dict['pair1']['max_tput']))

            self.logger.dumpLog("Up stream throughput is : {}".format(result_dict['pair1']['max_tput']))
        elif traffic_dict['stream'].lower() == "downstream":
            try:
                traffic_dict['stc_dev'].session.recv_line('THROUGHPUT.*DOWNSTREAM\s+(\d+.\d+)', timeout=30)
                result_dict['pair1']['max_tput'] = str(float(traffic_dict['stc_dev'].session.match(1))) + \
                                                   " " + "Mbits/sec"
            except:
                result_dict['pair1']['max_tput'] = str(None)
                self.logger.dumpLog("Error : While fetching  the Downstream output: {}"
                                    .format(result_dict['pair1']['max_tput']))
            self.logger.dumpLog("Down stream throughput is : {}".format(result_dict['pair1']['max_tput']))
        elif traffic_dict['stream'].lower() == "bidirectional":
            try:
                traffic_dict['stc_dev'].session.recv_line('THROUGHPUT.*BIDIR-DOWN\s+(\d+.\d+).*BIDIR-UP\s+(\d+.\d+)', timeout=30)
                result_dict['pair1']['max_tput'] = str(float(traffic_dict['stc_dev'].session.match(1))) + \
                                                   " " + "Mbits/sec"
                result_dict['pair2']={}
                result_dict['pair2']['max_tput'] = str(float(traffic_dict['stc_dev'].session.match(2))) + \
                                                   " " + "Mbits/sec"
                self.logger.dumpLog("bidi stream Downstream throughput is :{} , Upstream throughput is : {}"
                                    .format(traffic_dict['stc_dev'].session.match(1),
                                            traffic_dict['stc_dev'].session.match(2)))
            except:
                result_dict['pair1']['max_tput'] = str(None)
                result_dict['pair2']['max_tput'] = str(None)
                self.logger.dumpLog("Error : While fetching the Bidirectional output: {}"
                                    .format(result_dict['pair1']['max_tput']))

            self.logger.dumpLog("Run Finished")
            self.logger.dumpLog("Results taken")
        return result_dict

    def _generate_stc_cmd(self):
        """
        A method to construct the stc command for execution
        Args:
            self.traffic_params and end_point Params
        Returns:
           stc execution command
        """
        try:
            script_cmd = "tclsh {}{} \"{}\" \"{}\" \"{}\" \"{}\"".format(self.tcl_path,
                                                                         self.td_stc_udp_performance_script,
                                                                         self.special_param,
                                                                         self.end_point_param_1,
                                                                         self.end_point_param_2,
                                                                         self.traffic_param)
            return script_cmd
        except Exception:
            publish_html(comment="ERROR: Error in _generate_stc_cmd ")
            self.logger.dumpLog("{}".format(traceback.format_exc()))

    def test_func(self):
        """
        Sample Method to test the stc class
        Args:
            None
        Returs:
            None
        """
        print("method inside in this class %s" % self.__class__.__name__)


if __name__ == "__main__":
    obj = TrafficStc()
    obj.test_func()
