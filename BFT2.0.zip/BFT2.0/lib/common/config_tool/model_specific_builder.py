import os
import sys
import inspect
import model_specific
from model_specific  import *
from log_creator import loggerObject as logger

def model_method_builder(cls):
    def __init__(self, os, session, prompt, device_dict=None, dname=None, logger=logger, class_list=None):
        self.os = os
        self.session = session
        self.prompt = prompt
        self.dict = device_dict
        self.dname = dname
        self.logger = logger
        #calling init functions of all parent classes
        for c_obj in list(class_list.split(",")):
            for ele in inspect.getmembers(eval(c_obj)):
                if "__init__" in ele:
                    eval(c_obj).__init__(self)

    __init__.__name__ = "__init__"
    setattr(cls,__init__.__name__,__init__)


def model_cmd(tool_name="", model_name="", os_handle="", session_handle="", prompt="", device_dict=None, dname=None,
              logger=logger):
    model_class_list = model_list_builder(tool_name,model_name)
    exec ('class ModelCmdHolder(' + model_class_list + '): pass')
    #This dynamic class is formed with multiple inheritance, Hence Lib writter should not use
    #same attribute names accross classes
    model_method_builder(ModelCmdHolder)
    return ModelCmdHolder(os_handle, session_handle, prompt, device_dict=device_dict, dname=dname, logger=logger,
                          class_list=model_class_list)

def model_list_builder(tool_name,model_name):
    '''Return string of classes in model_tool and chipset'''
    cls_list=''
    nm=model_name+tool_name
    for name, obj in inspect.getmembers(model_specific):
        if inspect.isclass(obj):
            if name == nm:
                fldr_name=model_name.lower() + "_" + tool_name.lower()
                exec("from model_specific.%s.%s import *" %(model_name.lower(),fldr_name))
                cls_list = cls_list + ',' + "model_specific.%s.%s." %(model_name.lower(),fldr_name) + name
    return cls_list.strip(',')

if __name__ == '__main__':
    obj=model_cmd(tool_name="Clish",model_name="Grx350")
    obj.test_grx350_clish()
    obj=model_cmd(tool_name="Clish",model_name="Grx550")
    obj.test_grx550_clish()
    obj=model_cmd(tool_name="Clish",model_name="Vrx288")
    obj.test_vrx288_clish()
    obj=model_cmd(tool_name="Uci",model_name="Grx350")
    obj.test_grx350_uci()
    obj=model_cmd(tool_name="Uci",model_name="Grx550")
    obj.test_grx550_uci()
    obj=model_cmd(tool_name="Uci",model_name="Vrx288")
    obj.test_vrx288_uci()
    obj=model_cmd(tool_name="Fapi",model_name="Grx350")
    obj.test_grx350_fapi()
    obj=model_cmd(tool_name="Fapi",model_name="Grx550")
    obj.test_grx550_fapi()
    obj=model_cmd(tool_name="Fapi",model_name="Vrx288")
    obj.test_vrx288_fapi()
    
