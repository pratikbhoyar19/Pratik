import paramiko
from scp import SCPClient
import re
from config import kpi_para
from log_creator import loggerObject as logger
from log_creator import logger as logClass

class UtilsFapi:

    def createSSHClient(self, server, port, user, password):
        client = paramiko.SSHClient()
        client.load_system_host_keys()
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        client.connect(server, port, user, password)
        return client

    def scp_download(self,
                     server=None,
                     port=None,
                     user=None,
                     password=None,
                     from_location=None,
                     to_location=None):
        """
        The function is to download file from dut to test machine
        Args:
            server(str): server address of dut
            port (str/int): ssh port number for dut
            user(str): username of dut
            password(str): password of dut
            from_location(str): source path in dut
            to_location(str): destination path in test machine
        Returns:
            result_dict["result"]: pass/fail
        """
        result_dict={}
        result_dict['result'] = 'pass'
        try:
            ssh = self.createSSHClient(server, port, user, password)
            scp = SCPClient(ssh.get_transport())
            scp.get(r'{}'.format(from_location), r'{}'.format(to_location))
        except Exception as err:
            logger.dumpLog("scp download failed")
            result_dict['result'] = 'fail'
        return result_dict

    def scp_upload(self,
                   server=None,
                   port=None,
                   user=None,
                   password=None,
                   from_location=None,
                   to_location=None):
        """
        The function is to upload file to dut from test machine
        Args:
            server(str): server address of dut
            port (str/int): ssh port number for dut
            user(str): username of dut
            password(str): password of dut
            from_location(str): source path in test machine
            to_location(str): destination path in dut
        Returns:
            result_dict["result"]: pass/fail
        """
        result_dict={}
        result_dict['result'] = 'pass'
        try:
            ssh = self.createSSHClient(server, port, user, password)
            scp = SCPClient(ssh.get_transport())
            scp.put(r'{}'.format(from_location), r'{}'.format(to_location))
        except Exception as err:
            logger.dumpLog("scp upload failed")
            result_dict['result'] = 'fail'
        return result_dict

    def start_profiling_tool(self, exe_time=None):
        """
        This function is used to start profiling_tool(pecostat) tool
        Args:
            time(str/int):specific time
        Returns:
            result_dict["result"]: pass/fail
        """
        result_dict = {}
        result_dict["result"] = "pass"
        tool_status = self.check_profiling_tool()
        if tool_status:
            try:
                ti = int(int(exe_time) * 0.9)
                #if the pecostat is previously present kill it
                self.kill_profiling_tool()
                #if file is exit remove it
                self.session.send_recv("rm -rf /tmp/CPU_Util_file", timeout=20)
                #run the pecostat command
                self.session.send_line("pecostat -c pic0=0,EXL,K,S,U,IE 1 {} &>/tmp/CPU_Util_file &".format(ti))
                self.session.recv_line(self.prompt, timeout=20)
            except Exception:
                logger.dumpLog("Failed to start pecostat")
                result_dict["result"] = "fail"
        else:
            logger.dumpLog("pecostat is not present")
            result_dict["result"] = "fail"
        return result_dict

    def get_cpu_usage(self):
        """
        This function is used to parse the output of pecostat and calculating the avg cpu
        Args:
            None
        Returns:
            result_dict["result"]: pass/fail
            result_dict["avg_core_0"]: avg core0 val
            result_dict["avg_core_1"]: avg core0 val
        """
        result_dict = {}
        result_dict["result"] = "pass"
        count = 0
        try:
            output = self.session.send_recv("cat /tmp/CPU_Util_file", timeout=20)
            stop_op = re.findall(r'.*?Core0\s+load\s+\((\s+\d+.\d+|\d+.\d+).*?Core1\s+load\s+\((\s+\d+.\d+|\d+.\d+)', output)
            for i in stop_op:
                core0 = sum([(float(i[0])) for i in stop_op])
                core1 = sum([(float(i[1])) for i in stop_op])
                count = count+1
            avg_core_0 = core0/count
            avg_core_1 = core1/count
            logger.dumpLog("core0:{} ; core1:{}".format(avg_core_0, avg_core_1))
            result_dict['avg_core_0'] = avg_core_0
            result_dict['avg_core_1'] = avg_core_1
        except Exception:
            logger.dumpLog("pecostat file CPU_Util_file is empty in /tmp")
            result_dict["result"] = "fail"
        return result_dict

    def check_profiling_tool(self):
        """
        This function is used to check  profiling_tool present on the system
        Args:
            None
        Returns:
            result_dict["result"]=pass/fail
        """
        result_dict = {}
        result_dict["result"] = "pass"
        o_buf = self.session.send_recv("pecostat -V", timeout=20)
        if o_buf != None:
            s_obj = re.search(r'pecostat version',o_buf)
            if s_obj != None:
                logger.dumpLog("pecostat is present {}".format(s_obj.groups()))
            else:
                logger.dumpLog("pecostat is not present")
                result_dict["result"] = "fail"
        else:
            logger.dumpLog("pecostat is not present")
            result_dict["result"] = "fail"
        return result_dict

    def kill_profiling_tool(self):
        """
        This function is use stop pecostat in the system
        Args:
            None
        Returns:
            result_dict["result"]=pass/fail
        """
        result_dict = {}
        result_dict["result"] = "pass"
        try:
            self.session.send_recv("killall pecostat", timeout=20)
        except Exception as err:
            logger.dumpLog("{}".format(str(err)))
            result_dict["result"] = "fail"
        return result_dict


    def get_kpi_value(self,
                      wan_conn=None,
                      mode=None,
                      wan_proto=None,
                      accel_type=None,
                      stream=None,
                      proto=None,
                      pckt_len=None):
        """
        The function is to get KPI Value for combination
        Args:
            wan_conn(str): eth_tag/eth_untag/vdsl_ptm_30/vdsl_ptm_17a/adsl_atm
            mode(str): route/bridge
            wan_proto(str): static/dhcp/pppoe
            accel_type(str): PAE/MPE/SW_ACCEL/CPU_PATH
            stream(str): upstream/downstream/bidi
            proto(str): tcp/udp
            pckt_len(str): applicable for only udp
        Returns:
            result_dict["result"]: pass/fail
            result_dict["kpi"]: kpi value
        """
        result_dict = {}
        result_dict["result"] = "pass"
        kpi = None
        try:
            if mode.lower() == "route":
                if proto.lower() == "tcp":
                    kpi = kpi_para['KPI'][wan_conn.lower()][mode.lower()][wan_proto.lower()][accel_type.upper()][stream.lower()][proto.lower()]
                else:
                    kpi = kpi_para['KPI'][wan_conn.lower()][mode.lower()][wan_proto.lower()][accel_type.upper()]\
                    [stream.lower()][proto.lower()][int(pckt_len)]
            elif mode.lower() == "bridge":
                if proto.lower() == "tcp":
                    kpi = kpi_para['KPI'][wan_conn.lower()][mode.lower()][accel_type.upper()][stream.lower()][proto.lower()]
                else:
                    kpi = kpi_para['KPI'][wan_conn.lower()][mode.lower()][accel_type.upper()][stream.lower()][proto.lower()][int(pckt_len)]
            else:
                logger.dumpLog("None of the mode matched")
                result_dict["result"] = "fail"
        except Exception as err:
            logger.dumpLog("{}".format(str(err)))
            result_dict["result"] = "fail"

        if kpi != None:
            kpi = float(kpi) - (( float(kpi) * float(kpi_para['KPI']['tolerance'])) / 100)
            result_dict['kpi'] = float(kpi)
        return result_dict


