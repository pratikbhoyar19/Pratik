from globalVariables import *
import re
import time
from log_creator import loggerObject as logger
from log_creator import logger as logClass

class WanFapi:
    """This class will contain all fapi APIs related to Ipv4 functionality"""

    def __init__(self):
        pass

    def wan_create_conn(self,
            wan_conn=None,
            vlan_id=None,
            mode=None,
            vpi=None,
            vci=None):
        """
        The function is to configure the WAN connection of dut with standard linux commands
        Args:
            wan_conn(str): eth_tag/eth_untag
            vlan_id(str): vlan id to be used for tagged connections
            mode(str): route/bridge
        Returns:
            result_dict["result"]: pass/fail
        """
        result_dict = {}
        result_dict["result"]="pass"
        try:
            logger.dumpLog("Configure the wan mode.......")
            self.vlan_id = 0

            #wan interface creation as per wan_conn
            if wan_conn == "eth_untag":
                wan_iface = self.dict['eth_iface']
            elif wan_conn == "eth_tag":
                wan_iface = '{}.{}'.format(self.dict['eth_iface'],vlan_id)
                self.create_vlan_iface(iface=self.dict['eth_iface'], vlan_id=vlan_id)
            elif wan_conn == "vdsl_ptm_17a" or wan_conn == "vdsl_ptm_30":
                wan_iface = '{}.{}'.format(self.dict['vdsl_ptm_iface'], vlan_id)
                self.create_vlan_iface(iface=self.dict['vdsl_ptm_iface'], vlan_id=vlan_id)
            elif wan_conn == "adsl_atm":
                n_obj = re.search(r'nas(\d+)', self.dict['adsl_atm_iface'])
                nas_id = n_obj.group(1)
                #providing default values as per setups, if inputs not passed
                if vpi == None:
                    vpi = 1
                if vci == None:
                    vci = int(vlan_id)

                vpi_vci = "{}.{}".format(vpi,vci)
                op_d = self.config_adsl_atm_iface(mode=mode, nas_id=nas_id, encaps=0, vpi_vci=vpi_vci)
                if op_d['result'] == 'fail':
                    result_dict["result"] = "fail"
                    return result_dict
                op_d = self.verify_adsl(nas_id=nas_id, vpi=vpi, vci=vci)
                if op_d['result'] == 'fail':
                    result_dict["result"] = "fail"
                    return result_dict
                wan_iface = '{}'.format(self.dict['adsl_atm_iface'])
            else:
                logger.dumpLog("{} is not correct interface".format(wan_iface))
                result_dict["result"] = "fail"
                return result_dict

            result_dict['wan_iface'] = wan_iface
            logger.dumpLog("WAN connection type received is {}".format(wan_conn))
            logger.dumpLog("WAN interface received is {}".format(wan_iface))
        except Exception as err:
            result_dict["result"] = "fail"
            logger.dumpLog("{}".format(err))
        return result_dict

    def wan_mode_config(self,
            wan_proto=None,
            user=None,
            password=None,
            wan_iface=None,
            vlan_id=None):
        """
        The function is to configure the WAN mode of dut with standard linux commands
        Args:
            wan_proto(str): dhcp/static
            user(str): pppoe user name
            password(str): pppoe password
            wan_iface(str): iface to be configured
            vlan_id(str): vlan id to be used for tagged connections
        Returns:
            result_dict["result"]: pass/fail
            result_dict["ipaddr"]: ipaddr of wan port of dut
        """
        result_dict = {}
        result_dict["result"]="pass"
        try:
            logger.dumpLog("Configure the wan mode.......")
            self.vlan_id = 0
            self.wan_proto = wan_proto

            #configure protocol as per wan_mode
            if(wan_proto == "dhcp"):
                logger.dumpLog("WAN proto received is {}".format(wan_proto))
                op_d = self.config_dhcp_ip(iface=wan_iface)
            elif(wan_proto == "static"):
                if 'ptm' in wan_iface:
                    vlan_id = None
                    self.static_gw = self.dict['vdsl_ptm_gw']
                    self.static_ip = self.dict['static_vdsl_ptm_ip']
                elif 'nas' in wan_iface:
                    self.static_gw = self.dict['adsl_atm_gw']
                    self.static_ip = self.dict['static_adsl_atm_ip']
                else:
                    self.static_gw = self.dict['eth_gw']
                    self.static_ip = self.dict['static_eth_ip']

                op_d = self.os.config_static_ip(iface=wan_iface,
                                         static_ip=self.static_ip,
                                         netmask=self.dict['netmask'],
                                         vlan_id=vlan_id,
                                         gw=self.static_gw)
            elif(wan_proto == "pppoe"):
                op_d = self.os.config_pppoe_ip(iface=wan_iface,
                                               user=user,
                                               password=password)
                self.set_ppp_gw()
            else:
                result_dict["result"] = "fail"
                return result_dict

            if op_d['result'] == "fail":
                result_dict['result'] = "fail"
                return result_dict

        except Exception as err:
            result_dict["result"] = "fail"
            logger.dumpLog("{}".format(err))
        return result_dict

    def get_ip(self, iface=None):
        """
        The function to get ip with retry
        Args:
             iface(str): interface to be polled
        Returns:
             result_dict["result"]: pass/fail
             result_dict["ip"]:ip addr of interface
        """
        result_dict = {}
        result_dict["result"] = "pass"
        try:
            for i in range(0, 5):
                result_dict["ip"] = self.os.get_interface_ipaddr(iface)
                if not result_dict["ip"]:
                    time.sleep(5)
                    continue
                else:
                    break
            if i > 4:
                result_dict["result"] = "fail"
        except Exception as err:
            result_dict["result"] = "fail"
            logger.dumpLog("{}".format(err))
        return result_dict

    def config_dhcp_ip(self, iface=None):
        """
        The function to do dhcp configurations to interface
        Args:
             iface(str): interface on which ip needed
        Returns:
             result_dict["result"]: pass/fail
        """
        result_dict = {}
        result_dict["result"] = "pass"
        try:
            buf = self.session.send_recv("cat /etc/config.sh", timeout=20)
            s_ob = re.search('No such file or directory', buf)
            if s_ob != None:#file not present
                self.session.send_recv("touch /etc/config.sh", timeout=20)
            self.session.send_control('C')
            self.session.send_line('udhcpc -i %s -b'% iface)
            u_ob = self.session.recv_line('udhcpc:\s+setting\s+default\s+routers:', timeout=20)
            if u_ob == None:
                logger.dumpLog("udhcpc not able to get ip...aborting..process")
                self.session.send_control('C')
                result_dict["result"] = "fail"
        except Exception as err:
            result_dict["result"] = "fail"
            logger.dumpLog("{}".format(err))
        return result_dict

    def release_dhcp_ip(self, iface=None):
        """
        The function to release dhcp ip from interface
        Args:
             iface(str): interface on which ip to be removed
        Returns:
             result_dict["result"]: pass/fail
        """
        result_dict = {}
        result_dict["result"] = "pass"
        try:
            while True:
                cnt = 0
                output=self.session.send_recv('ps', timeout=20)
                pid_lst=re.findall('(\d+).*udhcpc\s+-i\s+%s'%iface,output)
                for pid in pid_lst:
                    cnt+=1
                    self.session.send_recv('kill -s USR2 {}'.format(pid), timeout=20)
                    self.session.send_recv('kill -9 {}'.format(pid), timeout=20)
                if cnt == 0:
                    break
        except Exception as err:
            result_dict["result"] = "fail"
            logger.dumpLog("{}".format(err))
        return result_dict

    def reset_network_defaults(self, wan_proto=None, wan_iface=None):
        """
        The function to reset network configurations set during wan creation
        Args:
            wan_proto(str): dhcp/static
        Returns:
            result_dict["result"]: pass/fail
        """
        op_dict = {}
        op_dict["result"] = "pass"
        result_dict = {}
        result_dict["result"] = "pass"
        try:
            if wan_proto == "dhcp":
                op_dict = self.release_dhcp_ip(iface=wan_iface)
            elif wan_proto == "static":
                op_dict = self.os.remove_static_ip(iface=wan_iface)
            if op_dict["result"] == "fail":
                result_dict["result"] = "fail"

            if wan_proto == "pppoe":
                self.session.send_recv("killall pppd", timeout=10)
                time.sleep(2)
        except Exception as err:
            result_dict["result"] = "fail"
            logger.dumpLog("{}".format(err))

        return result_dict

    def create_vlan_iface(self, iface=None, vlan_id=None):
        """
        The function to create vlan interface
        Args:
            iface(str): physical interface
            vlan_id(str): vlan id to be used
        Returns:
            result_dict["result"]: pass/fail
        """
        result_dict = {}
        result_dict["result"] = "pass"
        try:
            self.session.send_recv("ifconfig {} up".format(iface), timeout=20)
            self.session.send_recv("ip link add link {} name {}.{} type vlan id {}".format(iface,iface,vlan_id,vlan_id), timeout=20)
            self.session.send_recv("ifconfig {}.{} up".format(iface,vlan_id), timeout=20)
            buf = self.session.send_recv("ifconfig {}.{}".format(iface,vlan_id), timeout=20)
            s_obj = re.search('Device not found', buf)
            if s_obj != None:#iface not added successfully
                result_dict["result"] = "fail"
        except Exception as err:
            logger.dumpLog("{}".format(err))
            result_dict["result"] = "fail"
        return result_dict

    def rm_extra_ifaces(self):
        """
        The function to remove redundant wan interfaces
        Args:
            iface(str): interface to be matched
        Returns:
            result_dict["result"]: pass/fail
        """
        result_dict = {}
        result_dict['result'] = "pass"
        try:
            output = self.session.send_recv("ifconfig", timeout=20)
            #iface_lst = re.findall(r'{}_.\n*\w+'.format(self.dict['eth_iface']), output)
            iface_lst = list()
            self.session.send_recv("killall pppd", timeout=20)
            self.session.send_recv("killall br268ctl", timeout=20)
            self.session.send_recv("killall udhcpc", timeout=20)
            iface_lst.extend(re.findall('pppoe_\w+|ppp\d+|ptm\d+_\w+|nas\d+_\w+|ptm\d+\.\d+|{}_\w+|{}\.\d+'.format(self.dict['eth_iface'], self.dict['eth_iface']), output))
            #removing all interfaces present in list
            for w_iface in iface_lst:
                self.session.send_recv("ip link delete {}".format(w_iface), timeout=20)
        except Exception as err:
            logger.dumpLog("{}".format(err))
            result_dict["result"] = "fail"
        return result_dict

    def get_dut_wan_ip(self,wan_iface=None):
        """
        The function is to get wan ip of dut
        Args:
            wan_iface(str): iface whoes ip is needed
        Returns:
            result_dict["result"]: pass/fail
        """
        result_dict = {}
        result_dict['result'] = "pass"
        try:
            if_status = self.os.get_interface_status(wan_iface)
            if not if_status:
                result_dict['result'] = 'fail'
                return result_dict
            ipaddr_d = self.get_ip(iface=wan_iface)
            if ipaddr_d["result"] == "fail":
                result_dict['result'] = 'fail'
                return result_dict
            result_dict['ipaddr'] = ipaddr_d['ip']
        except Exception as err:
            result_dict["result"] = "fail"
            logger.dumpLog("{}".format(err))
        return result_dict

    def get_ppp_iface(self):
        """
        Function to get the ppp interface
        Args:
            None
        Returns:
            result_dict["result"]: pass/fail
        """
        result_dict = {}
        result_dict['result'] = "pass"
        ppp_iface = None
        try:
            for i in range(0,5):
                output = self.session.send_recv("ifconfig", timeout=20)
                if output != None:
                    s_obj = re.search(r'(ppp\d+)\s+Link',output)
                    if s_obj != None:
                        ppp_iface = s_obj.group(1)
                        result_dict['ppp_iface'] = ppp_iface
                        logger.dumpLog("ppp iface obtained is {}".format(result_dict['ppp_iface']))
                        break
                    else:
                        time.sleep(2)
                        continue
            if ppp_iface == None:
                result_dict['result'] = "fail"
        except Exception as err:
            result_dict["result"] = "fail"
            logger.dumpLog("{}".format(err))
        return result_dict

    def set_ppp_gw(self):
        result_dict = {}
        result_dict['result'] = "pass"
        try:
            ppp_d = self.get_ppp_iface()
            if ppp_d['result'] != "fail":
                ip_d = self.get_ip(iface=ppp_d['ppp_iface'])
                if ip_d['result'] != "fail":
                    ip = ip_d['ip']
                    tmp = ip.split('.')
                    tmp[3] = '1'
                    self.gw = '.'.join(tmp)
                    logger.dumpLog("Setting gw {}".format(self.gw))
                    self.session.send_recv("route add default gw {}".format(self.gw), timeout=20)
                else:
                    logger.dumpLog("not able to get ip")
            else:
                logger.dumpLog("not able to get iface")
        except Exception as err:
            result_dict["result"] = "fail"
            logger.dumpLog("{}".format(err))
        return result_dict

    def debug_func(self):
        print("Method inside this class %s" % self.__class__.__name__)

    def test_wan_fapi(self):
        print("method inside class WanFapi")

if __name__ == "__main__":
    obj = WanFapi()
    obj.debug_func()
