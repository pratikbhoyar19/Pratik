import re
import time
from log_creator import loggerObject as logger
from log_creator import logger as logClass

class DslFapi:
    """This class will contain all fapi APIs related to ADSL and VDSL functionality"""

    def __init__(self):
        pass

    def config_adsl_atm_iface(self, mode=None, nas_id=None, encaps=None, atm_qos=None, vpi_vci=None, sendbuf=None):
        """
        This function is used for the adsl configuration
        Args:
            mode(str): 0 - Route, 1 - Bridge(Default)
            nas_id(int/str): nasid for atm interface
            encaps(int/str): 0 - LLC/SNAP (Default), 1 - VCMux
            atm_qos(str): qos config value  
            vpi_vci(str): pvc value in VPI.VCI format
            sendbuf(int/str): Sendbuf
        Returns: 
            result_dict["result"]: pass/fail
        """
        result_dict = {}
        result_dict['result'] = "pass"
        #killing existing br2684ctl process and making nas0 down if exists
        self.del_adsl(nas_id=nas_id)
        try:
            if mode.lower() == "route":
                br2684ctl_cmd = "-b -p 1 "
            elif mode.lower() == "bridge":
                br2684ctl_cmd = "-b -p 1 "
            else:
                logger.dumplog("{} mode not supported, taking default mode as \"route\"".format(mode))
                br2684ctl_cmd = "-b -p 1 "

            if nas_id != None:
                br2684ctl_cmd += "-c {} ".format(nas_id)
            else:
                br2684ctl_cmd += "-c 0 "
            
            if encaps != None:
                br2684ctl_cmd += "-e {} ".format(encaps)
            else:
                br2684ctl_cmd += "-e 0 "

            if atm_qos != None:
                br2684ctl_cmd += "-q {} ".format(atm_qos)
         
            if sendbuf != None:
                br2684ctl_cmd += "-s {} ".format(sendbuf)

            if vpi_vci !=None:
                br2684ctl_cmd += "-a {} ".format(vpi_vci)
            else:
                logger.dumpLog("vpi vci is must, cannot procced without it....., aborting")
                result_dict['result'] = "fail"
                return result_dict
                
            self.session.send_line("/usr/sbin/br2684ctl {}".format(br2684ctl_cmd), send_block=False)
            time.sleep(5) 
            self.session.send_line("")#to get prompt
            self.session.send_recv("ifconfig nas{} up".format(nas_id), timeout=20)
        except Exception as err:
            logger.dumpLog("{}".format(err))
            result_dict["result"] = "fail"
        return result_dict

    def verify_adsl(self, nas_id=None, vpi=None, vci=None):
        """
        This function is used to verify adsl configuration
        Args:
            nas_id(int):
            vpi(int):
            vci(int):
        returns:  
            result_dict["result"]:pass/fail
        """
        result_dict={}
        result_dict['result'] = "pass"
        try:
            adsl_buf = self.session.send_recv("cat /proc/net/atm/pvc", timeout=20)
            
            adsl_op = re.search(r'TX\(PCR,Class\)\s+(\d+)\s+(\d+)\s+(\d+)', adsl_buf, re.I)
         
            if adsl_op != None:
                if len(adsl_op.groups()) != 3:
                    logger.dumpLog("pvc count fail")
                    result_dict['result'] = 'fail'
                elif len(adsl_op.groups()) == 3:
                    logger.dumpLog("PVC count matched")
                    if adsl_op.group(1) == nas_id:
                        if adsl_op.group(2) == vpi and adsl_op.group(3) == vci:
                            result_dict['vpi'] = adsl_op.group(2)
                            result_dict['vci'] = adsl_op.group(3)
                            logger.dumpLog("nas_id:{}, vpi:{}, vci:{}".format(adsl_op.group(1),adsl_op.group(2),adsl_op.group(3)))
                    else:
                        logger.dumpLog("Entry not found")            
                        result_dict['result'] = 'fail'
        except Exception as err:
            logger.dumpLog("{}".format(err))
            result_dict["result"] = "fail"
        return result_dict

    def del_adsl(self, nas_id=None):
        """
        This function is used to delete adsl configuration
        Args:
            nas_id(int/str): nas identifier
        returns:  
            result_dict["result"]:pass/fail
        """
        result_dict={}
        result_dict['result'] = "pass"
        try:
            self.session.send_recv("killall br2684ctl", timeout=20)
            #kiiling if any remaining process if exsisting
            adsl_buf = self.session.send_recv("ps | grep br2684ctl", timeout=20)
            op_ps = re.findall(r'(\d+).*br2684ctl',adsl_buf)
            if op_ps != None:
                for pid in op_ps:
                    self.session.send_recv('kill -9 {}'.format(pid), timeout=20)
            
            #checking if nas iface is up, then make it down 
            if_op = self.session.send_recv("ifconfig nas{}".format(nas_id), timeout=20)
            if_buf = re.search(r'Device not found', if_op)
            if if_buf == None:#iface present
                self.session.send_recv("ifconfig nas{} 0.0.0.0 down".format(nas_id), timeout=20)
        except Exception as err:
            logger.dumpLog("{}".format(err))
            result_dict["result"] = "fail"
        return result_dict

    def del_vdsl(self, vlan_id=None):
        """
        This function is used to delete vdsl configuration
        Args:
            vlan_id(int):vlan id         
        Returns:
            result_dict["result"]:pass/fail 
        """
        result_dict = {}
        result_dict["result"] = "pass"
        try:
            self.session.send_recv("ip link delete {}.{}".format(self.dict['vdsl_ptm_iface'], vlan_id), timeout=20)
            self.session.send_recv("ifconfig {} down".format(self.dict['vdsl_ptm_iface']), timeout=20)
        except Exception as err:
            logger.dumpLog("{}".format(err))
            result_dict["result"] = "fail"
        return result_dict

    def dsl_auto_mode_config(self):
        """
        This function is used to dsl auto mode configuration
        Args:
            None         
        Returns:
            result_dict["result"]:pass/fail 
        """        
        result_dict = {}
        result_dict["result"] = "pass"
        try:
            self.session.send_line("/opt/intel/bin/dsl_cpe_pipe.sh g997xtusecs -1 05 00 04 00 4C 01 04 07")
            self.session.recv_line(self.prompt, timeout=60)
            self.session.send_line("/opt/intel/bin/dsl_cpe_pipe.sh sics -1 0 1 1 1 3")
            self.session.recv_line(self.prompt, timeout=60)
            self.session.send_line("/opt/intel/bin/dsl_cpe_pipe.sh sics -1 m 1 2 1 1 3")
            self.session.recv_line(self.prompt, timeout=60)
        except Exception as err:
            logger.dumpLog("{}".format(err))
            result_dict["result"] = "fail"
        return result_dict

    def verify_dsl_daemon(self):
        """
        This function is used to verify dsl daemon process
        Args:
            None    
        Returns:
            result_dict["result"]:pass/fail
        """
        result_dict = {} 
        result_dict["result"] = "pass"
        try:
            buf=self.session.send_recv("ps", timeout=20)
            output=re.search(r"dsl_cpe_control",buf)
            if output != None:
                logger.dumpLog("dsl daemon {}  is already runing".format(output.group()))
            else:
                logger.dumpLog("dsl_cpe_control daemon is not runing, need to start.......")
                result_dict["result"] = "fail"
        except Exception as err:
            result_dict["result"] = "fail"
            logger.dumpLog("{}".format(err))
        return result_dict
                                      
    def check_show_time(self):
        """This function is used to check show time  
        Args:
            None    
        Returns:
            result_dict["result"]:pass/fail
        """
        result_dict = {}
        result_dict["result"] = "pass"
        try:
            for i in range(0, 15):
                self.session.send_line("dsl lsg")
                self.session.recv_line('nLineState=0x(\d+)')
                show_output = self.session.match(1)
                if int(show_output) != 801:
                    logger.dumpLog("Show time not reached .....")
                    time.sleep(2)
                    continue
                else:
                    logger.dumpLog("Show time reached")
                    break
            if int(show_output) != 801:
                logger.dumpLog("Show time not reached, aborting........")
                result_dict["result"] = "fail"
        except Exception as err:
            logger.dumpLog("Check show time unsuccessfull")
            result_dict["result"] = "fail"
        return result_dict

    def debug_func(self):
        print("Method inside this class %s" % self.__class__.__name__)

    def test_wan_fapi(self):
        print("method inside class DslFapi")

if __name__ == "__main__":
    obj = DslFapi()
    obj.debug_func()
