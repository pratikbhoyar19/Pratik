

class FirewallFapi:
    """This class contains Fapi APIs related to firewall functionality"""

    def __init__(self):
        pass

    def add_msq_rule(self, iface=None):
        """
        The function to configure MASQUERADE rule in dut
            Args:
                iface(str): output interface on which MASQUERADE rule to be applied
            Returns:
                result_dict["result"]: pass/fail
        """
        result_dict = {}
        result_dict["result"] = "pass"
        try:
            self.session.send_line("iptables -t nat -A POSTROUTING -o {} -j MASQUERADE".format(iface))
            self.session.recv_line(self.prompt, timeout=20)
        except Exception as err:
            result_dict["result"] = "fail"
            logger.dumpLog("{}".format(err))
        return result_dict

    def update_preroute(self, wan_ip=None, flag=None):
        """
        The function to add the pre route entry
            Args:
                wan_ip(str): dut wan ip
                flag(str): A/D
            Returns:
                result_dict["result"]: pass/fail
        """
        result_dict = {}
        result_dict["result"] = "pass"
        if not (flag.upper() == "A" or flag.upper() == "D"):
            result_dict["result"] = "fail"
            logger.dumpLog("\"{}\" is not valid flag".format(flag))
            return result_dict
        try:
            self.session.send_line("iptables -%s FW_NAT_PREROUTING_WAN -t nat -d %s -j FW_NAT_PREROUTING" %(flag.upper(), wan_ip))
            self.session.recv_line(self.prompt, timeout=20)
            self.session.send_line("iptables -%s FW_NAT_PREROUTING_WAN -t nat -d %s -j ACCEPT" %(flag.upper(), wan_ip))
            self.session.recv_line(self.prompt, timeout=20)
        except Exception as err:
            result_dict["result"] = "fail"
            logger.dumpLog("{}".format(err))
        return result_dict

    def modify_dmz_rule(self, dest_ip=None, flag=None):
        """
        The function to enable or disable dmz in dut
            Args:
                dest_ip(str): lan host ip
                flag(str): ENABLE/DISABLE
            Returns:
                result_dict["result"]: pass/fail
        """
        result_dict = {}
        result_dict["result"] = "pass"
        try:
            if (flag.upper() == "ENABLE"):
                self.session.send_line("iptables -I FW_DMZ -s %s -m state --state ESTABLISHED,RELATED -j ACCEPT" % dest_ip)
                self.session.recv_line(self.prompt, timeout=20)
                self.session.send_line("iptables -I FW_DMZ -d %s -j ACCEPT" % dest_ip)
                self.session.recv_line(self.prompt, timeout=20)
                self.session.send_line("iptables -t nat -A FW_NAT_DMZ -j DNAT --to %s" % dest_ip)
                self.session.recv_line(self.prompt, timeout=20)
            elif(flag.upper() == "DISABLE"):
                self.session.send_line("iptables -D FW_DMZ -s %s -m state --state ESTABLISHED,RELATED -j ACCEPT" % dest_ip)
                self.session.recv_line(self.prompt, timeout=20)
                self.session.send_line("iptables -D FW_DMZ -d %s -j ACCEPT" % dest_ip)
                self.session.recv_line(self.prompt, timeout=20)
                self.session.send_line("iptables -t nat -D FW_NAT_DMZ -j DNAT --to %s" % dest_ip)
                self.session.recv_line(self.prompt, timeout=20)
            else:
                result_dict["result"] = "fail"
                logger.dumpLog("\"{}\" is not valid flag".format(flag))
                return result_dict
        except Exception as err:
            result_dict["result"] = "fail"
            logger.dumpLog("{}".format(err))
        return result_dict

    def modify_firewall(self, flag=None):
        """
        The function to enable or disable firewall in dut
            Args:
                flag(str): A/D, A: DISABLE, D: ENABLE
            Returns:
                result_dict["result"]: pass/fail
        """
        result_dict = {}
        result_dict["result"] = "pass"
        if not (flag.upper() == "A" or flag.upper() == "D"):
            result_dict["result"] = "fail"
            logger.dumpLog("\"{}\" is not valid flag".format(flag))
            return result_dict
        try:
            self.session.send_line("iptables -{} FW_DISABLE -p ALL -j ACCEPT".format(flag.upper()))
            self.session.recv_line(self.prompt, timeout=20)
        except Exception as err:
            result_dict["result"] = "fail"
            logger.dumpLog("{}".format(err))
        return result_dict

    def add_forward_traffic_rule(self, proto=None, port=None, ip_addr=None, iface=None):
        """
        This function is used to configure port forwarding
        Args:
           proto(str):protocol(tcp/udp)
           port(str/int):port number
           ip_addr(str):host ip address
           iface(str):Dut_WAN interface
         Returns:
              result_dict["result"]:pass/fail
        """
        result_dict = {}
        result_dict["result"] = "pass"
        if not (proto.lower() == "tcp" or proto.lower() == "udp"):
            result_dict["result"] = "fail"
            logger.dumpLog("\"{}\" is not valid proto".format(proto))
            return result_dict
        try:
            self.session.send_line("iptables -t nat -I PREROUTING -p {} --dport {} -j DNAT --to {} -i {}".format(proto.lower(), port, ip_addr, iface))
            self.session.recv_line(self.prompt, timeout=20)
            self.session.send_line("iptables -A FORWARD -d {} -p {} --dport {} -j ACCEPT -i {}".format(ip_addr, proto.lower(), port, iface))
            self.session.recv_line(self.prompt, timeout=20)
        except Exception as err:
            result_dict["result"] = "fail"
            logger.dumpLog("{}".format(err))
        return result_dict

    def del_forward_traffic_rule(self, proto=None, port=None, ip_addr=None, iface=None):
        """
        This function is used to remove configuration port forwarding
        Args:
           proto(str):protocol(tcp/udp)
           port(str/int):port number
           ip_addr(str):host ip address
           iface(str):DUT_WAN interface
        Returns:
              result_dict["result"]:pass/fail
        """
        result_dict={}
        result_dict["result"] = "pass"
        if not (proto.lower() == "tcp" or proto.lower() == "udp"):
            result_dict["result"] = "fail"
            logger.dumpLog("\"{}\" is not valid proto".format(proto))
            return result_dict
        try:
            self.session.send_line("iptables -t nat -D PREROUTING -p {} --dport {} -j DNAT --to {} -i {}".format(proto.lower(), port, ip_addr, iface))
            self.session.recv_line(self.prompt, timeout=20)
            self.session.send_line("iptables -D FORWARD -d {} -p {} --dport {} -j ACCEPT -i {}".format(ip_addr, proto.lower(), port, iface))
            self.session.recv_line(self.prompt, timeout=20)
        except Exception as err:
            result_dict["result"] = "fail"
            logger.dumpLog("{}".format(err))
        return result_dict

    def add_packet_filtering_rule(self, proto=None, port=None, rule_name=None):
        """
        This function is used to configure packet filtering
        Args:
           proto(str):protocol(tcp/udp)
           port(str/int):port number
           rule_name(str):ACCEPT/REJECT
        Returns:
           result_dict["result"]:pass/fail
        """
        result_dict = {}
        result_dict["result"] = "pass"
        if not (rule_name.upper() == "ACCEPT" or rule_name.upper() == "REJECT"):
            result_dict["result"] = "fail"
            logger.dumpLog("\"{}\" is not valid rule name".format(rule_name))
            return result_dict
        if not (proto.lower() == "tcp" or proto.lower() == "udp"):
            result_dict["result"] = "fail"
            logger.dumpLog("\"{}\" is not valid proto".format(proto))
            return result_dict
        try:
            self.session.send_line("iptables -I FW_PACKET_FILTER -p {} --dport {} -j {}".format(proto.lower(), port, rule_name.upper()))
            self.session.recv_line(self.prompt, timeout=20)
        except Exception as err:
            result_dict["result"] = "fail"
            logger.dumpLog("{}".format(err))
        return result_dict

    def del_packet_filtering_rule(self, proto=None, port=None, rule_name=None):
        """
        This function is used to remove packet filtering
        Args:
           proto(str):protocol(tcp/udp)
           port(str/int):port number
           rule_name(str):ACCEPT/REJECT
        Returns:
           result_dict["result"]:pass/fail
        """
        result_dict = {}
        result_dict["result"] = "pass"
	if not (rule_name.upper() == "ACCEPT" or rule_name.upper() == "REJECT"):
            result_dict["result"] = "fail"
            logger.dumpLog("\"{}\" is not valid rule name".format(rule_name))
            return result_dict
        if not (proto.lower() == "tcp" or proto.lower() == "udp"):
            result_dict["result"] = "fail"
            logger.dumpLog("\"{}\" is not valid proto".format(proto))
            return result_dict
        try:
            self.session.send_line("iptables -I FW_PACKET_FILTER -p {} --dport {} -j {}".format(proto.lower(), port, rule_name.upper()))
            self.session.recv_line(self.prompt, timeout=20)
        except Exception as err:
            result_dict["result"] = "fail"
            logger.dumpLog("{}".format(err))
        return result_dict

    def add_ipsec_firewall(self, remote_ip=None, wan_ip=None):
        """
        To establish the Ipsec tunnel in endpoint2
        Args:
            remote_ip(str):Remote IP address
            wan_ip(str):Wan ip address
        Returns:
            result_dict["result"]:pass/fail
        """
        result_dict = {}
        result_dict["result"] = "pass"
        try:
            self.session.send_line("iptables -D INPUT -s {}/32 -d {}/32 -j ACCEPT 2>/dev/null".format(remote_ip, wan_ip))
            self.session.recv_line(self.prompt,timeout=20)
            self.session.send_line("iptables -I INPUT -s {}/32 -d {}/32 -j ACCEPT".format(remote_ip, wan_ip))
            self.session.recv_line(self.prompt,timeout=20)
            self.session.send_line("iptables -t nat -D POSTROUTING -m policy --dir out --pol  ipsec --proto esp --mode tunnel -j ACCEPT 2>/dev/null")
            self.session.recv_line(self.prompt,timeout=20)
            self.session.send_line("iptables -t nat -I POSTROUTING -m policy --dir out --pol  ipsec --proto esp --mode tunnel -j ACCEPT")
            self.session.recv_line(self.prompt,timeout=20)
            '''limiting the packet size for avaoiding the bigger data packets'''
            self.session.send_line("iptables -t filter -I FORWARD 1 -p tcp --tcp-flags SYN,RST SYN -j TCPMSS --set-mss 1374")
            self.session.recv_line(self.prompt,timeout=20)
        except Exception as err:
            logger.dumpLog("{}".format(err))
            result_dict["result"] = "fail"
        return result_dict

    def del_ipsec_firewall(self, remote_ip=None, wan_ip=None):
        """
        To stop the Ipsec tunnel in endpoint2
        Args:
            remote_ip(str):Remote IP address
            wan_ip(str):Wan ip address
        Returns:
            result_dict["result"]:pass/fail
        """
        result_dict = {}
        result_dict["result"] = "pass"
        try:
            self.session.send_line("iptables -D INPUT -s {}/32 -d {}/32 -j ACCEPT 2>/dev/null".format(remote_ip, wan_ip))
            self.session.recv_line(self.prompt,timeout=20)
            self.session.send_line("iptables -D INPUT -s {}/32 -d {}/32 -j ACCEPT".format(remote_ip, wan_ip))
            self.session.recv_line(self.prompt,timeout=20)
            self.session.send_line("iptables -t nat -D POSTROUTING -m policy --dir out --pol  ipsec --proto esp --mode tunnel -j ACCEPT 2>/dev/null")
            self.session.recv_line(self.prompt,timeout=20)
            self.session.send_line("iptables -t filter -D FORWARD -p tcp --tcp-flags SYN,RST SYN -j TCPMSS --set-mss 1374")
            self.session.recv_line(self.prompt,timeout=20)
        except Exception as err:
            logger.dumpLog("{}".format(err))
            result_dict["result"] = "fail"
        return result_dict

    def debug_func(self):
        print("Method inside this class %s" % self.__class__.__name__)

    def test_firewall_fapi(self):
        print("method inside class FirewallFapi")


if __name__ == "__main__":
    obj = FirewallFapi()
    obj.debug_func()

