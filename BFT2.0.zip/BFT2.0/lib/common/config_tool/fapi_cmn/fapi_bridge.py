import re
import time
from log_creator import loggerObject as logger
from log_creator import logger as logClass

class BridgeFapi:
    """This class will contain all fapi APIs related to Bridge functionality"""

    def __init__(self):
        pass

    def config_bridge_mode(self, bridge_name=None, iface=None):
        """
        The function to configure the bridge mode in dut
        Args:
            bridge_name(str): name of bridge
            iface(str): interface to be added to bridge
         
        Returns:
            result_dict["result"]: pass/fail
        """
        result_dict = {}
        result_dict['result'] = "pass"
        try:
            self.session.send_recv("/etc/init.d/odhcpd stop", timeout=20)
            time.sleep(5)
            op_d = self.add_iface_bridge(bridge_name=bridge_name, iface=iface)
            if op_d['result'] == "fail":
                result_dict['result'] = op_d['result']
                return result_dict
                
            op_d = self.validate_bridge(bridge_name=bridge_name, iface=iface)
            if op_d['result'] == "fail":
                result_dict['result'] = op_d['result']
                return result_dict
        except Exception as err:
            logger.dumpLog("{}".format(err))
            result_dict["result"] = "fail"
        return result_dict

    def add_iface_bridge(self, bridge_name=None, iface=None):
        """
        The function is used  to add the iface to bridge
        Args:
            bridge_name(str): name of bridge
            iface(str): interface to be added to bridge
         
        Returns:
            result_dict["result"]: pass/fail
        """
        result_dict = {}
        result_dict["result"] = "pass"
        try:
            self.session.send_recv("brctl addif {} {}".format(bridge_name,iface), timeout=20)
        except Exception as err:
            logger.dumpLog("{}".format(err))
            result_dict["result"] = "fail"
        return result_dict
    
    def validate_bridge(self, bridge_name=None, iface=None):
        """
        The function is used to validate the iface in bridge
        Args:
            bridge_name(str): name of bridge
            iface(str): interface to be added to bridge
        Returns:
            result_dict["result"]: pass/fail 
        """
        result_dict = {}
        result_dict["result"] = "pass"
        try:
            output=self.session.send_recv("brctl show", timeout=20)
            s_obj = re.search(r'{}'.format(iface), output)
            if s_obj == None:
                result_dict["result"] = "fail"
        except Exception as err:
            logger.dumpLog("{}".format(err))
            result_dict["result"] = "fail"
        
        return result_dict
    
    def del_iface_bridge(self,bridge_name=None,iface=None):
        """
        The function is used to remove confguration of  bridge
        Args:
            bridge_name(str): name of bridge
            iface(str): interface to be added to bridge
        Returns:
            result_dict["result"]: pass/fail
        """
        result_dict = {}
        result_dict["result"] = "pass"
        try:
            self.session.send_recv("brctl delif {} {}".format(bridge_name,iface), timeout=20)
            self.session.send_recv("/etc/init.d/odhcpd start", timeout=20)
        except Exception as err:
            logger.dumpLog("{}".format(err))
            result_dict["result"] = "fail"
        return result_dict

    def debug_func(self):
        print("Method inside this class %s" % self.__class__.__name__)

    def test_bridgefapi(self):
        print("method inside class BridgeFapi")


if __name__ == "__main__":
    obj = BridgeFapi()
    obj.debug_func()

