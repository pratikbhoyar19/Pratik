from globalVariables import *
from log_creator import loggerObject as logger
from log_creator import logger as logClass
import time
import re

class PpaCmdFapi:
    """This class will provide ppacmd related Apis"""

    def __init__(self):
        pass

    def hw_accel_enable(self,
                        wan_conn=None,
                        hw_type=None,
                        mode=None,
                        wan_iface=None,
                        qos_action=None):
        """
        The function to configure the hw accel in dut
        Args:
            bridge_name(str): name of bridge
            wan_conn(str): eth_tag/eth_untag/vdsl_ptm_17a/adsl_atm/vdsl_ptm_30
            hw_type(str): PAE/MPE
            mode(str): route/bridge
        Returns:
            result_dict["result"]: pass/fail
        """
        result_dict = {}
        result_dict['result'] = "pass"
        try:
            if mode != "bridge":
                op_d = self.add_wan_iface_ppa(wan_conn=wan_conn)
                if op_d['result'] == "fail":
                    result_dict['result'] = op_d['result']
                    return result_dict
                op_d = self.add_lan_iface_ppa()
                if op_d['result'] == "fail":
                    result_dict['result'] = op_d['result']
                    return result_dict

                #Adding Qos for link stability so that link should not go down during large data transmission
                if qos_action != None:
                    self.qos_action = qos_action
                    self.wan_conn = wan_conn
                    self.wan_iface = wan_iface
                    op_d = self.add_qos_link_stab(wan_conn=self.wan_conn, wan_iface=self.wan_iface, action=self.qos_action)
                    if op_d['result'] == "fail":
                        result_dict['result'] = op_d['result']
                        return result_dict

            else:
                op_d = self.add_bridge_ppa()
                if op_d['result'] == "fail":
                    result_dict['result'] = op_d['result']
                    return result_dict

            #Enabling Pae and Disabling Mpe if hw type is pae
            if hw_type == "PAE":
                op_d = self.pae_accel_config()
                if op_d['result'] == "fail":
                    result_dict['result'] = op_d['result']
                    return result_dict
            #Enabling Mpe and Disabling Paeif hw type is Mpe
            elif hw_type == "MPE":
                op_d = self.mpe_accel_config()
                if op_d['result'] == "fail":
                    result_dict['result'] = op_d['result']
                    return result_dict
            self.clear_nfconntrack()
        except Exception as err:
            logger.dumpLog("{}".format(err))
            result_dict['result'] = "fail"
        return result_dict

    def add_bridge_ppa(self):
        """
        The function to configure accel for bridge in dut
        Args:
            None
        Returns:
            result_dict["result"]: pass/fail
        """
        result_dict = {}
        result_dict['result'] = "pass"
        try:
            self.session.send_recv("ppacmd addbr {}".format(self.dict['br_name']), timeout=20)
        except Exception as err:
            logger.dumpLog("{}".format(err))
            result_dict['result'] = "fail"
        return result_dict

    def del_bridge_ppa(self):
        """
        The function to remove accel for bridge in dut
        Args:
            None
        Returns:
            result_dict["result"]: pass/fail
        """
        result_dict = {}
        result_dict['result'] = "pass"
        try:
            self.session.send_recv("ppacmd delbr {}".format(self.dict['br_name']), timeout=20)
        except Exception as err:
            logger.dumpLog("{}".format(err))
            result_dict['result'] = "fail"
        return result_dict

    def add_wan_iface_ppa(self, wan_conn=None):
        """
        The function to add wan ifaces in ppa engine
        Args:
            wan_conn(str): eth_tag/eth_untag/vdsl_ptm_17a/adsl_atm/vdsl_ptm_30
        Returns:
            result_dict["result"]: pass/fail
        """
        result_dict = {}
        result_dict['result'] = "pass"
        try:
            self.session.send_recv("ppacmd setppefp -f 1", timeout=20)
            self.session.send_recv("/tmp/ppacmd_wan_del", timeout=20)
            self.session.send_recv("echo '' > /tmp/ppacmd_wan_del", timeout=20)
            #in loop to add wan ifaces
            op_d = self.get_wan_iface_list(wan_conn=wan_conn)
            for iface in op_d['iface_list']:
                self.session.send_recv("ppacmd addwan -i {}".format(iface), timeout=20)
                self.session.send_recv("echo 'ppacmd delwan -i {}' >> /tmp/ppacmd_wan_del".format(iface), timeout=20)
            self.session.send_recv("chmod +x /tmp/ppacmd_wan_del", timeout=20)

            vl_d = self.ppa_validate_iface(ppa_cmd='ppacmd getwan', lst=op_d['iface_list'])
            if vl_d['result'] == 'fail':
               result_dict['result'] = "fail"
        except Exception as err:
            logger.dumpLog("{}".format(err))
            result_dict['result'] = "fail"
        return result_dict

    def add_lan_iface_ppa(self):
        """
        The function to add lan ifaces in ppa engine
        Args:
            None
        Returns:
            result_dict["result"]: pass/fail
        """
        result_dict = {}
        result_dict['result'] = "pass"
        op = None
        flag = False
        try:
            op_d = self.get_lan_iface_list(include_iface=self.dict['lan_iface'])
            for iface in op_d['iface_list']:
                self.session.send_recv("ppacmd addlan -i {}".format(iface), timeout=20)

            vl_d = self.ppa_validate_iface(ppa_cmd='ppacmd getlan', lst=op_d['iface_list'])
            if vl_d['result'] == 'fail':
               result_dict['result'] = "fail"
        except Exception as err:
            logger.dumpLog("{}".format(err))
            result_dict['result'] = "fail"
        return result_dict

    def ppa_validate_iface(self, ppa_cmd=None, lst=None):
        """
        The function to add lan/wan ifaces in ppa engine
        Args:
            ppa_cmd(str): ppa command to get ifaces
            lst(list): list of ifaces to be validated
        Returns:
            result_dict["result"]: pass/fail
        """
        result_dict = {}
        result_dict['result'] = "pass"
        op = None
        flag = False
        try:
            for i in range(0,5):
                buf = self.session.send_recv("{}".format(ppa_cmd), timeout=20)
                for iface in lst:
                    op = re.search('{}'.format(iface), buf)
                    if op == None:
                        flag = True
                        break
                    else:
                        flag = False

                if i < 4 and flag == True:
                    logger.dumpLog("{} not validate successfully ... retrying ...".format(ppa_cmd))
                    time.sleep(2)
                    continue
                elif i > 4 and flag == True:
                    logger.dumpLog("iface not added successfully using {}..aborting".format(ppa_cmd))
                    result_dict['result'] = 'fail'
                    return result_dict
                elif flag == False:
                    logger.dumpLog("iface added successfully using {}".format(ppa_cmd))
                    break
        except Exception as err:
            logger.dumpLog("{}".format(err))
            result_dict['result'] = "fail"
        return result_dict

    def mpe_accel_config(self):
        """
        The function to validate mpe enabled and pae disabled
        Args:
            None
        Returns:
            result_dict["result"]: pass/fail
        """
        result_dict = {}
        result_dict['result'] = "pass"
        try:
            logger.dumpLog("Trying to enable MPE accelaration")
            #Enabling Mpe and Disabling Pae
            op_d = self.enable_mpe()
            if op_d['result'] == "fail":
                result_dict['result'] = op_d['result']
                return result_dict
            op_d_pae = self.check_pae_status()
            if op_d_pae['result'] == "fail":
                result_dict['result'] = op_d_pae['result']
                return result_dict
            op_d_mpe = self.check_mpe_status()
            if op_d_mpe['result'] == "fail":
                result_dict['result'] = op_d_mpe['result']
                return result_dict
            #Checking if Mpe is enabled and Pae is disabled
            if op_d_pae['pae_status'] == 'disabled' and op_d_mpe['mpe_status'] == 'enable':
                logger.dumpLog("MPE is enabled in CPE")
                return result_dict
            else:
                logger.dumpLog("MPE is not enabled in CPE")
                result_dict['result'] = "fail"
                return result_dict
        except Exception as err:
            logger.dumpLog("{}".format(err))
            result_dict['result'] = "fail"
        return result_dict

    def pae_accel_config(self):
        """
        The function to validate pae enabled and mpe enable
        Args:
            None
        Returns:
            result_dict["result"]: pass/fail
        """
        result_dict = {}
        result_dict['result'] = "pass"
        try:
            #Enabling Pae and Enabling Mpe
            op_d = self.enable_pae()
            if op_d['result'] == "fail":
                result_dict['result'] = op_d['result']
                return result_dict
            op_d_pae = self.check_pae_status()
            if op_d_pae['result'] == "fail":
                result_dict['result'] = op_d_pae['result']
                return result_dict
            op_d_mpe = self.check_mpe_status()
            if op_d_mpe['result'] == "fail":
                result_dict['result'] = op_d_mpe['result']
                return result_dict

            #Checking if Pae is enabled and Mpe is enable
            if op_d_pae['pae_status'] == 'enabled' and op_d_mpe['mpe_status'] == 'enable':
                logger.dumpLog("PAE is enabled in CPE")
                return result_dict
        except Exception as err:
            logger.dumpLog("{}".format(err))
            result_dict['result'] = "fail"
        return result_dict

    def enable_pae(self):
        """
        The function to enable pae and enable mpe
        Args:
            None
        Returns:
            result_dict["result"]: pass/fail
        """
        result_dict = {}
        result_dict['result'] = "pass"
        try:
            self.session.send_recv("echo enable > /proc/ppa/mpe/accel", timeout=20)
            self.session.send_recv("echo enable > /proc/ppa/pae/accel", timeout=20)
            logger.dumpLog("PAE command enabled")
        except Exception as err:
            logger.dumpLog("{}".format(err))
            result_dict['result'] = "fail"
        return result_dict

    def enable_mpe(self):
        """
        The function to enable mpe and disable pae
        Args:
            None
        Returns:
            result_dict["result"]: pass/fail
        """
        result_dict = {}
        result_dict['result'] = "pass"
        try:
            self.session.send_recv("echo disable > /proc/ppa/pae/accel", timeout=20)
            self.session.send_recv("echo enable > /proc/ppa/mpe/accel", timeout=20)
            logger.dumpLog("MPE command enabled")
        except Exception as err:
            logger.dumpLog("{}".format(err))
            result_dict['result'] = "fail"
        return result_dict

    def check_pae_status(self):
        """
        The function to check pae status on dut
        Args:
            None
        Returns:
            result_dict["result"]: pass/fail
        """
        result_dict = {}
        result_dict['result'] = "pass"
        try:
            self.session.send_line("cat /proc/ppa/pae/accel")
            self.session.recv_line("\w+\s+\w+\s+\w+\s+\:\s(\w+).*",timeout=30)
            result_dict['pae_status'] = self.session.match(1)
        except Exception as err:
            logger.dumpLog("{}".format(err))
            result_dict['result'] = "fail"
        return result_dict

    def check_mpe_status(self):
        """
        The function to check mpe status on dut
        Args:
            None
        Returns:
            result_dict["result"]: pass/fail
        """
        result_dict = {}
        result_dict['result'] = "pass"
        try:
            self.session.send_line("cat /proc/ppa/mpe/accel")
            self.session.recv_line(".*?MPE accel\s+:\s+(\w+)",timeout=30)
            result_dict["mpe_status"] = self.session.match(1)
        except Exception as err:
            logger.dumpLog("{}".format(err))
            result_dict['result'] = "fail"
        return result_dict

    def hw_accel_disable(self, mode=None):
        """
        The function to revert accel on dut
        Args:
            mode(str): routr/bridge
        Returns:
            result_dict["result"]: pass/fail
        """
        result_dict = {}
        result_dict['result'] = "pass"
        try:
            if mode != "bridge":
                self.session.send_recv("/tmp/ppacmd_wan_del", timeout=20)
                self.session.send_recv("cat /tmp/ppacmd_wan_del", timeout=20)
                buf = self.session.send_recv("ppacmd getwan", timeout=20)
                op_d = self.clear_nfconntrack()
                if op_d['result'] == "fail":
                    logger.dumpLog("Flush nf_conntrack NOT Happend")
                    result_dict['result'] = op_d['result']
                    return result_dict

                if self.qos_action != None:
                    op_d = self.rm_qos_link_stab(wan_conn=self.wan_conn, wan_iface=self.wan_iface, action='D')
                    if op_d['result'] == "fail":
                        result_dict['result'] = op_d['result']
                        return result_dict
            else:
                op_d = self.del_bridge_ppa()
                if op_d['result'] == "fail":
                    result_dict['result'] = op_d['result']
                    return result_dict

            #enabling mpe and pae to restore intial condition
            self.enable_ppa_mpe()
        except Exception as err:
            logger.dumpLog("{}".format(err))
            result_dict['result'] = "fail"
        return result_dict

    def clear_nfconntrack(self):
        """
        The function to clear route entry on dut
        Args:
            None
        Returns:
            result_dict["result"]: pass/fail
        """
        result_dict = {}
        result_dict['result'] = "pass"
        try:
            for i in range (0,3):
                self.session.send_recv("echo f > /proc/net/nf_conntrack", timeout=20)
            return result_dict
        except Exception as err:
            logger.dumpLog("{}".format(err))
            result_dict['result'] = "fail"
        return result_dict

    def enable_ppa_mpe(self):
        """
        The function to enable pae and mpe accel on dut
        Args:
            None
        Returns:
            result_dict["result"]: pass/fail
        """
        result_dict = {}
        result_dict['result'] = "pass"
        try:
            self.session.send_recv("echo enable > /proc/ppa/pae/accel", timeout=20)
            self.session.send_recv("echo enable > /proc/ppa/mpe/accel", timeout=20)
            logger.dumpLog("MPE and PAE enabled")
        except Exception as err:
            logger.dumpLog("{}".format(err))
            result_dict['result'] = "fail"
        return result_dict

    def get_lan_iface_list(self, include_iface=None):
        """
        The function to get lan ifaces
        Args:
            include_iface(str): iface for inclusion
        Returns:
            result_dict["result"]: pass/fail
            result_dict["iface_list"]: lan iface list in dut
        """
        result_dict = {}
        result_dict['result'] = "pass"
        try:
            op = self.session.send_recv("ifconfig", timeout=20)
            result_dict['iface_list'] = re.findall(r'{}_\d+|wlan\d+|br-lan'.format(include_iface), op)
            logger.dumpLog("iface list: {}".format(result_dict['iface_list']))
        except Exception as err:
            logger.dumpLog("{}".format(err))
            result_dict['result'] = "fail"
        return result_dict

    def get_wan_iface_list(self, wan_conn=None):
        """
        The function to get wan ifaces
        Args:
            wan_conn(str): wan conenction
        Returns:
            result_dict["result"]: pass/fail
            result_dict["iface_list"]: wan iface list in dut
        """
        result_dict = {}
        result_dict['result'] = "pass"
        try:
            op = self.session.send_recv("ifconfig", timeout=20)

            if wan_conn == "eth_untag" or wan_conn == "eth_tag":
                result_dict['iface_list'] = re.findall(r'{}.\d+|{}|ppp\d+'.format(self.dict['eth_iface'], self.dict['eth_iface']), op)
            elif wan_conn == "vdsl_ptm_17a" or wan_conn == "vdsl_ptm_30":
                result_dict['iface_list'] = re.findall(r'{}.\d+|{}|ppp\d+'.format(self.dict['vdsl_ptm_iface'], self.dict['vdsl_ptm_iface']), op)
            elif wan_conn == "adsl_atm":
                result_dict['iface_list'] = re.findall(r'{}|ppp\d+'.format(self.dict['adsl_atm_iface']), op)

            logger.dumpLog("iface list: {}".format(result_dict['iface_list']))
        except Exception as err:
            logger.dumpLog("{}".format(err))
            result_dict['result'] = "fail"
        return result_dict

    def sw_accleration_config(self, enable=None):
        """
        To set the software acceleration path in the DUT
        Args:
            enable(bool): True/False
        Return:
            result_dict["result"]: pass/fail
        """
        result_dict = {}
        result_dict['result'] = "pass"
        if not (enable != None and (enable == True or enable == False)):
             logger.dumpLog("enable flag is not proper - {}".format(enable))
             result_dict['result'] = "fail"
             return result_dict
        try:
            if enable:
                #Disabling hw accel, pae and mpe
                self.session.send_line("ppacmd setppefp -f 0")
                self.session.recv_line(self.prompt, timeout=20)
                self.session.send_recv("echo disable > /proc/ppa/pae/accel")
                self.session.send_recv("echo disable > /proc/ppa/mpe/accel")
                #Enabling Sw accel
                self.session.send_line("ppacmd setswfp -f 1")
                self.session.recv_line(self.prompt, timeout=20)
            else:
                #Enabling hw accel, pae and mpe
                self.session.send_line("ppacmd setppefp -f 1")
                self.session.recv_line(self.prompt, timeout=20)

                self.enable_ppa_mpe()

                #Disabling Sw accel
                self.session.send_line("ppacmd setswfp -f 0")
                self.session.recv_line(self.prompt, timeout=20)
        except Exception as err:
            logger.dumpLog("{}".format(err))
            result_dict['result'] = "fail"
        return result_dict

    def enable_cpu_path(self):
        """
        Enable cpu path by disabling sw and hw acceleration
        Args:
            None
        Returns:
            result_dict["result"]: pass/fail
        """
        result_dict = {}
        result_dict['result'] = "pass"
        try:
            #Disabling hw accel and Sw Accel
            self.session.send_line("ppacmd setppefp -f 0")
            self.session.recv_line(self.prompt, timeout=20)
            self.session.send_recv("echo disable > /proc/ppa/pae/accel")
            self.session.send_recv("echo disable > /proc/ppa/mpe/accel")
            #Disabling Sw accel
            self.session.send_line("ppacmd setswfp -f 0")
            self.session.recv_line(self.prompt, timeout=20)
        except Exception as err:
            logger.dumpLog("{}".format(err))
            result_dict['result'] = "fail"
        return result_dict

    def test_func(self):
        print("method inside in this class %s" % self.__class__.__name__)

    def ppa_func(self):
        print("ppa inside in this class %s" % self.__class__.__name__)


if __name__ == "__main__":
    obj = PpaCmdFapi()
    obj.test_func()
