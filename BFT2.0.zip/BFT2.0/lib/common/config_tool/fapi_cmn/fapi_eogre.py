import paramiko
import re
from config import kpi_para
from log_creator import loggerObject as logger
from log_creator import logger as logClass

class EogreFapi:

    def __init__(self):
        pass

    def create_eogre_dut(self,
                         ip_addr=None,
                         wan_host_ip=None,
                         tun_dut_ip=None,
                         netmask=None):
        """
        This function is used to create eogre tunnel
        Args:
            ip_addr(str): local ip address
            wan_host_ip(str): wan host ip address
            tun_dut_ip(str): tunnel dut ip address
            netmask(str): netmask address
        Returns:
            result_dict["result"]: pass/fail
        """
        result_dict = {}
        result_dict["result"] = "pass"

        try:
            self.session.send_line('ip link add tunEoGre type gretap remote {} local {} ttl 255'.format(wan_host_ip,ip_addr))
            self.session.recv_line(self.prompt, timeout=20)
            self.session.send_line('ip link set tunEoGre up')
            self.session.recv_line(self.prompt, timeout=20)
            self.session.send_line('brctl addif br-lan tunEoGre')
            self.session.recv_line(self.prompt, timeout=20)
            self.session.send_line('brctl show')
            self.session.recv_line(self.prompt, timeout=20)
            #self.session.send_line('ppacmd addwan -i tunEoGre')
            #self.session.recv_line(self.prompt, timeout=20)
            #self.session.send_line('ppacmd getwan')
            #self.session.recv_line(self.prompt, timeout=20)
            #self.session.send_line('echo enable > /proc/ppa/api/bridged_flow_learning')
            #self.session.recv_line(self.prompt, timeout=20)

        except Exception as err:
            result_dict["result"] = "fail"
            logger.dumpLog("{}".format(err))
        return(result_dict)

    def delete_eogre_dut(self,
                         ip_addr=None,
                         wan_host_ip=None):
        """
        This function is used to delete eogre tunnel
        Args:
            ip_addr(str): local ip address
            wan_host_ip(str): wan host ip address
        Returns:
            result_dict["result"]: pass/fail
        """
        result_dict = {}
        result_dict["result"] = "pass"

        try:
            #self.session.send_line('ppacmd delwan -i tunEoGre')
            #self.session.recv_line(self.prompt, timeout=20)
            #self.session.send_line('ppacmd getwan')
            #self.session.recv_line(self.prompt, timeout=20)
            self.session.send_line('brctl delif br-lan tunEoGre')
            self.session.recv_line(self.prompt, timeout=20)
            self.session.send_line('ip link set tunEoGre down')
            self.session.recv_line(self.prompt, timeout=20)
            self.session.send_line('ip link del tunEoGre type gretap remote {} local {} ttl 255'.format(ip_addr, wan_host_ip))
            self.session.recv_line(self.prompt, timeout=20)
            self.session.send_line('ifconfig br-lan mtu 1500')
            self.session.recv_line(self.prompt, timeout=20)
            self.session.send_line('brctl show')
            self.session.recv_line(self.prompt,timeout=20)
        except Exception as err:
            result_dict["result"] = "fail"
            logger.dumpLog("{}".format(err))
        return(result_dict)

if __name__ == "__main__":
    obj = EogreFapi()
    obj.debug_func()
