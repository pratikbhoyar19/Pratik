

class MulticastFapi:
    """This class will contain all fapi APIs related to Multicast functionality"""

    def __init__(self):
        pass

    def debug_func(self):
        print("Method inside this class %s" % self.__class__.__name__)

    def test_multicastfapi(self):
        print("method inside class MulticastFapi")


if __name__ == "__main__":
    obj = MulticastFapi()
    obj.debug_func()
