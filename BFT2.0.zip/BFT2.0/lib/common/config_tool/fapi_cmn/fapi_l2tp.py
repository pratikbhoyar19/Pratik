import re
from log_creator import loggerObject as logger
from log_creator import logger as logClass

class L2tpTunnelFapi:
    """This class will contain all fapi APIs related to L2TP functionality"""

    def __init__(self):
        pass

    def l2tp_rm_files_server(self):
        """
        To remove exiting xl2tpd.conf and options.xl2tpd files from dut
        Args:
            None
        Returns:
            result_dict["result"]:pass/fail
        """
        result_dict = {}
        result_dict["result"] = "pass"
        logger.dumpLog("removing exiting configured files from Dut")
        try:
            self.session.send_line("rm -rf /etc/xl2tpd/xl2tpd.conf")
            self.session.recv_line(self.prompt,timeout=20)
            self.session.send_line("rm -rf /etc/ppp/options.xl2tpd")
            self.session.recv_line(self.prompt,timeout=20)
            logger.dumpLog("File deleted successfully ")
        except Exception as err:
            logger.dumpLog("{}".format(err))
            result_dict["result"] = "fail"
        return result_dict

    def create_xl2tpd_conf_server(self, lns_addr=None):
        """
           To create xl2tpd.conf file at dut
           Args:
               lns_addr(str): wan host ip address
           Returns:
               result_dict['result']:pass/fail
        """
        result_dict = {}
        result_dict["result"] = "pass"
        logger.dumpLog("creating the xl2tpd.conf file at Dut")
        try:
            self.session.send_line("echo '[lac l2tp_pppd]' >> /etc/xl2tpd/xl2tpd.conf")
            self.session.recv_line(self.prompt ,timeout=20)
            self.session.send_line("echo 'lns = {}' >> /etc/xl2tpd/xl2tpd.conf".format(lns_addr))
            self.session.recv_line(self.prompt ,timeout=20)
            self.session.send_line("echo ';require chap = yes' >> /etc/xl2tpd/xl2tpd.conf")
            self.session.recv_line(self.prompt ,timeout=20)
            self.session.send_line("echo ';refuse pap = yes' >> /etc/xl2tpd/xl2tpd.conf")
            self.session.recv_line(self.prompt ,timeout=20)
            self.session.send_line("echo ';require authentication = no' >> /etc/xl2tpd/xl2tpd.conf")
            self.session.recv_line(self.prompt ,timeout=20)
            self.session.send_line("echo ';name = LinuxVPNserver' >> /etc/xl2tpd/xl2tpd.conf")
            self.session.recv_line(self.prompt ,timeout=20)
            self.session.send_line("echo 'ppp debug = yes' >> /etc/xl2tpd/xl2tpd.conf")
            self.session.recv_line(self.prompt ,timeout=20)
            self.session.send_line("echo 'pppoptfile = /etc/ppp/options.xl2tpd' >> /etc/xl2tpd/xl2tpd.conf")
            self.session.recv_line(self.prompt ,timeout=20)
            self.session.send_line("echo ';length bit = yes' >> /etc/xl2tpd/xl2tpd.conf")
            self.session.recv_line(self.prompt ,timeout=20)
        except Exception as err:
            logger.dumpLog("{}".format(err))
            result_dict["result"] = "fail"
        return result_dict

    def create_xl2tpd_options_server(self):
        """
           To create option.xl2tpd file at dut
           Args:

           Returns:
               result_dict['result']:pass/fail
        """
        result_dict = {}
        result_dict["result"] = "pass"
        logger.dumpLog("creating the options.xl2tpd file at Dut")
        try:
            self.session.send_line("echo '' > /etc/ppp/options.xl2tpd")
            self.session.recv_line(self.prompt,timeout=20)
            self.session.send_line("echo 'noauth' >> /etc/ppp/options.xl2tpd")
            self.session.recv_line(self.prompt,timeout=20)
            self.session.send_line("echo 'debug' >> /etc/ppp/options.xl2tpd")
            self.session.recv_line(self.prompt,timeout=20)
            self.session.send_line("echo 'dump' >> /etc/ppp/options.xl2tpd")
            self.session.recv_line(self.prompt,timeout=20)
            self.session.send_line("echo 'logfd 2' >> /etc/ppp/options.xl2tpd")
            self.session.recv_line(self.prompt,timeout=20)
            self.session.send_line("echo 'logfile /var/log/xl2tpd.log' >> /etc/ppp/options.xl2tpd")
            self.session.recv_line(self.prompt,timeout=20)
            self.session.send_line("echo 'noccp' >> /etc/ppp/options.xl2tpd")
            self.session.recv_line(self.prompt,timeout=20)
            self.session.send_line("echo 'novj' >> /etc/ppp/options.xl2tpd")
            self.session.recv_line(self.prompt,timeout=20)
            self.session.send_line("echo 'novjccomp' >> /etc/ppp/options.xl2tpd")
            self.session.recv_line(self.prompt ,timeout=20)
            self.session.send_line("echo 'nopcomp' >> /etc/ppp/options.xl2tpd")
            self.session.recv_line(self.prompt,timeout=20)
            self.session.send_line("echo 'noaccomp' >> /etc/ppp/options.xl2tpd")
            self.session.recv_line(self.prompt,timeout=20)
        except Exception as err:
            logger.dumpLog("{}".format(err))
            result_dict["result"] = "fail"
        return result_dict

    def xl2tpd_copy_tmp_server(self):
        """
           To copy xl2tpd.conf on dut in tmp directory
           Args:
               None
           Returns:
               result_dict['result']:pass/fail
        """
        result_dict = {}
        result_dict["result"] = "pass"
        try:
            self.session.send_line("rm -rf /tmp/xl2tpd")
            self.session.recv_line(self.prompt,timeout=20)
            self.session.send_line("mkdir /tmp/xl2tpd")
            self.session.recv_line(self.prompt,timeout=20)
            self.session.send_line("cp /etc/xl2tpd/xl2tpd.conf /tmp/xl2tpd/xl2tpd.conf")
            self.session.recv_line(self.prompt, timeout=20)
        except Exception as err:
            logger.dumpLog("{}".format(err))
            result_dict["result"] = "fail"
        return result_dict

    def start_l2tp_server(self):
        """
           To start l2tp server on dut
           Args:
               None
           Returns:
               result_dict['result']:pass/fail
        """
        result_dict = {}
        result_dict["result"] = "pass"
        try:
            self.session.send_recv("/etc/init.d/xl2tpd stop", timeout=20)
            self.session.send_line("rm -rf /var/run/xl2tpd")
            self.session.recv_line(self.prompt, timeout=20)
            self.session.send_line("mkdir /var/run/xl2tpd")
            self.session.recv_line(self.prompt, timeout=20)
            self.session.send_line("touch /var/run/xl2tpd/l2tp-control")
            self.session.recv_line(self.prompt, timeout=20)
            self.session.send_line("chmod 777 /var/run/xl2tpd/l2tp-control")
            self.session.recv_line(self.prompt, timeout=20)
            logger.dumpLog("starting l2tp server at Dut side")
            self.session.send_line("xl2tpd -D &")
            self.session.recv_line(self.prompt, timeout=20)
            self.session.send_line("")
            self.session.recv_line(self.prompt, timeout=20)
        except Exception as err:
            logger.dumpLog("{}".format(err))
            result_dict["result"] = "fail"
        return result_dict

    def l2tp_pppd_echo_server(self, ip_addr=None):
        """
           To start l2tp-control at dut
           Args:
               ip_addr(str):wan host ip address
           Returns:
               result_dict['result']:pass/fail
        """
        result_dict = {}
        result_dict["result"] = "pass"
        try:
            self.session.send_line('echo "c l2tp_pppd"> /var/run/xl2tpd/l2tp-control')
            status = self.session.recv_line('Call established with {}'.format(ip_addr), timeout=20)
            if status == True:
                logger.dumpLog("{}".format(status))
            else:
                result_dict["result"] = "fail"
            self.session.send_line("")
            self.session.recv_line(self.prompt, timeout=20)
        except Exception as err:
            logger.dumpLog("{}".format(err))
            result_dict["result"] = "fail"
        return result_dict


    def debug_func(self):
        print("Method inside this class %s" % self.__class__.__name__)

    def test_l2tptunnelfapi(self):
        print("method inside class L2tpTunnelFapi")


if __name__ == "__main__":
    obj = L2tpTunnelFapi()
    obj.debug_func()
