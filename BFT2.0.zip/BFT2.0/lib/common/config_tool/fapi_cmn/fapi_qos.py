from log_creator import loggerObject as logger
from log_creator import logger as logClass

class QosFapi:

    def __init__(self):
        pass

    def qos_modify(self, action=None):
        '''To enable the qos in cpe'''
        result_dict = {}
        result_dict['result'] = 'pass'
        try:
            if action != None and action.upper() == 'A':
                val = 1
            elif action != None and action.upper() == 'D':
                val = 0
            else:
                logger.dumpLog("Wrong action passed - {}".format(action))
                result_dict['result'] = 'fail'
                return result_dict

            self.session.send_line('qoscfg -I {}'.format(val))
            self.session.recv_line(self.prompt,timeout=30)
            self.session.send_line('qoscfg -L')
            self.session.recv_line('QoS status: Enable',timeout=20)
        except Exception as err:
            logger.dumpLog("Error in taking action {} on qos at DUT/cpe - {}".format(err))
            result_dict['result'] = 'fail'
        return result_dict

    def qos_map_to_wan_iface(self,
                             wan_conn=None,
                             wan_iface=None,
                             action=None):
        '''To configure qos to map inteface on board
              Arguments: wan_ifname    - This argument is the WAN interface name, default name is empty
                         wan_conn      - This argument is the WAN conection type, default type is 'eth_tag'
                         action        - This argument is the type of action , default type is tsv_qos_del
              Usage : ifcfg --iface/--ifmap
              A/D/R [interface name] -t [interface category] -b [base interface]
              iface:interface, ifmap:interface category object
        '''
        result_dict = {}
        result_dict['result'] = 'pass'

        try:
            if not (action != None and (action.upper() == 'A' or action.upper() == 'D')):
                logger.dumpLog("wrong action passed - {}".format(action))
                result_dict['result'] = 'fail'
                return result_dict

            o_dict = self.get_baseiface_category(wan_conn=wan_conn, wan_iface=wan_iface)
            if o_dict['result'] == 'fail':
                result_dict['result'] = 'fail'
                logger.dumpLog("not able to get base iface and category")
                return result_dict

            self.session.send_line("ifcfg --ifmap -{} {} -t {} -b {} -l {}"\
                                   .format(action, wan_iface, self.interface_category, self.base_ifname, self.base_ifname))
            self.session.recv_line(self.prompt, timeout=20)
            self.session.send_line("ifcfg --ifmap -{} br-lan -t 0 -b br-lan -l br-lan".format(action))
            self.session.recv_line(self.prompt, timeout=20)
        except Exception as err:
            logger.dumpLog("Error in qos map to interface at DUT/cpe - {}".format(err))
            result_dict['result'] = 'fail'
        return result_dict

    def qos_queue_update(self,
                         wan_iface=None,
                         action=None,
                         queue_name=None,
                         queue_precedence=None,
                         traffic_class=None,
                         drop_alog=None,
                         schedule_alog=None,
                         length=None,
                         queue_weight=None,
                         traffic_flow="upstream"):
        '''To configure qos to map inteface on board
              Arguments: wan_ifname    - This argument is the WAN interface name, default name is empty
                         action        - This argument is the type of action , default type is tsv_qos_del
                         queue_name    - This argument is the name of the queue
                         queue_precedence - This argument is the queue precedence value
                         traffic_class - This argumnet is the queue traffic class, either DT or RED
                         drop_alog     - This argumnet is indicate the drop algorithm type
                         schedule_alog - This argumnet is indicate the schedule algorithm type, either sp or wfq
                         length        - This argument is the queue lenth in bytes, default value 102400
                         queue_weight  - This argumnet is the weight of the queue for algorithm of WFQ, default is 0
                         traffic_flow  - This argumnet indicates the type of traffic flow, default is tsv_upstream
        '''
        result_dict = {}
        result_dict['result'] = 'pass'
        base_cmd = ""
        try:
            if not (action != None and (action.upper() == 'A' or action.upper() == 'D')):
                logger.dumpLog("wrong action passed - {}".format(action))
                result_dict['result'] = 'fail'
                return result_dict

            if traffic_flow != None and traffic_flow.lower() == 'upstream':
                interface = wan_iface
            else:
                interface = self.dict['br_name']

            if queue_name == None or length == None or traffic_class == None or \
                             queue_precedence == None or schedule_alog == None:
                logger.dumpLog("one of the parameter is of None type {} {} {} {} {}"\
                               .format(queue_name, length, traffic_class, queue_precedence, schedule_alog))
                result_dict['result'] = 'fail'
                return result_dict

            base_cmd += "qcfg --queue -{} {} -l {} -i {} --map {} ".format(action, queue_name, length, interface, traffic_class)

            if schedule_alog != None and schedule_alog.lower() == "sp":
                base_cmd += "-m sp "
            elif schedule_alog != None and schedule_alog.lower() == "wfq":
                base_cmd += "-m wfq --weight {} ".format(queue_weight)

            base_cmd += "--priority {} ".format(queue_precedence)

            if drop_alog != None and drop_alog.upper() == "DT":
                base_cmd += "-d tail"

            self.session.send_line('{}'.format(base_cmd))
            self.session.recv_line('Requested queue configuration succeeded' ,timeout=20)
            self.session.send_line("qcfg --queue -L  all -i {}".format(interface))
            self.session.recv_line(self.prompt, timeout=20)
        except Exception as err:
            logger.dumpLog("Error in configure the QoS queue at DUT/cpe - {}".format(err))
            result_dict['result'] = 'fail'
        return result_dict

    def add_qos_link_stab(self,
                          wan_conn=None,
                          wan_iface=None,
                          action=None):
        '''To configure the default and management queue in CPE'''
        result_dict = {}
        result_dict['result'] = 'fail'

        try:
            if not (action != None and (action.upper() == 'A' or action.upper() == 'D')):
                logger.dumpLog("wrong action passed - {}".format(action))
                return result_dict

            #getting def and mgmt queue as per wan_conn
            o_dict = self.get_def_mgmt_q(wan_conn=wan_conn)
            if o_dict['result'] == 'fail':
                logger.dumpLog("not able to get default and mgmt queues")
                return result_dict

            #enabling QOS on DUT
            o_dict = self.qos_modify(action=action.upper())
            if o_dict['result'] == 'fail':
                logger.dumpLog("qos mapping to wan failed")
                return result_dict
            #mapping qos to wan iface
            o_dict = self.qos_map_to_wan_iface(wan_conn=wan_conn,
                                               wan_iface= wan_iface,
                                               action=action.upper())
            if o_dict['result'] == 'fail':
                logger.dumpLog("qos mapping to wan failed")
                return result_dict
            #deleting Qos queues on DUT
            o_dict = self.qos_queue_update(wan_iface=wan_iface,
                                           queue_name=self.def_queue,
                                           queue_precedence="8",
                                           traffic_class="8",
                                           drop_alog="DT",
                                           schedule_alog="SP",
                                           action=action.upper(),
                                           length=102400)
            if o_dict['result'] == 'fail':
                logger.dumpLog("qos mapping to wan iface for \"{}\" failed".format(self.def_queue))
                return result_dict

            o_dict = self.qos_queue_update(wan_iface=wan_iface,
                                           queue_name=self.mgmt_queue,
                                           queue_precedence="1",
                                           traffic_class="1",
                                           drop_alog="DT",
                                           schedule_alog="SP",
                                           action=action.upper(),
                                           length=102400)
            if o_dict['result'] == 'fail':
                logger.dumpLog("qos mapping to wan iface for \"{}\" failed".format(self.mgmt_queue))
                return result_dict

            result_dict['result'] = 'pass'
        except Exception as err:
            logger.dumpLog("Error in configure the default qos queues at DUT/cpe - {}".format(err))
        return result_dict

    def rm_qos_link_stab(self,
                         wan_conn=None,
                         wan_iface=None,
                         action=None):
        '''To configure the default and management queue in CPE'''
        result_dict = {}
        result_dict['result'] = 'fail'
        try:
            if not (action != None and (action.upper() == 'A' or action.upper() == 'D')):
                logger.dumpLog("wrong action passed - {}".format(action))
                return result_dict

            #getting def and mgmt queue as per wan_conn
            o_dict = self.get_def_mgmt_q(wan_conn=wan_conn)
            if o_dict['result'] == 'fail':
                logger.dumpLog("not able to get default and mgmt queues")
                return result_dict

            #deleting Qos queues on DUT
            o_dict = self.qos_queue_update(wan_iface=wan_iface,
                                           queue_name=self.mgmt_queue,
                                           queue_precedence="1",
                                           traffic_class="1",
                                           drop_alog="DT",
                                           schedule_alog="SP",
                                           action=action.upper(),
                                           length=102400)
            if o_dict['result'] == 'fail':
                logger.dumpLog("qos mapping to wan iface for \"{}\" failed".format(self.mgmt_queue))
                return result_dict

            o_dict = self.qos_queue_update(wan_iface=wan_iface,
                                           queue_name=self.def_queue,
                                           queue_precedence="8",
                                           traffic_class="8",
                                           drop_alog="DT",
                                           schedule_alog="SP",
                                           action=action.upper(),
                                           length=102400)
            if o_dict['result'] == 'fail':
                logger.dumpLog("qos mapping to wan iface for \"{}\" failed".format(self.def_queue))
                return result_dict

            #removing QoS mapping from wan iface
            o_dict = self.qos_map_to_wan_iface(wan_conn=wan_conn,
                                               wan_iface= wan_iface,
                                               action=action.upper())
            if o_dict['result'] == 'fail':
                logger.dumpLog("qos mapping to wan failed")
                return result_dict

            #disabling QoS on DUT
            o_dict = self.qos_modify(action=action.upper())
            if o_dict['result'] == 'fail':
                logger.dumpLog("qos mapping to wan failed")
                return result_dict

            result_dict['result'] = 'pass'
        except Exception as err:
            logger.dumpLog("Error in configure the default qos queues at DUT/cpe - {}".format(err))
        return result_dict

    def get_def_mgmt_q(self, wan_conn=None):
        result_dict = {}
        result_dict['result'] = 'pass'
        try:
            if wan_conn == 'eth_tag' or wan_conn == 'eth_untag':
                self.def_queue = "ethwan_def_queue"
                self.mgmt_queue = "ethwan_mgmt_q"

            elif wan_conn == 'vdsl_ptm_17a' or wan_conn == 'vdsl_ptm_30':
                self.def_queue = "ptmwan_def_queue"
                self.mgmt_queue = "ptmwan_mgmt_q"

            elif wan_conn == 'adsl_atm' :
                self.def_queue = "atmwan_def_queue"
                self.mgmt_queue = "atmwan_mgmt_q"

            else:
                logger.dumpLog("Wrong wan_conn passed {}".format(wan_conn))
                result_dict['result'] = 'fail'
        except Exception as err:
            logger.dumpLog("Exception in getting def and mgmt queue - {}".format(err))
            result_dict['result'] = 'fail'
        return result_dict

    def get_baseiface_category(self, wan_conn=None, wan_iface=None):
        '''
            Interface categories
              ETH LAN - 0
              ETH WAN - 1
              PTM WAN - 2
              ATM WAN - 3
              LTQ WAN - 4
              WLAN DirectPath - 5
              WLAN Non-DirectPath - 6
              Local - 7
        '''
        result_dict = {}
        result_dict['result'] = 'pass'
        try:
            if wan_conn == 'eth_tag' or wan_conn == 'eth_untag':
                self.interface_category = 1
            elif wan_conn == 'vdsl_ptm_17a' or wan_conn == 'vdsl_ptm_30':
                self.interface_category = 2
            elif wan_conn == 'adsl_atm' :
                self.interface_category = 3
            else:
                logger.dumpLog("Wrong wan_conn passed {}".format(wan_conn))
                result_dict['result'] = 'fail'
            self.base_ifname = wan_iface.split('.')[0]
        except Exception as err:
            logger.dumpLog("exception in getting iface category and base ifname {}".format(err))
            result_dict['result'] = 'fail'
        return result_dict
