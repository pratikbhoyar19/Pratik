

class Ipv4Fapi:
    """This class will contain all fapi APIs related to Ipv4 functionality"""

    def __init__(self):
        pass

    def debug_func(self):
        print("Method inside this class %s" % self.__class__.__name__)

    def test_ipv4fapi(self):
        print("method inside class Ipv4Fapi")

if __name__ == "__main__":
    obj = Ipv4Fapi()
    obj.debug_func()
