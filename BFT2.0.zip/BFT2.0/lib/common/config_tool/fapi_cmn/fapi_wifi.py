


class WifiFapi:
    """This class will contain all fapi APIs related to Wifi functionality"""

    def __init__(self):
        pass

    def debug_func(self):
        print("Method inside this class %s" % self.__class__.__name__)

    def test_wififapi(self):
        print("method inside class WifiFapi")


if __name__ == "__main__":
    obj = WifiFapi()
    obj.debug_func()
