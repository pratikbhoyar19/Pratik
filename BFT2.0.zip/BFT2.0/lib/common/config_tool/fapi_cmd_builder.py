import os
import inspect
import fapi_cmn
from fapi_cmn import *
from generic_api import *
from testfactory import *
from log_creator import loggerObject as logger

def fapi_method_builder(cls):
    def __init__(self, os, session, prompt, device_dict=None, dname=None, logger=logger, class_list=None):
        self.os = os
        self.session = session
        self.prompt = prompt
        self.dict = device_dict
        self.dname = dname
        self.logger = logger
        #calling init functions of all parent classes
        for c_obj in list(class_list.split(",")):
            for ele in inspect.getmembers(eval(c_obj)):
                if "__init__" in ele:
                    eval(c_obj).__init__(self)

    __init__.__name__ = "__init__"
    setattr(cls,__init__.__name__,__init__)

def fapi_cmd(os_handle="", session_handle="", prompt="", device_dict=None, dname=None, logger=logger):
    fapi_class_list = fapi_list_builder()
    exec ('class FapiCmdHolder(' + fapi_class_list + '): pass')
    #This dynamic class is formed with multiple inheritance, Hence Lib writter should not use
    #same attribute names accross classes
    fapi_method_builder(FapiCmdHolder)
    return FapiCmdHolder(os_handle, session_handle, prompt, device_dict=device_dict, dname=dname, logger=logger,
                         class_list=fapi_class_list)


def fapi_list_builder():
    '''Return list of classes in fapi_cmn'''
    cls_list=''
    for name, obj in inspect.getmembers(fapi_cmn):
        if inspect.isclass(obj) and "Fapi" in name:
            cls_list = cls_list + ',' + name
    cls_list+=',GenericApi,TestFactory'
    return cls_list.strip(',')


if __name__ == '__main__':
    objFapi  = fapi_cmd()
    objFapi.debug_func()
    objFapi.test_bridgefapi()
    objFapi.test_ipv4fapi()
    objFapi.test_l2tptunnelfapi()
    objFapi.test_multicastfapi()
    objFapi.test_wififapi()
