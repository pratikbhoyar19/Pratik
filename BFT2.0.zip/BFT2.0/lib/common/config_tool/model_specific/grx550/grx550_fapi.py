import os
import time
import re
from ipaddress import *

from log_creator import loggerObject as logger
from log_creator import logger as logClass
from framework.publish_info_to_html import publish_html

class Grx550Fapi:
    """This class will provide model specific apis"""

    def hw_accel_validate(self,
                          message=None,
                          proto=None,
                          lan_host_eth_ip=None,
                          wan_host_eth_ip=None,
                          stream=None,
                          tun_name=None,
                          ipv6_enable=False,
                          hw_type=None,
                          wan_conn=None,
                          wait_time=None,
                          loop_count=None,
                          obj=None):
        '''To validate the Hardware accelaration for MPE and PAE
           Argumnets: message	- This argumnet is for store the return type and message
                      system        - This argument is the object where the hw accel validate check. default object is board
                      proto		- This argument is will specifies the type of transport layer, default value is "tcp"
                      lan_host_eth_ip	- This argumnet is for LAN machine ip address, default ip is tsv_lan_static_ip
                      wan_host_eth_ip	- This argumnet is for WAN machine ip address, default ip is tsv_wan_static_ipaddr
                      stream	- This argument is specifies the type of traffic flow , default value "upstream"
                      tun_name	- This argumnet is the object for telling the type of Tunnel,
                      ipv6_enable - This argument is the status of IPv6 type, default value is False
                      hw_ype	- This argument specifies the type of HW accelaration MPE/PAE'''

        try:
            resultflag = "SUCCESS"
            if hw_type.upper() == "PAE":#that is PAE Case
                try:
                    session_cnt = self.validate_session_cnt(proto=proto,
                                                            stream=stream,
                                                            tun_name=tun_name,
                                                            loop_count=loop_count,
                                                            wait_time=wait_time)
                    if not session_cnt:
                        logger.dumpLog("Session count validation fails")
                        resultflag = "FAIL"
                        message[0] = ("Session count validation fails")
                        message[1] = resultflag
                        return False
                except Exception as err:
                    logger.dumpLog("*****FAILURE******")
                    resultflag = "FAIL"
                    message[0] = "{}".format(err)
                    message[1] = resultflag
                    return False

            # this block is for both MPE nd PAE
            try:
                if(tun_name == "L2TP" or tun_name == "GRE" or tun_name == "IPSEC") \
                                             and (stream == "upstream" or stream == "bidi"):
                    hw_type_tmu = "MPE"#this is special case for l2tp,gre and ipsec in upstream and bidi only
                else:
                    hw_type_tmu = hw_type
                #polling loop to wait for traffic generator to start, espcially STC
                if hw_type.upper() == "MPE":
                    time.sleep(10)

                for i in range(0, int(loop_count)):
                    eval_msg = ['msg','flag']
                    self.eval_tmu_eqt(eval_msg=eval_msg,
                                 hw_type=hw_type_tmu,
                                 stream=stream,
                                 wan_conn=wan_conn,
                                 pae_route_resultflag=resultflag)
                    if eval_msg[1] == 'FAIL' or eval_msg[1] == 'False':
                        if i >= int(int(loop_count)-1):
                            resultflag = "FAIL"
                            break
                        time.sleep(int(wait_time))
                        continue
                    else:
                        break
                message[0] = eval_msg[0]
            except:
                resultflag = "FAIL"
                message[0] = ("Issue while executing eval_tmu_eqt()")
                logger.dumpLog("*****FAILURE******")
            #message[1] = resultflag

            if hw_type.upper() == "PAE" and session_cnt == True:#that is PAE Case
                try:
                    msg1 = self.eval_pae_route_cmd(proto=proto,
                                                   lan_ip=lan_host_eth_ip,
                                                   wan_ip=wan_host_eth_ip,
                                                   stream=stream,
                                                   ipv6_enable=ipv6_enable,
                                                   tun_name=tun_name,
                                                   loop_count=loop_count,
                                                   wait_time=wait_time,
                                                   obj=obj)
                    if not msg1:
                        logger.dumpLog("Hw accel validation Route entry fails")
                        resultflag = "FAIL"
                        message[0] = message[0] + ("\nHw accel validation Route entry fails")
                    else:
                        message[0] = message[0] + "\n" + msg1
                except:
                    resultflag = "FAIL"
                    message[0] = message[0] + ("\nIssue while executing eval_pae_route_cmd()")
                    logger.dumpLog("*****FAILURE******")
        except Exception as e:
            logger.dumpLog("Issue with hw_accel_validate() - %s" %str(e))
            message="FAIL"
        message[1] = resultflag

    def validate_session_cnt(self, proto=None, stream=None, tun_name=None, loop_count=None, wait_time=None):
        try:
            #polling loop to wait for traffic generator to start, espcially STC
            for i in range (0,int(loop_count)):
                if self.validate_session(proto=proto,
                                         stream=stream,
                                         tun_name=tun_name):
                    break
                time.sleep(int(wait_time))
            else:
                self.session.send_line("cat /proc/ppa/pae/route")
                self.session.recv_line(self.prompt, timeout=10)
                raise Exception("Retry limit has been exceeded to get Sessions")

            #creating session file in DUT
            srcfile=None
            self.log_dirname = self.session.get_log_dir()
            self.srcfile = "/tmp/ppa_pae_log"
            self.session.send_line("cat /proc/ppa/pae/route &>{}".format(self.srcfile))
            self.session.recv_line(self.prompt, timeout=20)
            return True
        except Exception as e:
            logger.dumpLog("Issue with Hw sessions generation -- %s" %str(e))
            reultflag = "FAIL"
            return False

    def eval_pae_route_cmd(self,
                           proto=None,
                           lan_ip=None,
                           wan_ip=None,
                           stream=None,
                           ipv6_enable=False,
                           tun_name=None,
                           loop_count=None,
                           wait_time=None,
                           obj=None):
        '''Eval the pae route command cat /proc/ppa/pae/route in CPE
          Argumnets: system        - This argument is the object where route eval, default object is board
                     stream        - This argumnet is type of the traffic, default value is "upstream"
                     proto         - This argument is will specifies the type of transport layer, default value is "tcp"
                     lan_ip       - This argumnet is for LAN machine ip address, default ip is tsv_lan_static_ip
                     wan_ip       - This argumnet is for WAN machine ip address, default ip is tsv_wan_static_ipaddr
                     ipv6_enable - This argument is the status of IPv6 type, default value is False'''
        self.session.send_control("C")
        try:
            obj.tools.scp_download(server=self.dict['ipaddr'],
                              port="22",
                              user=self.dict['username'],
                              password=self.dict['password'],
                              from_location=self.srcfile,
                              to_location=self.log_dirname)

            self.session.send_line("rm -rf {}".format(self.srcfile))
            self.session.recv_line(self.prompt)
            ip_list = list()
            pktcnt_list = list()
            fname = os.path.join(self.log_dirname, "ppa_pae_log")
            #publish_html(comment="PAE log file:",log_link=fname)
            publish_html(comment="PAE log file:")

            msg =  self.session_parse(fname, lan_ip, wan_ip, proto, stream, ipv6_enable)
            if not msg:
                raise BaseException("Session Parsing Fails")
            return msg
        except:
            logger.dumpLog("route entry not parse -- %s" %str(e))
            return False

    def eval_tmu_eqt(self,
                     eval_msg=None,
                     stream=None,
                     hw_type=None,
                     wan_conn=None,
                     pae_route_resultflag="FAIL"):
        '''To eval tmu eqt values echo m -1 > /sys/kernel/debug/tmu/eqt
           Argumnets: system        - This argument is the object where eqt eval, default object is board
                      stream	- This argumnet is type of the traffic, default value is "upstream"
                      hw_type	- This argument specifies the type of HW accelaration MPE/PAE'''
        val_eqt_msg = ['msg','flag']
        clear_TmuEqt = self.clearTmuEQT()
        if clear_TmuEqt:
            self.session.send_control("C")
            time.sleep(2)
            output = self.session.send_recv("echo m -1 > /sys/kernel/debug/tmu/eqt", timeout=20)
            """[506266.950000]              36   35035028   35035028          0 (         0          0          0          0)          0          0 --CHXX MPE_FW """
            if hw_type == "MPE":
                match = re.search(".*?\d{2}\s+(\d+)\s+(\d+)\s+(\d+)\s+\(\s+\d+\s+\d+\s+\d+\s+\d+\)\s+\d+\s+\d+\s+\-\-\w+\s+CPU.*?\d{2}\s+(\d+)\s+(\d+)\s+(\d+)\s+\(\s+\d+\s+\d+\s+\d+\s+\d+\)\s+\d+\s+\d+\s+\-\-\w+\s+MPE_FW",output, re.DOTALL)
                if match:
                    cpu_enq = int(match.group(1))
                    cpu_deq = int(match.group(2))
                    cpu_drop = int(match.group(3))
                    logger.dumpLog("CPU enq deq drop: %d %d %d" % (cpu_enq,cpu_deq,cpu_drop))
                    mpe_enq = int(match.group(4))
                    mpe_deq = int(match.group(5))
                    mpe_drop = int(match.group(6))
                    logger.dumpLog("MPE enq deq drop: %d %d %d" % (mpe_enq, mpe_deq, mpe_drop))
                else:
                    alt_match = re.search(".*?\d{2}\s+(\d+)\s+(\d+)\s+(\d+)\s+\(\s+\d+\s+\d+\s+\d+\s+\d+\)\s+\d+\s+\d+\s+\-\-\w+\s+MPE_FW", output, re.DOTALL)
                    if alt_match:
                        cpu_enq = int(0)
                        cpu_deq = int(0)
                        cpu_drop = int(0)
                        logger.dumpLog("CPU enq deq drop: %d %d %d" % (cpu_enq,cpu_deq,cpu_drop))
                        mpe_enq = int(alt_match.group(1))
                        mpe_deq = int(alt_match.group(2))
                        mpe_drop = int(alt_match.group(3))
                        logger.dumpLog("MPE enq deq drop: %d %d %d" % (mpe_enq, mpe_deq, mpe_drop))
                tmu_result = self.validate_tmu_eqt(val_eqt_msg=val_eqt_msg,
                                                   enq=mpe_enq,
                                                   deq=mpe_deq,
                                                   drop=mpe_drop,
                                                   cpu_enq=cpu_enq,
                                                   cpu_deq=cpu_deq,
                                                   cpu_drop=cpu_drop,
                                                   flag="MPE",
                                                   pae_route_resultflag=pae_route_resultflag)
            elif hw_type == "PAE" and stream == "downstream":
                match = re.search(".*?\d{2}\s+(\d+)\s+(\d+)\s+(\d+)\s+\(\s+\d+\s+\d+\s+\d+\s+\d+\)\s+\d+\s+\d+\s+\-\-\w+\s+ETH_LAN.*?\d{2}\s+(\d+)\s+(\d+)\s+(\d+)\s+\(\s+\d+\s+\d+\s+\d+\s+\d+\)\s+\d+\s+\d+\s+\-\-\w+\s+CPU", output, re.DOTALL)
                if match:
                    ethLan_enq = int(match.group(1))
                    ethLan_deq = int(match.group(2))
                    ethLan_drop = int(match.group(3))
                    logger.dumpLog("Eth LAN enq deq drop: %d %d %d" % (ethLan_enq, ethLan_deq, ethLan_drop))
                    cpu_enq = int(match.group(4))
                    cpu_deq = int(match.group(5))
                    cpu_drop = int(match.group(6))
                    logger.dumpLog("CPU enq deq drop: %sd %d %d" % (cpu_enq, cpu_deq, cpu_drop))
                else:
                    alt_match= re.search(".*?\d{2}\s+(\d+)\s+(\d+)\s+(\d+)\s+\(\s+\d+\s+\d+\s+\d+\s+\d+\)\s+\d+\s+\d+\s+\-\-\w+\s+ETH_LAN",output, re.DOTALL)
                    if alt_match:
                       ethLan_enq = int(alt_match.group(1))
                       ethLan_deq = int(alt_match.group(2))
                       ethLan_drop = int(alt_match.group(3))
                       logger.dumpLog("Eth LAN enq deq drop: %d %d %d" % (ethLan_enq, ethLan_deq, ethLan_drop))
                       cpu_enq = int(0)
                       cpu_deq = int(0)
                       cpu_drop = int(0)
                       logger.dumpLog("CPU enq deq drop: %d %d %d" % (cpu_enq, cpu_deq, cpu_drop))

                tmu_result = self.validate_tmu_eqt(val_eqt_msg=val_eqt_msg,
                                                   enq=ethLan_enq,
                                                   deq=ethLan_deq,
                                                   drop=ethLan_drop,
                                                   cpu_enq=cpu_enq,
                                                   cpu_deq=cpu_deq,
                                                   cpu_drop=cpu_drop,
                                                   flag="ETH_LAN",
                                                   pae_route_resultflag=pae_route_resultflag)
            else:
                if not (wan_conn == "eth_tag" or wan_conn == "eth_untag"):
                    match= re.search(".*?\d{2}\s+(\d+)\s+(\d+)\s+(\d+)\s+\(\s+\d+\s+\d+\s+\d+\s+\d+\)\s+\d+\s+\d+\s+\-\-\w+\s+CPU.*?\d{2}\s+(\d+)\s+(\d+)\s+(\d+)\s+\(\s+\d+\s+\d+\s+\d+\s+\d+\)\s+\d+\s+\d+\s+\-\-\w+\s+FAST_WLAN",output, re.DOTALL)
                    if match:
                        eth_eq=4;eth_dq=5;eth_drp=6;cpu_eq=1;cpu_dq=2;cpu_drp=3
                        con_name = "FAST_WLAN"

                        ethWan_enq = int(match.group(eth_eq))
                        ethWan_deq = int(match.group(eth_dq))
                        ethWan_drop = int(match.group(eth_drp))
                        logger.dumpLog("%s enq deq drop: %d %d %d" % (con_name, ethWan_enq, ethWan_deq, ethWan_drop))
                        cpu_enq = int(match.group(cpu_eq))
                        cpu_deq = int(match.group(cpu_dq))
                        cpu_drop = int(match.group(cpu_drp))
                        logger.dumpLog("CPU enq deq drop: %d %d %d" % (cpu_enq, cpu_deq, cpu_drop))
                    else:
                        alt_match = re.search(".*?\d{2}\s+(\d+)\s+(\d+)\s+(\d+)\s+\(\s+\d+\s+\d+\s+\d+\s+\d+\)\s+\d+\s+\d+\s+\-\-\w+\s+FAST_WLAN.*?\d{2}\s+(\d+)\s+(\d+)\s+(\d+)\s+\(\s+\d+\s+\d+\s+\d+\s+\d+\)\s+\d+\s+\d+\s+\-\-\w+\s+CPU", output, re.DOTALL)
                        if alt_match:
                            eth_eq=1;eth_dq=2;eth_drp=3;cpu_eq=4;cpu_dq=5;cpu_drp=6
                            con_name = "FAST_WLAN"
                            ethWan_enq = int(alt_match.group(eth_eq))
                            ethWan_deq = int(alt_match.group(eth_dq))
                            ethWan_drop = int(alt_match.group(eth_drp))
                            logger.dumpLog("%s enq deq drop: %d %d %d" % (con_name, ethWan_enq, ethWan_deq, ethWan_drop))
                            cpu_enq = int(alt_match.group(cpu_eq))
                            cpu_deq = int(alt_match.group(cpu_dq))
                            cpu_drop = int(alt_match.group(cpu_drp))
                            logger.dumpLog("CPU enq deq drop: %d %d %d" % (cpu_enq, cpu_deq, cpu_drop))
                        else:
                            final_match = re.search(".*?\d{2}\s+(\d+)\s+(\d+)\s+(\d+)\s+\(\s+\d+\s+\d+\s+\d+\s+\d+\)\s+\d+\s+\d+\s+\-\-\w+\s+FAST_WLAN", output, re.DOTALL)
                            if final_match:
                                con_name = "FAST_WLAN"
                                ethWan_enq = int(final_match.group(1))
                                ethWan_deq = int(final_match.group(2))
                                ethWan_drop = int(final_match.group(3))
                                logger.dumpLog("%s enq deq drop: %d %d %d" % (con_name, ethWan_enq, ethWan_deq, ethWan_drop))
                                cpu_enq = int(0)
                                cpu_deq = int(0)
                                cpu_drop = int(0)
                                logger.dumpLog("CPU enq deq drop: %d %d %d" % (cpu_enq, cpu_deq, cpu_drop))


                else:
                    match = re.search(".*?\d{2}\s+(\d+)\s+(\d+)\s+(\d+)\s+\(\s+\d+\s+\d+\s+\d+\s+\d+\)\s+\d+\s+\d+\s+\-\-\w+\s+ETH_WAN.*?\d{2}\s+(\d+)\s+(\d+)\s+(\d+)\s+\(\s+\d+\s+\d+\s+\d+\s+\d+\)\s+\d+\s+\d+\s+\-\-\w+\s+CPU", output, re.DOTALL)
                    if match:
                        eth_eq=1;eth_dq=2;eth_drp=3;cpu_eq=4;cpu_dq=5;cpu_drp=6
                        con_name = "ETH_WAN"
                        ethWan_enq = int(match.group(eth_eq))
                        ethWan_deq = int(match.group(eth_dq))
                        ethWan_drop = int(match.group(eth_drp))
                        logger.dumpLog("%s enq deq drop: %d %d %d" % (con_name, ethWan_enq, ethWan_deq, ethWan_drop))
                        cpu_enq = int(match.group(cpu_eq))
                        cpu_deq = int(match.group(cpu_dq))
                        cpu_drop = int(match.group(cpu_drp))
                        logger.dumpLog("CPU enq deq drop: %d %d %d" % (cpu_enq, cpu_deq, cpu_drop))
                    else:
                        alt_match=re.search(".*?\d{2}\s+(\d+)\s+(\d+)\s+(\d+)\s+\(\s+\d+\s+\d+\s+\d+\s+\d+\)\s+\d+\s+\d+\s+\-\-\w+\s+CPU.*?\d{2}\s+(\d+)\s+(\d+)\s+(\d+)\s+\(\s+\d+\s+\d+\s+\d+\s+\d+\)\s+\d+\s+\d+\s+\-\-\w+\s+ETH_WAN", output, re.DOTALL)
                        if alt_match:
                            eth_eq=4;eth_dq=5;eth_drp=6;cpu_eq=1;cpu_dq=2;cpu_drp=3
                            con_name = "ETH_WAN"
                            ethWan_enq = int(alt_match.group(eth_eq))
                            ethWan_deq = int(alt_match.group(eth_dq))
                            ethWan_drop = int(alt_match.group(eth_drp))
                            logger.dumpLog("%s enq deq drop: %d %d %d" % (con_name, ethWan_enq, ethWan_deq, ethWan_drop))
                            cpu_enq = int(alt_match.group(cpu_eq))
                            cpu_deq = int(alt_match.group(cpu_dq))
                            cpu_drop = int(alt_match.group(cpu_drp))
                            logger.dumpLog("CPU enq deq drop: %d %d %d" % (cpu_enq, cpu_deq, cpu_drop))
                        else:
                            final_match= re.search(".*?\d{2}\s+(\d+)\s+(\d+)\s+(\d+)\s+\(\s+\d+\s+\d+\s+\d+\s+\d+\)\s+\d+\s+\d+\s+\-\-\w+\s+ETH_WAN",output, re.DOTALL)
                            if final_match:
                                con_name = "ETH_WAN"
                                ethWan_enq = int(final_match.group(1))
                                ethWan_deq = int(final_match.group(2))
                                ethWan_drop = int(final_match.group(3))
                                logger.dumpLog("%s enq deq drop: %d %d %d" % (con_name, ethWan_enq, ethWan_deq, ethWan_drop))
                                cpu_enq = int(0)
                                cpu_deq = int(0)
                                cpu_drop = int(0)
                                logger.dumpLog("CPU enq deq drop: %d %d %d" % (cpu_enq, cpu_deq, cpu_drop))
                tmu_result = self.validate_tmu_eqt(val_eqt_msg=val_eqt_msg,
                                                   enq=ethWan_enq,
                                                   deq=ethWan_deq,
                                                   drop=ethWan_drop,
                                                   cpu_enq=cpu_enq,
                                                   cpu_deq=cpu_deq,
                                                   cpu_drop=cpu_drop,
                                                   flag=con_name,
                                                   pae_route_resultflag=pae_route_resultflag)

            eval_msg[0] = val_eqt_msg[0]
            eval_msg[1] = val_eqt_msg[1]

        else:
            logger.dumpLog("Fail to clear TMU EQT validation")
            eval_msg[1]='FAIL'
            return False


    def validate_session(self,
                         proto=None,
                         stream=None,
                         tun_name=None):
        if proto == "tcp":
            if stream != "bidi":
                s_count = 2
            else:
                s_count = 4
        elif proto == "udp":
            if stream != "bidi":
                s_count = 1
            else:
                s_count = 2
        if tun_name == "IPSEC":
                s_count = s_count + 1
        try:
            self.session.send_line("cat /proc/ppa/pae/route | egrep Index -c")
            self.session.recv_line("(\d+)",timeout=10)
            session_cnt = int(self.session.match(1))
            logger.dumpLog("Session count = {}".format(session_cnt))
            if session_cnt != s_count:
                logger.dumpLog("Generated session count do not match with pre-counted session!!!")
                return False
            return True
        except Exception as e:
            self.session.send_control('C')
            logger.dumpLog("Timeout happened!!!!!!")
            return False


    def session_parse(self,
                      fname,
                      src_ip,
                      dst_ip,
                      proto,
                      stream,
                      ipv6_enable=False):
        '''To validate the pae route entry
    	Arguments: fname	- This argumnet is file name,
                      proto         - This argument is will specifies the type of transport layer, default value is "tcp"
                      src_ip       - This argumnet is for sourcemachine ip address
                      dst_ip       - This argumnet is for destination machine ip address
                      stream        - This argument is specifies the type of traffic flow
                      ipv6_enable - This argument is the status of IPv6 type, default value is False'''
        logger.dumpLog("starting parsing file %s" % fname)
        logger.dumpLog ("%s %s %s %s" % (src_ip, dst_ip, proto, stream))
        src_ip = str(ip_address(unicode(src_ip)).exploded.upper())
        dst_ip = str(ip_address(unicode(dst_ip)).exploded.upper())
        logger.dumpLog ("%s %s %s %s" % (src_ip, dst_ip, proto, stream))
        for_flag = 0
        acc_flag = 0
        for_src_ip = ""
        for_dst_ip = ""
        for_hit = 0
        for_ses_count = 0
        ack_src_ip = ""
        ack_dst_ip = ""
        ack_hit = 0
        ack_ses_count = 0
        bidi_dict={0:{"src_ip":"null", "dst_ip":"null", "hit_status":0, "ssn_cnt" : 0},
                   1:{"src_ip":"null", "dst_ip":"null", "hit_status":0, "ssn_cnt" : 0},
                   2:{"src_ip":"null", "dst_ip":"null", "hit_status":0, "ssn_cnt" : 0},
                   3:{"src_ip":"null", "dst_ip":"null", "hit_status":0, "ssn_cnt" : 0}}

        result_dict={'for_up':{"src_ip":"null","dst_ip":"null","ssn_cnt":0},
                      'ack_up':{"src_ip":"null","dst_ip":"null","ssn_cnt":0},
                      'for_down':{"src_ip":"null","dst_ip":"null","ssn_cnt":0},
                      'ack_down':{"src_ip":"null","dst_ip":"null","ssn_cnt":0}}

        bidi_index=0
        try:
            with open (fname, "r") as myfile:
                line = "a"
                while line:
                    line = myfile.readline()
                    if "Src IP" in line:
                        if ipv6_enable:
                            in_src_ip = self.get_ip_from_string(line)
                            in_src_ip = str(ip_address(unicode(in_src_ip)).exploded.upper())
                        else:
                            m = re.search(r'([0-9]+(?:\.[0-9]+){3})', line)
                            in_src_ip = m.group(1)
                        logger.dumpLog("Source IP: {}".format(in_src_ip))
                        if in_src_ip == src_ip:
                            logger.dumpLog ("Forward Source IP: {}".format(in_src_ip))
                            for_src_ip = in_src_ip
                            while line:
                               line = myfile.readline()
                               if "Dest IP" in line:
                                   if ipv6_enable:
                                       for_dst_ip = get_ip_from_string(line)
                                       for_dst_ip = str(ip_address(unicode(for_dst_ip)).exploded.upper())
                                   else:
                                       m = re.search(r'([0-9]+(?:\.[0-9]+){3})', line)
                                       for_dst_ip = m.group(1)
                                   logger.dumpLog("Forward Destination IP: {}".format(for_dst_ip))
                                   continue
                               if "Hit Status" in line:
                                   m = re.search(r'(\d)', line)
                                   for_hit = int (m.group(1))
                                   logger.dumpLog("Forward Hit Status: {}".format(for_hit))
                                   continue
                               if "Session Counters" in line:
                                   m = re.search(r'(\d+)', line)
                                   for_ses_count = int (m.group(1))
                                   logger.dumpLog("Forward Session count: {}".format(for_ses_count))
                                   for_flag = 1
                                   break

                            if stream == "bidi":
                                if not self.update_bidi_dict(bidi_dict,
                                                        src_ip=for_src_ip,
                                                        dst_ip=for_dst_ip,
                                                        hit_status=for_hit,
                                                        ssn_cnt=for_ses_count,
                                                        bidi_index=bidi_index):
                                    return False
                                bidi_index = bidi_index + 1

                        elif in_src_ip == dst_ip:
                            logger.dumpLog ("Ack Source IP: {}".format(in_src_ip))
                            ack_src_ip = in_src_ip
                            while line:
                               line = myfile.readline()
                               if "Dest IP" in line:
                                   if ipv6_enable:
                                       ack_dst_ip = get_ip_from_string(line)
                                       ack_dst_ip = str(ip_address(unicode(ack_dst_ip)).exploded.upper())
                                   else:
                                       m = re.search(r'([0-9]+(?:\.[0-9]+){3})', line)
                                       ack_dst_ip = m.group(1)
                                   logger.dumpLog("Ack Destination IP: {}".format(ack_dst_ip))
                                   continue
                               if "Hit Status" in line:
                                   m = re.search(r'(\d)', line)
                                   ack_hit = int (m.group(1))
                                   logger.dumpLog("Ack Hit status: {}".format(ack_hit))
                                   continue
                               if "Session Counters" in line:
                                   m = re.search(r'(\d+)', line)
                                   ack_ses_count = int (m.group(1))
                                   logger.dumpLog("Ack Session count: {}".format(ack_ses_count))
                                   ack_flag = 1
                                   break
                            if stream == "bidi":
                                if not self.update_bidi_dict(bidi_dict,
                                                        src_ip=ack_src_ip,
                                                        dst_ip=ack_dst_ip,
                                                        hit_status=ack_hit,
                                                        ssn_cnt=ack_ses_count,
                                                        bidi_index=bidi_index):
                                    return False
                                bidi_index = bidi_index + 1

                myfile.close()

            if proto == "tcp":
                if stream == "upstream":
                    if for_src_ip == src_ip and for_dst_ip == dst_ip and for_hit > 0 and for_ses_count > 0 and ack_src_ip == dst_ip and ack_hit > 0 and ack_ses_count > 0:
                        msg = ("Forward path->SrcIP: %s, DstIP: %s, session cnt: %d \nAck path->SrcIP: %s, DstIP: %s, session cnt: %d" % (for_src_ip, for_dst_ip, for_ses_count, ack_src_ip, ack_dst_ip, ack_ses_count))
                    else:
                        return False
                elif stream == "downstream":
                    if for_src_ip == src_ip and for_dst_ip == dst_ip and for_hit > 0 and for_ses_count > 0 and ack_src_ip == dst_ip and ack_hit > 0 and ack_ses_count > 0:
                        msg = ("Forward path->SrcIP: %s, DstIP: %s, session cnt: %d \nAck path->SrcIP: %s, DstIP: %s, session cnt: %d" % (ack_src_ip, ack_dst_ip, ack_ses_count, for_src_ip, for_dst_ip, for_ses_count))
                    else:
                        return False
                elif stream == "bidi":
                    if not self.validate_and_get_bidi_params(src_ip,
                                                        dst_ip,
                                                        bidi_dict,
                                                        result_dict,
                                                        proto):
                        logger.dumpLog("issue while validating")
                        return False
                    msg = ("Upstream-Forward path->SrcIP: %s, DstIP: %s, session cnt: %d \
                            \nUpstream-Ack path->SrcIP: %s, DstIP: %s, session cnt: %d \
                            \nDownstream-Forward path->SrcIP: %s, DstIP: %s, session cnt: %d \
                            \nDownstream-Ack path->SrcIP: %s, DstIP: %s, session cnt: %d" \
                            % (result_dict['for_up']['src_ip'],result_dict['for_up']['dst_ip'],result_dict['for_up']['ssn_cnt'],\
                               result_dict['ack_up']['src_ip'],result_dict['ack_up']['dst_ip'],result_dict['ack_up']['ssn_cnt'],\
                               result_dict['for_down']['src_ip'],result_dict['for_down']['dst_ip'],result_dict['for_down']['ssn_cnt'],\
                               result_dict['ack_down']['src_ip'],result_dict['ack_down']['dst_ip'],result_dict['ack_down']['ssn_cnt']))

                else:
                    return False
            else:
                if stream == "upstream":
                    if for_src_ip == src_ip and for_dst_ip == dst_ip and for_hit > 0 and for_ses_count > 0:
                        msg = ("Forward path->SrcIP: %s, DstIP: %s, session cnt: %d " % (for_src_ip, for_dst_ip, for_ses_count))
            	    else:
            	        return False
                elif stream == "downstream":
                    if ack_src_ip == dst_ip and ack_hit > 0 and ack_ses_count > 0:
                        msg = ("Forward path->SrcIP: %s, DstIP: %s, session cnt: %d " % (ack_src_ip, ack_dst_ip, ack_ses_count))
             	    else:
            	        return False
                elif stream == "bidi":
                    if not self.validate_and_get_bidi_params(src_ip,
                                                        dst_ip,
                                                        bidi_dict,
                                                        result_dict,
                                                        proto):
                        logger.dumpLog("issue while validating")
                        return False
                    msg = ("Upstream-Forward path->SrcIP: %s, DstIP: %s, session cnt: %d \
                            \nDownstream-Forward path->SrcIP: %s, DstIP: %s, session cnt: %d" \
                            % (result_dict['for_up']['src_ip'],result_dict['for_up']['dst_ip'],result_dict['for_up']['ssn_cnt'], \
                               result_dict['for_down']['src_ip'],result_dict['for_down']['dst_ip'],result_dict['for_down']['ssn_cnt']))

            logger.dumpLog("Route Entry details: %s" % msg)
            return msg
        except Exception as e:
            myfile.close()
            logger.dumpLog("Issue in the PROC Route entry - %s" %str(e))
            return False


    def update_bidi_dict(self,
                         bidi_dict,
                         src_ip="",
                         dst_ip="",
                         hit_status=0,
                         ssn_cnt=0,
                         bidi_index=0):
        try:
            bidi_dict[bidi_index]["src_ip"]=src_ip
            bidi_dict[bidi_index]["dst_ip"]=dst_ip
            bidi_dict[bidi_index]["hit_status"]=hit_status
            bidi_dict[bidi_index]["ssn_cnt"]=ssn_cnt
            return True
        except exception as e:
            logger.dumpLog("issue in updating bidi dict-%s" %str(e))
            return False


    def get_ip_from_string(self, line):
        '''To get IPv6 address
         Argumants: line	 - This argument is where has to get ipv6 address'''
        list1 = line.split("=")
        list1[1] = list1[1].replace("[","")
        list1[1] = list1[1].replace("]","")
        list1[1] = list1[1].replace("\n","")
        list1[1] = list1[1].replace("\b","")
        list1[1] = list1[1].replace("\t","")
        list1[1] = list1[1].replace(" ","")
        return str(list1[1])

    def validate_and_get_bidi_params(self,
                                     src_ip,
                                     dst_ip,
                                     bidi_dict,
                                     result_dict,
                                     proto):
        try:
            #validating hit status and ssn_cnts
            if proto == "tcp":
                sessions=4
            else:
                sessions=2

            for i in range(0,sessions):
                if bidi_dict[i]['hit_status'] > 0 and bidi_dict[i]['ssn_cnt'] > 0:
                    continue
                else:
                    logger.dumpLog("hit status and ssn cnt validation fails")
                    return False
            logger.dumpLog("hit status and ssn cnts are valid")

            if proto == "tcp":
                #Grepping src_ip and dst_ip with session cnts
                src_index=[0,0]
                lcl_index=0
                for i in range(0,sessions):
                    if src_ip == bidi_dict[i]['src_ip']:#taking upstream srcip as refrence for seggregation
                        src_index[lcl_index]=i
                        lcl_index = lcl_index + 1


                if bidi_dict[src_index[0]]['ssn_cnt'] > bidi_dict[src_index[1]]['ssn_cnt']:#1st dict is carrying  forward session and 2nd carrying ack session
                    if not self.update_result_dict(result_dict,
                                              bidi_dict,
                                              ssn1_str='for_up',
                                              index1=src_index[0],
                                              ssn2_str='ack_down',
                                              index2=src_index[1]):
                        logger.dumpLog("bidi params updation fails")
                        return False
                else:
                    if not self.update_result_dict(result_dict,
                                              bidi_dict,
                                              ssn1_str='for_up',
                                              index1=src_index[1],
                                              ssn2_str='ack_down',
                                              index2=src_index[0]):
                        logger.dumpLog("bidi params updation fails")
                        return False

                dst_index=[0,0]
                lcl_index=0
                for i in range(0,sessions):
                    if dst_ip == bidi_dict[i]['src_ip']:#taking upstream dstip as refrence for seggregation
                        dst_index[lcl_index]=i
                        lcl_index = lcl_index + 1

                if bidi_dict[dst_index[0]]['ssn_cnt'] > bidi_dict[dst_index[1]]['ssn_cnt']:#1st dict is carrying  forward session and 2nd carrying ack session
                    if not self.update_result_dict(result_dict,
                                              bidi_dict,
                                              ssn1_str='for_down',
                                              index1=dst_index[0],
                                              ssn2_str='ack_up',
                                              index2=dst_index[1]):
                        logger.dumpLog("bidi params updation fails")
                        return False
                else:

                    if not self.update_result_dict(result_dict,
                                              bidi_dict,
                                              ssn1_str='for_down',
                                              index1=dst_index[1],
                                              ssn2_str='ack_up',
                                              index2=dst_index[0]):
                        logger.dumpLog("bidi params updation fails")
                        return False
                return True
            else:#udp case
                if bidi_dict[0]['src_ip'] == src_ip:
                    index1=0
                    index2=1
                else:
                    index1=1
                    index2=0
                if not self.update_result_dict(result_dict,
                                          bidi_dict,
                                          ssn1_str='for_up',
                                          index1=index1,
                                          ssn2_str='for_down',
                                          index2=index2):
                    logger.dumpLog("bidi params updation fails")
                    return False

                if not self.validate_result_dict(result_dict, src_ip, dst_ip, proto):
                    logger.dumpLog("bidi params validation fails")
                    return False

                return True
        except Exception as e:
            logger.dumpLog("issue while validating bidi params - %s" %str(e))
            return False


    def clearTmuEQT(self):
        '''clearing the TMu EQT using the command echo c -1 > /proc/tmu/eqt in CPE
           Argumnets: system        - This argument is the object where the tmu eqt entry clear. default object is board'''
        try:

            self.session.send_line("echo c -1 > /sys/kernel/debug/tmu/eqt")
            self.session.recv_line(self.prompt, timeout=20)
            return True
        except:
            logger.dumpLog("Issue in ppacmd getlan/wansessions command")
            return False

    def validate_tmu_eqt(self,
                         val_eqt_msg='',
                         enq=0,
                         deq=0,
                         drop=0,
                         cpu_enq=0,
                         cpu_deq=0,
                         cpu_drop=0,
                         flag="MPE",
                         pae_route_resultflag=""):
        '''To validate the queue flags hit status for MPE/PAE
           Arguments: enq	- This argumant is enque value of queue flag
                      deq	- This argumant is deque value of queue flag
                      drop	- This argumant is drop value of queue flag
                      cpu_enq- This argumant is enque value of queue CPU flag
                      cpu_deq- This argumant is deque value of queue CPU flag
                      cpu_drop- This argumant is drop value of queue CPU flag
                      flag	- This argument specifies the type of HW accelaration MPE/PAE'''
        logger.dumpLog("In TMU EQT validation")
        resultflag = "SUCCESS"
        try:
            if enq:
                enq_digits = len(str(enq))
                cpu_enq_digits = len(str(cpu_enq))
                result_digits = int(enq_digits - cpu_enq_digits)
                logger.dumpLog("dif digits of flag and CPU: %d" % result_digits)
                packet_drops = int(drop)
                cpu_packet_drops = int(cpu_drop)
                if (result_digits < 2):
                    if pae_route_resultflag == "SUCCESS" and result_digits == 1:
                        msg = ("\n %s enq deq drop ->%d %d %d \n CPU enq deq drop -> %d %d %d" %(flag, enq, deq, drop, cpu_enq, cpu_deq, cpu_drop))
                        logger.dumpLog(msg)
                    else:
                        logger.dumpLog ("failed : traffic is going through CPU path\n")
                        msg = ("\n %s enq deq drop ->%d %d %d \n CPU enq deq drop -> %d %d %d \nFailed : traffic is going through CPU path" %(flag, enq, deq, drop, cpu_enq, cpu_deq, cpu_drop))
                        resultflag = "FAIL"
                elif (packet_drops > 100):
                    logger.dumpLog ("failed : packets %d are dropping at %s\n" % (packet_drops, flag))
                    msg = ("\n %s enq deq drop ->%d %d %d \n CPU enq deq drop -> %d %d %d \nWarning : packets %d are dropping at %s" %(flag, enq, deq, drop, cpu_enq, cpu_deq, cpu_drop, packet_drops, flag))
                    #resultflag = "FAIL"
                elif (cpu_packet_drops > 100):
                    logger.dumpLog ("failed : packets %d  are dropping at CPU\n" % cpu_packet_drops)
                    msg = ("\n %s enq deq drop ->%d %d %d \n CPU enq deq drop -> %d %d %d\nFailed : packets %d  are dropping at CPU" %(flag, enq, deq, drop, cpu_enq, cpu_deq, cpu_drop, cpu_packet_drops))
                    resultflag = "FAIL"
                else:
                    msg = ("\n %s enq deq drop ->%d %d %d \n CPU enq deq drop -> %d %d %d" %(flag, enq, deq, drop, cpu_enq, cpu_deq, cpu_drop))
                    logger.dumpLog(msg)
            else:
                logger.dumpLog ("failed : No packets capture\n")
                msg = ("failed : No packets capture")
                resultflag = "FAIL"
            val_eqt_msg[0] = msg
            val_eqt_msg[1] = resultflag
        except Exception as e:
            logger.dumpLog("issue while validating tmu params - %s" %str(e))
            msg = ("issue while validating tmu params - %s" %str(e))
            resultflag = "FAIL"
            val_eqt_msg[0] = msg
            val_eqt_msg[1] = resultflag

    def update_result_dict(self, result_dict, bidi_dict, ssn1_str="", index1=0, ssn2_str="", index2=0):
        try:
            result_dict[ssn1_str]['src_ip']=bidi_dict[index1]['src_ip']
            result_dict[ssn1_str]['dst_ip']=bidi_dict[index1]['dst_ip']
            result_dict[ssn1_str]['ssn_cnt']=bidi_dict[index1]['ssn_cnt']
            result_dict[ssn2_str]['src_ip']=bidi_dict[index2]['src_ip']
            result_dict[ssn2_str]['dst_ip']=bidi_dict[index2]['dst_ip']
            result_dict[ssn2_str]['ssn_cnt']=bidi_dict[index2]['ssn_cnt']
            return True
        except Exception as e:
            logger.dumpLog("issue while updating result dict - %s" %str(e))
            return False


    def validate_result_dict(self, result_dict, src_ip, dst_ip, proto):
        try:
            if proto == "tcp":
                if result_dict['for_up']['src_ip'] == src_ip and\
                   result_dict['for_up']['dst_ip'] == dst_ip and\
                   result_dict['ack_up']['src_ip'] == dst_ip and\
                   result_dict['for_down']['src_ip'] == dst_ip and\
                   result_dict['ack_down']['src_ip'] == src_ip and\
                   result_dict['ack_down']['dst_ip'] ==dst_ip:
                    logger.dumpLog("bidi src ip and dest ip up and down mactches")
                    return True
                else:
                    logger.dumpLog("bidi src ip and dest ip up and down does not mactches")
                    return False
            else:#udp case
                if result_dict['for_up']['src_ip'] == src_ip and\
                   result_dict['for_up']['dst_ip'] == dst_ip and\
                   result_dict['for_down']['src_ip'] == dst_ip:
                    logger.dumpLog("bidi src ip and dest ip up and down mactches")
                    return True
                else:
                    logger.dumpLog("bidi src ip and dest ip up and down does not mactches")
                    return False
        except Exception as e:
            logger.dumpLog("issue while validating bidi results - %s" %str(e))
            return False

    def __init__(self):
        pass

    def test_func(self):
        print("method inside this class %s" % self.__class__.__name__)


    def test_grx550_fapi(self):
        print("test_grx550_fapi")

if __name__ == "__main__":
    obj = Grx550Fapi()
    obj.test_func()
