

class Grx550Uci:
    """This class will provide model specific apis"""


    def __init__(self):
        pass

    def test_func(self):
        print("method inside this class %s" % self.__class__.__name__)

    def test_grx550_uci(self):
        print("test_grx550_uci")

if __name__ == "__main__":
    obj = Grx550Uci()
    obj.test_func()
