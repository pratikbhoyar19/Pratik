import os
import glob
test_files = glob.glob(os.path.dirname(__file__)+"/*")
for x in sorted([os.path.basename(f)[:] for f in test_files if not "__" in f and not "*.py*" in f]):
    try:
        exec("from %s import *" % x)
    except Exception as e:
        print(e)
        print("Warning: could not import from file %s." % x)

