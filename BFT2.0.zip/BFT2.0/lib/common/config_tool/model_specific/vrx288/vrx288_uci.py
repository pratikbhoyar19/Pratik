

class Vrx288Uci:
    """This class will provide model specific apis"""


    def __init__(self):
        pass

    def test_func(self):
        print("method inside this class %s" % self.__class__.__name__)

    def test_vrx288_uci(self):
        print("test_vrx288_uci")

if __name__ == "__main__":
    obj = Vrx288Uci()
    obj.test_func()
