

class Vrx288Clish:
    """This class will provide model specific apis"""


    def __init__(self):
        pass

    def test_func(self):
        print("method inside this class %s" % self.__class__.__name__)


    def test_vrx288_clish(self):
        print("test_vrx288_clish")

if __name__ == "__main__":
    obj = Vrx288Clish()
    obj.test_func()
