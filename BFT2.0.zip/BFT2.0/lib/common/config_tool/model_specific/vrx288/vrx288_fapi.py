

class Vrx288Fapi:
    """This class will provide model specific apis"""


    def __init__(self):
        pass

    def test_func(self):
        print("method inside this class %s" % self.__class__.__name__)


    def test_vrx288_fapi(self):
        print("test_vrx288_fapi")

if __name__ == "__main__":
    obj = Vrx288Fapi()
    obj.test_func()
