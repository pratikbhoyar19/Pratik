
class Grx750Fapi:
    """This class will provide model specific apis"""

    def __init__(self):
        pass

    def hw_accel_validate(self,
                          message=None,
                          proto=None,
                          lan_host_eth_ip=None,
                          wan_host_eth_ip=None,
                          stream=None,
                          tun_name=None,
                          ipv6_enable=False,
                          hw_type=None,
                          wan_conn=None,
                          wait_time=None,
                          loop_count=None,
                          obj=None):
        '''To validate the Hardware accelaration for MPE and PAE
           Argumnets: message	- This argumnet is for store the return type and message
                      system        - This argument is the object where the hw accel validate check. default object is board
                      proto		- This argument is will specifies the type of transport layer, default value is "tcp"
                      lan_host_eth_ip	- This argumnet is for LAN machine ip address, default ip is tsv_lan_static_ip
                      wan_host_eth_ip	- This argumnet is for WAN machine ip address, default ip is tsv_wan_static_ipaddr
                      stream	- This argument is specifies the type of traffic flow , default value "upstream"
                      tun_name	- This argumnet is the object for telling the type of Tunnel,
                      ipv6_enable - This argument is the status of IPv6 type, default value is False
                      hw_ype	- This argument specifies the type of HW accelaration MPE/PAE'''

        print("DUMMY 750 HW ACCEL API is called for Demonstration")
        return True

    def test_func(self):
        print("method inside this class %s" % self.__class__.__name__)

    def test_grx750_fapi(self):
        print("test_grx750_fapi")

if __name__ == "__main__":
    obj = Grx750Fapi()
    obj.test_func()
