class Grx750Clish:
    """This class will provide model specific apis"""

    def __init__(self):
        pass

    def test_func(self):
        print("method inside this class %s" % self.__class__.__name__)

    def test_grx750_clish(self):
        print("test_grx750_clish")

if __name__ == "__main__":
    obj = Grx750Clish()
    obj.test_func()
