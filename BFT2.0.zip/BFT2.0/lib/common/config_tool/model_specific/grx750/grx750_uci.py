class Grx750Uci:
    """This class will provide model specific apis"""

    def __init__(self):
        pass

    def test_func(self):
        print("method inside this class %s" % self.__class__.__name__)

    def test_grx750_uci(self):
        print("test_grx750_uci")

if __name__ == "__main__":
    obj = Grx750Uci()
    obj.test_func()
