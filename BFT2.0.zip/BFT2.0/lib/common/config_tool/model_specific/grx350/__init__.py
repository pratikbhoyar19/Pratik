import os
import glob
test_files = glob.glob(os.path.dirname(__file__)+"/*.py")
#print(test_files)
for x in sorted([os.path.basename(f)[:-3] for f in test_files if not "__" in f]):
    #print("x=%s" %x)
    try:
        exec("from %s import *" % x)
        #print("from %s import *" % x)
    except Exception as e:
        print(e)
        print("Warning: could not import from file %s." % x)