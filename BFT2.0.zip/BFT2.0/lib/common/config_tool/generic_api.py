

class GenericApi:
    '''consist of general apis'''

    def __init__(self):
        pass

    def test_func(self):
        print("method inside this class %s" % self.__class__.__name__)


if __name__ == "__main__":
    obj = GenericApi()
    obj.test_func()
