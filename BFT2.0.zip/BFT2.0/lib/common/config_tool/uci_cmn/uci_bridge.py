

class BridgeUci:
    """This class will contain all uci APIs related to Bridge functionality"""


    def __init__(self):
        pass

    def debug_func(self):
        print("Method inside this class %s" % self.__class__.__name__)

    def test_bridgeuci(self):
        print("method inside class BridgeUci")


if __name__ == "__main__":
    obj = BridgeUci()
    obj.debug_func()

