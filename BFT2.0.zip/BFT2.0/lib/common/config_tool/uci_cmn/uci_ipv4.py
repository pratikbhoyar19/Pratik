from globalVariables import *
import time
from log_creator import loggerObject as logger
#from devices import dut,lan,wan

class Ipv4Uci:
    """This class will contain all uci APIs related to Ipv4 functionality"""

    def __init__(self):
        pass

    def is_valid_static_ip(self, obtain_ip, assing_ip):
        if(obtain_ip == assing_ip):
            return True
        else:
            logger.dumpLog("IP is not valid")
            return False

    def net_commit_changes(self, tsv_timeout):
        '''To commit and save changes in the network config file of DUT
           Arguments: tsv_timeout - This airgument is the sleep value'''
        self.session.send_line("uci commit")
        #self.session.recv_line('.*:~#', timeout=50)
        self.session.send_line("/etc/init.d/network restart")
        time.sleep(tsv_timeout)
        self.session.send_line("\n")

    def wan_gen_conf(self,
            wan_ifname=tsv_ethwan_untagged,
            wan_proto=tsv_ip_proto_dhcp,
            wan_iface=tsv_ethernet_iface,
            vlan_id=tsv_eth_vlan, ipv6_enable=False):
        '''To configure the general WAN method in network conf file of board
           Arguments: wan_ifname  - This argument is the WAN interface name, default name is tsv_ethwan_untagged
                      wan_proto   - This argument is the WAN protocol name, default proto is tsv_ip_proto_dhcp
                      wan_iface   - This argument is the WAN iface, default WAN iface is tsv_ethernet_iface
                      vlan_id     - This argument is the WAN vlan id, default id is tsv_eth_vlan
                      ipv6_enable - This argument is the status of IPv6 type, default value is False'''
        if ipv6_enable:
            self.session.send_line("uci set network.%s=interface" % wan_iface)

        if vlan_id:
            self.session.send_line(
                "uci set network.%s.enable_vlan=%d" %
                (wan_iface, vlan_id))
        self.session.send_line("uci set network.%s.ifname=%s" % (wan_iface, wan_ifname))
        self.session.send_line("uci set network.%s.proto=%s" % (wan_iface, wan_proto))

    def wan_static_conf(self,
            wan_ipaddr=tsv_wan_static_ipaddr,
            wan_gateway=tsv_wan_static_gw,
            wan_netmask=tsv_wan_netmask,
            wan_iface=tsv_ethernet_iface,
            wan_dns=tsv_wan_dns_addr1):
        '''To configure static WAN method in network conf file of board
           Arguments: wan_ipaddr   - This argument is the WAN IP address, default IP is tsv_wan_static_ipaddr
                      wan_gateway  - This argument is the WAN gateway IP address, default gateway IP is tsv_wan_static_gw
                      wan_netmask  - This argument is the WAN netmask, default netmask is tsv_wan_netmask
                      wan_iface    - This argument is the WAN iface, default iface is tsv_ethernet_iface
                      wan_dns      - This argument is the WAN DNS IP address, default IP is tsv_wan_dns_addr1'''
        self.session.send_line("uci set network.%s.ipaddr=%s" % (wan_iface, wan_ipaddr))
        self.session.recv_line(self.prompt)
        self.session.send_line("uci set network.%s.gateway=%s" % (wan_iface, wan_gateway))
        self.session.recv_line(self.prompt)
        self.session.send_line("uci set network.%s.netmask=%s" % (wan_iface, wan_netmask))
        self.session.recv_line(self.prompt)
        self.session.send_line("uci set network.%s.dns=%s" % (wan_iface, wan_dns))

    def wan_pppoe_conf(self,
            pppoe_user=tsv_pppoe_user,
            pppoe_pass=tsv_pppoe_pass,
            wan_iface=tsv_ethernet_iface):
        '''To configure pppoe WAN method in network conf file of board
           Arguments: pppoe_user  - This argument is the WAN PPPoE user name, default name is tsv_pppoe_user
                      pppoe_pass  - This argument is the WAN PPPoE password, default password is tsv_pppoe_pass
                      wan_iface   - This argument is the WAN iface, default iface is tsv_ethernet_iface'''
        self.session.send_line("uci set network.%s.username=%s" % (wan_iface, pppoe_user))
        self.session.recv_line(self.prompt)
        self.session.send_line("uci set network.%s.password=%s" % (wan_iface, pppoe_pass))
        self.session.recv_line(self.prompt)

    def wan_pppoa_conf(self,
            pppoa_user=tsv_pppoa_user,
            pppoa_pass=tsv_pppoa_pass,
            pppoa_vpi=tsv_pppoa_vpi,
            pppoa_vci=tsv_pppoa_vci,
            pppoa_encaps=tsv_pppoa_encaps,
            wan_iface=tsv_ethernet_iface):
        '''To configure pppoa WAN method in network conf file of board
           Arguments: pppoa_user   - This argument is the PPPoA user name, default name is tsv_pppoa_user
                      pppoa_pass   - This argument is the PPPoA password, default password is tsv_pppoa_pass
                      pppoa_vpi    - This argument is the PPPoA vpi value, default value is tsv_pppoa_vpi
                      pppoa_vci    - This argument is the PPPoA vci value, default value is tsv_pppoa_vci
                      pppoa_encaps - This argument is the PPPoA encaps value, default value is tsv_pppoa_encaps
                      wan_iface   - This argument is the WAN iface, default WAN iface is tsv_ethernet_iface'''
        self.session.send_line("uci set network.%s.username=%s" % (wan_iface, pppoa_user))
        self.session.recv_line(self.prompt)
        self.session.send_line("uci set network.%s.password=%s" % (wan_iface, pppoa_pass))
        self.session.recv_line(self.prompt)
        self.session.send_line("uci set network.%s.vpi=%s" % (wan_iface, pppoa_vpi))
        self.session.recv_line(self.prompt)
        self.session.send_line("uci set network.%s.vci=%s" % (wan_iface, pppoa_vci))
        self.session.recv_line(self.prompt)
        self.session.send_line("uci set network.%s.encaps=%s" % (wan_iface, pppoa_encaps))
        self.session.recv_line(self.prompt)

    def wan_conn_config(self, wan_conn=tsv_ethernet_iface, ipv6_enable=False):
        '''To select connection type by Setting default route in network conf file of board
           Arguments: wan_conn   -  This argument is the WAN connection type, default type is tsv_ethernet_iface
                      ipv6_enable - This argument is the status of IPv6 type, default value is False'''
        if not ipv6_enable==True:
            iface_list = [
                tsv_ethernet_iface,
                tsv_vdsl_iface,
                tsv_adsl_wan_iface]
        else:
            iface_list = [
                tsv_ipv6_ethwan_iface, tsv_ipv6_vdsl_iface]
        for iface in iface_list:
            self.session.send_line(
                "uci set network.%s.defaultroute=%s" %
                (iface, tsv_defaultroute_reset))
        self.session.send_line(
            "uci set network.%s.defaultroute=%s" %
            (wan_conn, tsv_defaultroute_set))

    def wan_mode_config(self,
            wan_proto=tsv_ip_proto_dhcp,
            wan_interface=dut_wan_interface,
            user=tsv_pppoe_user,
            password=tsv_pppoe_pass,
            static_ipaddr=tsv_wan_static_ipaddr,
            static_gw=tsv_wan_static_gw,
            wan_netmask=tsv_wan_netmask,
            wan_conn=tsv_ethwan_untagged,
            wan_dns=tsv_wan_dns_addr1,
            vpi=tsv_pppoa_vpi,
            vci=tsv_pppoa_vci,
            encaps=tsv_pppoa_encaps,
            ipv6_enable=False,
            netmask=tsv_ipv6_route_netmask):
        '''To configure the WAN mode in network conf file of board
           Arguments: wan_proto     - This argument is the WAN protocol type, default type is tsv_ip_proto_dhcp
                      wan_interface - This argument is the WAN interface name, default name is dut_wan_interface
                      user          - This argument is the user name, default name is tsv_pppoe_user
                      password      - This argument is the password, default password is tsv_pppoe_pass
                      static_ipaddr - This argument is the WAN static IP address, default IP is tsv_wan_static_ipaddr
                      static_gw     - This argument is the WAN static gateway IP address, default gateway is tsv_wan_static_gw
                      wan_netmask   - This argument is the WAN static netmask, default netmask is tsv_wan_netmask
                      wan_conn      - This argument is the WAN conection type, default type is tsv_ethwan_untagged
                      wan_dns       - This argument is the WAN DNS address, default addr is tsv_wan_dns_addr1
                      vpi           - This argument is the vpi value, default value is tsv_pppoa_vpi
                      vci           - This argument is the vci value, default value is tsv_pppoa_vci
                      encaps        - This argument is the encaps value, default value is tsv_pppoa_encaps
                      ipv6_enable - This argument is the status of IPv6 type, default value is False'''
        logger.dumpLog("configures the wan mode From logger")
        global dut_wan_interface
        vlan_id = 0
        if ipv6_enable:

            if wan_conn is tsv_ipv6_ethwan_untagged:
                dut_wan_interface = tsv_ipv6_ethwan_untagged
                wan_iface = tsv_ipv6_ethwan_iface
            if wan_conn is tsv_ipv6_ethwan_tagged:
                dut_wan_interface = tsv_ipv6_ethwan_tagged
                wan_iface = tsv_ipv6_ethwan_iface
                vlan_id = tsv_eth_vlan
            if wan_conn is tsv_ipv6_vdsl_ptm_tagged_17a:
                dut_wan_interface = tsv_ipv6_vdsl_ptm_tagged_17a
                wan_iface = tsv_ipv6_vdsl_iface
                vlan_id = tsv_dsl_vlan
            if wan_conn is tsv_ipv6_ethwan_slaac_stateless_tagged:
                dut_wan_interface = tsv_ipv6_ethwan_slaac_stateless_tagged
                wan_iface = tsv_ipv6_ethwan_iface
                vlan_id = tsv_eth_slaac_stateless_vlan
            if wan_conn is tsv_ipv6_ethwan_slaac_stateful_tagged:
                dut_wan_interface = tsv_ipv6_ethwan_slaac_stateful_tagged
                wan_iface = tsv_ipv6_ethwan_iface
                vlan_id = tsv_eth_slaac_stateful_vlan
            if wan_conn is tsv_ipv6_ptmwan_slaac_stateless_tagged:
                dut_wan_interface = tsv_ipv6_ptmwan_slaac_stateless_tagged
                wan_iface = tsv_ipv6_vdsl_iface
                vlan_id = tsv_eth_slaac_stateless_vlan
            if wan_conn is tsv_ipv6_ptmwan_slaac_stateful_tagged:
                dut_wan_interface = tsv_ipv6_ptmwan_slaac_stateful_tagged
                wan_iface = tsv_ipv6_vdsl_iface
                vlan_id = tsv_eth_slaac_stateful_vlan

        else:
            if wan_conn is tsv_ethwan_untagged:
                dut_wan_interface = tsv_ethwan_untagged
                wan_iface = tsv_ethernet_iface
            if wan_conn is tsv_ethwan_tagged:
                dut_wan_interface = tsv_ethwan_tagged
                wan_iface = tsv_ethernet_iface
                vlan_id = tsv_eth_vlan
            if wan_conn is tsv_vdsl_ptm_tagged:
                dut_wan_interface = tsv_vdsl_ptm_tagged
                wan_iface = tsv_vdsl_iface
                vlan_id = tsv_dsl_vlan
            if wan_conn is tsv_adsl_atm_untagged:
                dut_wan_interface = tsv_adsl_atm_untagged
                wan_iface = tsv_adsl_iface
                vlan_id = tsv_dsl_vlan
            if wan_conn is tsv_adsl_atm_tagged:
                dut_wan_interface = tsv_adsl_atm_tagged
                wan_iface = tsv_adsl_wan_iface
                wan_bridge = tsv_adsl_iface

        logger.dumpLog("WAN connection received is " + wan_conn)
        logger.dumpLog("WAN interface received is " + dut_wan_interface)

        if (dut_wan_interface == tsv_adsl_atm_tagged) and (
                wan_proto != tsv_ip_proto_pppoa):
            self.wan_atm_config(
                username=tsv_adsl_atm_username,
                password=tsv_adsl_atm_pass,
                wan_bridge=wan_bridge,
                vpi=vpi,
                vci=vci,
                encaps=encaps)

        '''if wan conf does not matches executes this logic'''
        self.wan_gen_conf(dut_wan_interface, wan_proto, wan_iface, vlan_id, ipv6_enable)

        if(wan_proto == tsv_ip_proto_dhcp) or (wan_proto == tsv_ipv6_proto_dhcpv6):
            pass

        elif(wan_proto == tsv_ip_proto_pppoe):
            self.wan_pppoe_conf(user, password, wan_iface)

        elif(wan_proto == tsv_ip_proto_static):
            self.wan_static_conf(
                static_ipaddr,
                static_gw,
                wan_netmask,
                wan_iface,
                wan_dns)

        elif(wan_proto == tsv_ip_proto_pppoa):
            self.wan_pppoa_conf(user, password, vpi, vci, encaps, wan_iface)

        else:
            return False
        self.wan_conn_config(wan_conn=wan_iface, ipv6_enable=ipv6_enable)
        self.net_commit_changes(tsv_timeout)
        logger.dumpLog("opestate WAN interface received is " + dut_wan_interface)

        dut_wan_if_name = dut_wan_interface
        if(wan_proto == tsv_ip_proto_pppoe):
            dut_wan_if_name = "pppoe-" + wan_iface

        if ipv6_enable:
            ip_address = 0
            for i in range(0, 3):
                ip_address = self.os.get_interface_ipv6(dut_wan_if_name, netmask=netmask)
                if not ip_address:
                    time.sleep(tsv_timeout)
                    continue
                else:
                    break
        else:
            ip_address = 0
            for i in range(0, 3):
                #print(dut_wan_if_name)
                ip_address = self.os.get_interface_ipaddr(dut_wan_if_name)
                if not ip_address:
                    time.sleep(tsv_timeout)
                    continue
                else:
                    break

        if(wan_proto == tsv_ip_proto_static):
            if not self.os.is_valid_static_ip(str(ip_address), str(static_ipaddr)):
                return False

        return ip_address

    def reset_network_defaults(self):
        '''To reset the network to defaults in DUT
           Arguments: system    - This argument is the object to reset the network, default object is board'''
        self.session.send_line('rm -rf /etc/config/network')
        #self.session.recv_line(self.prompt)
        self.session.send_line('/rom/etc/uci-defaults/network')
        #self.session.recv_line(self.prompt)
        self.net_commit_changes(int(tsv_timeout))
        return True

    def wan_atm_config(self,
            username=tsv_adsl_atm_username,
            password=tsv_adsl_atm_pass,
            wan_bridge=tsv_adsl_iface,
            vpi=tsv_atm_vpi,
            vci=tsv_atm_vci,
            encaps=tsv_atm_encaps):
        '''To configure pppoa WAN method in network conf file of board
           Arguments: board        - This argument is the object in which atm configuration will be done, default object is board
                      wan_bridge   - This argument is the atm bridge name, default name is tsv_adsl_iface
                      vpi          - This argument is the ATM vpi value, default value is tsv_atm_vpi
                      vci          - This argument is the ATM vci value, default value is tsv_atm_vci
                      encaps       - This argument is the ATM encaps value, default value is tsv_atm_encaps'''
        self.session.send_line("uci set network.%s=atm-bridge" % (wan_bridge))
        self.session.recv_line(self.prompt)
        self.session.send_line("uci set network.%s.vpi=%s" % (wan_bridge, vpi))
        self.session.recv_line(self.prompt)
        self.session.send_line("uci set network.%s.vci=%s" % (wan_bridge, vci))
        self.session.recv_line(self.prompt)
        self.session.send_line("uci set network.%s.encaps=%s" % (wan_bridge, encaps))
        self.session.recv_line(self.prompt)

    def firewall_commit_changes(self,tsv_timeout):
        '''To commit and save changes in the firewall config file of board(DUT)'''
        self.session.send_line("uci commit firewall")
        #self.session.recv_line(self.prompt)
        self.session.send_line("/etc/init.d/firewall restart")
        time.sleep(10)

    def add_remove_dmz_rule(self,dest_ip=tsv_lan_static_ip, enable=tsv_dmz_deactiavte):
        ''' To add or remove dmz rule in firewall config file of board(DUT)
        Arguments: dest_ip   - This argument is the dest_ip of DMZ rule, default ip is lan_host_eth_ip
        enable    - This argument is the status of DMZ rule, default status is tsv_dmz_deactiavte'''
        self.session.send_line('uci set firewall.dmz.dest_ip=%s' % dest_ip)
        self.session.send_line('uci set firewall.dmz.enabled=%s' % enable)
        self.firewall_commit_changes()

    def add_remove_dmz_rule_firewall(self,dest_ip=tsv_lan_static_ip, enable=tsv_dmz_deactiavte,\
                                     param=tsv_firewall_default_forward,forward_rule=tsv_firewall_reject,tsv_timeout=tsv_timeout):
        '''To add or remove dmz rule in firewall config file of board(DUT)
        Arguments: dest_ip   - This argument is the dest_ip of DMZ rule, default ip is lan_host_eth_ip
        enable    - This argument is the status of DMZ rule, default status is tsv_dmz_deactiavte'''
        self.session.send_line('uci set firewall.dmz.dest_ip=%s' % dest_ip)
        self.session.send_line('uci set firewall.dmz.enabled=%s' % enable)
        self.session.send_line("uci set firewall.@defaults[0].%s=%s" % (param, forward_rule))
        self.session.send_line("uci commit firewall")
        self.session.send_line("/etc/init.d/firewall restart")
        time.sleep(int('10'))

    def add_default_config(self,param=tsv_firewall_default_forward,forward_rule=tsv_firewall_reject):
        '''To enable/disable firewall default parameters in firewall config file of board(DUT)
        Arguments: param        - This argument is the parameter name, default name is tsv_firewall_default_forward
        forward_rule - This argument is the forwarding rule, default rule is tsv_firewall_reject'''
        self.session.send_line("uci set firewall.@defaults[0].%s=%s" % (param, forward_rule))
        self.firewall_commit_changes()

    def debug_func(self):
        print("Method inside this class %s" % self.__class__.__name__)

    def test_ipv4uci(self):
        print("method inside class Ipv4Uci")

if __name__ == "__main__":
    obj = Ipv4Uci()
    obj.debug_func()
