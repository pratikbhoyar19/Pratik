

class MulticastUci:
    """This class will contain all uci APIs related to Multicast functionality"""


    def __init__(self):
        pass

    def debug_func(self):
        print("Method inside this class %s" % self.__class__.__name__)

    def test_multicastuci(self):
        print("method inside class MulticastUci")


if __name__ == "__main__":
    obj = MulticastUci()
    obj.debug_func()
