from lib.wlan.test_lib.global_params import *
from globalVariables import *
import copy

class WifiUci:
    """This class will contains uci APIs related to Wifi functionality"""

    radio_params_org = {}
    prev_r_params = {}
    global_ap_radio=""

    def __init__(self):
        pass

    def test_wifi(self):
        print("in uci wifi")

    def config_ap_gen(
            self,
            radio_params,
            wlan_index,
            revert=tsv_revert_reset,
            caller_api=""):
        '''To configure the system with general wifi configs
           Arguments: radio_parms  - This argument is a dictionary with radio parameters which has to configure
                      wlan_index   - This argument is the index value of wifi iface config
                      system       - This argument is the object where wifi configurations has to do, default object is board'''
        i = wlan_index
        if caller_api != "":#BFT2.0 Supports this logic
            if caller_api == "setUpClass" or caller_api == "tearDownClass":
                if i == 0:
                    self.radio_params_org = copy.deepcopy(radio2g_params)
                elif i == 1:
                    self.radio_params_org = copy.deepcopy(radio5g_params)
                self.prev_r_params = copy.deepcopy(radio_params)
            elif caller_api == "setUp":
                self.radio_params_org = copy.deepcopy(self.prev_r_params)
        else:#legacy operation
            if i == 0:
                self.radio_params_org = copy.deepcopy(radio2g_params)
            elif i == 1:
                self.radio_params_org = copy.deepcopy(radio5g_params)

        if revert == tsv_revert_set:
            self.logger.dumpLog("swapping logic needed for reverting")
            temp = radio_params
            radio_params = self.radio_params_org
            self.radio_params_org = temp

            self.session.send_line(
                "uci set wireless.@wifi-iface[%s].encryption=%s" %
                (i, radio_params['wlan_enc']))
            self.session.send_line(
                "uci set wireless.@wifi-iface[%s].key=%s" %
                (i, radio_params['wlan_key']))

        try:
            if radio_params['wlan_ifname'] != self.radio_params_org['wlan_ifname']:
                self.session.send_line(
                    "uci set wireless.%s.ifname=%s" %
                    (radio_params['wlan_iface'],
                     radio_params['wlan_ifname']))

            if radio_params['wlan_beacon_interval'] != self.radio_params_org['wlan_beacon_interval']:
                self.session.send_line(
                    "uci set wireless.%s.beacon_int=%s" %
                    (radio_params['wlan_iface'],
                     radio_params['wlan_beacon_interval']))

    #        if radio_params['wlan_radio_disable'] != self.radio_params_org['wlan_radio_disable']:
    #            self.session.send_line(
    #                "uci set wireless.%s.disabled=%s" %
    #                (radio_params['wlan_iface'],
    #                 radio_params['wlan_radio_disable']))

            if radio_params['wlan_channel'] != self.radio_params_org['wlan_channel']:
                self.session.send_line(
                    "uci set wireless.%s.channel=%s" %
                    (radio_params['wlan_iface'],
                     radio_params['wlan_channel']))

            if radio_params['wlan_iface'] != self.radio_params_org['wlan_iface']:
                self.session.send_line(
                    "uci set wireless.@wifi-iface[%s].device=%s" %
                    (i, radio_params['wlan_iface']))

            if radio_params['wlan_ifname'] != self.radio_params_org['wlan_ifname']:
                self.session.send_line(
                    "uci set wireless.@wifi-iface[%s].ifname=%s" %
                    (i, radio_params['wlan_ifname']))

            if radio_params['wlan_ssid'] != self.radio_params_org['wlan_ssid']:
                self.session.send_line(
                    "uci set wireless.@wifi-iface[%s].ssid=%s" %
                    (i, radio_params['wlan_ssid']))

            if radio_params['wlan_wpa_grpkey'] != self.radio_params_org['wlan_wpa_grpkey']:
                self.session.send_line(
                    "uci set wireless.@wifi-iface[%s].wpa_group_rekey=%s" %
                    (i, radio_params['wlan_wpa_grpkey']))

            if radio_params['wlan_wps_pin'] != self.radio_params_org['wlan_wps_pin']:
                self.session.send_line(
                    "uci set wireless.@wifi-iface[%s].wps_pin=%s" %
                    (i, radio_params['wlan_wps_pin']))

            if radio_params['wlan_wps_device_name'] != self.radio_params_org['wlan_wps_device_name']:
                self.session.send_line(
                    "uci set wireless.@wifi-iface[%s].wps_device_name=%s" %
                    (i, radio_params['wlan_wps_device_name']))

            if radio_params['wlan_wpa_pushbutton'] != self.radio_params_org['wlan_wpa_pushbutton']:
                self.session.send_line(
                    "uci set wireless.@wifi-iface[%s].wps_pushbutton=%s" %
                    (i, radio_params['wlan_wpa_pushbutton']))

            if radio_params['wlan_wmm'] != self.radio_params_org['wlan_wmm']:
                self.session.send_line(
                    "uci set wireless.@wifi-iface[%s].wmm=%s" %
                    (i, radio_params['wlan_wmm']))

            if radio_params['wlan_isolate'] != self.radio_params_org['wlan_isolate']:
                self.session.send_line(
                    "uci set wireless.@wifi-iface[%s].isolate=%s" %
                    (i, radio_params['wlan_isolate']))

            if radio_params['wlan_wds'] != self.radio_params_org['wlan_wds']:
                self.session.send_line(
                    "uci set wireless.@wifi-iface[%s].wds=%s" %
                    (i, radio_params['wlan_wds']))

            if radio_params['wlan_hidden'] != self.radio_params_org['wlan_hidden']:
                self.session.send_line(
                    "uci set wireless.@wifi-iface[%s].hidden=%s" %
                    (i, radio_params['wlan_hidden']))

            if radio_params['wlan_maxassoc_sta'] != self.radio_params_org['wlan_maxassoc_sta']:
                self.session.send_line(
                    "uci set wireless.@wifi-iface[%s].maxassoc=%s" %
                    (i, radio_params['wlan_maxassoc_sta']))

            if radio_params['wlan_iface_disable'] != self.radio_params_org['wlan_iface_disable']:
                self.session.send_line(
                    "uci set wireless.@wifi-iface[%s].disabled=%s" %
                    (i, radio_params['wlan_iface_disable']))

            if radio_params['wlan_macpolicy'] != self.radio_params_org['wlan_macpolicy']:
                self.session.send_line(
                    "uci set wireless.@wifi-iface[%s].macpolicy=%s" %
                    (i, radio_params['wlan_macpolicy']))

            if radio_params['wlan_mode'] != self.radio_params_org['wlan_mode']:
                self.session.send_line(
                    "uci set wireless.@wifi-iface[%s].mode=%s" %
                    (i, radio_params['wlan_mode']))

            if radio_params['wlan_bssid'] != self.radio_params_org['wlan_bssid']:
                self.session.send_line("uci set wireless.@wifi-iface[%s].bssid=%s" %(i, radio_params['wlan_bssid']))
            self.session.send_line("uci commit")
            return True
        except BaseException:
            return False

    def config_ap_wpa(self, radio_params, wlan_index):
        '''To configure the system with wifi WPA configs
           Arguments: radio_parms  - This argument is a dictionary with radio parameters which has to configure
                      wlan_index   - This argument is the index value of wifi iface config
                      system       - This argument is the object where wifi configurations has to do, default object is board'''
        i = wlan_index
        
        try:
            if radio_params['wlan_enc'] != self.radio_params_org['wlan_enc']:
                self.session.send_line(
                    "uci set wireless.@wifi-iface[%s].encryption=%s" %
                    (i, radio_params['wlan_enc']))
            if radio_params['wlan_key'] != self.radio_params_org['wlan_key']:
                self.session.send_line(
                    "uci set wireless.@wifi-iface[%s].key=%s" %
                    (i, radio_params['wlan_key']))
            self.session.send_line("uci commit")
            return True
        except BaseException:
            return False

    def config_ap_open(self, radio_params, wlan_index):
        '''To configure the system with wifi open configs
           Arguments: radio_parms  - This argument is a dictionary with radio parameters which has to configure
                      wlan_index   - This argument is the index value of wifi iface config
                      system       - This argument is the object where wifi configurations has to do, default object is board'''
        i = wlan_index
        
        try:
            if radio_params['wlan_enc'] != self.radio_params_org['wlan_enc']:
                self.session.send_line(
                    "uci set wireless.@wifi-iface[%s].encryption=%s" %
                    (i, radio_params['wlan_enc']))
                self.session.send_line("uci del wireless.@wifi-iface[%s].key" % (i))
                self.session.send_line("uci commit")
            return True
        except BaseException:
            return False


    def config_ap_wep(self, radio_params, wlan_index):
        '''To configure the system with wifi WEP configs
           Arguments: radio_parms  - This argument is a dictionary with radio parameters which has to configure
                      wlan_index   - This argument is the index value of wifi iface config
                      system       - This argument is the object where wifi configurations has to do, default object is board'''
        i = wlan_index
        try:
            self.session.send_line(
                "uci set wireless.@wifi-iface[%s].encryption=%s" %
                (i, radio_params['wlan_enc']))
            self.session.send_line("uci del wireless.@wifi-iface[%s].key" % (i))
            self.session.send_line(
                "uci set wireless.@wifi-iface[%s].key1=%s" %
                (i, radio_params['wlan_key1']))
            self.session.send_line("uci commit")
            return True
        except BaseException:
            return False


    def config_ap_security(self, radio_params, wlan_index, caller_api=""):
        '''To update the wifi configs in system
           Arguments: radio_parms  - This argument is a dictionary with radio parameters which has to configure
                      wlan_index   - This argument is the index value of wifi iface config
                      system       - This argument is the object where wifi configurations has to do, default object is board'''
        self.logger.dumpLog("Inside config_ap_security")
        if not self.config_ap_gen(radio_params, wlan_index, caller_api=caller_api):
            return False
        enc_type = radio_params['wlan_enc']
        if(enc_type == tsv_wlan_wpa2_enc_type or enc_type == tsv_wlan_wpa_enc_type or enc_type == tsv_wlan_wpa_wpa2_enc_type):
            if not self.config_ap_wpa(
                    radio_params, wlan_index):
                return False
        elif(enc_type == tsv_wlan_wep64_enc_type or enc_type == tsv_wlan_wep128_enc_type):
            if not self.config_ap_wep(
                    radio_params, wlan_index):
                return False
        elif(enc_type == tsv_wlan_open_enc_type):
            if not self.config_ap_open(
                    radio_params, wlan_index):
                return False
        else:
            self.logger.dumpLog("this is type of enc is not supported")
            return False
        return True


    def configure_ap(self, radio_params, ap_radio=tsv_ap_radio2g, caller_api=""):
        '''To configure the wifi AP configs in system
           Arguments: radio_parms  - This argument is a dictionary with radio parameters which has to configure
                      wlan_index   - This argument is the index value of wifi iface config
                      system       - This argument is the object where wifi configurations has to do, default object is board'''
        self.set_global_ap_radio(ap_radio)
        if ap_radio == tsv_ap_radio2g:
            wlan_index = 0
            if not self.os.check_iface_status(iface=radio_params['wlan_iface']):
                self.logger.dumpLog("interface is down, AP Configuration failed")
                return False
            if not self.config_ap_security(
                    radio_params, wlan_index, caller_api=caller_api):
                return False
        if ap_radio == tsv_ap_radio5g:
            wlan_index = 1
            if not self.os.check_iface_status(iface=radio_params['wlan_iface']):
                self.logger.dumpLog("interface is down, AP Configuration failed")
                return False
            if not self.config_ap_security(
                    radio_params, wlan_index, caller_api=caller_api):
                return False
        if not self.restart_wifi():
            self.logger.dumpLog(
                "After multiple retries, prompt did not come, prompt failure")
            return False
        '''Work around to add wlan interface to bridge'''
        self.session.send_line("brctl addif br-lan wlan0")
        self.session.send_line("brctl addif br-lan wlan2")
        return True


    def radio_enable_disable(
            self,
            wlan_iface,
            wlan_enable_disable=tsv_wlan_radio_disable_reset):
        '''To enable/disable the wifiradio
           Arguments: wlan_iface          - This argument is the wlan iface name
                      system              - This argument is the object where wifi radio has to enable/disable, default object is board
                      wlan_enable_disable - This argument is the enable/disable value, default value is tsv_wlan_radio_disable_reset'''
        try:
            self.session.set_window_size(200, 200)
            self.session.send_line("uci set wireless.%s.disabled=%s" %(wlan_iface, wlan_enable_disable))
            self.session.recv_line(self.prompt, timeout=int(tsv_timeout_5))
            self.session.send_line("uci commit")
            self.session.recv_line(self.prompt, timeout=int(tsv_timeout_5))
            if not self.restart_wifi(radio_enable=wlan_enable_disable):
                return False
            if wlan_enable_disable == tsv_wlan_radio_disable_reset:
                self.session.send_line("ifconfig %s up" % wlan_iface)
                self.session.recv_line(self.prompt, timeout=int(tsv_timeout_5))
            else:
                self.session.send_line("ifconfig %s down" % wlan_iface)
                self.session.recv_line(self.prompt, timeout=int(tsv_timeout_5))
            return True
        except BaseException:
            return False

   
    def restart_wifi(self, radio_enable=tsv_wlan_radio_disable_reset):
        '''To restart wifi card in system and wait until we get the promt
           Arguments: system     - This argument is the object where the wifi card has to restart, default object is board'''
        radio = self.get_global_ap_radio()
        if (radio == tsv_ap_radio2g):
            radio_params = copy.deepcopy(radio2g_params)
        elif (radio == tsv_ap_radio5g):
            radio_params = copy.deepcopy(radio5g_params)

        if radio_enable == tsv_wlan_radio_disable_reset:
            Radiostr = "Enable %s DONE" % radio_params["wlan_iface"]
        else:
            Radiostr = "Disable %s DONE" % radio_params["wlan_iface"]

        self.session.send_control('c')
        self.session.send_line("/etc/init.d/network restart")
        try:
            self.session.recv_line(Radiostr, timeout=int(600))
        except Exception as e:
            self.logger.dumpLog("exception is %s\n" % str(e))
        for i in range(0, 2000):
            addr = self.os.get_mac_addr(interface=radio_params['wlan_iface'])
            if not addr:
                self.logger.dumpLog("Still wifi is not up!!!!")
                continue
            else:
                self.logger.dumpLog("<<<%s is MAC addr, and wifi is up now>>>" % addr)
                return True
        return True


    def config_ap_to_org(
            self,
            radio_params,
            ap_radio=tsv_ap_radio2g,
            caller_api=""):
        ''' '''
        self.logger.dumpLog("reverting DUT to original values")
        if ap_radio == tsv_ap_radio2g:
            index = 0
        elif ap_radio == tsv_ap_radio5g:
            index = 1

        if not self.config_ap_gen(
                radio_params,
                index,
                revert=tsv_revert_set, caller_api=caller_api):
            self.logger.dumpLog("reverting DUT to original values failed")
            return False
        self.restart_wifi()
        self.logger.dumpLog("reverting DUT to original values  success")
        return True


#    def wifi_swap_dict(self, radio_params, self.radio_params_org):
#        ''' '''
#        self.logger.dumpLog("swapping logic starts")
#        try:
#            temp_radio = radio_params
#            radio_params = self.radio_params_org
#            self.radio_params_org = temp_radio
#            self.logger.dumpLog("swapping logic success")
#        except BaseException:
#            self.logger.dumpLog("swapping logic fails")
#            return False
#        return True

    def set_global_ap_radio(self, ap_radio):
        self.logger.dumpLog("set global ap radio")
        self.global_ap_radio = ap_radio
        return True


    def get_global_ap_radio(self):
        self.logger.dumpLog("get global ap radio")
        return self.global_ap_radio
        #global global_ap_radio
        #return global_ap_radio


    def wlan_form_bridge(self):
        self.session.send_line("brctl addif br-lan wlan0")
        self.session.send_line("brctl addif br-lan wlan2")
        return True

    def debug_func(self):
        self.logger.dumpLog("Method inside this class %s" % self.__class__.__name__)

    def test_wifiuci(self):
        print("method inside class WifiUci")


if __name__ == "__main__":
    obj = WifiUci()
    obj.debug_func()


