import os
import inspect
import uci_cmn
from uci_cmn import *
from generic_api import *
from testfactory import *
from log_creator import loggerObject as logger

def uci_method_builder(cls):
    def __init__(self, os, session, prompt, device_dict=None, dname=None, logger=logger, class_list=None):
        self.os = os
        self.session = session
        self.prompt = prompt
        self.dict = device_dict
        self.dname = dname
        self.logger = logger
        #calling init functions of all parent classes
        for c_obj in list(class_list.split(",")):
            for ele in inspect.getmembers(eval(c_obj)):
                if "__init__" in ele:
                    eval(c_obj).__init__(self)
            
    __init__.__name__ = "__init__"
    setattr(cls,__init__.__name__,__init__)


def uci_cmd(os_handle="", session_handle="", prompt="", device_dict=None, dname=None, logger=logger):
    uci_class_list = uci_list_builder()
    exec ('class UciCmdHolder(' + uci_class_list + '): pass')
    #This dynamic class is formed with multiple inheritance, Hence Lib writter should not use
    #same attribute names accross classes
    uci_method_builder(UciCmdHolder)
    return UciCmdHolder(os_handle, session_handle, prompt, device_dict=device_dict, dname=dname, logger=logger,
                        class_list=uci_class_list)


def uci_list_builder():
    '''Return list of classes in uci_cmn'''
    cls_list=''
    for name, obj in inspect.getmembers(uci_cmn):
        if inspect.isclass(obj) and "Uci" in name:
            cls_list = cls_list + ',' + name
    cls_list+=',GenericApi,TestFactory'
    return cls_list.strip(',')


if __name__ == '__main__':
    objUci  = uci_cmd()
    objUci.debug_func()
    objUci.test_bridgeuci()
    objUci.test_ipv4uci()
    objUci.test_l2tptunneluci()
    objUci.test_multicastuci()
    objUci.test_wifiuci()
