

class Ipv4Clish:
    """This class will contain all clish APIs related to Ipv4 functionality"""

    def __init__(self):
        pass

    def debug_func(self):
        print("Method inside this class %s" % self.__class__.__name__)

    def test_ipv4clish(self):
        print("method inside class Ipv4Clish")

if __name__ == "__main__":
    obj = Ipv4Clish()
    obj.debug_func()
