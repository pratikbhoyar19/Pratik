

class L2tpTunnelClish:
    """This class will contain all clish APIs related to L2TP functionality"""

    def __init__(self):
        pass

    def debug_func(self):
        print("Method inside this class %s" % self.__class__.__name__)

    def test_l2tptunnelclish(self):
        print("method inside class L2tpTunnelClish")

if __name__ == "__main__":
    obj = L2tpTunnelClish()
    obj.debug_func()
