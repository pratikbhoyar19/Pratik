

#Should contain rdkb common methods
class Rdkb:
    """This class contains common methods for rdkb sw distribution"""

    def __init__(self):
        pass

    def test_func(self):
        print("method inside in this class %s" % self.__class__.__name__)


if __name__ == "__main__":
    obj = Rdkb()
    obj.test_func()
