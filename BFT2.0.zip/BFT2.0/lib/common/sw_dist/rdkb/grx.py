from rdkb import Rdkb


#Should contain grx specific and will inherit common methods
class RdkbGrx(Rdkb):
    """This class will provide handle for Grx model series for Rdkb sw distribution"""

    def __init__(self):
        pass

    def test_func_grx(self):
        print("rdkbgrx tested")

    def test_func(self):
        print("rdkbgrx tested")
        #print(self.os)
        #print(self.session)
        #print(self.prompt)
        #print(self.dict)
        #print(self.dname)

if __name__ == "__main__":
    obj = RdkbGrx()
    obj.test_func()
