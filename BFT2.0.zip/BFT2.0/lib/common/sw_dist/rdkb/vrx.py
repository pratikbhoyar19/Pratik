from rdkb import Rdkb


#Should contain vrx specific and will inherit common methods
class RdkbVrx(Rdkb):
    """This class will provide handle for Vrx model series for Rdkb sw distribution"""

    def __init__(self):
        pass

    def test_func_vrx(self):
        print("rdkbvrx tested")

    def test_func(self):
        print("rdkbvrx tested")
        #print(self.os)
        #print(self.session)
        #print(self.prompt)
        #print(self.dict)
        #print(self.dname)

if __name__ == "__main__":
    obj = RdkbVrx()
    obj.test_func()
