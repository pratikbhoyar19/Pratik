from ugw import Ugw


#Should contain vrx specific and will inherit common methods
class UgwVrx(Ugw):
    """This class will provide handle for Vrx model series for Ugw sw distribution"""


    def __init__(self):
        pass

    def test_func_vrx(self):
        print("ugwvrx tested")

    def test_func(self):
        print("ugwvrx tested")
        #print(self.os)
        #print(self.session)
        #print(self.prompt)
        #print(self.dict)
        #print(self.dname)


if __name__ == "__main__":
    obj = UgwVrx()
    obj.test_func()
