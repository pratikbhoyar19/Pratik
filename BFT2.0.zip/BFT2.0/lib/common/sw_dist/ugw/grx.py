import os
import platform
import re
import traceback
from datetime import datetime
from time import sleep

import config
from lib.common.sw_dist.ugw.ugw import Ugw
from log_creator import loggerObject as logger


class UgwGrx(Ugw):
    GRX_prompt = '(GRX500 #)'
    logger = logger

    def __init__(self):
        pass

    def __write_log(self, msg):
        self.logger.dumpLog(msg)

    def burn_image(self, lan_server_ip, flash_version, wlan_ap =True, nand_boot_update=True, interface=None):
        """
        Method to burn images on DUT

        Follows procedure to flash GRX350/Axepoint/GRX55O using tftp.

        Args:
            lan_server_ip: lan ip address
            flash_version: image version to be flashed
            interface: [Optional]
            wlan_ap = True|False
                      True:for wlan ap image upgrade
                      False:Used for Ugw image upgade'
            nand_boot_updae = True|False
                      True: Updates the nand boot images also
                      False: Just updates full_image and skips nand_boot update

        Returns:
            True|False
                True: On Successful image burn
                False: On unsuccessful image burn

        Raises:
            None
        """
        try:
            if wlan_ap:
                self._send_command("cd /")
                for i in range(5):
                    current_ap_version = self.get_ap_build_version(wlan_ap)
                    if type(current_ap_version) != bool:
                        break
                else:
                    self.__write_log("Could not fetch dut current version ! please check if AP is in hang state!!")
                    return False
            else:
                current_ap_version = self.get_ap_build_version(wlan_ap=False)

            if flash_version == current_ap_version:
                return True
            if interface is None:
                interface = "br-lan"
            current_time = datetime.now()
            lan_server_ip = str(lan_server_ip)
            for i in range(5):
                lan_static_ip = self.os.get_interface_ipaddr(interface)
                if type(lan_static_ip) != bool:
                    break
            else:
                self.__write_log("Could not fetch dut lan static IP ! please check if AP is in hang state!!")
                return False
            for i in range(5):
                ap_mac_addr = self.os.get_mac_addr(interface)
                if type(ap_mac_addr) != bool:
                    break
            else:
                self.__write_log("Could not fetch dut MAC address ! please check if AP is in hang state!!")
                return False
            self._send_command('reboot')
            try:
                self.__dut_auto_boot()
            except:
                self.__write_log("Failed to get bootloader prompt: {}".format(traceback.format_exc()))
                return False
            self.__write_log("Setting serverip")
            self._send_command('setenv serverip ' + lan_server_ip + ';save')
            try:
                self._receive_response(self.GRX_prompt, timeout=15)
            except:
                self.__write_log("Failed to set serverip: {}".format(traceback.format_exc()))
                return False
            self.__write_log("Setting DUT IP address")
            self._send_command('setenv ipaddr ' + lan_static_ip + ';save')
            try:
                self._receive_response(self.GRX_prompt, timeout=15)
            except:
                self.__write_log("Failed to set ipaddr: {}".format(traceback.format_exc()))
                return False
            if nand_boot_update:
                self.__write_log("update the nand boot")
                self._send_command('run update_nandboot')
                try:
                    self._receive_response(self.GRX_prompt, timeout=15)
                except:
                    self.__write_log("Failed to update nandboot: {}".format(traceback.format_exc()))
                    return False
                self.__write_log("reset uboot config")
                self._send_command('run reset_uboot_config')
                try:
                    self._receive_response(self.GRX_prompt, timeout=15)
                except:
                    self.__write_log("Failed to reset uboot: {}".format(traceback.format_exc()))
                    return False
                self.__write_log("Setting serverip")
                self._send_command('setenv serverip ' + lan_server_ip + ';save')
                try:
                    self._receive_response(self.GRX_prompt, timeout=10)
                except:
                    self.__write_log("Failed to set serverip: {}".format(traceback.format_exc()))
                    return False
                self.__write_log("Setting DUT IP address")
                self._send_command('setenv ipaddr ' + lan_static_ip + ';save')
                try:
                    self._receive_response(self.GRX_prompt, timeout=10)
                except:
                    self.__write_log("Failed to set ipaddr: {}".format(traceback.format_exc()))
                    return False
                if float(flash_version) > 8:
                    self.__write_log("resest the device")
                    self._send_command('reset')
                else:
                    self.__write_log("update the gphy firmware")
                    self._send_command('run update_gphyfirmware')
                try:
                    self.__dut_auto_boot()
                except:
                    self.__write_log("Failed to update gphyfirmware: {}".format(traceback.format_exc()))
                    return False
                self.__write_log("update the boot core")
                self._send_command('run update_bootcore')
                try:
                    self.__dut_nand_expect()
                except:
                    self.__write_log("Failed to update bootcore: {}".format(traceback.format_exc()))
                    return False
            self.__write_log("update the full image")
            self._send_command('run update_fullimage')
            try:
                if self._receive_response('Bad Header Checksum', timeout=40) is True:
                    self.__write_log("Image Got Corruputed and will boot with previous loaded image: {}".format(traceback.format_exc()))
                    self.__reset()
                    return False

                if self.__dut_nand_expect():
                    sleep(5)
                    self._send_command("\n")
                    while self._receive_response(self.GRX_prompt, timeout=3) is False:
                        sleep(10)
                        self._send_command("\n")
            except:
                self.__write_log("Failed to run fullimage: {}".format(traceback.format_exc()))
                return False
            self.__write_log("Setting ethaddr")
            self._send_command('set ethaddr ' + ap_mac_addr.lower() + ';save')
            try:
                self._receive_response(self.GRX_prompt, timeout=10)
            except:
                self.__write_log("Failed to set mac_addr: {}".format(traceback.format_exc()))
                return False
            self.__write_log(" Reset the DUT")
            sleep(10)
            self._send_command("\n")
            if self._receive_response(self.GRX_prompt) is False:
                sleep(10)
                self._send_command("\n")
            try:
                self.__reset()
            except:
                self.__write_log("Failed to reset: {}".format(traceback.format_exc()))
                return False
            sleep(5)
            new_ap_version = self.get_ap_build_version(wlan_ap)
            bootuptime = self.get_seconds_uptime()
            self.__write_log("flashing\nstart time: {}\nend time: {}".format(current_time, datetime.now()))
            self.__write_log("Dut bootup time is {} sec's".format(bootuptime))
            self.__write_log("previous build of dut: {}, new build: {}".format(current_ap_version, new_ap_version))
            #Currently comparing the two versions, cannot differeniate between upgrade and downgrade
            if wlan_ap:
                if current_ap_version == new_ap_version:
                    self.__write_log("flashing failed ... !")
                    return False
            self.__write_log("Flashing Successful ... !")
            return new_ap_version
        except (TypeError, AttributeError, Exception) as err:
            self.__write_log("{}".format(traceback.format_exc()))
            return False

    def get_seconds_uptime(self):
        """
        Method to get uptime for the DUT

        Args:
            None
        Returns:
            Seconds for Dut boot up
        Raises:
            None
        """
        self._send_command('cat /proc/uptime')
        seconds_up = self._receive_response('(\d+).(\d+) (\d+).(\d+)')
        return seconds_up

    def _send_command(self, command):
        """
        Method to send command over console

        Args:
            command: command to be sent
        Returns:
            None
        Raises:
            None
        """
        self.__write_log(
            'Sending "{}" on "{}" console.'.format("Enter" if "\n" in command else command, self.dict['name']))
        self.session.send_line(str(command))

    def _receive_response(self, pattern, timeout=20, return_type=None):
        """
        Method to receive response from the console

        Args:
            pattern: pattern to match specific output
            timeout: timeout
            return_type: default is string else boolean
        Returns:
            matched pattern or True|False
        Raises:
            None
        """
        self.__write_log("Waiting for {} pattern on {} console log!".format(pattern, self.dict['name']))
        if self.session.recv_line(pattern, timeout=timeout):
            if return_type is None:
                return str(self.session.match(1))
            else:
                return True
        else:
            return False

    def __dut_auto_boot(self):
        """
        Method to obtain uboot prompt
        Args:
            None
        Returns:
            None
        Raises:
            None
        """
        if self._receive_response('(Hit any key to stop autoboot:)|(ROM VER: 2.1.0)', timeout=15):
            for i in range(10):
                self._send_command('\n')
                sleep(0.5)
        if self._receive_response(self.GRX_prompt, timeout=10):
            self.__write_log("Received {} Prompt ... !".format(self.GRX_prompt))

    def __dut_nand_expect(self):
        """
        Method to verify image burn completion
        Args:
            None
        Returns:
            None
        Raises:
            None
        """
        self._receive_response('(Writing to Nand... done)|(Writing to NAND... OK)', timeout=60)
        sleep(3)

    def test_func(self):
        self.__write_log("method inside in this class %s" % self.__class__.__name__)

    def get_ap_build_version(self,wlan_ap=True):
        """
        Method to get version on dut
        Args:
            None
        Returns:
            None
        Raises:
            None
        """
        if wlan_ap:
            for i in range(5):
                sleep(1)
                output = self.session.send_recv("version.sh | grep \"Wave wlan version\"")
                reobj = re.search(r"Wave wlan version: (.*)",output)
                if reobj:
                    return reobj.group(1)
            return False
        else:
            self._send_command("version.sh | grep UGW")
            result = self._receive_response("Software: ([A-z0-9.-]+)")
            self._send_command("cd /")
            self._receive_response(self.session.prompt)
            return result

    def __reset(self):
        """
        Method to reset the DUT from uboot prompt
        Args:
            None
        Returns:
            ip address of the interface
        Raises:
            None
        """
        self._send_command('reset')
        return self.reboot(hard_reboot=True)

    def download_build_version(self, build_path):
        """
        This method downloads the flash build from remote network directory

        Args:
            build_path (str): completed build path for the build

        Returns:
            True : on successful download build
            False : on unsuccessful download build

        Raises:
            SystemError: if drive mapping failed
        """
        INTEGRATION_FILES_TO_BE_DOWNLOADED = [
            'fullimage.img',
            'gphy_firmware.img',
            'u-boot-nand.bin',
            'uImage_bootcore',
        ]
        download_status = {
            'fullimage.img': False,
            'gphy_firmware.img': False,
            'u-boot-nand.bin': False,
            'uImage_bootcore': False,
        }
        destination = os.path.join(os.getcwd(), 'tools', 'tftp', 'tmp')
        result = True
        build_path = re.sub(r"\\|/", "/", str(build_path))
        if build_path is False:
            self.logger.dumpLog("build_path cannot be False... build_path = {}".format(build_path))
            return False
        build_path, site = self.__site_update_build_path(build_path)
        self.logger.dumpLog(
            "copying {} build files from site: {}, path: {}".format(INTEGRATION_FILES_TO_BE_DOWNLOADED, site,
                                                                    build_path))
        for retry in range(10):
            for file_name in INTEGRATION_FILES_TO_BE_DOWNLOADED:
                command = "pscp -pw {} {}@{}:{}{} {}".format(config.runtime_para['password'], config.runtime_para['username'], site, build_path,
                                                                        file_name, destination)
                self.logger.dumpLog("Executing command : {}".format(command))
                copy_result = -1
                if download_status[file_name] is False:
                    copy_result = os.system("echo y | {}".format(command))
                if copy_result == 0:
                    download_status[file_name] = True
                    self.logger.dumpLog("{} copied successfully to {}".format(file_name, destination))
                else:
                    self.logger.dumpLog("{} did not copy to {}".format(file_name, destination))
                    result = False
            if result is True:
                break
            sleep(12)
        return result

    def __site_update_build_path(self, build_path):
        if platform.system().lower() == 'windows':
            site = "isamba.iil.intel.com"
        else:
            raise NotImplementedError("Not implemented for {}".format(platform.system()))
        forward_slash_start = "" if str(build_path).startswith('/') else "/"
        forward_slash_end = "" if str(build_path).endswith('/') else "/"
        return "/nfs/site/proj{}{}{}".format(forward_slash_start, build_path, forward_slash_end), site


if __name__ == "__main__":
    obj = UgwGrx()
    obj.test_func()
