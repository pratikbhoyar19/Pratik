import os
import re
from time import sleep

from log_creator import loggerObject as logger
from framework.publish_info_to_html import publish_html

#Should contain ugw common methods
class Ugw:
    """This class contains common methods for ugw sw distribution"""

    def __init__(self):
        pass

    def test_func(self):
        print("method inside in this class %s" % self.__class__.__name__)

    def verify_log_for_errors(self):
        """
         Method to verify log in logs
            Args:
                client type(object)
                    Master PC session
            Returns:
                False/True
                    False : Error found
                    True : No Error Found
            Raises:
                None
        """
        flag_fatal, flag_unconfirmed_message, ignoredCount = 0, 0, 0
        erro_expr = "MAC exception.*TS 0x[\da-f]+r|Asserting FW|MAC fatal error.* TS|Unconfirmed messages|Kernel panic|kernel paging|Fatal exception|out_of_memory|page allocation failure|Aborting application|Call Trace"
        log_file = os.path.join(self.session.get_log_dir(), "dut.log")
        logger.dumpLog("checking Log inside : {} .".format(log_file))
        if not os.path.exists(log_file):
            logger.dumpLog("Log file {} does not found. Exit.".format(log_file))
            return False
        with open(log_file, "r") as f:
            log_txt = f.read()
        errors_list = re.findall(erro_expr, log_txt)
        total_errors_count = len(errors_list)
        logger.dumpLog("Error list {}".format(errors_list))
        intentional_assert_str = 'do_debug_assert'
        intentional_assert_start_pos = log_txt.find(intentional_assert_str)
        if intentional_assert_start_pos > -1 and total_errors_count > 0:
            for i in range(0, total_errors_count):
                err = errors_list[i]
                err_start_pos = log_txt.find(err)#err[0]
                if err_start_pos > intentional_assert_start_pos:
                    ignoredCount = ignoredCount + total_errors_count - i
                    errors_list = errors_list[0:i]
                    break
        if total_errors_count > ignoredCount:
            for err in errors_list:
                err_start_pos = log_txt.find(err)
                err_end_pos = err_start_pos + len(err)
                err_msg = log_txt[err_start_pos:err_end_pos]
                publish_html(comment=err_msg)
                logger.dumpLog(err_msg)
            interface = re.search("CID-(.*): MAC event: (.*): MAC fatal error:", log_txt)
            interface = list(interface.groups()) if interface is not None else []
            logger.dumpLog("interface = {}".format(interface))
            if interface is not None and len(interface) > 0:
                # fatal error
                inter = interface[1]
                active_int_index = 0
                if active_int_index != inter:  # fatal error on interface that not active
                    flag_fatal = 1
                    self.get_fw_dumps()
            interface = re.search("CID-(.*): Resetting FW because of message timeout. Message ID is (.*)", log_txt)
            interface = list(interface.groups()) if interface is not None else []
            if len(interface) != 0:
                inter = interface[0]
                if active_int_index != inter:
                    # Unconfirmed messages on interface that not active
                    logger.dumpLog("Unconfirmed messages on interface wlan{} that not active".format(inter))
                    flag_unconfirmed_message = 1
                else:
                    logger.dumpLog("Unconfirmed messages Not found")
            if total_errors_count >= 3:
                logger.dumpLog("Total Error Count = {}".format(total_errors_count))
                return False
            elif total_errors_count == (flag_fatal + flag_unconfirmed_message):
                logger.dumpLog("errors aren't belong to active interface, status is pass")
                return True
            else:
                return False
        out_buffer = self.session.send_recv("cat /proc/meminfo | grep Unevictable", timeout=20)
        logger.dumpLog(out_buffer)
        if total_errors_count > 0:
            logger.dumpLog("==================== Stopped debugging ================================")
            return False
        else:
            return True

    def get_fw_dumps(self):
        """
            Method to GET DUMPS FROM DUT
                Args:
                    None
                Returns:
                    None
                Raises:
                    None
        """
        try:
            logger.dumpLog("Get dumps from Auto Recovery")
            output_dir = self.__send_recv_command("ls /opt", timeout=2)
            vendor = "lantiq" if output_dir.find("intel") == -1 else "intel"
            self.session.send_line("cd /opt/{}/wave".format(vendor))
            out_buffer = self.session.send_recv("echo \"count=`ls | grep  *dump*.tar -c`\"", timeout=10)
            retval = re.search("count=([\d]+).*", out_buffer)
            retval = retval.groups(1) if retval is not None else 0
            if retval < 1:
                self.session.send_line("ls -l")
                self.session.send_line("cd /tmp/wlan_wave")
                out_buffer = self.session.send_recv("echo \"count=`ls | grep  *dump*.tar -c`\"", timeout=10)
                retval = re.findall("count=([\d]+).*", out_buffer)
                retval = retval.groups(1) if retval is not None else 0
            if retval < 1:
                logger.dumpLog("=========== Dump files _dump.tar wasn't found.==============")
                self.session.send_line("ls -l")
                self.session.send_line("cd /")
                return False
            else:
                logger.dumpLog("Dump files was found.")
                out_buffer = self.session.send_recv("tar cf /tmp/AggDumps.tar *dump*.tar", timeout=15)
                logger.dumpLog(out_buffer)
                self.session.send_line("cd /tmp/")
                done = self.session.copy_from_dut("/tmp/AggDumps.tar")
                if not done:
                    logger.dumpLog("File copy from dut is unsuccessful So trying again...")
                    done_1 = self.session.copy_from_dut("/tmp/AggDumps.tar")
                    if not done_1:
                        done_2 = self.session.copy_from_dut("/tmp/AggDumps.tar")
                        if not done_2:
                            logger.dumpLog("Failed to copy logs Kindly try again...")
                        else:
                            self.session.send_line("cd /")
                            self.session.send_line("rm /AggDums.tar")
                    else:
                        self.session.send_line("rm /AggDums.tar")
                        self.session.send_line("cd /")
                #TODO
                #***out_buffer = self.session.send_recv("cd /;run ugw_logs.sh generate");  # Generate log
                #***out_buffer = self.session.send_recv("cd /tmp;tar cf ugw_logs.tar ugw_logs");  # Aggregate logs to tar file
                #***self.session.copy_from("/tmp/ugw_logs.tar", self.dict['tftp_ipaddr'])
                #***out_buffer = self.session.send_recv("rm /tmp/ugw_logs.tar");  # transfer the file to local computer and remove it from AP
        except Exception as e:
            self.session.send_line("cd /")
            logger.dumpLog("failed due to {}".format(str(e)))


    def check_prompt_and_login(self):
        """
        Method to log into the dut
            Args:
                None
            Returns:
                None
            Raises:
                None
        """
        for i in range(5):
            self.session.send_line("\n")
        if self.session.recv_line('(login:)', timeout=5):
            self.auto_login()

    def reboot(self, hard_reboot=False):
        if hard_reboot is False:
            for i in range(3):
                self.session.send_line("cd /")
                self.session.send_line("\n")
            self.session.send_line("reboot")

        if self.session.recv_line('(##NOTIFY_BRIDGE_UP##)|(BOOT OK)|(SHOWTIME!!)', timeout=450):
            if hard_reboot is False:
                logger.dumpLog("{} reboot was successful ... ! Attempting log in ...".format(self.dict['name']))
            sleep(12)
            return self.auto_login()
        self.session.send_line("\n")
        if self.session.recv_line('(login:)', timeout=10):
            logger.dumpLog("{} reboot was successful ... ! Attempting log in ...".format(self.dict['name']))
            return self.auto_login()
        logger.dumpLog("{} reboot was unsuccessful ... !".format(self.dict['name']))
        return self.auto_login()

    def auto_login(self):
        for i in range(10):
            self.session.send_line("\n")
            if self.session.recv_line('(login:)', timeout=2):
                self.session.send_line("\n")
                break
        self.session.send_line(self.dict['username'])
        self.session.recv_line('(Password:)', timeout=5)
        self.session.send_line(self.dict['password'])
        sleep(2)
        for i in range(3):
            self.session.send_line("\n")
        if self.session.recv_line(self.session.prompt, timeout=5):
            logger.dumpLog("{} login successful ... !".format(self.dict['name']))
            return True
        logger.dumpLog("{} login unsuccessful ... !".format(self.dict['name']))
        return False

    def is_dut_in_hang_state(self):
        """
        Method to check if dut is in hang state

        Args:
             None

        Returns: (boolean)
            if DUT is in hang state return True else False

        Raises:
            None
        """
        try:
            def send_command(multiplier=5):
                for i in range(multiplier):
                    self.session.send_line("\n")

            if len(self.session.prompt) == 0:
                return True
            on_main_prompt, on_boot_prompt = True, True
            send_command(5)
            if self.session.recv_line(self.session.prompt, timeout=8) is False:
                on_main_prompt = False
            send_command(5)
            if self.session.recv_line("(GRX\d{3}\s#)", timeout=8) is False:
                on_boot_prompt = False
        except Exception as e:
            raise
        else:
            if on_boot_prompt is True and on_main_prompt is False:
                send_command(4)
                self.session.send_line("reset")
                return not(self.reboot(hard_reboot=True))
            result = (on_main_prompt is True and on_boot_prompt is True) or (
                        on_main_prompt is False and on_boot_prompt is False)
            return result

    def reset_if_boot_prompt(self):
        for i in range(5):
            self.session.send_line("\n")
        if self.session.recv_line("(GRX\d{3}\s#)", timeout=4) is True:
            self.session.send_line('reset')
            self.auto_login()
            self.session.set_prompt()
        for i in range(5):
            self.session.send_line("\n")
        if self.session.recv_line("(GRX\d{3}\s#)", timeout=4) is True:
            return False
        publish_html(comment="{}: factory reset succes!".format(self.dict['name']))
        return True

    def factory_reset(self):
        self.session.send_line("factorycfg.sh")
        return self.reboot(hard_reboot=True)

if __name__ == "__main__":
    obj = Ugw()
    obj.test_func()
