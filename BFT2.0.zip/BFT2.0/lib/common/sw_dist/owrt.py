

#Should contain owrt common methods
class Owrt:
    """This class contains common methods for owrt sw distribution"""

    def __init__(self):
        pass

    def test_func(self):
        print("Owrt tested")
        #print(self.os)
        #print(self.session)
        #print(self.prompt)
        #print(self.dict)
        #print(self.dname)


if __name__ == "__main__":
    obj = Owrt()
    obj.test_func()
