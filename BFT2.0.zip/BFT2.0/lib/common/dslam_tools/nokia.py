import re
import time
from log_creator import loggerObject as logger

class Nokia:
    """This class will provide handle for Nokia Dslam apis """


    def __init__(self):
        pass

    def configure_dslam(self, server_script=None):    
        '''
        This function is used to configure dslam for different profiles
        Args:
            server_script: script to be executed on the dslam
        Returns:
            return_dict["result"]: pass/fail
        '''
        result_dict = {}
        result_dict["result"] = "pass"
        try:
            logger.dumpLog("Start configuring Dslam with {} script".format(server_script))
            s_buf = self.session.send_recv("{}".format(server_script), timeout=120)
            output = re.search(r'SSH ([A-Z]+\s+[A-Z]+\s+SU[A-Z]+)', s_buf)
            if output != None:
                logger.dumpLog("Dslam is configured for script {}".format(server_script))
            else:
                logger.dumpLog("Failed to configure Dslam script")
                result_dict["result"] = "fail"
        except Exception as e:
            logger.dumpLog("Failed to connect to the DSLAM {}".format(e))
            return_dict["result"] = "fail"
        return result_dict                                                                              
                                                                                      
    def test_nokia(self):
         print("nokia Dslam tested")

if __name__ == "__main__":
    obj = Nokia()
    obj.test_nokia()
