

class Rev3:
    """This class will provide handle for Rev3 Dslam apis """


    def __init__(self):
        pass

    def test_func(self):
        print("method inside in this class %s" % self.__class__.__name__)

    def test_rev3(self):
        print("rev3 tested")

if __name__ == "__main__":
    obj = Rev3()
    obj.test_rev3()
