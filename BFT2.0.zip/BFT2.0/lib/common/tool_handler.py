class ToolSelect:

    def __init__(self, m_pri, m_sec, pri, sec):
        self.m_pri = m_pri
        self.m_sec = m_sec
        self.pri = pri
        self.sec = sec

    def __str__(self):
        return "True"

    def __getattr__(self, name):
        def method(*args, **kwargs):
            var = self
            my_func = None
            try:
                my_func = eval("var.m_pri."+name)
                if args and not kwargs:
                    return my_func(*args)
                elif kwargs and not args:
                    return my_func(**kwargs)
                elif args and kwargs:
                    return my_func(*args, **kwargs)
                else:
                    return my_func()
            except Exception as err:
                if "no attribute" in str(err):
                    try:
                        my_func = eval("var.pri."+ name)
                        if args and not kwargs:
                            return my_func(*args)
                        elif kwargs and not args:
                            return my_func(**kwargs)
                        elif args and kwargs:
                            return my_func(*args, **kwargs)
                        else:
                            return my_func()
                    except Exception as err:
                        if "no attribute" in str(err):
                            try:
                                my_func = eval("var.m_sec." + name)
                                if args and not kwargs:
                                    return my_func(*args)
                                elif kwargs and not args:
                                    return my_func(**kwargs)
                                elif args and kwargs:
                                    return my_func(*args, **kwargs)
                                else:
                                    return my_func()
                            except Exception as err:
                                if "no attribute" in str(err):
                                    try:
                                        my_func = eval("var.sec." + name)
                                        if args and not kwargs:
                                            return my_func(*args)
                                        elif kwargs and not args:
                                            return my_func(**kwargs)
                                        elif args and kwargs:
                                            return my_func(*args, **kwargs)
                                        else:
                                            return my_func()
                                    except Exception as err:
                                        print("Method (%s) is not found -- %s" % (name, err))
                                else:
                                    print("Issues present in the method - '%s'" % name)
                        else:
                            print("Issues present in the method - '%s'" % name)
                else:
                    print("Issues present in the method - '%s'" % name)
        method.__name__ = name
        return method
