import os
import sys
import inspect
import dslam_tools
from dslam_tools import *
from log_creator import loggerObject as logger

def dslam_method_builder(cls):
    def __init__(self, class_list=None):
        #calling init functions of all parent classes
        for c_obj in list(class_list.split(",")):
            for ele in inspect.getmembers(eval(c_obj)):
                if "__init__" in ele:
                    eval(c_obj).__init__(self)

    __init__.__name__ = "__init__"
    setattr(cls,__init__.__name__,__init__)
   
    def config_update(self, os, session, prompt, device_dict=None,
                      dname=None, logger=logger):
        self.os = os
        self.session = session
        self.prompt = prompt
        self.dict = device_dict
        self.dname = dname
        self.logger = logger
       
    config_update.__name__ = "config_update"
    setattr(cls,config_update.__name__,config_update)

def dslam_cmd(tool_name=None):
    dslam_class_list = dslam_list_builder(tool_name)
    exec ('class DslamCmdHolder(' + dslam_class_list + '): pass')
    #This dynamic class is formed with multiple inheritance, Hence Lib writter should not use
    #same attribute names accross classes
    dslam_method_builder(DslamCmdHolder)
    return DslamCmdHolder(class_list=dslam_class_list)

def dslam_list_builder(tool_name):
    '''Return string of classes in dslam_tool'''
    cls_list=''
    for name, obj in inspect.getmembers(dslam_tools):
        if inspect.isclass(obj):
            if name == tool_name:
                cls_list = cls_list + ',' + name

    return cls_list.strip(',')

if __name__ == '__main__':
    obj = dslam_cmd(tool_name="Nokia")
    obj.test_nokia() 
    obj = dslam_cmd(tool_name="Rev3")
    obj.test_rev3() 

