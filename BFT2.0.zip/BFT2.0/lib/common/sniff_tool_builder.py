import os
import sys
import inspect
import sniffer_tools
from sniffer_tools import *
import sniffer_tools.model_specific
from sniffer_tools.model_specific import *
from log_creator import loggerObject as logger


def sniffer_method_builder(cls):
    def __init__(self, class_list=None):
        #calling init functions of all parent classes
        for c_obj in list(class_list.split(",")):
            for ele in inspect.getmembers(eval(c_obj)):
                if "__init__" in ele:
                    eval(c_obj).__init__(self)

    __init__.__name__ = "__init__"
    setattr(cls,__init__.__name__,__init__)
   
    def config_update(self, os, session, prompt, device_dict=None,
                      dname=None, logger=logger):
        self.os = os
        self.session = session
        self.prompt = prompt
        self.dict = device_dict
        self.dname = dname
        self.logger = logger
       
    config_update.__name__ = "config_update"
    setattr(cls,config_update.__name__,config_update)


def sniffer_cmd(tool_name="",model_specific_name=""):
    sniffer_class_list = sniffer_list_builder(tool_name, model_specific_name)
    exec ('class SnifferCmdHolder(' + sniffer_class_list + '): pass')
    #This dynamic class is formed with multiple inheritance, Hence Lib writter should not use
    #same attribute names accross classes
    sniffer_method_builder(SnifferCmdHolder)
    return SnifferCmdHolder(class_list=sniffer_class_list)


def sniffer_list_builder(tool_name,model_specific_name):
    '''Return string of classes in sniffer_tool and model_specific'''
    cls_list=''
    for name, obj in inspect.getmembers(sniffer_tools):
        if inspect.isclass(obj):
            if name == tool_name:
                cls_list = cls_list + ',' + name

    if model_specific_name:
        for name, obj in inspect.getmembers(sniffer_tools.model_specific):
            if inspect.isclass(obj):
                if name == model_specific_name:
                    cls_list = cls_list + ',' + name

    return cls_list.strip(',')

if __name__ == '__main__':
    obj=sniffer_cmd(tool_name="Tcpdump",model_specific_name="Wcs")
    obj.test_tcpdump()
    obj.set_channel()
    obj=sniffer_cmd(tool_name="Tcpdump",model_specific_name="Intel8260")
    obj.test_tcpdump()
    obj.set_channel()
    obj=sniffer_cmd(tool_name="Omnipeek",model_specific_name="Wcs")
    obj.test_omnipeek()
    obj.set_channel()
    obj=sniffer_cmd(tool_name="Omnipeek",model_specific_name="Intel8260")
    obj.test_omnipeek()
    obj.set_channel()
    obj=sniffer_cmd(tool_name="Wireshark",model_specific_name="Wcs")
    obj.test_wireshark()
    obj.set_channel()
    obj=sniffer_cmd(tool_name="Wireshark",model_specific_name="Intel8260")
    obj.test_wireshark()
    obj.set_channel()
    obj=sniffer_cmd(tool_name="Tcpdump")
    obj.test_tcpdump()
    obj=sniffer_cmd(tool_name="Omnipeek")
    obj.test_omnipeek()
    obj=sniffer_cmd(tool_name="Wireshark")
    obj.test_wireshark()


