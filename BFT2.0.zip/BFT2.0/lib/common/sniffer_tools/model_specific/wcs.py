

class Wcs:


    def __init__(self):
        pass


    def set_channel(self):
        print("channel is set for wcs chipset, model_specific")
