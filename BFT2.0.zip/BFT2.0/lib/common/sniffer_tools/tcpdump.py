

class Tcpdump:
    """This class will provide handle for tcpdump sniffer apis """


    def __init__(self):
        pass

    def test_func(self):
        print("method inside in this class %s" % self.__class__.__name__)

    def test_tcpdump(self):
        print("tcpdump tested")

if __name__ == "__main__":
    obj = Tcpdump()
    obj.test_func()
