

class Omnipeek:
    """This class will provide handle for omnipeek sniffer apis """


    def __init__(self):
        pass

    def test_func(self):
        print("method inside in this class %s" % self.__class__.__name__)

    def test_omnipeek(self):
        print("omnipeek tested")

if __name__ == "__main__":
    obj = Omnipeek()
    obj.test_func()
