

class Wireshark:
    """This class will provide handle for wireshark sniffer apis """


    def __init__(self):
        pass

    def test_func(self):
        print("method inside in this class %s" % self.__class__.__name__)

    def test_wireshark(self):
        print("wireshark tested")

if __name__ == "__main__":
    obj = Wireshark()
    obj.test_func()
