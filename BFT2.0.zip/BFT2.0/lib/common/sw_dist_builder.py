import os
import sys
import inspect
import re
import sw_dist
from sw_dist import *
import sw_dist.rdkb
from sw_dist.rdkb import *
import sw_dist.ugw
from sw_dist.ugw import *
from log_creator import loggerObject as logger


def swdist_method_builder(cls):
    def config_update(self, os, session, prompt, device_dict=None,
                      dname=None, logger=logger):
        self.os = os
        self.session = session
        self.prompt = prompt
        self.dict = device_dict
        self.dname = dname
        self.logger = logger
    config_update.__name__ = "config_update"
    setattr(cls,config_update.__name__,config_update)


def swdist_cmd(sw_dist_name="",model_specific_name=""):
    swdist_class_list = swdist_list_builder(sw_dist_name, model_specific_name)
    exec ('class SwdistCmdHolder(' + swdist_class_list + '): pass')
    swdist_method_builder(SwdistCmdHolder)
    return SwdistCmdHolder()


def swdist_list_builder(sw_dist_name,model_specific_name):
    '''Return string of classes in sniffer_tool and model_specific'''
    cls_list=''
    mdl_name = re.match(r'([A-Za-z]*)', model_specific_name).group(1)
    cls_name = sw_dist_name.capitalize() + mdl_name.capitalize()
    if sw_dist_name.lower() == "owrt":
        for name, obj in inspect.getmembers(sw_dist):
            if inspect.isclass(obj):
                cls_list = cls_list + ',' + obj.__name__
    elif sw_dist_name.lower() == "rdkb":
        for name, obj in inspect.getmembers(sw_dist.rdkb):
            if inspect.isclass(obj):
                if name == cls_name:
                    cls_list = cls_list + ',' + obj.__name__
    elif sw_dist_name.lower() == "ugw":
        for name, obj in inspect.getmembers(sw_dist.ugw):
            if inspect.isclass(obj):
                if name == cls_name:
                    cls_list = cls_list + ',' + obj.__name__

    return cls_list.strip(',')

if __name__ == '__main__':
    obj=swdist_cmd(sw_dist_name="owrt",model_specific_name="GRX550")
    obj.test_func()
    obj=swdist_cmd(sw_dist_name="owrt",model_specific_name="VRX288")
    obj.test_func()
    obj=swdist_cmd(sw_dist_name="rdkb",model_specific_name="GRX550")
    obj.test_func_grx()
    obj=swdist_cmd(sw_dist_name="rdkb",model_specific_name="VRX288")
    obj.test_func_vrx()
    obj=swdist_cmd(sw_dist_name="ugw",model_specific_name="GRX550")
    obj.test_func_grx()
    obj=swdist_cmd(sw_dist_name="ugw",model_specific_name="VRX288")
    obj.test_func_vrx()
    obj=swdist_cmd(sw_dist_name="rdkb",model_specific_name="GRX550")
    obj.test_func()
    obj=swdist_cmd(sw_dist_name="rdkb",model_specific_name="VRX288")
    obj.test_func()
    obj=swdist_cmd(sw_dist_name="ugw",model_specific_name="GRX550")
    obj.test_func()
    obj=swdist_cmd(sw_dist_name="ugw",model_specific_name="VRX288")
    obj.test_func()
